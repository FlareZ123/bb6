import ZipAuditCore

set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace BB6.Agent1Raw139E0OneRDLate
open BB6Coverage BB6Coverage.Agent31Pump BB6Coverage.Agent50Zipper
open BB6Coverage.Agent10ZipAudit BB6.Agent13BlankDelay BB6.Agent50TNFPilot BB6.Agent31ThreeHole

def p : PartialMachine := FAR.fromCodes [7,6,11,22,14,19,2,16,15,11,24,0]
def O (n : Nat) : List Bool := rep [true] n
def P (n : Nat) : List Bool := rep [false,true,true] n
@[simp] theorem O_zero : O 0 = [] := rfl
@[simp] theorem O_succ (n : Nat) : O (n+1) = true :: O n := rfl
@[simp] theorem P_zero : P 0 = [] := rfl
@[simp] theorem P_succ (n : Nat) : P (n+1) = [false,true,true] ++ P n := rfl

theorem O_add (m n : Nat) : O (m+n) = O m ++ O n := by
  induction m with
  | zero => simp only [Nat.zero_add,O_zero,List.nil_append]
  | succ m ih => rw [Nat.succ_add, O_succ, O_succ, ih]; rfl

theorem O_twos (k : Nat) : O (2*k) = rep [true,true] k := by
  induction k with
  | zero => rfl
  | succ k ih => rw [Nat.mul_succ, Nat.add_comm (2*k) 2, O_add, ih]; rfl

theorem O_threes (k : Nat) : O (3*k) = rep [true,true,true] k := by
  induction k with
  | zero => rfl
  | succ k ih => rw [Nat.mul_succ, Nat.add_comm (3*k) 3, O_add, ih]; rfl

def B (R : List Bool) : Z0 := ⟨1,[],R⟩

theorem c_pair (L R : List Bool) :
    run0 p 2 ⟨2,[true]++L,[true,true]++R⟩ =
      some ⟨2,[true]++[true,true]++L,R⟩ := rfl

theorem scan_odd (k : Nat) (R : List Bool) :
    run0 p (2*k+1) (B (O (2*k+1)++R)) = some ⟨2,O (2*k+2),R⟩ := by
  have h1 : run0 p 1 (B (O (2*k+1)++R)) = some ⟨2,[true,true],O (2*k)++R⟩ := rfl
  have h2 := sweepR p 2 [true] [] [true,true] [true,true] 2 c_pair k [true] R
  rw [← O_twos] at h2
  have h2' : run0 p (2*k) ⟨2,[true,true],O (2*k)++R⟩ = some ⟨2,O (2*k+2),R⟩ := by
    rw [show 2*k+2=1+(2*k+1) by omega, O_add 1, O_add (2*k) 1]
    exact h2
  simpa only [Nat.add_comm 1 (2*k)] using join0 h1 h2'

theorem scan_even (k : Nat) (R : List Bool) (hR : R.headD false = false) :
    run0 p (2*k+3) (B (O (2*k+2)++R)) = some ⟨2,false::O (2*k+3),R.tail⟩ := by
  have h1 := scan_odd k (true::R)
  have h1' : run0 p (2*k+1) (B (O (2*k+2)++R)) = some ⟨2,O (2*k+2),true::R⟩ := by
    have he : O (2*k+2)++R = O (2*k+1)++true::R := by
      rw [show 2*k+2=2*k+1+1 by omega, O_add (2*k+1),List.append_assoc]; rfl
    rw [he]; exact h1
  have h2 : run0 p 2 ⟨2,O (2*k+2),true::R⟩ = some ⟨2,false::O (2*k+3),R.tail⟩ := by
    cases R with
    | nil => rfl
    | cons b R => cases b <;> simp_all <;> rfl
  simpa only [show 2*k+1+2=2*k+3 by omega] using join0 h1' h2

theorem back_one (L R : List Bool) :
    run0 p 3 ⟨2,[false,true]++[true]++L,R⟩ = some ⟨2,[false,true]++L,[true]++R⟩ := rfl

theorem back (n : Nat) (R : List Bool) :
    run0 p (3*n+5) ⟨2,false::O (n+1),R⟩ = some (B (O (n+3)++R)) := by
  have h1 := sweepL p 2 [false,true] [] [true] [true] 3 back_one n [] R
  have h1' : run0 p (3*n) ⟨2,false::O (n+1),R⟩ = some ⟨2,[false,true],O n++R⟩ := by
    rw [O_succ]
    simpa only [O, List.append_nil, List.nil_append, List.cons_append] using h1
  have h2 (S : List Bool) : run0 p 5 ⟨2,[false,true],S⟩ = some (B (O 3++S)) := rfl
  have h := join0 h1' (h2 (O n++R))
  have hout : O 3++(O n++R)=O (n+3)++R := by
    rw [show n+3=3+n by omega,O_add 3,List.append_assoc]
  simpa only [hout] using h

theorem even_blank (k : Nat) :
    run0 p (8*k+14) (B (O (2*k+2))) = some (B (O (2*k+5))) := by
  have h1 := scan_even k [] rfl
  have h2 := back (2*k+2) []
  have h := join0 h1 h2
  rw [show 8*k+14=2*k+3+(3*(2*k+2)+5) by omega]
  simpa only [List.append_nil] using h

theorem even_pattern (k : Nat) (R : List Bool) :
    run0 p (8*k+14) (B (O (2*k+2)++[false,true,true]++R)) =
      some (B (O (2*k+7)++R)) := by
  have h1 := scan_even k ([false,true,true]++R) rfl
  have h2 := back (2*k+2) ([true,true]++R)
  have h := join0 h1 h2
  have hout : O (2*k+2+3)++([true,true]++R) = O (2*k+7)++R := by
    rw [show 2*k+7=2*k+2+3+2 by omega,O_add (2*k+2+3),List.append_assoc]; rfl
  simpa only [hout,List.append_assoc,show 2*k+3+(3*(2*k+2)+5)=8*k+14 by omega] using h

theorem odd_pattern (k : Nat) (R : List Bool) :
    run0 p (8*k+16) (B (O (2*k+1)++[false,true,true]++R)) =
      some (B (O (2*k+6)++R)) := by
  have h1 := scan_odd k ([false,true,true]++R)
  have h2 : run0 p 4 ⟨2,O (2*k+2),[false,true,true]++R⟩ =
      some ⟨2,false::O (2*k+3),true::R⟩ := rfl
  have h3 := back (2*k+2) (true::R)
  have h := join0 (join0 h1 h2) h3
  have hout : O (2*k+2+3)++true::R = O (2*k+6)++R := by
    rw [show 2*k+6=2*k+2+3+1 by omega,O_add (2*k+2+3),List.append_assoc]; rfl
  simpa only [hout,List.append_assoc,show 2*k+1+4+(3*(2*k+2)+5)=8*k+16 by omega] using h

theorem odd_blank (k : Nat) :
    run0 p (2*k+4) (B (O (2*k+1))) = some ⟨0,O (2*k+3),[true]⟩ := by
  have h1 := scan_odd k []
  have h2 : run0 p 3 ⟨2,O (2*k+2),[]⟩ = some ⟨0,O (2*k+3),[true]⟩ := rfl
  simpa only [List.append_nil] using join0 h1 h2

theorem triple_one (L R : List Bool) :
    run0 p 3 ⟨0,[]++[true,true,true]++L,R⟩ = some ⟨0,L,[false,true,true]++R⟩ := rfl

theorem triple (k r : Nat) :
    run0 p (3*k) ⟨0,O (3*k+r),[true]⟩ = some ⟨0,O r,P k++[true]⟩ := by
  have h := sweepL p 0 [] [] [true,true,true] [false,true,true] 3 triple_one k (O r) [true]
  simpa only [O_add,O_threes,P,List.nil_append] using h

theorem rem0 (R : List Bool) :
    run0 p 18 ⟨0,[],P 2++R⟩ = some (B (O 8++R)) := rfl

theorem rem1 (R : List Bool) :
    run0 p 1 ⟨0,O 1,R⟩ = some (B (true::R)) := rfl

theorem rem2 (R : List Bool) :
    run0 p 2 ⟨0,O 2,R⟩ = some ⟨5,[],true::true::R⟩ := rfl

def cost (m : Nat) : Nat := 4*m+6+6*(m%2)
theorem contract (m : Nat) (R : List Bool) (hm : 0<m) :
    run0 p (cost m) (B (O m++[false,true,true]++R)) = some (B (O (m+5)++R)) := by
  by_cases he : m%2=0
  · obtain ⟨k,hk⟩ : ∃ k : Nat,m=2*k+2 := ⟨m/2-1,by omega⟩
    subst m
    have hc : cost (2*k+2)=8*k+14 := by unfold cost; omega
    rw [hc]
    exact even_pattern k R
  · obtain ⟨k,hk⟩ : ∃ k : Nat,m=2*k+1 := ⟨m/2,by omega⟩
    subst m
    have hc : cost (2*k+1)=8*k+16 := by unfold cost; omega
    rw [hc]
    exact odd_pattern k R

def drainCost (m : Nat) : Nat → Nat
  | 0 => 0
  | k+1 => cost m+drainCost (m+5) k

theorem drain (m k : Nat) (hm : 0<m) :
    run0 p (drainCost m k) (B (O m++(P k++[true]))) = some (B (O (m+5*k+1))) := by
  induction k generalizing m with
  | zero => simp only [drainCost,P_zero,List.append_nil,run0]; rw [show m+5*0+1=m+1 by omega,O_add]; rfl
  | succ k ih =>
    have h := join0 (contract m (P k++[true]) hm) (ih (m+5) (by omega))
    rw [drainCost,show m+5*(k+1)+1=m+5+5*k+1 by omega]
    simpa only [P_succ,List.append_assoc] using h

theorem oddReturn1 (k j : Nat) (he : 2*k+3=3*j+1) :
    run0 p (2*k+4+3*j+1+drainCost 1 j) (B (O (2*k+1))) = some (B (O (5*j+2))) := by
  have h1 := odd_blank k
  rw [he] at h1
  have h := join0 (join0 (join0 h1 (triple j 1)) (rem1 (P j++[true]))) (drain 1 j (by decide))
  simpa only [show 1+5*j+1=5*j+2 by omega] using h

theorem oddReturn0 (k j : Nat) (he : 2*k+3=3*(j+2)) :
    run0 p (2*k+4+3*(j+2)+18+drainCost 8 j) (B (O (2*k+1))) = some (B (O (5*j+9))) := by
  have h1 := odd_blank k
  rw [he] at h1
  have h2 := triple (j+2) 0
  have h2' : run0 p (3*(j+2)) ⟨0,O (3*(j+2)),[true]⟩ = some ⟨0,[],P 2++(P j++[true])⟩ := by
    simpa only [Nat.add_zero,O_zero,P_succ,P_zero,List.nil_append,List.append_assoc] using h2
  simpa only [show 8+5*j+1=5*j+9 by omega] using join0 (join0 (join0 h1 h2') (rem0 (P j++[true]))) (drain 8 j (by decide))

theorem oddFinal (k j : Nat) (he : 2*k+3=3*j+2) :
    run0 p (2*k+4+3*j+2) (B (O (2*k+1))) = some ⟨5,[],true::true::(P j++[true])⟩ := by
  have h1 := odd_blank k
  rw [he] at h1
  exact join0 (join0 h1 (triple j 2)) (rem2 (P j++[true]))


/-- The blank entry, checked against the literal partial table. -/
theorem prefix0 : run0 p 10 (project start) = some (B (O 4)) := rfl
theorem prefix1 : run0 p 32 (project start) = some (B (O 7)) := by
  have h := even_blank 1
  rw [show 8*1+14=22 by decide] at h
  have hjoin := join0 prefix0 h
  rw [show 10+22=32 by decide] at hjoin
  exact hjoin
theorem prefix2 : run0 p 107 (project start) = some (B (O 14)) := by
  have h := oddReturn0 3 1 (by decide)
  have hc : 6+4+3*(1+2)+18+drainCost 8 1 = 75 := by decide +kernel
  rw [hc] at h
  have hjoin := join0 prefix1 h
  rw [show 32+75=107 by decide] at hjoin
  exact hjoin
theorem prefix3 : run0 p 169 (project start) = some (B (O 17)) := by
  have h := even_blank 6
  rw [show 8*6+14=62 by decide] at h
  have hjoin := join0 prefix2 h
  rw [show 107+62=169 by decide] at hjoin
  exact hjoin
theorem prefix4 : run0 p 586 (project start) = some (B (O 32)) := by
  have h := oddReturn1 8 6 (by decide)
  have hc : 16+4+3*6+1+drainCost 1 6 = 417 := by decide +kernel
  rw [hc] at h
  have hjoin := join0 prefix3 h
  rw [show 169+417=586 by decide] at hjoin
  exact hjoin
theorem prefix5 : run0 p 720 (project start) = some (B (O 35)) := by
  have h := even_blank 15
  rw [show 8*15+14=134 by decide] at h
  have hjoin := join0 prefix4 h
  rw [show 586+134=720 by decide] at hjoin
  exact hjoin
theorem prefix6 : run0 p 2271 (project start) = some (B (O 62)) := by
  have h := oddReturn1 17 12 (by decide)
  have hc : 34+4+3*12+1+drainCost 1 12 = 1551 := by decide +kernel
  rw [hc] at h
  have hjoin := join0 prefix5 h
  rw [show 720+1551=2271 by decide] at hjoin
  exact hjoin
theorem prefix7 : run0 p 2525 (project start) = some (B (O 65)) := by
  have h := even_blank 30
  rw [show 8*30+14=254 by decide] at h
  have hjoin := join0 prefix6 h
  rw [show 2271+254=2525 by decide] at hjoin
  exact hjoin
theorem prefix8 : run0 p 7566 (project start) = some (B (O 112)) := by
  have h := oddReturn1 32 22 (by decide)
  have hc : 64+4+3*22+1+drainCost 1 22 = 5041 := by decide +kernel
  rw [hc] at h
  have hjoin := join0 prefix7 h
  rw [show 2525+5041=7566 by decide] at hjoin
  exact hjoin
theorem prefix9 : run0 p 8020 (project start) = some (B (O 115)) := by
  have h := even_blank 55
  rw [show 8*55+14=454 by decide] at h
  have hjoin := join0 prefix8 h
  rw [show 7566+454=8020 by decide] at hjoin
  exact hjoin
theorem prefix10 : run0 p 23107 (project start) = some (B (O 194)) := by
  have h := oddReturn0 57 37 (by decide)
  have hc : 114+4+3*(37+2)+18+drainCost 8 37 = 15087 := by decide +kernel
  rw [hc] at h
  have hjoin := join0 prefix9 h
  rw [show 8020+15087=23107 by decide] at hjoin
  exact hjoin
theorem prefix11 : run0 p 23889 (project start) = some (B (O 197)) := by
  have h := even_blank 96
  rw [show 8*96+14=782 by decide] at h
  have hjoin := join0 prefix10 h
  rw [show 23107+782=23889 by decide] at hjoin
  exact hjoin
theorem prefix12 : run0 p 68046 (project start) = some (B (O 332)) := by
  have h := oddReturn1 98 66 (by decide)
  have hc : 196+4+3*66+1+drainCost 1 66 = 44157 := by decide +kernel
  rw [hc] at h
  have hjoin := join0 prefix11 h
  rw [show 23889+44157=68046 by decide] at hjoin
  exact hjoin
theorem prefix13 : run0 p 69380 (project start) = some (B (O 335)) := by
  have h := even_blank 165
  rw [show 8*165+14=1334 by decide] at h
  have hjoin := join0 prefix12 h
  rw [show 68046+1334=69380 by decide] at hjoin
  exact hjoin
theorem prefix14 : run0 p 195831 (project start) = some (B (O 562)) := by
  have h := oddReturn1 167 112 (by decide)
  have hc : 334+4+3*112+1+drainCost 1 112 = 126451 := by decide +kernel
  rw [hc] at h
  have hjoin := join0 prefix13 h
  rw [show 69380+126451=195831 by decide] at hjoin
  exact hjoin
theorem prefix15 : run0 p 198085 (project start) = some (B (O 565)) := by
  have h := even_blank 280
  rw [show 8*280+14=2254 by decide] at h
  have hjoin := join0 prefix14 h
  rw [show 195831+2254=198085 by decide] at hjoin
  exact hjoin
theorem prefix16 : run0 p 554722 (project start) = some (B (O 944)) := by
  have h := oddReturn0 282 187 (by decide)
  have hc : 564+4+3*(187+2)+18+drainCost 8 187 = 356637 := by decide +kernel
  rw [hc] at h
  have hjoin := join0 prefix15 h
  rw [show 198085+356637=554722 by decide] at hjoin
  exact hjoin
theorem prefix17 : run0 p 558504 (project start) = some (B (O 947)) := by
  have h := even_blank 471
  rw [show 8*471+14=3782 by decide] at h
  have hjoin := join0 prefix16 h
  rw [show 554722+3782=558504 by decide] at hjoin
  exact hjoin
theorem prefix18 : run0 p 1559911 (project start) = some (B (O 1582)) := by
  have h := oddReturn1 473 316 (by decide)
  have hc : 946+4+3*316+1+drainCost 1 316 = 1001407 := by decide +kernel
  rw [hc] at h
  have hjoin := join0 prefix17 h
  rw [show 558504+1001407=1559911 by decide] at hjoin
  exact hjoin
theorem prefix19 : run0 p 1566245 (project start) = some (B (O 1585)) := by
  have h := even_blank 790
  rw [show 8*790+14=6334 by decide] at h
  have hjoin := join0 prefix18 h
  rw [show 1559911+6334=1566245 by decide] at hjoin
  exact hjoin
theorem prefix20 : run0 p 4363062 (project start) = some (B (O 2644)) := by
  have h := oddReturn0 792 527 (by decide)
  have hc : 1584+4+3*(527+2)+18+drainCost 8 527 = 2796817 := by decide +kernel
  rw [hc] at h
  have hjoin := join0 prefix19 h
  rw [show 1566245+2796817=4363062 by decide] at hjoin
  exact hjoin
theorem prefix21 : run0 p 4373644 (project start) = some (B (O 2647)) := by
  have h := even_blank 1321
  rw [show 8*1321+14=10582 by decide] at h
  have hjoin := join0 prefix20 h
  rw [show 4363062+10582=4373644 by decide] at hjoin
  exact hjoin
theorem prefix22 : run0 p 12167879 (project start) = some (B (O 4414)) := by
  have h := oddReturn0 1323 881 (by decide)
  have hc : 2646+4+3*(881+2)+18+drainCost 8 881 = 7794235 := by decide +kernel
  rw [hc] at h
  have hjoin := join0 prefix21 h
  rw [show 4373644+7794235=12167879 by decide] at hjoin
  exact hjoin
theorem prefix23 : run0 p 12185541 (project start) = some (B (O 4417)) := by
  have h := even_blank 2206
  rw [show 8*2206+14=17662 by decide] at h
  have hjoin := join0 prefix22 h
  rw [show 12167879+17662=12185541 by decide] at hjoin
  exact hjoin
theorem prefix24 : run0 p 33878406 (project start) = some (B (O 7364)) := by
  have h := oddReturn0 2208 1471 (by decide)
  have hc : 4416+4+3*(1471+2)+18+drainCost 8 1471 = 21692865 := by decide +kernel
  rw [hc] at h
  have hjoin := join0 prefix23 h
  rw [show 12185541+21692865=33878406 by decide] at hjoin
  exact hjoin
theorem prefix25 : run0 p 33907868 (project start) = some (B (O 7367)) := by
  have h := even_blank 3681
  rw [show 8*3681+14=29462 by decide] at h
  have hjoin := join0 prefix24 h
  rw [show 33878406+29462=33907868 by decide] at hjoin
  exact hjoin
theorem prefix26 : run0 p 94249335 (project start) = some (B (O 12282)) := by
  have h := oddReturn1 3683 2456 (by decide)
  have hc : 7366+4+3*2456+1+drainCost 1 2456 = 60341467 := by decide +kernel
  rw [hc] at h
  have hjoin := join0 prefix25 h
  rw [show 33907868+60341467=94249335 by decide] at hjoin
  exact hjoin
theorem prefix27 : run0 p 94298469 (project start) = some (B (O 12285)) := by
  have h := even_blank 6140
  rw [show 8*6140+14=49134 by decide] at h
  have hjoin := join0 prefix26 h
  rw [show 94249335+49134=94298469 by decide] at hjoin
  exact hjoin
theorem prefixFinal : run0 p 94323044 (project start) = some ⟨5,[],true::true::(P 4095++[true])⟩ := by
  have h := oddFinal 6142 4095 (by decide)
  rw [show 2*6142+4+3*4095+2 = 24575 by decide] at h
  have hjoin := join0 prefix27 h
  rw [show 94298469+24575=94323044 by decide] at hjoin
  exact hjoin

/-- The original zipper computation reaches the unknown F0 slot for the first time. -/
theorem first_query : zipRead p 94323044 = some (5,false) := by
  have h := (run_project p 94323044 start).trans prefixFinal
  unfold zipRead
  cases he : zrun p 94323044 start with
  | none => rw [he] at h; cases h
  | some z =>
    have h' : project z = ⟨5,[],true::true::(P 4095++[true])⟩ := by
      rw [he] at h; exact Option.some.inj h
    have hs : (z.q,z.l.headD false) = (5,false) := by
      change ((project z).q,(project z).l.headD false) = _
      rw [h']; rfl
    exact congrArg some hs

theorem noAssignedHalt : weightedTNFNoAssignedHalt p := by
  intro s; rcases s with ⟨q,b⟩; have hq : q.val < 6 := q.isLt
  have hcases : q = 0 ∨ q = 1 ∨ q = 2 ∨ q = 3 ∨ q = 4 ∨ q = 5 := by
    simp only [Fin.ext_iff]; omega
  rcases hcases with h|h|h|h|h|h <;> subst q <;> cases b <;> decide

theorem query : queryOK 94323050 p 94323044 (5,false) = true := by
  unfold queryOK
  rw [← zipRead_eq, first_query]
  decide

theorem weighted : Cover (WeightedBound 94323050) p := by
  apply Cover.leaf
  intro m hm
  exact (certified 94323050 p (.last 94323044 (5,false)) (by decide) noAssignedHalt
    (by simp only [check,query,Bool.true_and]; decide)).sound m hm

#print axioms first_query
#print axioms weighted
end BB6.Agent1Raw139E0OneRDLate
