import BlockFARBridge
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent1WideBlock
open BB6BlockFAR (Q Ray Move Table Prim cons tail blankRay primStep run run_add primBlank blank_cons)
structure Sym where
  b0 : Bool
  b1 : Bool
  b2 : Bool
  b3 : Bool
  b4 : Bool
  b5 : Bool
  b6 : Bool
  b7 : Bool
  deriving DecidableEq, Repr

def Sym.zero : Sym := ⟨false,false,false,false,false,false,false,false⟩

def Sym.code (s : Sym) : Nat := 1*s.b0.toNat + 2*s.b1.toNat + 4*s.b2.toNat + 8*s.b3.toNat + 16*s.b4.toNat + 32*s.b5.toNat + 64*s.b6.toNat + 128*s.b7.toNat

def Sym.ofCode (n : Nat) : Sym := ⟨n/1%2 == 1,n/2%2 == 1,n/4%2 == 1,n/8%2 == 1,n/16%2 == 1,n/32%2 == 1,n/64%2 == 1,n/128%2 == 1⟩

def symbols : List Sym := (List.range 256).map Sym.ofCode

theorem code_lt (s : Sym) : s.code < 256 := by
  have hb0 : s.b0.toNat ≤ 1 := by cases s.b0 <;> decide
  have hb1 : s.b1.toNat ≤ 1 := by cases s.b1 <;> decide
  have hb2 : s.b2.toNat ≤ 1 := by cases s.b2 <;> decide
  have hb3 : s.b3.toNat ≤ 1 := by cases s.b3 <;> decide
  have hb4 : s.b4.toNat ≤ 1 := by cases s.b4 <;> decide
  have hb5 : s.b5.toNat ≤ 1 := by cases s.b5 <;> decide
  have hb6 : s.b6.toNat ≤ 1 := by cases s.b6 <;> decide
  have hb7 : s.b7.toNat ≤ 1 := by cases s.b7 <;> decide
  unfold Sym.code
  omega

theorem ofCode_code (s : Sym) : Sym.ofCode s.code = s := by
  have hb0 : s.b0.toNat ≤ 1 := by cases s.b0 <;> decide
  have hb1 : s.b1.toNat ≤ 1 := by cases s.b1 <;> decide
  have hb2 : s.b2.toNat ≤ 1 := by cases s.b2 <;> decide
  have hb3 : s.b3.toNat ≤ 1 := by cases s.b3 <;> decide
  have hb4 : s.b4.toNat ≤ 1 := by cases s.b4 <;> decide
  have hb5 : s.b5.toNat ≤ 1 := by cases s.b5 <;> decide
  have hb6 : s.b6.toNat ≤ 1 := by cases s.b6 <;> decide
  have hb7 : s.b7.toNat ≤ 1 := by cases s.b7 <;> decide
  have h0 : (s.code / 1 % 2 == 1) = s.b0 := by
    have he : s.code / 1 % 2 = s.b0.toNat := by
      unfold Sym.code
      omega
    rw [he]
    cases s.b0 <;> rfl
  have h1 : (s.code / 2 % 2 == 1) = s.b1 := by
    have he : s.code / 2 % 2 = s.b1.toNat := by
      unfold Sym.code
      omega
    rw [he]
    cases s.b1 <;> rfl
  have h2 : (s.code / 4 % 2 == 1) = s.b2 := by
    have he : s.code / 4 % 2 = s.b2.toNat := by
      unfold Sym.code
      omega
    rw [he]
    cases s.b2 <;> rfl
  have h3 : (s.code / 8 % 2 == 1) = s.b3 := by
    have he : s.code / 8 % 2 = s.b3.toNat := by
      unfold Sym.code
      omega
    rw [he]
    cases s.b3 <;> rfl
  have h4 : (s.code / 16 % 2 == 1) = s.b4 := by
    have he : s.code / 16 % 2 = s.b4.toNat := by
      unfold Sym.code
      omega
    rw [he]
    cases s.b4 <;> rfl
  have h5 : (s.code / 32 % 2 == 1) = s.b5 := by
    have he : s.code / 32 % 2 = s.b5.toNat := by
      unfold Sym.code
      omega
    rw [he]
    cases s.b5 <;> rfl
  have h6 : (s.code / 64 % 2 == 1) = s.b6 := by
    have he : s.code / 64 % 2 = s.b6.toNat := by
      unfold Sym.code
      omega
    rw [he]
    cases s.b6 <;> rfl
  have h7 : (s.code / 128 % 2 == 1) = s.b7 := by
    have he : s.code / 128 % 2 = s.b7.toNat := by
      unfold Sym.code
      omega
    rw [he]
    cases s.b7 <;> rfl
  cases s
  simp only [Sym.ofCode,Sym.mk.injEq]
  exact ⟨h0,h1,h2,h3,h4,h5,h6,h7⟩

theorem symbols_complete (s : Sym) : s ∈ symbols := by
  exact List.mem_map.mpr ⟨s.code,List.mem_range.mpr (code_lt s),ofCode_code s⟩

inductive Pos where | p0 | p1 | p2 | p3 | p4 | p5 | p6 | p7
  deriving DecidableEq, Repr

def Sym.read (s : Sym) : Pos → Bool
  | .p0 => s.b0
  | .p1 => s.b1
  | .p2 => s.b2
  | .p3 => s.b3
  | .p4 => s.b4
  | .p5 => s.b5
  | .p6 => s.b6
  | .p7 => s.b7

def Sym.write (s : Sym) (p : Pos) (w : Bool) : Sym :=
  match p with
  | .p0 => ⟨w,s.b1,s.b2,s.b3,s.b4,s.b5,s.b6,s.b7⟩
  | .p1 => ⟨s.b0,w,s.b2,s.b3,s.b4,s.b5,s.b6,s.b7⟩
  | .p2 => ⟨s.b0,s.b1,w,s.b3,s.b4,s.b5,s.b6,s.b7⟩
  | .p3 => ⟨s.b0,s.b1,s.b2,w,s.b4,s.b5,s.b6,s.b7⟩
  | .p4 => ⟨s.b0,s.b1,s.b2,s.b3,w,s.b5,s.b6,s.b7⟩
  | .p5 => ⟨s.b0,s.b1,s.b2,s.b3,s.b4,w,s.b6,s.b7⟩
  | .p6 => ⟨s.b0,s.b1,s.b2,s.b3,s.b4,s.b5,w,s.b7⟩
  | .p7 => ⟨s.b0,s.b1,s.b2,s.b3,s.b4,s.b5,s.b6,w⟩

def leftRay : List Sym → Ray
  | [] => blankRay
  | a::r => cons a.b7 (cons a.b6 (cons a.b5 (cons a.b4 (cons a.b3 (cons a.b2 (cons a.b1 (cons a.b0 (leftRay r))))))))

def rightRay : List Sym → Ray
  | [] => blankRay
  | a::r => cons a.b0 (cons a.b1 (cons a.b2 (cons a.b3 (cons a.b4 (cons a.b5 (cons a.b6 (cons a.b7 (rightRay r))))))))

theorem leftRay_unfold (l : List Sym) :
    leftRay l = cons (l.headD Sym.zero).b7 (cons (l.headD Sym.zero).b6 (cons (l.headD Sym.zero).b5 (cons (l.headD Sym.zero).b4 (cons (l.headD Sym.zero).b3 (cons (l.headD Sym.zero).b2 (cons (l.headD Sym.zero).b1 (cons (l.headD Sym.zero).b0 (leftRay l.tail)))))))) := by
  cases l with
  | nil => simp [leftRay,Sym.zero,blank_cons]
  | cons a r => rfl

theorem rightRay_unfold (r : List Sym) :
    rightRay r = cons (r.headD Sym.zero).b0 (cons (r.headD Sym.zero).b1 (cons (r.headD Sym.zero).b2 (cons (r.headD Sym.zero).b3 (cons (r.headD Sym.zero).b4 (cons (r.headD Sym.zero).b5 (cons (r.headD Sym.zero).b6 (cons (r.headD Sym.zero).b7 (rightRay r.tail)))))))) := by
  cases r with
  | nil => simp [rightRay,Sym.zero,blank_cons]
  | cons a r => rfl

def render (q : Q) (p : Pos) (a : Sym) (l r : List Sym) : Prim :=
  match p with
  | .p0 => ⟨q,leftRay l,cons a.b0 (cons a.b1 (cons a.b2 (cons a.b3 (cons a.b4 (cons a.b5 (cons a.b6 (cons a.b7 (rightRay r))))))))⟩
  | .p1 => ⟨q,cons a.b0 (leftRay l),cons a.b1 (cons a.b2 (cons a.b3 (cons a.b4 (cons a.b5 (cons a.b6 (cons a.b7 (rightRay r)))))))⟩
  | .p2 => ⟨q,cons a.b1 (cons a.b0 (leftRay l)),cons a.b2 (cons a.b3 (cons a.b4 (cons a.b5 (cons a.b6 (cons a.b7 (rightRay r))))))⟩
  | .p3 => ⟨q,cons a.b2 (cons a.b1 (cons a.b0 (leftRay l))),cons a.b3 (cons a.b4 (cons a.b5 (cons a.b6 (cons a.b7 (rightRay r)))))⟩
  | .p4 => ⟨q,cons a.b3 (cons a.b2 (cons a.b1 (cons a.b0 (leftRay l)))),cons a.b4 (cons a.b5 (cons a.b6 (cons a.b7 (rightRay r))))⟩
  | .p5 => ⟨q,cons a.b4 (cons a.b3 (cons a.b2 (cons a.b1 (cons a.b0 (leftRay l))))),cons a.b5 (cons a.b6 (cons a.b7 (rightRay r)))⟩
  | .p6 => ⟨q,cons a.b5 (cons a.b4 (cons a.b3 (cons a.b2 (cons a.b1 (cons a.b0 (leftRay l)))))),cons a.b6 (cons a.b7 (rightRay r))⟩
  | .p7 => ⟨q,cons a.b6 (cons a.b5 (cons a.b4 (cons a.b3 (cons a.b2 (cons a.b1 (cons a.b0 (leftRay l))))))),cons a.b7 (rightRay r)⟩

structure BlockConfig where
  q : Q
  dir : Bool
  l : List Sym
  r : List Sym
abbrev EntryPos (dir : Bool) : Pos := if dir then .p0 else .p7

def BlockConfig.render (c : BlockConfig) : Prim :=
  BB6.Agent1WideBlock.render c.q (EntryPos c.dir) (c.r.headD Sym.zero) c.l c.r.tail

def BlockConfig.next (c : BlockConfig) (q : Q) (dir : Bool) (w : Sym) : BlockConfig :=
  if dir then ⟨q,true,w::c.l,c.r.tail⟩
  else ⟨q,false,c.l.tail,c.l.headD Sym.zero::w::c.r.tail⟩

structure Exit where
  steps : Nat
  q : Q
  dir : Bool
  w : Sym
  deriving DecidableEq, Repr

def macroRun (M : Table) : Nat → Q → Pos → Sym → Option Exit
  | 0,_,_,_ => none
  | fuel+1,q,p,a => do
    let mv ← M q (a.read p)
    let w := a.write p mv.write
    let more (p' : Pos) := (macroRun M fuel mv.next p' w).map fun e => {e with steps := e.steps+1}
    match p,mv.right with
    | .p0,false => return ⟨1,mv.next,false,w⟩
    | .p0,true => more .p1
    | .p1,false => more .p0
    | .p1,true => more .p2
    | .p2,false => more .p1
    | .p2,true => more .p3
    | .p3,false => more .p2
    | .p3,true => more .p4
    | .p4,false => more .p3
    | .p4,true => more .p5
    | .p5,false => more .p4
    | .p5,true => more .p6
    | .p6,false => more .p5
    | .p6,true => more .p7
    | .p7,false => more .p6
    | .p7,true => return ⟨1,mv.next,true,w⟩

def blockExit (M : Table) (q : Q) (dir : Bool) (a : Sym) : Option Exit :=
  macroRun M 12289 q (EntryPos dir) a

theorem macroRun_sound (M : Table) (fuel : Nat) (q : Q) (p : Pos) (a : Sym)
    (l r : List Sym) (e : Exit) (h : macroRun M fuel q p a = some e) :
    0 < e.steps ∧
    run M e.steps (render q p a l r) = some
      (render e.q (EntryPos e.dir)
        (if e.dir then r.headD Sym.zero else l.headD Sym.zero)
        (if e.dir then e.w::l else l.tail)
        (if e.dir then r.tail else e.w::r)) := by
  induction fuel generalizing q p a e with
  | zero => simp [macroRun] at h
  | succ fuel ih =>
    cases hm : M q (a.read p) with
    | none => simp [macroRun,hm] at h
    | some mv =>
      cases p <;> cases hd : mv.right <;>
        simp [macroRun,hm,hd,Option.map_eq_some_iff] at h <;>
        simp [Sym.read] at hm
      · subst e
        constructor
        · simp
        · simp [run,primStep,render,Sym.write,EntryPos,hm,hd]
          rw [leftRay_unfold l]
          cases l <;> simp [rightRay]
      · obtain ⟨e',he',rfl⟩ := h
        obtain ⟨hpos,hrun⟩ := ih mv.next .p1 (a.write .p0 mv.write) e' he'
        refine ⟨by simp,?_⟩
        simpa [run,primStep,render,Sym.write,hm,hd] using hrun
      · obtain ⟨e',he',rfl⟩ := h
        obtain ⟨hpos,hrun⟩ := ih mv.next .p0 (a.write .p1 mv.write) e' he'
        refine ⟨by simp,?_⟩
        simpa [run,primStep,render,Sym.write,hm,hd] using hrun
      · obtain ⟨e',he',rfl⟩ := h
        obtain ⟨hpos,hrun⟩ := ih mv.next .p2 (a.write .p1 mv.write) e' he'
        refine ⟨by simp,?_⟩
        simpa [run,primStep,render,Sym.write,hm,hd] using hrun
      · obtain ⟨e',he',rfl⟩ := h
        obtain ⟨hpos,hrun⟩ := ih mv.next .p1 (a.write .p2 mv.write) e' he'
        refine ⟨by simp,?_⟩
        simpa [run,primStep,render,Sym.write,hm,hd] using hrun
      · obtain ⟨e',he',rfl⟩ := h
        obtain ⟨hpos,hrun⟩ := ih mv.next .p3 (a.write .p2 mv.write) e' he'
        refine ⟨by simp,?_⟩
        simpa [run,primStep,render,Sym.write,hm,hd] using hrun
      · obtain ⟨e',he',rfl⟩ := h
        obtain ⟨hpos,hrun⟩ := ih mv.next .p2 (a.write .p3 mv.write) e' he'
        refine ⟨by simp,?_⟩
        simpa [run,primStep,render,Sym.write,hm,hd] using hrun
      · obtain ⟨e',he',rfl⟩ := h
        obtain ⟨hpos,hrun⟩ := ih mv.next .p4 (a.write .p3 mv.write) e' he'
        refine ⟨by simp,?_⟩
        simpa [run,primStep,render,Sym.write,hm,hd] using hrun
      · obtain ⟨e',he',rfl⟩ := h
        obtain ⟨hpos,hrun⟩ := ih mv.next .p3 (a.write .p4 mv.write) e' he'
        refine ⟨by simp,?_⟩
        simpa [run,primStep,render,Sym.write,hm,hd] using hrun
      · obtain ⟨e',he',rfl⟩ := h
        obtain ⟨hpos,hrun⟩ := ih mv.next .p5 (a.write .p4 mv.write) e' he'
        refine ⟨by simp,?_⟩
        simpa [run,primStep,render,Sym.write,hm,hd] using hrun
      · obtain ⟨e',he',rfl⟩ := h
        obtain ⟨hpos,hrun⟩ := ih mv.next .p4 (a.write .p5 mv.write) e' he'
        refine ⟨by simp,?_⟩
        simpa [run,primStep,render,Sym.write,hm,hd] using hrun
      · obtain ⟨e',he',rfl⟩ := h
        obtain ⟨hpos,hrun⟩ := ih mv.next .p6 (a.write .p5 mv.write) e' he'
        refine ⟨by simp,?_⟩
        simpa [run,primStep,render,Sym.write,hm,hd] using hrun
      · obtain ⟨e',he',rfl⟩ := h
        obtain ⟨hpos,hrun⟩ := ih mv.next .p5 (a.write .p6 mv.write) e' he'
        refine ⟨by simp,?_⟩
        simpa [run,primStep,render,Sym.write,hm,hd] using hrun
      · obtain ⟨e',he',rfl⟩ := h
        obtain ⟨hpos,hrun⟩ := ih mv.next .p7 (a.write .p6 mv.write) e' he'
        refine ⟨by simp,?_⟩
        simpa [run,primStep,render,Sym.write,hm,hd] using hrun
      · obtain ⟨e',he',rfl⟩ := h
        obtain ⟨hpos,hrun⟩ := ih mv.next .p6 (a.write .p7 mv.write) e' he'
        refine ⟨by simp,?_⟩
        simpa [run,primStep,render,Sym.write,hm,hd] using hrun
      · subst e
        constructor
        · simp
        · simp [run,primStep,render,Sym.write,EntryPos,hm,hd,leftRay]
          rw [rightRay_unfold r]
          cases r <;> rfl

theorem macro_sound (M : Table) (c : BlockConfig) (e : Exit)
    (h : blockExit M c.q c.dir (c.r.headD Sym.zero) = some e) :
    0 < e.steps ∧ run M e.steps c.render = some (c.next e.q e.dir e.w).render := by
  have h' := macroRun_sound M 12289 c.q (EntryPos c.dir) (c.r.headD Sym.zero) c.l c.r.tail e h
  refine ⟨h'.1,?_⟩
  cases hd : e.dir <;> simpa [BlockConfig.render,BlockConfig.next,hd] using h'.2

def blockBlank : BlockConfig := ⟨0,true,[],[]⟩
theorem render_blank : blockBlank.render = primBlank := by
  simp [blockBlank,BlockConfig.render,primBlank,EntryPos,render,leftRay,rightRay,Sym.zero,blank_cons]

theorem forever_of_invariant (M : Table) (P : BlockConfig → Prop)
    (closed : ∀ c, P c → ∃ e, blockExit M c.q c.dir (c.r.headD Sym.zero) = some e ∧ P (c.next e.q e.dir e.w))
    (c : BlockConfig) (hc : P c) : ∀ n, ∃ d, run M n c.render = some d := by
  intro n
  induction n using Nat.strongRecOn generalizing c with
  | ind n ih =>
    obtain ⟨e,he,hnext⟩ := closed c hc
    obtain ⟨hpos,hrun⟩ := macro_sound M c e he
    by_cases hle : e.steps ≤ n
    · obtain ⟨d,hd⟩ := ih (n-e.steps) (by omega) _ hnext
      refine ⟨d,?_⟩
      rw [show n=e.steps+(n-e.steps) by omega,run_add,hrun]
      exact hd
    · have hrun' := hrun
      rw [show e.steps=n+(e.steps-n) by omega,run_add] at hrun'
      cases hh : run M n c.render with
      | none => simp [hh] at hrun'
      | some d => exact ⟨d,rfl⟩

#print axioms macroRun_sound
#print axioms forever_of_invariant
end BB6.Agent1WideBlock
