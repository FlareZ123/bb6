import WideBlock
import FastThreeHoleAudit
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent1WideBlock
open BB6BlockFAR (Q Table Prim run primBlank LState Node finCode)

def activeLookup {α : Type} (key : Nat) : List (Nat × α) → Option α
  | [] => none
  | (k,v)::r => if k = key then some v else activeLookup key r

theorem activeLookup_mem {α : Type} {key : Nat} {rows : List (Nat × α)} {v : α}
    (h : activeLookup key rows = some v) : (key,v) ∈ rows := by
  induction rows with
  | nil => simp [activeLookup] at h
  | cons hd tl ih =>
    rcases hd with ⟨k,w⟩
    by_cases hk : k = key
    · subst k
      simp [activeLookup] at h
      subst w
      exact List.mem_cons_self
    · simp [activeLookup,hk] at h
      exact List.mem_cons_of_mem _ (ih h)

structure ActiveData (d n : Nat) where
  start : LState d
  pushRows : Nat → List (Nat × Nat)
  controlCodes : Nat → Nat
  auxiliaryCodes : Nat → Nat
  predecessorCodes : Nat → List Nat
  edgeRows : Nat → List (Nat × List Nat)
  zeroCodes : Nat
  zeroNextCodes : Nat → Nat

def ActiveData.push {d n} (C : ActiveData d n) (l : LState d) (a : Sym) : Option (LState d) :=
  match (activeLookup a.code (C.pushRows l.val)).getD 0 with
  | 0 => none
  | j+1 => some (finCode d j)
def ActiveData.control {d n} (C : ActiveData d n) (l : LState d) (q : Q) (dir : Bool) : Node n :=
  finCode n (C.controlCodes (12*l.val+2*q.val+dir.toNat))
def ActiveData.auxiliary {d n} (C : ActiveData d n) (l : LState d) (q : Q) (b : Sym) : Node n :=
  finCode n (C.auxiliaryCodes (1536*l.val+256*q.val+b.code))
def ActiveData.predecessors {d n} (C : ActiveData d n) (l : LState d) : List (LState d × Sym) :=
  (C.predecessorCodes l.val).map fun x => (finCode d (x/256),Sym.ofCode (x%256))
def ActiveData.targets {d n} (C : ActiveData d n) (v : Node n) (a : Sym) : List (Node n) :=
  ((activeLookup a.code (C.edgeRows v.val)).getD []).map (finCode n)
def ActiveData.zero {d n} (C : ActiveData d n) (v : Node n) : Bool := C.zeroCodes.testBit v.val
def ActiveData.zeroNext {d n} (C : ActiveData d n) (v : Node n) : Node n := finCode n (C.zeroNextCodes v.val)
def ActiveData.leftVal {d n} (C : ActiveData d n) : List Sym → Option (LState d)
  | [] => some C.start
  | a::r => (C.leftVal r).bind (fun l => C.push l a)
def ActiveData.accept {d n} (C : ActiveData d n) : List Sym → Node n → Prop
  | [],v => C.zero v = true
  | a::r,v => ∃ t ∈ C.targets v a, C.accept r t
def ActiveData.zeroCheck {d n} (C : ActiveData d n) (v : Node n) : Bool :=
  if C.zero v then C.zero (C.zeroNext v) && decide (C.zeroNext v ∈ C.targets v Sym.zero) else true
def ActiveData.baseCheck {d n} (C : ActiveData d n) : Bool :=
  decide (C.push C.start Sym.zero = some C.start) &&
    C.zero (C.control C.start 0 true) && (List.finRange (n+1)).all C.zeroCheck
def ActiveData.predCheckAt {d n} (C : ActiveData d n) (l : LState d) (b : Sym) : Bool :=
  match C.push l b with
  | none => true
  | some j => decide ((l,b) ∈ C.predecessors j)
def ActiveData.fastPredAt {d n} (C : ActiveData d n) (l : LState d) : Bool :=
  (C.pushRows l.val).all fun e => C.predCheckAt l (Sym.ofCode e.1)
theorem ActiveData.fastPredAt_sound {d n} (C : ActiveData d n) (l : LState d)
    (h : C.fastPredAt l = true) (a : Sym) : C.predCheckAt l a = true := by
  cases he : activeLookup a.code (C.pushRows l.val) with
  | none => simp [ActiveData.predCheckAt,ActiveData.push,he]
  | some v =>
    have hh := List.all_eq_true.mp h (a.code,v) (activeLookup_mem he)
    simpa only [ofCode_code] using hh

def ActiveData.fastInclusion {d n} (C : ActiveData d n) (v p : Node n) : Bool :=
  (!C.zero v || C.zero p) &&
    (C.edgeRows v.val).all fun e =>
      (C.targets v (Sym.ofCode e.1)).all fun t => decide (t ∈ C.targets p (Sym.ofCode e.1))
theorem ActiveData.inclusion_sound {d n} (C : ActiveData d n) (v p : Node n)
    (h : C.fastInclusion v p = true) (r : List Sym) (hr : C.accept r v) : C.accept r p := by
  simp only [ActiveData.fastInclusion,Bool.and_eq_true,Bool.or_eq_true] at h
  cases r with
  | nil =>
    rcases h.1 with hv|hp
    · have h' : C.zero v = true := hr
      simp [h'] at hv
    · exact hp
  | cons a r =>
    obtain ⟨t,ht,hrest⟩ := hr
    cases he : activeLookup a.code (C.edgeRows v.val) with
    | none => simp [ActiveData.targets,he] at ht
    | some ts =>
      have hh := List.all_eq_true.mp h.2 (a.code,ts) (activeLookup_mem he)
      rw [ofCode_code] at hh
      exact ⟨t,of_decide_eq_true (List.all_eq_true.mp hh t ht),hrest⟩

def ActiveData.leftCheck {d n} (C : ActiveData d n) (p : Node n) (a : Sym) (e : Exit)
    (pre : LState d × Sym) : Bool :=
  let (l,b) := pre
  let u := C.auxiliary l e.q b
  decide (u ∈ C.targets (C.control l e.q false) b) &&
    (C.targets p a).all fun v => decide (v ∈ C.targets u e.w)
def ActiveData.fastRow {d n} (C : ActiveData d n) (M : Table) (l : LState d) (q : Q) (dir : Bool) (a : Sym) : Bool :=
  let p := C.control l q dir
  if (C.targets p a).isEmpty then true else
  match blockExit M q dir a with
  | none => false
  | some e =>
    if e.dir then
      match C.push l e.w with
      | none => false
      | some j => (C.targets p a).all fun v => C.fastInclusion v (C.control j e.q true)
    else (C.predecessors l).all (C.leftCheck p a e)
def ActiveData.fastRowsAt {d n} (C : ActiveData d n) (M : Table) (l : LState d) : Bool :=
  (List.finRange 6).all fun q => [false,true].all fun dir =>
    (C.edgeRows (C.control l q dir).val).all fun e => C.fastRow M l q dir (Sym.ofCode e.1)
theorem ActiveData.fastRowsAt_sound {d n} (C : ActiveData d n) (M : Table) (l : LState d)
    (h : C.fastRowsAt M l = true) (q : Q) (dir : Bool) (a : Sym) : C.fastRow M l q dir a = true := by
  have h := List.all_eq_true.mp (List.all_eq_true.mp h q (List.mem_finRange q)) dir (by cases dir <;> simp)
  cases he : activeLookup a.code (C.edgeRows (C.control l q dir).val) with
  | none => simp [ActiveData.fastRow,ActiveData.targets,he]
  | some ts =>
    have hh := List.all_eq_true.mp h (a.code,ts) (activeLookup_mem he)
    simpa only [ofCode_code] using hh

def ActiveData.Valid {d n} (C : ActiveData d n) (M : Table) : Prop :=
  C.baseCheck = true ∧ (List.finRange (d+1)).all C.fastPredAt = true ∧ (List.finRange (d+1)).all (C.fastRowsAt M) = true

theorem ActiveData.leftVal_pop {d n} (C : ActiveData d n) (hzero : C.push C.start Sym.zero = some C.start)
    (r : List Sym) (l : LState d) (h : C.leftVal r = some l) :
    ∃ j, C.leftVal r.tail = some j ∧ C.push j (r.headD Sym.zero) = some l := by
  cases r with
  | nil =>
    simp [ActiveData.leftVal] at h
    subst l
    exact ⟨C.start,rfl,hzero⟩
  | cons a r =>
    simp only [ActiveData.leftVal] at h
    cases hj : C.leftVal r with
    | none => simp [hj] at h
    | some j => exact ⟨j,hj,by simpa [hj] using h⟩

theorem ActiveData.accept_pop {d n} (C : ActiveData d n) (hzero : ∀ v, C.zeroCheck v = true)
    (r : List Sym) (v : Node n) (h : C.accept r v) :
    ∃ t ∈ C.targets v (r.headD Sym.zero), C.accept r.tail t := by
  cases r with
  | cons a r => exact h
  | nil =>
    have hz : C.zero v = true := h
    have H := hzero v
    simp [ActiveData.zeroCheck,hz] at H
    exact ⟨C.zeroNext v,H.2,H.1⟩

def ActiveData.Invariant {d n} (C : ActiveData d n) (c : BlockConfig) : Prop :=
  ∃ l, C.leftVal c.l = some l ∧ C.accept c.r (C.control l c.q c.dir)
theorem ActiveData.blank_invariant {d n} (C : ActiveData d n) (h : C.baseCheck = true) : C.Invariant blockBlank := by
  simp only [ActiveData.baseCheck,Bool.and_eq_true,decide_eq_true_eq] at h
  exact ⟨C.start,rfl,h.1.2⟩
theorem ActiveData.closed {d n} (C : ActiveData d n) (M : Table) (h : C.Valid M)
    (c : BlockConfig) (hc : C.Invariant c) :
    ∃ e, blockExit M c.q c.dir (c.r.headD Sym.zero) = some e ∧ C.Invariant (c.next e.q e.dir e.w) := by
  obtain ⟨l,hl,hr⟩ := hc
  have hb := h.1
  simp only [ActiveData.baseCheck,Bool.and_eq_true,decide_eq_true_eq] at hb
  have hz (v : Node n) : C.zeroCheck v = true := List.all_eq_true.mp hb.2 v (List.mem_finRange v)
  obtain ⟨v,hv,hrest⟩ := C.accept_pop hz c.r _ hr
  let a := c.r.headD Sym.zero
  let p := C.control l c.q c.dir
  have H := C.fastRowsAt_sound M l (List.all_eq_true.mp h.2.2 l (List.mem_finRange l)) c.q c.dir a
  have hn : (C.targets p a).isEmpty = false := by
    cases hh : C.targets p a with
    | nil => change v ∈ C.targets p a at hv; simp [hh] at hv
    | cons x xs => rfl
  unfold ActiveData.fastRow at H
  change (if (C.targets p a).isEmpty then true else _) = true at H
  rw [hn] at H
  simp only [Bool.false_eq_true,ite_false] at H
  cases he : blockExit M c.q c.dir a with
  | none => simp [he] at H
  | some e =>
    refine ⟨e,rfl,?_⟩
    rw [he] at H
    cases hed : e.dir with
    | true =>
      simp only [hed,ite_true] at H
      cases hj : C.push l e.w with
      | none => simp [hj] at H
      | some j =>
        rw [hj] at H
        have hi := List.all_eq_true.mp H v hv
        refine ⟨j,?_,?_⟩
        · simp [BlockConfig.next,ActiveData.leftVal,hl,hj]
        · exact C.inclusion_sound v (C.control j e.q true) hi c.r.tail hrest
    | false =>
      simp only [hed,Bool.false_eq_true,ite_false] at H
      obtain ⟨j,hj,hpush⟩ := C.leftVal_pop hb.1.1 c.l l hl
      have hp := C.fastPredAt_sound j (List.all_eq_true.mp h.2.1 j (List.mem_finRange j)) (c.l.headD Sym.zero)
      unfold ActiveData.predCheckAt at hp
      rw [hpush] at hp
      have hmem := of_decide_eq_true hp
      have hh := List.all_eq_true.mp H (j,c.l.headD Sym.zero) hmem
      simp only [ActiveData.leftCheck,Bool.and_eq_true,decide_eq_true_eq] at hh
      refine ⟨j,?_,?_⟩
      · simpa [BlockConfig.next,hed] using hj
      · change C.accept (c.l.headD Sym.zero::e.w::c.r.tail) (C.control j e.q false)
        exact ⟨_,hh.1,v,of_decide_eq_true (List.all_eq_true.mp hh.2 v hv),hrest⟩

theorem ActiveData.sound {d n} (C : ActiveData d n) (M : Table) (h : C.Valid M) :
    ∀ k, ∃ c, run M k primBlank = some c := by
  rw [← render_blank]
  exact forever_of_invariant M C.Invariant (C.closed M h) blockBlank (C.blank_invariant h.1)

def rangeCheck (d : Nat) (f : Fin (d+1) → Bool) (lo len : Nat) : Bool :=
  (List.range' lo len).all (fun i => f (finCode d i))
theorem rangeCheck_join (d : Nat) (f : Fin (d+1) → Bool) (lo m n : Nat)
    (h1 : rangeCheck d f lo m = true) (h2 : rangeCheck d f (lo+m) n = true) :
    rangeCheck d f lo (m+n) = true := by
  unfold rangeCheck at h1 h2 ⊢
  rw [← List.range'_append,List.all_append,h1,Nat.one_mul,h2]
  rfl
theorem rangeCheck_full (d : Nat) (f : Fin (d+1) → Bool)
    (h : rangeCheck d f 0 (d+1) = true) : (List.finRange (d+1)).all f = true := by
  apply List.all_eq_true.mpr
  intro l _
  have hm : l.val ∈ List.range' 0 (d+1) := by simp [List.mem_range',l.isLt]
  have he : finCode d l.val = l := Fin.ext (Nat.mod_eq_of_lt l.isLt)
  simpa only [he] using List.all_eq_true.mp h l.val hm
#print axioms ActiveData.sound
end BB6.Agent1WideBlock
