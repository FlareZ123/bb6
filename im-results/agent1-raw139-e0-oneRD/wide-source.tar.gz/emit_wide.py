from widegraph import generate
from collections import defaultdict,deque,Counter
from pathlib import Path
T=[7,8,11,3,14,5,22,16,15,11,24,0]
left,nodes,delta,edges,moves=generate(T,8,1,2,3,True,100000,True)
print('raw',len(left),len(nodes),sum(map(len,edges.values())))
zero={0};rev=defaultdict(list)
for s,es in edges.items():
    for a,t in es:
        if a==0:rev[t].append(s)
zq=deque(zero)
while zq:
    for s in rev[zq.popleft()]:
        if s not in zero:zero.add(s);zq.append(s)
D,N=len(left),len(nodes)
rows=defaultdict(lambda: defaultdict(set))
for s,es in edges.items():
    for a,t in es:rows[s][a].add(t)
cls=[int(s in zero) for s in range(N)]
while True:
    keys={};new=[]
    for s in range(N):
        k=(s in zero,tuple((a,tuple(sorted({cls[t] for t in ts}))) for a,ts in sorted(rows[s].items())))
        new.append(keys.setdefault(k,len(keys)))
    if new==cls:break
    cls=new
dead=len(set(cls));C=dead+1
r2=defaultdict(set);z2={cls[s] for s in zero}
for s,es in rows.items():
    for a,ts in es.items():r2[cls[s],a].update(cls[t] for t in ts)
ctr={tuple(rest):cls[i] for i,(k,*rest) in enumerate(nodes) if k=='c'}
aux={}
for i,(k,*rest) in enumerate(nodes):
    if k=='x':
        p,b=rest;_,l,q,d=nodes[p];aux[l,q,d,b]=cls[i]
# Do not merge the left DFA, to retain the exact generated predecessor support.
pred=defaultdict(list)
for (l,a),j in sorted(delta.items()):pred[j].append(256*l+a)
assert delta[0,0]==0 and ctr[0,0,1] in z2
zeroNext={s:min(r2[s,0]&z2) for s in z2}
print('minimized right',D,C,'edges',sum(map(len,r2.values())),'zero',len(z2),'active controls',len(ctr))
A=256;K=256
push,ctrl,auxr,edge=(defaultdict(list) for _ in range(4))
for (l,a),j in sorted(delta.items()):push[l].append((a,j+1))
for (l,q,d),v in sorted(ctr.items()):ctrl[l].append((2*q+d,v+1))
for (l,q,d,b),v in sorted(aux.items()):
    assert d==0;auxr[6*l+q].append((b,v+1))
for (s,a),ts in sorted(r2.items()):
    if ts:edge[s].append((a,sorted(ts)))
# All codes use positive sentinels; unpacking checks exact finite data in Lean.
def pack(xs,bits):
    assert all(0<=x<(1<<bits) for x in xs)
    return sum(x<<(bits*i) for i,x in enumerate(xs))
def emit_lookup(name,mapping,default=0):
    stride=16;groups=defaultdict(dict)
    for key,val in mapping.items():
        if val!=default:groups[key//stride][key%stride]=val
    values=[]
    for key,vs in sorted(groups.items()):
        bits=max(1,default.bit_length(),*(v.bit_length() for v in vs.values()))
        code=pack([vs.get(j,default) for j in range(stride)],bits)
        values.append((key,f'({bits},{hex(code)})'))
    db=max(1,default.bit_length());fallback=f'({db},{hex(pack([default]*stride,db))})'
    def tree(xs):
        if not xs:return fallback
        if len(xs)==1:
            k,v=xs[0];return f'if i = {k} then {v} else {fallback}'
        k=len(xs)//2
        return f'if i < {xs[k][0]} then ({tree(xs[:k])}) else ({tree(xs[k:])})'
    return (f'def {name}Chunks (i : Nat) : Nat × Nat := '+tree(values)+'\n'+f'def {name} (i : Nat) : Nat := let p := {name}Chunks (i/{stride}); (p.2 >>> (p.1*(i%{stride}))) % (2^p.1)\n')
pairbits=8+max(D,C+1).bit_length()+1;tbits=C.bit_length();max_t=max(1,max(len(ts) for vs in edge.values() for _,ts in vs));ebits=8+tbits*max_t+1;pbits=(A*D).bit_length();pfuel=max(1,max(map(len,pred.values())))
def kv(m):return {i:pack([key+K*v+1 for key,v in vs],pairbits) for i,vs in m.items()}
em={i:pack([1+a+A*pack([t+1 for t in ts],tbits) for a,ts in vs],ebits) for i,vs in edge.items()}
pm={i:pack([v+1 for v in vs],pbits) for i,vs in pred.items() if vs}
name='E0OneRD4267';ns='BB6.Agent1WideBlock.'+name
s=f'import WideSparse\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\nnamespace {ns}\nopen BB6BlockFAR (Table Move)\n'
s+='def machine : Table := fun q b => (['+','.join('none' if v is None else f'some ⟨{str(bool(v[0])).lower()},{str(bool(v[1])).lower()},{v[2]}⟩' for v in moves)+'] : List (Option Move))[2*q.val+b.toNat]?.getD none\n'
s+='''def unpack : Nat → Nat → Nat → List Nat
  | 0,_,_ => []
  | k+1,b,x =>
    let y := x % (2^b)
    if y=0 then [] else (y-1)::unpack k b (x >>> b)
def pairs (fuel bits code : Nat) : List (Nat × Nat) :=
  (unpack fuel bits code).map fun x => (x%256,x/256)
'''
for field,mapping,default in [('pushData',kv(push),0),('ctrlData',kv(ctrl),0),('auxData',kv(auxr),0),('predData',pm,0),('edgeData',em,0),('zeroNextCodes',zeroNext,dead)]:s+=emit_lookup(field,mapping,default)
s+=f'''def pushRows (l : Nat) : List (Nat × Nat) := pairs {A} {pairbits} (pushData l)
def controlCodes (i : Nat) : Nat := ((activeLookup (i%12) (pairs 12 {pairbits} (ctrlData (i/12)))).getD {dead+1}).pred
def auxiliaryCodes (i : Nat) : Nat := ((activeLookup (i%{A}) (pairs {A} {pairbits} (auxData (i/{A})))).getD {dead+1}).pred
def predecessorCodes (l : Nat) : List Nat := unpack {pfuel} {pbits} (predData l)
def edgeRows (v : Nat) : List (Nat × List Nat) := (unpack {A} {ebits} (edgeData v)).map fun x => (x%{A},unpack {max_t} {tbits} (x/{A}))
def cert : ActiveData {D-1} {C-1} := {{
  start := 0
  pushRows := pushRows
  controlCodes := controlCodes
  auxiliaryCodes := auxiliaryCodes
  predecessorCodes := predecessorCodes
  edgeRows := edgeRows
  zeroCodes := {hex(sum(1<<v for v in z2))}
  zeroNextCodes := zeroNextCodes
}}
end {ns}
'''
Path(name+'Packed.lean').write_text(s)
s=f'import {name}Packed\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\nnamespace {ns}\nopen BB6BlockFAR (run primBlank)\n'
s+='theorem base_ok : cert.baseCheck = true := by decide +kernel\n'
for kind,f in [('pred','cert.fastPredAt'),('rows','(cert.fastRowsAt machine)')]:
    def combine(lo,length):
        if length<=16:
            tag=f'{kind}_{lo}_{length}'
            return f'theorem {tag} : rangeCheck {D-1} {f} {lo} {length} = true := by decide +kernel\n',tag
        left=length//2;ls,ln=combine(lo,left);rs,rn=combine(lo+left,length-left);tag=f'{kind}_{lo}_{length}'
        return ls+rs+f'theorem {tag} : rangeCheck {D-1} {f} {lo} {length} = true := rangeCheck_join {D-1} {f} {lo} {left} {length-left} {ln} {rn}\n',tag
    proof,tag=combine(0,D);s+=proof+f'theorem {kind}_full : (List.finRange {D}).all {f} = true := rangeCheck_full _ _ {tag}\n'
s+=f'''theorem valid : cert.Valid machine := ⟨base_ok,pred_full,rows_full⟩
theorem forever : ∀ k, ∃ c, run machine k primBlank = some c := cert.sound machine valid
def ctr : BB6Coverage.PartialMachine := BB6Coverage.FAR.fromCodes {T}
theorem same : BB6Coverage.FAR.reflectPartial ctr = BB6BlockFAR.partialTable machine :=
  BB6.Agent31ThreeHole.tableOK_sound _ _ (by decide)
theorem never (m : BB6Coverage.Machine) (hm : BB6Coverage.compatible ctr m) : BB6Coverage.NeverHalts m :=
  BB6Coverage.FAR.reflectNever m (BB6BlockFAR.transfer_never machine _ (by simpa only [← same] using BB6Coverage.FAR.reflectCompatible ctr m hm) forever)
#print axioms same
#print axioms never
end {ns}
'''
Path(name+'Proof.lean').write_text(s)
print('written',Path(name+'Packed.lean').stat().st_size,Path(name+'Proof.lean').stat().st_size)
