"""Raw139 E0=1RD. Block-FAR discovery adapted from Agent6's E0=0RC code.
All discovered certificates require independent source-level acceptance.
"""
import json,hashlib,pathlib
from collections import Counter,defaultdict,deque
from functools import lru_cache
from itertools import product
from multiprocessing import Pool
WORK=pathlib.Path(__file__).resolve().parent
PARENT=[7,24,11,24,14,24,24,16,15,11,24,24]

def generate(table,width=2,cap=1,mod=1,runs=1,flip=False,event_limit=10000,phase=False):
    alphabet=2**width
    moves=[None if n==24 else ((n>>1)&1,bool(n&1)!=flip,n>>2) for n in table]
    @lru_cache(None)
    def macro(q,d,a):
        h=0 if d else width-1; seen=set()
        while 0<=h<width:
            k=(q,h,a)
            if k in seen:return None
            seen.add(k);mv=moves[2*q+(a>>h&1)]
            if mv is None:return None
            w,d,q=mv;a=(a&~(1<<h))|(w<<h);h+=1 if d else -1
        return q,d,a
    left=[()];leftids={():0};delta={};pred=defaultdict(list)
    nodes=[('T',)];nodeids={nodes[0]:0};edges=defaultdict(set);copier=defaultdict(set);pending=defaultdict(set);event=deque()
    def node(key):
        if key not in nodeids:nodeids[key]=len(nodes);nodes.append(key)
        return nodeids[key]
    def ctrl(l,q,d):return node(('c',l,q,int(d)))
    def add(s,a,t):
        if (a,t) not in edges[s]:edges[s].add((a,t));event.append((s,a,t))
    def copy(q,v):
        if q not in copier[v]:
            copier[v].add(q)
            for a,t in tuple(edges[v]):add(q,a,t)
    def applyleft(l0,b,q,w,v):
        p=ctrl(l0,q,False);x=node(('x',p,b));add(x,w,v);add(p,b,x)
    def push(l,a):
        key=(l,a)
        if key in delta:return delta[key]
        xs=left[l]
        if not xs and a==0:ys=()
        elif phase:ys=((a,)+xs[0][:runs-1] if xs else (a,), ((xs[1] if xs else 0)+1)%mod)
        elif xs and xs[0][0]==a:
            s,n,m=xs[0];ys=((s,min(cap,n+1),(m+1)%mod),)+xs[1:]
        else:ys=((a,1,1%mod),)+xs[:runs-1]
        if ys not in leftids:leftids[ys]=len(left);left.append(ys)
        j=leftids[ys];delta[key]=j;pred[j].append(key)
        for q,w,v in pending[j]:applyleft(l,a,q,w,v)
        return j
    push(0,0);add(0,0,0);copy(ctrl(0,0,True),0)
    count=0
    while event:
        s,a,v=event.popleft();count+=1
        if count>event_limit:return None
        for q in tuple(copier[s]):add(q,a,v)
        key=nodes[s]
        if key[0]!='c':continue
        _,l,q,d=key;m=macro(q,bool(d),a)
        if m is None:return None
        q2,d2,w=m
        if d2:copy(ctrl(push(l,w),q2,True),v)
        elif (q2,w,v) not in pending[l]:
            pending[l].add((q2,w,v))
            for l0,b in pred[l]:applyleft(l0,b,q2,w,v)
    return left,nodes,delta,edges,moves

