import MacroCheck

namespace BB6Block
open BB6Coverage

/-- An affine inequality in an inner natural loop index holds throughout
    a finite interval iff it holds at both endpoints. Outer parameters
    may enter both endpoints through arbitrary integer expressions. -/
theorem affine_guard_interval (a d : Int) (T : Nat) (hT : 0<T)
    (h0 : 0≤a) (h1 : 0≤a+d*((T-1:Nat):Int)) :
    ∀ j : Nat, j<T → 0≤a+d*(j:Int) := by
  intro j hj
  by_cases hd : 0≤d
  · have hp := Int.mul_nonneg hd (show 0≤(j:Int) by omega)
    omega
  · have hle : (j:Int)≤((T-1:Nat):Int) := by omega
    have hm := Int.mul_le_mul_of_nonpos_left (show d≤0 by omega) hle
    omega

theorem affine_guard_infinite (a d : Int) (h0 : 0≤a) (hd : 0≤d) (j : Nat) : 0≤a+d*(j:Int) := by
  have hp := Int.mul_nonneg hd (show 0≤(j:Int) by omega)
  omega

/-- Each guard is an intercept and an inner-index coefficient, with all
    outer parameters already evaluated. This elimination is exact even
    when an affine approximation was used to choose the repeat count. -/
def Guards (g : List (Int×Int)) (j : Nat) : Prop :=
  ∀ p, p∈g → 0≤p.1+p.2*(j:Int)

theorem guards_interval (g : List (Int×Int)) (T : Nat) (hT : 0<T)
    (h0 : Guards g 0) (h1 : Guards g (T-1)) : ∀ j, j<T → Guards g j := by
  intro j hj p hp
  exact affine_guard_interval p.1 p.2 T hT (by simpa using h0 p hp) (h1 p hp) j hj

theorem guards_infinite (g : List (Int×Int)) (h0 : Guards g 0)
    (hd : ∀ p, p∈g → 0≤p.2) : ∀ j, Guards g j := by
  intro j p hp
  exact affine_guard_infinite p.1 p.2 (by simpa using h0 p hp) (hd p hp) j

/-- Source-checked segment. Translation of the block base is unrestricted.
    The certificate carries the exact primitive cost and displacement. -/
def Segment (m : Machine) (c d : RleCfg k) (cost : Nat) (shift : Int) : Prop :=
  ∀ b, run m cost (c.source b)=some (d.source (b+shift))

theorem Segment.refl (m : Machine) (c : RleCfg k) : Segment m c c 0 0 := by
  intro b; simp [run]

theorem Segment.trans {m : Machine} {a b c : RleCfg k} {n p : Nat} {x y : Int}
    (h : Segment m a b n x) (g : Segment m b c p y) : Segment m a c (n+p) (x+y) := by
  intro z
  rw [run_add,h z]
  simpa [Int.add_assoc] using g (z+x)

theorem Segment.macro {m : Machine} {c d : RleCfg k} {n : Nat} {x : Int}
    (hk : 0<k) (h : Macro m c n x d) : Segment m c d n x := h.sound hk

theorem Segment.path (m : Machine) (hk : 0<k) (xs : List MacroSpec)
    (c : RleCfg k) (v : Checked k) (h : checkPath m xs c=some v) :
    Segment m c v.target v.cost v.shift := checkPath_sound k hk m xs c v h

def PositiveEdge (m : Machine) (c d : RleCfg k) : Prop :=
  ∃ cost shift, 0<cost ∧ Segment m c d cost shift

/-- Compose a parameterized sequence of positive segments without
    evaluating or enumerating the loop iterations in the proof. -/
theorem repeat_segments (m : Machine) (fam : Nat→RleCfg k) (T : Nat)
    (body : ∀ j, j<T → PositiveEdge m (fam j) (fam (j+1))) :
    ∃ cost shift, T≤cost ∧ Segment m (fam 0) (fam T) cost shift := by
  induction T with
  | zero => exact ⟨0,0,by omega,Segment.refl m (fam 0)⟩
  | succ T ih =>
    obtain ⟨n,x,hn,hx⟩ := ih (fun j hj => body j (by omega))
    obtain ⟨p,y,hp,hy⟩ := body T (by omega)
    exact ⟨n+p,x+y,by omega,hx.trans hy⟩

/-- Endpoint-eliminated bounded loop: arbitrary positive number of inner
    iterations, each checked under exactly the affine guard family. -/
theorem repeat_guarded (m : Machine) (fam : Nat→RleCfg k) (g : List (Int×Int)) (T : Nat)
    (hT : 0<T) (h0 : Guards g 0) (h1 : Guards g (T-1))
    (body : ∀ j, Guards g j → PositiveEdge m (fam j) (fam (j+1))) :
    ∃ cost shift, T≤cost ∧ Segment m (fam 0) (fam T) cost shift := by
  exact repeat_segments m fam T (fun j hj => body j (guards_interval g T hT h0 h1 j hj))

/-- The same rule can be used recursively at the next enclosing loop.
    In particular the derived segment has strictly positive cost. -/
theorem repeat_guarded_positive (m : Machine) (fam : Nat→RleCfg k) (g : List (Int×Int)) (T : Nat)
    (hT : 0<T) (h0 : Guards g 0) (h1 : Guards g (T-1))
    (body : ∀ j, Guards g j → PositiveEdge m (fam j) (fam (j+1))) :
    PositiveEdge m (fam 0) (fam T) := by
  obtain ⟨n,x,hn,hx⟩ := repeat_guarded m fam g T hT h0 h1 body
  exact ⟨n,x,by omega,hx⟩

/-- Any forward-closed family of compressed configurations with
    positive-cost source-checked transitions is a nonhalting certificate.
    A finite raw prefix from the blank root is explicit. -/
theorem invariant_never (m : Machine) (P : RleCfg k→Prop) (c : RleCfg k)
    (entryCost : Nat) (entryShift : Int) (entry : Segment m (rleBlank k) c entryCost entryShift)
    (hstart : P c) (closed : ∀ d, P d → ∃ e, P e ∧ PositiveEdge m d e) : NeverHalts m := by
  have hr : ∀ T, ∃ d n x, P d ∧ T≤n ∧ Segment m c d n x := by
    intro T
    induction T with
    | zero => exact ⟨c,0,0,hstart,by omega,Segment.refl m c⟩
    | succ T ih =>
      obtain ⟨d,n,x,hd,hn,hx⟩ := ih
      obtain ⟨e,he,p,y,hp,hy⟩ := closed d hd
      exact ⟨e,n+p,x+y,he,by omega,hx.trans hy⟩
  apply arbitrary_live
  intro T
  obtain ⟨d,n,x,_,hn,hx⟩ := hr T
  refine ⟨entryCost+n,d.source (entryShift+x),by omega,?_⟩
  have hh := (entry.trans hx) 0
  simpa [rleBlank_source] using hh

/-- Unbounded repetition with no negative inner-index guard is a
    special case of a positive-step invariant, with no cutoff. -/
theorem infinite_guarded (m : Machine) (fam : Nat→RleCfg k)
    (entryCost : Nat) (entryShift : Int) (entry : Segment m (rleBlank k) (fam 0) entryCost entryShift)
    (g : List (Int×Int)) (h0 : Guards g 0) (hd : ∀ p,p∈g→0≤p.2)
    (body : ∀ j, Guards g j → PositiveEdge m (fam j) (fam (j+1))) : NeverHalts m := by
  apply invariant_never m (fun c => ∃ j,c=fam j) (fam 0) entryCost entryShift entry ⟨0,rfl⟩
  intro d hd'
  obtain ⟨j,rfl⟩ := hd'
  exact ⟨fam (j+1),⟨j+1,rfl⟩,body j (guards_infinite g h0 hd j)⟩

#print axioms affine_guard_interval
#print axioms repeat_guarded_positive
#print axioms invariant_never
#print axioms infinite_guarded
end BB6Block
