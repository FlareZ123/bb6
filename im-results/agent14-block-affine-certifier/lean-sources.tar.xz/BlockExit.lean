import Frontier

namespace BB6Block
open BB6Coverage

structure Local where
  state : Fin 6
  pos : Int
  word : List Bool
  deriving DecidableEq, Repr

def inside (c : Local) : Bool := decide (0 ≤ c.pos ∧ c.pos < (c.word.length : Int))

def patch (base : Int) (w : List Bool) (t : Int → Bool) (x : Int) : Bool :=
  if base ≤ x ∧ x < base + (w.length : Int) then w[(x-base).toNat]?.getD false else t x

def embed (base : Int) (t : Int → Bool) (c : Local) : Config :=
  ⟨c.state,base+c.pos,patch base c.word t⟩

def update (c : Local) (mv : Move) : Local :=
  ⟨mv.next,c.pos + (if mv.right then 1 else -1), c.word.set c.pos.toNat mv.write⟩

def localStep (m : Machine) (c : Local) : Option Local :=
  if inside c then (m (c.state,c.word[c.pos.toNat]?.getD false)).map (update c) else none

/-- Stop at the first local exit, or return none if fuel is exhausted or a
    halt is encountered before crossing the boundary. -/
def localRun (m : Machine) : Nat → Local → Option (Nat × Local)
  | 0,c => if inside c then none else some (0,c)
  | f+1,c => if inside c then
      (localStep m c).bind fun d => (localRun m f d).map fun (n,e) => (n+1,e)
    else some (0,c)

theorem patch_inside (b : Int) (w : List Bool) (t : Int → Bool) (i : Int)
    (h : 0≤i ∧ i<(w.length : Int)) : patch b w t (b+i) = w[i.toNat]?.getD false := by
  simp [patch,show b ≤ b+i by omega,show b+i<b+(w.length:Int) by omega,show b+i-b=i by omega]

theorem patch_outside (b : Int) (w : List Bool) (t : Int → Bool) (x : Int)
    (h : x<b ∨ b+(w.length:Int)≤x) : patch b w t x = t x := by
  simp [patch,show ¬(b≤x ∧ x<b+(w.length:Int)) by omega]

theorem inside_iff (c : Local) : inside c = true ↔ 0 ≤ c.pos ∧ c.pos < (c.word.length : Int) := by simp [inside]

theorem update_len (c : Local) (mv : Move) : (update c mv).word.length=c.word.length := by simp [update]

theorem update_patch (b : Int) (t : Int → Bool) (c : Local) (mv : Move)
    (h : inside c = true) (x : Int) :
    patch b (update c mv).word t x =
      (if x=b+c.pos then mv.write else patch b c.word t x) := by
  obtain ⟨hp,hq⟩ := (inside_iff c).mp h
  have hi : c.pos.toNat < c.word.length := by omega
  by_cases hx : b≤x ∧ x<b+(c.word.length:Int)
  · have hxi : (x-b).toNat < c.word.length := by omega
    by_cases he : x=b+c.pos
    · have hind : (x-b).toNat=c.pos.toNat := by omega
      simp [patch,update,he,show b≤b+c.pos by omega,show b+c.pos<b+(c.word.length:Int) by omega,show b+c.pos-b=c.pos by omega,hi]
    · have hne : (x-b).toNat≠c.pos.toNat := by omega
      simp [patch,update,hx,he,Ne.symm hne]
  · have he : x≠b+c.pos := by omega
    simp [patch,update,hx,he]

theorem localStep_sound (m : Machine) (b : Int) (t : Int → Bool)
    (c d : Local) (h : localStep m c=some d) :
    rawStep m (embed b t c)=some (embed b t d) ∧ d.word.length=c.word.length := by
  cases hi : inside c with
  | false => simp [localStep,hi] at h
  | true =>
    cases hm : m (c.state,c.word[c.pos.toNat]?.getD false) with
    | none => simp [localStep,hi,hm] at h
    | some mv =>
      have hd : update c mv=d := by simpa [localStep,hi,hm] using h
      subst d
      constructor
      · have hread : readSlot (embed b t c)=(c.state,c.word[c.pos.toNat]?.getD false) := by
          simp only [readSlot,embed]
          rw [patch_inside b c.word t c.pos ((inside_iff c).mp hi)]
        simp only [rawStep,hread,hm,Option.map_some]
        congr 1
        unfold applyMove embed update
        simp only
        congr 1
        · omega
        · funext x
          exact (update_patch b t c mv hi x).symm
      · exact update_len c mv

theorem run_add (m : Machine) (c : Config) (n k : Nat) :
    run m (n+k) c = (run m n c).bind (run m k) := by
  induction k with
  | zero => simp [run]
  | succ k ih =>
    rw [Nat.add_succ,run,ih]
    cases h : run m n c with
    | none => rfl
    | some d => rfl

theorem localRun_sound (m : Machine) (f : Nat) (c d : Local) (n : Nat)
    (h : localRun m f c=some (n,d)) (b : Int) (t : Int→Bool) :
    run m n (embed b t c)=some (embed b t d) ∧
    d.word.length=c.word.length ∧ inside d=false ∧ n≤f := by
  induction f generalizing c d n with
  | zero =>
    cases hi : inside c with
    | true => simp [localRun,hi] at h
    | false =>
      have he : n=0 ∧ d=c := by simpa [localRun,hi,eq_comm] using h
      obtain ⟨rfl,rfl⟩ := he
      simp [run,hi]
  | succ f ih =>
    cases hi : inside c with
    | false =>
      have he : n=0 ∧ d=c := by simpa [localRun,hi,eq_comm] using h
      obtain ⟨rfl,rfl⟩ := he
      simp [run,hi]
    | true =>
      cases hs : localStep m c with
      | none => simp [localRun,hi,hs] at h
      | some e =>
        cases hr : localRun m f e with
        | none => simp [localRun,hi,hs,hr] at h
        | some p =>
          obtain ⟨k,g⟩ := p
          have he : n=k+1 ∧ d=g := by simpa [localRun,hi,hs,hr,eq_comm] using h
          obtain ⟨rfl,rfl⟩ := he
          obtain ⟨h1,h2⟩ := localStep_sound m b t c e hs
          obtain ⟨h3,h4,h5,h6⟩ := ih e d k hr
          refine ⟨?_,h4.trans h2,h5,by omega⟩
          rw [Nat.add_comm k 1,run_add]
          change (rawStep m (embed b t c)).bind (run m k) = _
          rw [h1]
          exact h3

#print axioms localRun_sound
end BB6Block
