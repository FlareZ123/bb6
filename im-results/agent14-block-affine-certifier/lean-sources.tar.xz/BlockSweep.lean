import BlockExit

namespace BB6Block
open BB6Coverage

def wordMatches (t : Int→Bool) (b : Int) (w : List Bool) : Prop :=
  ∀ x, b≤x ∧ x<b+(w.length:Int) → t x=w[(x-b).toNat]?.getD false

theorem patch_eq (t : Int→Bool) (b : Int) (w : List Bool)
    (h : wordMatches t b w) : patch b w t=t := by
  funext x
  by_cases hx : b≤x ∧ x<b+(w.length:Int)
  · simp [patch,hx,h x hx]
  · simp [patch,hx]

def patches (addr : Nat→Int) (w : List Bool) (t : Int→Bool) : Nat→Int→Bool
  | 0 => t
  | n+1 => patch (addr n) w (patches addr w t n)

def disjointBlocks (addr : Nat→Int) (len : Nat) : Prop :=
  ∀ i j, i<j → addr i+(len:Int)≤addr j ∨ addr j+(len:Int)≤addr i

theorem patches_preserve (addr : Nat→Int) (w : List Bool) (t : Int→Bool)
    (h : disjointBlocks addr w.length) (n j : Nat) (hnj : n≤j) (x : Int)
    (hx : addr j≤x ∧ x<addr j+(w.length:Int)) :
    patches addr w t n x=t x := by
  induction n with
  | zero => rfl
  | succ n ih =>
    have hd := h n j (by omega)
    have ho : x<addr n ∨ addr n+(w.length:Int)≤x := by omega
    rw [patches,patch_outside _ _ _ _ ho,ih (by omega)]

/-- Exact block-local execution, including arbitrary nonblank exterior. -/
theorem exit_from_match (m : Machine) (f n : Nat) (c d : Local)
    (hc : localRun m f c=some (n,d)) (b : Int) (t : Int→Bool)
    (h : wordMatches t b c.word) :
    run m n ⟨c.state,b+c.pos,t⟩=some ⟨d.state,b+d.pos,patch b d.word t⟩ := by
  have hr := (localRun_sound m f c d n hc b t).1
  simpa only [embed,patch_eq t b c.word h] using hr

/-- A repeated same-state block exit may be batched across any number of
    disjoint blocks. The tape outside all written blocks remains unchanged.
    The theorem uses the physical source step count, not the macro count. -/
theorem sweep_sound (m : Machine) (f cost n : Nat) (q : Fin 6)
    (p e : Int) (w v : List Bool)
    (hr : localRun m f ⟨q,p,w⟩=some (cost,⟨q,e,v⟩))
    (addr : Nat→Int) (hs : ∀ j, addr j+e=addr (j+1)+p)
    (hd : disjointBlocks addr w.length) (t : Int→Bool)
    (ht : ∀ j, j<n → wordMatches t (addr j) w) :
    run m (cost*n) ⟨q,addr 0+p,t⟩ =
      some ⟨q,addr n+p,patches addr v t n⟩ := by
  have hlen : v.length=w.length := (localRun_sound m f ⟨q,p,w⟩ ⟨q,e,v⟩ cost hr 0 t).2.1
  have hd' : disjointBlocks addr v.length := by rw [hlen]; exact hd
  induction n with
  | zero => simp [run,patches]
  | succ n ih =>
    have hh := ih (fun j hj => ht j (by omega))
    have hmatch : wordMatches (patches addr v t n) (addr n) w := by
      intro x hx
      have hx' : addr n≤x ∧ x<addr n+(v.length:Int) := by rw [hlen]; exact hx
      rw [patches_preserve addr v t hd' n n (by omega) x hx']
      exact ht n (by omega) x hx
    have he := exit_from_match m f cost ⟨q,p,w⟩ ⟨q,e,v⟩ hr (addr n) (patches addr v t n) hmatch
    rw [Nat.mul_succ,run_add,hh]
    simp only [Option.bind_some]
    rw [he]
    simp [hs,patches]

/-- A rightgoing repeated block has a valid disjoint placement for all
    natural repetition counts. -/
theorem right_disjoint (b : Int) (k : Nat) :
    disjointBlocks (fun j => b+(k:Int)*(j:Int)) k := by
  intro i j hij
  left
  have h : (i:Int)+1≤(j:Int) := by omega
  have h' := Int.mul_le_mul_of_nonneg_left h (show 0≤(k:Int) by omega)
  simp only [Int.mul_add,Int.mul_one] at h'
  dsimp
  omega

theorem left_disjoint (b : Int) (k : Nat) :
    disjointBlocks (fun j => b-(k:Int)*(j:Int)) k := by
  intro i j hij
  right
  have h : (i:Int)+1≤(j:Int) := by omega
  have h' := Int.mul_le_mul_of_nonneg_left h (show 0≤(k:Int) by omega)
  simp only [Int.mul_add,Int.mul_one] at h'
  dsimp
  omega

theorem sweep_right (m : Machine) (f cost n : Nat) (q : Fin 6)
    (w v : List Bool) (b : Int) (t : Int→Bool)
    (hr : localRun m f ⟨q,0,w⟩=some (cost,⟨q,w.length,v⟩))
    (ht : ∀ j, j<n → wordMatches t (b+(w.length:Int)*(j:Int)) w) :
    run m (cost*n) ⟨q,b,t⟩ =
      some ⟨q,b+(w.length:Int)*(n:Int),patches (fun j => b+(w.length:Int)*(j:Int)) v t n⟩ := by
  have hh := sweep_sound m f cost n q 0 w.length w v hr
    (fun j => b+(w.length:Int)*(j:Int))
    (by intro j; simp [Int.mul_add]; omega)
    (right_disjoint b w.length) t ht
  simpa using hh

theorem sweep_left (m : Machine) (f cost n : Nat) (q : Fin 6)
    (w v : List Bool) (b : Int) (t : Int→Bool)
    (hr : localRun m f ⟨q,(w.length:Int)-1,w⟩=some (cost,⟨q,-1,v⟩))
    (ht : ∀ j, j<n → wordMatches t (b-(w.length:Int)*(j:Int)) w) :
    run m (cost*n) ⟨q,b+(w.length:Int)-1,t⟩ =
      some ⟨q,b-(w.length:Int)*(n:Int)+(w.length:Int)-1,patches (fun j => b-(w.length:Int)*(j:Int)) v t n⟩ := by
  have hh := sweep_sound m f cost n q ((w.length:Int)-1) (-1) w v hr
    (fun j => b-(w.length:Int)*(j:Int))
    (by intro j; simp [Int.mul_add]; omega)
    (left_disjoint b w.length) t ht
  simpa [Int.add_sub_assoc] using hh

/-- A positive-time family of arbitrary-length runs proves every finite
    primitive time defined. No uniform upper bound on macro times needed. -/
theorem arbitrary_live (m : Machine) (c : Config)
    (h : ∀ n, ∃ k d, n≤k ∧ run m k c=some d) :
    ∀ n, (run m n c).isSome=true := by
  intro n
  obtain ⟨k,d,hk,hr⟩ := h n
  cases he : run m n c with
  | some _ => rfl
  | none =>
    have hbad := run_none_add m c n (k-n) he
    have heq : n+(k-n)=k := by omega
    rw [heq,hr] at hbad
    contradiction

theorem infinite_sweep (m : Machine) (f cost : Nat) (q : Fin 6)
    (p e : Int) (w v : List Bool)
    (hr : localRun m f ⟨q,p,w⟩=some (cost,⟨q,e,v⟩)) (hc : 0<cost)
    (addr : Nat→Int) (hs : ∀ j, addr j+e=addr (j+1)+p)
    (hd : disjointBlocks addr w.length) (t : Int→Bool)
    (ht : ∀ j, wordMatches t (addr j) w) :
    ∀ n, (run m n ⟨q,addr 0+p,t⟩).isSome=true := by
  apply arbitrary_live
  intro n
  refine ⟨cost*n,_,?_,sweep_sound m f cost n q p e w v hr addr hs hd t (fun j _ => ht j)⟩
  exact Nat.le_mul_of_pos_left n hc

#print axioms sweep_sound
#print axioms sweep_right
#print axioms sweep_left
#print axioms infinite_sweep
end BB6Block
