import BlockSweep

namespace BB6Block
open BB6Coverage

abbrev Word (k : Nat) := {w : List Bool // w.length=k}

def zeroWord (k : Nat) : Word k := ⟨List.replicate k false,by simp⟩

def blockTape (k : Nat) (words : Int→Word k) (x : Int) : Bool :=
  (words (x/(k:Int))).val[(x%(k:Int)).toNat]?.getD false

theorem index_of_cell (k : Nat) (hk : 0<k) (j i : Int)
    (hi : 0≤i ∧ i<(k:Int)) :
    (j*(k:Int)+i)/(k:Int)=j ∧ (j*(k:Int)+i)%(k:Int)=i := by
  have he : j*(k:Int)+i=i+j*(k:Int) := by omega
  rw [he,Int.add_mul_ediv_right _ _ (by omega),Int.add_mul_emod_self_right]
  rw [Int.ediv_eq_zero_of_lt hi.1 hi.2,Int.emod_eq_of_lt hi.1 hi.2]
  simp

theorem blockTape_cell (k : Nat) (hk : 0<k) (words : Int→Word k)
    (j i : Int) (hi : 0≤i ∧ i<(k:Int)) :
    blockTape k words (j*(k:Int)+i)=(words j).val[i.toNat]?.getD false := by
  obtain ⟨h1,h2⟩ := index_of_cell k hk j i hi
  simp [blockTape,h1,h2]

theorem blockTape_matches (k : Nat) (hk : 0<k) (words : Int→Word k) (j : Int) :
    wordMatches (blockTape k words) (j*(k:Int)) (words j).val := by
  intro x hx
  have hlen := (words j).property
  rw [hlen] at hx
  have hi : 0≤x-j*(k:Int) ∧ x-j*(k:Int)<(k:Int) := by omega
  have hh := blockTape_cell k hk words j (x-j*(k:Int)) hi
  have he : j*(k:Int)+(x-j*(k:Int))=x := by omega
  rwa [he] at hh

def writeBlock (words : Int→Word k) (j : Int) (v : Word k) (i : Int) : Word k :=
  if i=j then v else words i

theorem patch_blockTape (k : Nat) (hk : 0<k) (words : Int→Word k) (j : Int) (v : Word k) :
    patch (j*(k:Int)) v.val (blockTape k words)=blockTape k (writeBlock words j v) := by
  funext x
  let i := x/(k:Int)
  let r := x%(k:Int)
  have hr : 0≤r ∧ r<(k:Int) := ⟨Int.emod_nonneg _ (by omega),Int.emod_lt_of_pos _ (by omega)⟩
  have he : i*(k:Int)+r=x := Int.ediv_mul_add_emod x k
  by_cases h : i=j
  · have he' : x=j*(k:Int)+r := by rw [←h]; exact he.symm
    rw [he',patch_inside _ _ _ _ (by rw [v.property]; exact hr),blockTape_cell _ hk _ _ _ hr]
    simp [writeBlock]
  · have ho : x<j*(k:Int) ∨ j*(k:Int)+(v.val.length:Int)≤x := by
      rw [v.property,←he]
      rcases Int.lt_or_gt_of_ne h with hi|hi
      · left
        have hmul := Int.mul_le_mul_of_nonneg_right (show i+1≤j by omega) (show 0≤(k:Int) by omega)
        rw [Int.add_mul,Int.one_mul] at hmul
        omega
      · right
        have hmul := Int.mul_le_mul_of_nonneg_right (show j+1≤i by omega) (show 0≤(k:Int) by omega)
        rw [Int.add_mul,Int.one_mul] at hmul
        omega
    rw [patch_outside _ _ _ _ ho,←he,blockTape_cell _ hk _ _ _ hr,blockTape_cell _ hk _ _ _ hr]
    simp [writeBlock,h]

/-- Absolute block-grid machine, retaining the exact physical head offset.
    Word length is invariant by the local source interpreter. -/
structure BlockCfg (k : Nat) where
  state : Fin 6
  index : Int
  offset : Int
  words : Int→Word k

def BlockCfg.source {k : Nat} (c : BlockCfg k) : Config :=
  ⟨c.state,c.index*(k:Int)+c.offset,blockTape k c.words⟩

def BlockCfg.local {k : Nat} (c : BlockCfg k) : Local :=
  ⟨c.state,c.offset,(c.words c.index).val⟩

theorem single_block_sound (k : Nat) (hk : 0<k) (m : Machine) (c : BlockCfg k)
    (f cost : Nat) (q : Fin 6) (e : Int) (v : Word k)
    (hr : localRun m f c.local=some (cost,⟨q,e,v.val⟩)) :
    run m cost c.source=
      some (BlockCfg.source ⟨q,c.index,e,writeBlock c.words c.index v⟩) := by
  have hh := exit_from_match m f cost c.local ⟨q,e,v.val⟩ hr
    (c.index*(k:Int)) (blockTape k c.words) (blockTape_matches k hk c.words c.index)
  simpa [BlockCfg.source,BlockCfg.local,patch_blockTape k hk] using hh

def batchWrite (words : Int→Word k) (addr : Nat→Int) (v : Word k) : Nat→Int→Word k
  | 0 => words
  | n+1 => writeBlock (batchWrite words addr v n) (addr n) v

theorem batchWrite_tape (k : Nat) (hk : 0<k) (words : Int→Word k) (addr : Nat→Int) (v : Word k) (n : Nat) :
    blockTape k (batchWrite words addr v n)=
      patches (fun j => addr j*(k:Int)) v.val (blockTape k words) n := by
  induction n with
  | zero => rfl
  | succ n ih => rw [batchWrite,←patch_blockTape k hk,ih,patches]

def writeInterval (words : Int→Word k) (lo hi : Int) (v : Word k) (i : Int) : Word k :=
  if lo≤i ∧ i<hi then v else words i

theorem batchWrite_right (words : Int→Word k) (b : Int) (v : Word k) (n : Nat) :
    batchWrite words (fun j => b+(j:Int)) v n=writeInterval words b (b+(n:Int)) v := by
  induction n with
  | zero => funext i; simp [batchWrite,writeInterval,show ¬(b≤i ∧ i<b) by omega]
  | succ n ih =>
    rw [batchWrite,ih]
    funext i
    unfold writeBlock writeInterval
    dsimp
    by_cases he : i=b+(n:Int)
    · have hh : b≤i ∧ i<b+((n+1:Nat):Int) := by omega
      rw [if_pos he,if_pos (by simpa only [Int.natCast_succ] using hh)]
    · have hh : (b≤i ∧ i<b+(n:Int)) ↔ (b≤i ∧ i<b+((n+1:Nat):Int)) := by omega
      simp [he,hh]

theorem batchWrite_left (words : Int→Word k) (b : Int) (v : Word k) (n : Nat) :
    batchWrite words (fun j => b-(j:Int)) v n=writeInterval words (b-(n:Int)+1) (b+1) v := by
  induction n with
  | zero => funext i; simp [batchWrite,writeInterval,show ¬(b+1≤i ∧ i<b+1) by omega]
  | succ n ih =>
    rw [batchWrite,ih]
    funext i
    unfold writeBlock writeInterval
    dsimp
    by_cases he : i=b-(n:Int)
    · simp [he]; omega
    · have hh : (b-(n:Int)+1≤i ∧ i<b+1) ↔ (b-((n+1:Nat):Int)+1≤i ∧ i<b+1) := by omega
      simp [he,hh]

/-- Batch right across n identical words, including a completely arbitrary
    block tape beyond those n words. The output is a single interval update. -/
theorem batch_right_sound (k : Nat) (hk : 0<k) (m : Machine) (f cost n : Nat)
    (q : Fin 6) (b : Int) (words : Int→Word k) (w v : Word k)
    (hr : localRun m f ⟨q,0,w.val⟩=some (cost,⟨q,k,v.val⟩))
    (hw : ∀ j : Nat, j<n → words (b+(j:Int))=w) :
    run m (cost*n) (BlockCfg.source ⟨q,b,0,words⟩)=
      some (BlockCfg.source ⟨q,b+(n:Int),0,writeInterval words b (b+(n:Int)) v⟩) := by
  have ht : ∀ j : Nat, j<n → wordMatches (blockTape k words) ((b+(j:Int))*(k:Int)) w.val := by
    intro j hj
    rw [←hw j hj]
    exact blockTape_matches k hk words _
  have h1 : ∀ j : Nat, (b+(j:Int))*(k:Int) = b*(k:Int)+(k:Int)*(j:Int) := by
    intro j; rw [Int.add_mul,Int.mul_comm (j:Int)]
  have hh := sweep_sound m f cost n q 0 k w.val v.val hr (fun j => (b+(j:Int))*(k:Int))
    (by intro j; change (b+(j:Int))*(k:Int)+(k:Int)=(b+((j+1:Nat):Int))*(k:Int)+0; simp [Int.add_mul]; omega)
    (by rw [w.property]; intro i j hij; have hh := right_disjoint (b*(k:Int)) k i j hij; simpa only [h1] using hh)
    (blockTape k words) ht
  rw [←batchWrite_tape k hk words (fun j => b+(j:Int)) v n,batchWrite_right] at hh
  simpa [BlockCfg.source] using hh

theorem batch_left_sound (k : Nat) (hk : 0<k) (m : Machine) (f cost n : Nat)
    (q : Fin 6) (b : Int) (words : Int→Word k) (w v : Word k)
    (hr : localRun m f ⟨q,(k:Int)-1,w.val⟩=some (cost,⟨q,-1,v.val⟩))
    (hw : ∀ j : Nat, j<n → words (b-(j:Int))=w) :
    run m (cost*n) (BlockCfg.source ⟨q,b,(k:Int)-1,words⟩)=
      some (BlockCfg.source ⟨q,b-(n:Int),(k:Int)-1,writeInterval words (b-(n:Int)+1) (b+1) v⟩) := by
  have ht : ∀ j : Nat, j<n → wordMatches (blockTape k words) ((b-(j:Int))*(k:Int)) w.val := by
    intro j hj
    rw [←hw j hj]
    exact blockTape_matches k hk words _
  have h1 : ∀ j : Nat, (b-(j:Int))*(k:Int) = b*(k:Int)-(k:Int)*(j:Int) := by
    intro j; rw [Int.sub_mul,Int.mul_comm (j:Int)]
  have hh := sweep_sound m f cost n q ((k:Int)-1) (-1) w.val v.val hr (fun j => (b-(j:Int))*(k:Int))
    (by intro j; change (b-(j:Int))*(k:Int)+(-1)=(b-((j+1:Nat):Int))*(k:Int)+((k:Int)-1); simp [Int.sub_mul,Int.add_mul]; omega)
    (by rw [w.property]; intro i j hij; have hh := left_disjoint (b*(k:Int)) k i j hij; simpa only [h1] using hh)
    (blockTape k words) ht
  rw [←batchWrite_tape k hk words (fun j => b-(j:Int)) v n,batchWrite_left] at hh
  simpa [BlockCfg.source] using hh

#print axioms single_block_sound
#print axioms batch_right_sound
#print axioms batch_left_sound
end BB6Block
