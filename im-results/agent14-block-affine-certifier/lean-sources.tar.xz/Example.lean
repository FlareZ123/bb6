import AffineLoop
namespace BB6Block
open BB6Coverage

def grow : Machine := fun (q,v) =>
  match q.val,v with
  | 0,false => some ⟨true,true,1⟩
  | 0,true => some ⟨true,true,0⟩
  | 1,false => some ⟨true,false,2⟩
  | 2,true => some ⟨true,false,2⟩
  | 2,false => some ⟨false,true,0⟩
  | _,_ => none

def ones2 : Word 2 := ⟨[true,true],rfl⟩
def fam (n : Nat) : RleCfg 2 := ⟨0,false,ones2,[],pushBlocks ones2 n []⟩
def c1 (n : Nat) : RleCfg 2 := ⟨0,false,zeroWord 2,[(ones2,n+1)],[]⟩
def c2 (n : Nat) : RleCfg 2 := ⟨2,true,ones2,pushBlocks ones2 n [],[(ones2,1)]⟩
def c3 (n : Nat) : RleCfg 2 := ⟨2,true,zeroWord 2,[],[(ones2,n+2)]⟩

theorem grow_entry : Segment grow (rleBlank 2) (fam 0) 4 0 := by
  exact Segment.path grow (by decide) [⟨3,1⟩,⟨1,1⟩] _ ⟨4,0,fam 0⟩ (by decide)

theorem e1 (n : Nat) : Macro grow (fam n) (2*(n+1)) (n+1:Int) (c1 n) := by
  have h := Macro.manyRight (m:=grow) (fam n) 2 2 (n+1) ones2 (by omega) rfl (by rfl) (by
    cases n <;> simp [fam,pushBlocks,prefixSame,ones2,zeroWord])
  have ht : (fam n).goRight (fam n).state ones2 (n+1)=c1 n := by
    cases n <;> simp [fam,c1,RleCfg.goRight,pushBlocks,lookup,dropBlocks,ones2,zeroWord]
  simpa [ht] using h

theorem e2 (n : Nat) : Macro grow (c1 n) 3 (-1) (c2 n) := by
  have h := Macro.left (m:=grow) (c1 n) 3 3 2 ones2 (by rfl)
  have ht : (c1 n).goLeft 2 ones2 1=c2 n := by
    cases n <;> simp [c1,c2,RleCfg.goLeft,pushBlocks,lookup,dropBlocks,ones2,zeroWord]
  simpa [ht] using h

theorem e3 (n : Nat) : Macro grow (c2 n) (2*(n+1)) (-(n+1:Int)) (c3 n) := by
  have h := Macro.manyLeft (m:=grow) (c2 n) 2 2 (n+1) ones2 (by omega) rfl (by rfl) (by
    cases n <;> simp [c2,pushBlocks,prefixSame,ones2,zeroWord])
  have ht : (c2 n).goLeft (c2 n).state ones2 (n+1)=c3 n := by
    cases n <;> simp [c2,c3,RleCfg.goLeft,pushBlocks,lookup,dropBlocks,ones2,zeroWord]
  simpa [ht] using h

theorem e4 (n : Nat) : Macro grow (c3 n) 1 1 (fam (n+1)) := by
  have h := Macro.right (m:=grow) (c3 n) 1 1 0 (zeroWord 2) (by rfl)
  have ht : (c3 n).goRight 0 (zeroWord 2) 1=fam (n+1) := by
    simp [c3,fam,RleCfg.goRight,pushBlocks,lookup,dropBlocks,ones2,zeroWord]
  simpa [ht] using h

theorem grow_body (n : Nat) : Segment grow (fam n) (fam (n+1)) (4*n+8) 0 := by
  have h := (((Segment.macro (by decide) (e1 n)).trans (Segment.macro (by decide) (e2 n))).trans (Segment.macro (by decide) (e3 n))).trans (Segment.macro (by decide) (e4 n))
  have hc : 2*(n+1)+3+2*(n+1)+1=4*n+8 := by omega
  have hs : (n:Int)+1 + -1 + -((n:Int)+1)+1=0 := by omega
  rwa [hc,hs] at h

theorem grow_never : NeverHalts grow := by
  apply infinite_guarded grow fam 4 0 grow_entry [] (by simp [Guards]) (by simp)
  intro n _
  exact ⟨4*n+8,0,by omega,grow_body n⟩

#print axioms grow_never
end BB6Block
