import RleStep

namespace BB6Block
open BB6Coverage

structure MacroSpec where
  fuel : Nat
  count : Nat
  deriving Repr, DecidableEq

structure Checked (k : Nat) where
  cost : Nat
  shift : Int
  target : RleCfg k
  deriving Repr, DecidableEq

/-- The untrusted accelerator supplies only fuel and repetition count.
    All state, write, exit, cost, and compressed-prefix data are recomputed. -/
def checkMacro (m : Machine) (c : RleCfg k) (s : MacroSpec) : Option (Checked k) :=
  if s.count=0 then none else
    match localRun m s.fuel c.local with
    | none => none
    | some (cost,d) =>
      if h : d.word.length=k then
        let v : Word k := ⟨d.word,h⟩
        if d.pos=(k:Int) then
          if s.count=1 then some ⟨cost,1,c.goRight d.state v 1⟩ else
          if d.state=c.state ∧ c.side=false ∧ prefixSame c.word c.right (s.count-1)=true then
            some ⟨cost*s.count,s.count,c.goRight c.state v s.count⟩ else none
        else if d.pos=(-1:Int) then
          if s.count=1 then some ⟨cost,-1,c.goLeft d.state v 1⟩ else
          if d.state=c.state ∧ c.side=true ∧ prefixSame c.word c.left (s.count-1)=true then
            some ⟨cost*s.count,-(s.count:Int),c.goLeft c.state v s.count⟩ else none
        else none
      else none

theorem checkMacro_sound (m : Machine) (c : RleCfg k) (s : MacroSpec) (v : Checked k)
    (h : checkMacro m c s=some v) : Macro m c v.cost v.shift v.target := by
  unfold checkMacro at h
  split at h
  · contradiction
  · rename_i hn
    cases hr : localRun m s.fuel c.local with
    | none => simp [hr] at h
    | some p =>
      rcases p with ⟨cost,d⟩
      simp only [hr] at h
      split at h
      · rename_i hlen
        let w : Word k := ⟨d.word,hlen⟩
        split at h
        · rename_i hpos
          have he : d=⟨d.state,k,w.val⟩ := by cases d; simp_all [w]
          have hr' : localRun m s.fuel c.local=some (cost,⟨d.state,k,w.val⟩) := by rw [←he]; exact hr
          split at h
          · cases h
            exact Macro.right c s.fuel cost d.state w hr'
          · split at h
            · rename_i hg
              cases h
              exact Macro.manyRight c s.fuel cost s.count w (by omega) hg.2.1 (by simpa [hg.1] using hr') hg.2.2
            · contradiction
        · split at h
          · rename_i hpos
            have he : d=⟨d.state,-1,w.val⟩ := by cases d; simp_all [w]
            have hr' : localRun m s.fuel c.local=some (cost,⟨d.state,-1,w.val⟩) := by rw [←he]; exact hr
            split at h
            · cases h
              exact Macro.left c s.fuel cost d.state w hr'
            · split at h
              · rename_i hg
                cases h
                exact Macro.manyLeft c s.fuel cost s.count w (by omega) hg.2.1 (by simpa [hg.1] using hr') hg.2.2
              · contradiction
          · contradiction
      · contradiction

def checkPath (m : Machine) : List MacroSpec → RleCfg k → Option (Checked k)
  | [],c => some ⟨0,0,c⟩
  | s::xs,c =>
    match checkMacro m c s with
    | none => none
    | some a =>
      match checkPath m xs a.target with
      | none => none
      | some b => some ⟨a.cost+b.cost,a.shift+b.shift,b.target⟩

theorem checkPath_sound (k : Nat) (hk : 0<k) (m : Machine) (xs : List MacroSpec)
    (c : RleCfg k) (v : Checked k) (h : checkPath m xs c=some v) (b : Int) :
    run m v.cost (c.source b)=some (v.target.source (b+v.shift)) := by
  induction xs generalizing c v b with
  | nil =>
    simp only [checkPath,Option.some.injEq] at h
    subst v
    simp [run]
  | cons s xs ih =>
    cases hs : checkMacro m c s with
    | none => simp [checkPath,hs] at h
    | some a =>
      cases ht : checkPath m xs a.target with
      | none => simp [checkPath,hs,ht] at h
      | some t =>
        simp only [checkPath,hs,ht,Option.some.injEq] at h
        subst v
        have ha := (checkMacro_sound m c s a hs).sound hk b
        have hb := ih a.target t ht (b+a.shift)
        rw [run_add,ha]
        simpa [Int.add_assoc] using hb

theorem checkPath_pos (k : Nat) (hk : 0<k) (m : Machine) (xs : List MacroSpec)
    (hne : xs≠[]) (c : RleCfg k) (v : Checked k) (h : checkPath m xs c=some v) : 0<v.cost := by
  cases xs with
  | nil => contradiction
  | cons s xs =>
    cases hs : checkMacro m c s with
    | none => simp [checkPath,hs] at h
    | some a =>
      cases ht : checkPath m xs a.target with
      | none => simp [checkPath,hs,ht] at h
      | some t =>
        simp only [checkPath,hs,ht,Option.some.injEq] at h
        subst v
        have ha := (checkMacro_sound m c s a hs).positive hk
        simp only
        omega

#print axioms checkMacro_sound
#print axioms checkPath_sound
#print axioms checkPath_pos
end BB6Block
