import RleTape

namespace BB6Block
open BB6Coverage

/-- The guard for a finite straight sweep reads only its compressed prefix. -/
def prefixSame (w : Word k) : Runs k → Nat → Bool
  | [],n => n==0 || w==zeroWord k
  | (v,c)::xs,n => if n=0 then true else
      if w=v then if n≤c then true else prefixSame w xs (n-c) else false

theorem prefixSame_sound (w : Word k) (xs : Runs k) (n : Nat)
    (h : prefixSame w xs n=true) : ∀ i, i<n → lookup xs i=w := by
  induction xs generalizing n with
  | nil =>
    intro i hi
    have hn : n≠0 := by omega
    have hw : w=zeroWord k := by apply Subtype.ext; simpa [prefixSame,hn] using h
    simp [lookup,hw]
  | cons x xs ih =>
    obtain ⟨v,c⟩ := x
    intro i hi
    have hn : n≠0 := by omega
    by_cases he : w=v
    · subst v
      by_cases hc : n≤c
      · simp [lookup,show i<c by omega]
      · have htail : prefixSame w xs (n-c)=true := by simpa [prefixSame,hn,hc] using h
        by_cases hj : i<c
        · simp [lookup,hj]
        · simpa [lookup,hj] using ih (n-c) htail (i-c) (by omega)
    · simp [prefixSame,hn,he] at h

theorem local_cost_pos (m : Machine) (f cost : Nat) (c d : Local)
    (hi : inside c=true) (hr : localRun m f c=some (cost,d)) : 0<cost := by
  cases f with
  | zero => simp [localRun,hi] at hr
  | succ f =>
    cases hs : localStep m c with
    | none => simp [localRun,hi,hs] at hr
    | some e =>
      cases he : localRun m f e with
      | none => simp [localRun,hi,hs,he] at hr
      | some v =>
        obtain ⟨n,t⟩ := v
        have hh : n+1=cost := by simpa [localRun,hi,hs,he] using congrArg (Option.map Prod.fst) hr
        omega

theorem rle_inside (c : RleCfg k) (hk : 0<k) : inside c.local=true := by
  apply (inside_iff c.local).mpr
  simp only [RleCfg.local,RleCfg.offset,c.word.property]
  split <;> omega

theorem single_right_rle (k : Nat) (hk : 0<k) (m : Machine) (c : RleCfg k)
    (f cost : Nat) (q : Fin 6) (v : Word k)
    (hr : localRun m f c.local=some (cost,⟨q,k,v.val⟩)) (b : Int) :
    run m cost (c.source b)=some ((c.goRight q v 1).source (b+1)) := by
  have h := single_block_sound k hk m (c.grid b) f cost q k v (by simpa [BlockCfg.local,RleCfg.grid,RleCfg.wordAt,RleCfg.local] using hr)
  have hw := right_words c q v 1 (by decide) b
  have he : writeBlock (c.grid b).words b v = writeInterval (c.grid b).words b (b+1) v := by
    funext i
    have hh : (i=b) ↔ (b≤i ∧ i<b+1) := by omega
    simp [writeBlock,writeInterval,hh]
  simp only [RleCfg.grid] at h
  change writeBlock (fun i => c.wordAt (i-b)) b v = writeInterval (fun i => c.wordAt (i-b)) b (b+1) v at he
  change ((c.goRight q v 1).grid (b+1)).words = writeInterval (fun i => c.wordAt (i-b)) b (b+1) v at hw
  rw [he,←hw] at h
  change run m cost (c.source b)=some (BlockCfg.source ⟨q,b,k,((c.goRight q v 1).grid (b+1)).words⟩) at h
  rw [h]
  congr 1
  unfold RleCfg.source BlockCfg.source RleCfg.grid RleCfg.offset RleCfg.goRight
  congr 1
  · simp [Int.add_mul]

theorem single_left_rle (k : Nat) (hk : 0<k) (m : Machine) (c : RleCfg k)
    (f cost : Nat) (q : Fin 6) (v : Word k)
    (hr : localRun m f c.local=some (cost,⟨q,-1,v.val⟩)) (b : Int) :
    run m cost (c.source b)=some ((c.goLeft q v 1).source (b-1)) := by
  have h := single_block_sound k hk m (c.grid b) f cost q (-1) v (by simpa [BlockCfg.local,RleCfg.grid,RleCfg.wordAt,RleCfg.local] using hr)
  have hw := left_words c q v 1 (by decide) b
  have he : writeBlock (c.grid b).words b v = writeInterval (c.grid b).words (b-1+1) (b+1) v := by
    funext i
    have hh : (i=b) ↔ (b-1+1≤i ∧ i<b+1) := by omega
    simp [writeBlock,writeInterval,hh]
  simp only [RleCfg.grid] at h
  change writeBlock (fun i => c.wordAt (i-b)) b v = writeInterval (fun i => c.wordAt (i-b)) (b-1+1) (b+1) v at he
  change ((c.goLeft q v 1).grid (b-1)).words = writeInterval (fun i => c.wordAt (i-b)) (b-1+1) (b+1) v at hw
  rw [he,←hw] at h
  change run m cost (c.source b)=some (BlockCfg.source ⟨q,b,-1,((c.goLeft q v 1).grid (b-1)).words⟩) at h
  rw [h]
  congr 1
  unfold RleCfg.source BlockCfg.source RleCfg.grid RleCfg.offset RleCfg.goLeft
  congr 1
  · simp [Int.sub_mul]; omega

theorem batch_right_rle (k : Nat) (hk : 0<k) (m : Machine) (c : RleCfg k)
    (f cost n : Nat) (hn : 0<n) (v : Word k) (hs : c.side=false)
    (hr : localRun m f c.local=some (cost,⟨c.state,k,v.val⟩))
    (hp : prefixSame c.word c.right (n-1)=true) (b : Int) :
    run m (cost*n) (c.source b)=some ((c.goRight c.state v n).source (b+(n:Int))) := by
  have hmatch : ∀ j : Nat, j<n → (c.grid b).words (b+(j:Int))=c.word := by
    intro j hj
    change c.wordAt (b+(j:Int)-b)=c.word
    rw [show b+(j:Int)-b=(j:Int) by omega]
    by_cases hz : j=0
    · simp [RleCfg.wordAt,hz]
    · have hh := prefixSame_sound c.word c.right (n-1) hp (j-1) (by omega)
      simp only [RleCfg.wordAt,show (j:Int)≠0 by omega,show ¬(j:Int)<0 by omega,ite_false]
      rw [show ((j:Int)-1).toNat=j-1 by omega]; exact hh
  have hh := batch_right_sound k hk m f cost n c.state b (c.grid b).words c.word v
    (by simpa [RleCfg.local,RleCfg.offset,hs] using hr) hmatch
  rw [←right_words c c.state v n hn b] at hh
  simpa [RleCfg.source,RleCfg.grid,RleCfg.offset,hs,RleCfg.goRight] using hh

theorem batch_left_rle (k : Nat) (hk : 0<k) (m : Machine) (c : RleCfg k)
    (f cost n : Nat) (hn : 0<n) (v : Word k) (hs : c.side=true)
    (hr : localRun m f c.local=some (cost,⟨c.state,-1,v.val⟩))
    (hp : prefixSame c.word c.left (n-1)=true) (b : Int) :
    run m (cost*n) (c.source b)=some ((c.goLeft c.state v n).source (b-(n:Int))) := by
  have hmatch : ∀ j : Nat, j<n → (c.grid b).words (b-(j:Int))=c.word := by
    intro j hj
    change c.wordAt (b-(j:Int)-b)=c.word
    rw [show b-(j:Int)-b= -(j:Int) by omega]
    by_cases hz : j=0
    · simp [RleCfg.wordAt,hz]
    · have hh := prefixSame_sound c.word c.left (n-1) hp (j-1) (by omega)
      simp only [RleCfg.wordAt,show -(j:Int)≠0 by omega,show -(j:Int)<0 by omega,ite_false,ite_true]
      rw [show (-(-(j:Int))-1).toNat=j-1 by omega]; exact hh
  have hh := batch_left_sound k hk m f cost n c.state b (c.grid b).words c.word v
    (by simpa [RleCfg.local,RleCfg.offset,hs] using hr) hmatch
  rw [←left_words c c.state v n hn b] at hh
  simpa [RleCfg.source,RleCfg.grid,RleCfg.offset,hs,RleCfg.goLeft] using hh

/-- One proof-carrying block macro: nontrivial straight repeats need the
    matching entry edge, unchanged state, and a checked prefix. -/
inductive Macro (m : Machine) : RleCfg k → Nat → Int → RleCfg k → Prop where
  | right (c : RleCfg k) (f cost : Nat) (q : Fin 6) (v : Word k)
      (hr : localRun m f c.local=some (cost,⟨q,k,v.val⟩)) : Macro m c cost 1 (c.goRight q v 1)
  | left (c : RleCfg k) (f cost : Nat) (q : Fin 6) (v : Word k)
      (hr : localRun m f c.local=some (cost,⟨q,-1,v.val⟩)) : Macro m c cost (-1) (c.goLeft q v 1)
  | manyRight (c : RleCfg k) (f cost n : Nat) (v : Word k) (hn : 0<n) (hs : c.side=false)
      (hr : localRun m f c.local=some (cost,⟨c.state,k,v.val⟩))
      (hp : prefixSame c.word c.right (n-1)=true) : Macro m c (cost*n) n (c.goRight c.state v n)
  | manyLeft (c : RleCfg k) (f cost n : Nat) (v : Word k) (hn : 0<n) (hs : c.side=true)
      (hr : localRun m f c.local=some (cost,⟨c.state,-1,v.val⟩))
      (hp : prefixSame c.word c.left (n-1)=true) : Macro m c (cost*n) (-(n:Int)) (c.goLeft c.state v n)

theorem Macro.sound (hk : 0<k) {m : Machine} {c d : RleCfg k} {cost : Nat} {shift : Int}
    (h : Macro m c cost shift d) (b : Int) : run m cost (c.source b)=some (d.source (b+shift)) := by
  cases h with
  | right f cost q v hr => exact single_right_rle k hk m c f cost q v hr b
  | left f cost q v hr => simpa [Int.sub_eq_add_neg] using single_left_rle k hk m c f cost q v hr b
  | manyRight f cost n v hn hs hr hp => exact batch_right_rle k hk m c f cost n hn v hs hr hp b
  | manyLeft f cost n v hn hs hr hp => simpa [Int.sub_eq_add_neg] using batch_left_rle k hk m c f cost n hn v hs hr hp b

theorem Macro.positive (hk : 0<k) {m : Machine} {c d : RleCfg k} {cost : Nat} {shift : Int}
    (h : Macro m c cost shift d) : 0<cost := by
  cases h with
  | right f cost q v hr => exact local_cost_pos m f cost c.local _ (rle_inside c hk) hr
  | left f cost q v hr => exact local_cost_pos m f cost c.local _ (rle_inside c hk) hr
  | manyRight f cost n v hn hs hr hp => exact Nat.mul_pos (local_cost_pos m f cost c.local _ (rle_inside c hk) hr) hn
  | manyLeft f cost n v hn hs hr hp => exact Nat.mul_pos (local_cost_pos m f cost c.local _ (rle_inside c hk) hr) hn

def rleBlank (k : Nat) : RleCfg k := ⟨⟨0,by decide⟩,false,zeroWord k,[],[]⟩

theorem rleBlank_source (k : Nat) : (rleBlank k).source 0=blank := by
  unfold RleCfg.source RleCfg.grid BlockCfg.source RleCfg.offset rleBlank blank
  simp only [Bool.false_eq_true,ite_false,Int.zero_mul,Int.add_zero]
  congr 1
  funext x
  unfold blockTape RleCfg.wordAt
  simp only [Int.sub_zero,lookup]
  split
  · simp [zeroWord,List.getElem?_replicate]; split <;> rfl
  · split <;> simp [zeroWord,List.getElem?_replicate] <;> split <;> rfl

#print axioms Macro.sound
#print axioms Macro.positive
#print axioms rleBlank_source
end BB6Block
