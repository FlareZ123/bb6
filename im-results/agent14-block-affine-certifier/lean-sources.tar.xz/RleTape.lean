import BlockTape

namespace BB6Block
open BB6Coverage

abbrev Runs (k : Nat) := List (Word k × Nat)

def lookup : Runs k → Nat → Word k
  | [],_ => zeroWord k
  | (w,n)::xs,i => if i<n then w else lookup xs (i-n)

def dropBlocks (n : Nat) : Runs k → Runs k
  | [] => []
  | (w,c)::xs => if n<c then (w,c-n)::xs else dropBlocks (n-c) xs

def pushBlocks (w : Word k) (n : Nat) (xs : Runs k) : Runs k :=
  if n=0 then xs else
  match xs with
  | [] => if w=zeroWord k then [] else [(w,n)]
  | (v,c)::rest => if w=v then (w,n+c)::rest else (w,n)::xs

theorem lookup_drop (xs : Runs k) (n i : Nat) :
    lookup (dropBlocks n xs) i=lookup xs (n+i) := by
  induction xs generalizing n i with
  | nil => rfl
  | cons x xs ih =>
    obtain ⟨w,c⟩ := x
    by_cases h : n<c
    · simp only [dropBlocks,h,ite_true,lookup]
      by_cases hi : i<c-n
      · simp [hi,show n+i<c by omega]
      · simp [hi,show ¬n+i<c by omega,show i-(c-n)=n+i-c by omega]
    · simp only [dropBlocks,h,ite_false,lookup,show ¬n+i<c by omega]
      rw [ih,show n-c+i=n+i-c by omega]

theorem lookup_push (xs : Runs k) (w : Word k) (n i : Nat) :
    lookup (pushBlocks w n xs) i=if i<n then w else lookup xs (i-n) := by
  by_cases hn : n=0
  · simp [pushBlocks,hn]
  cases xs with
  | nil =>
    by_cases hw : w=zeroWord k
    · simp [pushBlocks,hn,hw,lookup]
    · simp [pushBlocks,hn,hw,lookup]
  | cons x xs =>
    obtain ⟨v,c⟩ := x
    by_cases hw : w=v
    · subst v
      simp only [pushBlocks,hn,ite_false,ite_true,lookup]
      by_cases hi : i<n
      · simp [hi,show i<n+c by omega]
      · by_cases hj : i<n+c
        · simp [hi,hj,show i-n<c by omega]
        · simp [hi,hj,show ¬i-n<c by omega,show i-(n+c)=i-n-c by omega]
    · simp [pushBlocks,hn,hw,lookup]

structure RleCfg (k : Nat) where
  state : Fin 6
  side : Bool -- true: head at right edge; false: left edge
  word : Word k
  left : Runs k
  right : Runs k
  deriving DecidableEq, Repr

def RleCfg.offset (c : RleCfg k) : Int := if c.side then (k:Int)-1 else 0

def RleCfg.wordAt (c : RleCfg k) (i : Int) : Word k :=
  if i=0 then c.word else if i<0 then lookup c.left (-i-1).toNat else lookup c.right (i-1).toNat

def RleCfg.grid (c : RleCfg k) (b : Int) : BlockCfg k :=
  ⟨c.state,b,c.offset,fun i => c.wordAt (i-b)⟩

def RleCfg.source (c : RleCfg k) (b : Int) : Config := (c.grid b).source

def RleCfg.local (c : RleCfg k) : Local := ⟨c.state,c.offset,c.word.val⟩

def RleCfg.goRight (c : RleCfg k) (q : Fin 6) (v : Word k) (n : Nat) : RleCfg k :=
  ⟨q,false,lookup c.right (n-1),pushBlocks v n c.left,dropBlocks n c.right⟩

def RleCfg.goLeft (c : RleCfg k) (q : Fin 6) (v : Word k) (n : Nat) : RleCfg k :=
  ⟨q,true,lookup c.left (n-1),dropBlocks n c.left,pushBlocks v n c.right⟩

/-- Moving the compressed zipper to the right writes precisely the interval
    of crossed blocks, and reindexes everything else without alteration. -/
theorem right_words (c : RleCfg k) (q : Fin 6) (v : Word k) (n : Nat) (hn : 0<n) (b : Int) :
    ((c.goRight q v n).grid (b+(n:Int))).words = writeInterval (c.grid b).words b (b+(n:Int)) v := by
  funext i
  let j := i-b
  have hj : i=b+j := by dsimp [j]; omega
  have he : i-(b+(n:Int))=j-(n:Int) := by omega
  change (c.goRight q v n).wordAt (i-(b+(n:Int))) = if b≤i ∧ i<b+(n:Int) then v else c.wordAt (i-b)
  rw [he]
  change (c.goRight q v n).wordAt (j-(n:Int)) = if b≤i ∧ i<b+(n:Int) then v else c.wordAt j
  by_cases h1 : j<(n:Int)
  · have hnz : j-(n:Int)≠0 := by omega
    have hneg : j-(n:Int)<0 := by omega
    simp only [RleCfg.wordAt,hnz,ite_false,hneg,ite_true,RleCfg.goRight,lookup_push]
    by_cases hj0 : 0≤j
    · have hpos : (- (j-(n:Int))-1).toNat<n := by omega
      simp only [hpos,show b≤i ∧ i<b+(n:Int) by omega,true_and,ite_true]
    · have hpos : ¬ (-(j-(n:Int))-1).toNat<n := by omega
      have hind : (-(j-(n:Int))-1).toNat-n=(-j-1).toNat := by omega
      simp only [hpos,hind,show ¬(b≤i ∧ i<b+(n:Int)) by omega,show j≠0 by omega,show j<0 by omega,ite_true,ite_false]
  · have hfalse : ¬(b≤i ∧ i<b+(n:Int)) := by omega
    have hjpos : 0<j := by omega
    by_cases heq : j=(n:Int)
    · have hidx : (j-1).toNat=n-1 := by omega
      simp only [RleCfg.wordAt,RleCfg.goRight,show j-(n:Int)=0 by omega,ite_true,hfalse,show ¬j<0 by omega,show j≠0 by omega,hidx,ite_false]
    · have hidx : n+(j-(n:Int)-1).toNat=(j-1).toNat := by omega
      simp only [RleCfg.wordAt,RleCfg.goRight,show j-(n:Int)≠0 by omega,show ¬j-(n:Int)<0 by omega,hfalse,show j≠0 by omega,show ¬j<0 by omega,lookup_drop,hidx,ite_false]

/-- The mirrored compressed zipper update, with unchanged exterior. -/
theorem left_words (c : RleCfg k) (q : Fin 6) (v : Word k) (n : Nat) (hn : 0<n) (b : Int) :
    ((c.goLeft q v n).grid (b-(n:Int))).words = writeInterval (c.grid b).words (b-(n:Int)+1) (b+1) v := by
  funext i
  let j := i-b
  have hj : i=b+j := by dsimp [j]; omega
  have he : i-(b-(n:Int))=j+(n:Int) := by omega
  change (c.goLeft q v n).wordAt (i-(b-(n:Int))) = if b-(n:Int)+1≤i ∧ i<b+1 then v else c.wordAt (i-b)
  rw [he]
  change (c.goLeft q v n).wordAt (j+(n:Int)) = if b-(n:Int)+1≤i ∧ i<b+1 then v else c.wordAt j
  by_cases h1 : - (n:Int)<j
  · have hnz : j+(n:Int)≠0 := by omega
    have hneg : ¬ j+(n:Int)<0 := by omega
    simp only [RleCfg.wordAt,hnz,ite_false,hneg,RleCfg.goLeft,lookup_push]
    by_cases hj0 : j≤0
    · have hpos : (j+(n:Int)-1).toNat<n := by omega
      simp only [hpos,show b-(n:Int)+1≤i ∧ i<b+1 by omega,true_and,ite_true]
    · have hpos : ¬ (j+(n:Int)-1).toNat<n := by omega
      have hind : (j+(n:Int)-1).toNat-n=(j-1).toNat := by omega
      simp only [hpos,hind,show ¬(b-(n:Int)+1≤i ∧ i<b+1) by omega,show j≠0 by omega,show ¬j<0 by omega,ite_false]
  · have hfalse : ¬(b-(n:Int)+1≤i ∧ i<b+1) := by omega
    have hjpos : j<0 := by omega
    by_cases heq : j= -(n:Int)
    · have hidx : (-j-1).toNat=n-1 := by omega
      simp only [RleCfg.wordAt,RleCfg.goLeft,show j+(n:Int)=0 by omega,hfalse,show j<0 by omega,show j≠0 by omega,hidx,ite_true,ite_false]
    · have hidx : n+(-(j+(n:Int))-1).toNat=(-j-1).toNat := by omega
      simp only [RleCfg.wordAt,RleCfg.goLeft,show j+(n:Int)≠0 by omega,show j+(n:Int)<0 by omega,hfalse,show j≠0 by omega,show j<0 by omega,lookup_drop,hidx,ite_true,ite_false]

#print axioms right_words
#print axioms left_words
end BB6Block
