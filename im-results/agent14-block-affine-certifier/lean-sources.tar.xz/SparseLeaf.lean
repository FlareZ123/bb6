import AffineLoop
namespace BB6Block
open BB6Coverage

/-- Unassigned entries are pessimistically absent. A *successful* step
    under this projection necessarily uses an assigned ordinary row. -/
def pessimistic (p : PartialMachine) : Machine := fun s => (p s).join

theorem pessimistic_step {p : PartialMachine} {m : Machine} (hc : compatible p m)
    {c d : Config} (h : rawStep (pessimistic p) c=some d) : rawStep m c=some d := by
  cases hp : p (readSlot c) with
  | none => simp [rawStep,pessimistic,hp] at h
  | some a =>
    cases a with
    | none => simp [rawStep,pessimistic,hp] at h
    | some t =>
      have hm := hc (readSlot c) (some t) hp
      simpa [rawStep,pessimistic,hp,hm] using h

theorem pessimistic_run {p : PartialMachine} {m : Machine} (hc : compatible p m)
    (n : Nat) {c d : Config} (h : run (pessimistic p) n c=some d) : run m n c=some d := by
  induction n generalizing d with
  | zero => simpa [run] using h
  | succ n ih =>
    cases hr : run (pessimistic p) n c with
    | none => simp [run,hr] at h
    | some v =>
      have hv := ih hr
      have hs : rawStep (pessimistic p) v=some d := by simpa [run,hr] using h
      simpa [run,hv] using pessimistic_step hc hs

theorem pessimistic_never_leaf (p : PartialMachine) (B : Nat)
    (h : NeverHalts (pessimistic p)) : Cover (DecidedBelow B) p := by
  apply Cover.leaf
  intro m hc
  left
  intro n
  cases hr : run (pessimistic p) n blank with
  | none => have hn := h n; simp [hr] at hn
  | some d => simp [pessimistic_run hc n hr]

/-- An actually assigned halt, unlike an unassigned row, certifies the
    final attempted query for every compatible completion. -/
theorem pessimistic_halt_leaf (p : PartialMachine) (B n : Nat) (d : Config)
    (h : run (pessimistic p) n blank=some d) (hh : p (readSlot d)=some none)
    (hb : n+1≤B) : Cover (DecidedBelow B) p := by
  apply Cover.leaf
  intro m hc
  have hr := pessimistic_run hc n h
  have hstop := hc _ _ hh
  right
  exact ⟨n,hb,by simp [HaltsAfter,run,hr,rawStep,hstop]⟩

theorem segment_halt_leaf (p : PartialMachine) (B n : Nat) (s : Int) (c : RleCfg k)
    (h : Segment (pessimistic p) (rleBlank k) c n s)
    (hh : p (readSlot (c.source s))=some none) (hb : n+1≤B) : Cover (DecidedBelow B) p := by
  apply pessimistic_halt_leaf p B n (c.source s) _ hh hb
  simpa [rleBlank_source] using h 0

/-- Counted macro replay directly produces a universal sparse-table leaf.
    Final halt must be explicitly assigned in the input partial table. -/
theorem checked_halt_leaf (p : PartialMachine) (B : Nat) (k : Nat) (hk : 0<k)
    (xs : List MacroSpec) (v : Checked k)
    (h : checkPath (pessimistic p) xs (rleBlank k)=some v)
    (hh : p (readSlot (v.target.source v.shift))=some none) (hb : v.cost+1≤B) : Cover (DecidedBelow B) p :=
  segment_halt_leaf p B v.cost v.shift v.target (Segment.path (pessimistic p) hk xs _ v h) hh hb

#print axioms pessimistic_never_leaf
#print axioms checked_halt_leaf
end BB6Block
