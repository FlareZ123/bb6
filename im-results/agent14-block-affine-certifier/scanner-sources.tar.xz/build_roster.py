"""Encode a newline-delimited rooted BB6 roster after removing optional tables.

Pass the exact historical roster and any subsequent removal TSVs. A removal
is recognized by the original 6-state standard-format string in a TSV field.
The resulting roster order is inherited from the input roster.
"""
import argparse
import hashlib
import pathlib
import re

PATTERN = re.compile(r'(?:(?:[01][LR][A-F]|---){2}_){5}(?:[01][LR][A-F]|---){2}')

def read_tables(path):
    return PATTERN.findall(pathlib.Path(path).read_text())

def encode(table):
    entries = re.findall(r'[01][LR][A-F]|---', table)
    assert len(entries) == 12 and entries[0] == '1RB', table
    return ''.join('Y' if t == '---' else chr(ord('A')+12*int(t[0])+6*(t[1]=='R')+ord(t[2])-ord('A')) for t in entries[1:])

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('roster')
    parser.add_argument('removal_tsvs', nargs='*')
    args = parser.parse_args()
    removed = {table for p in args.removal_tsvs for table in read_tables(p)}
    roster = [t for t in read_tables(args.roster) if t not in removed]
    assert len(set(roster)) == len(roster)
    raw = '\n'.join(roster)+'\n'
    pathlib.Path('roster.txt').write_text(raw)
    pathlib.Path('roster.enc').write_text(''.join(map(encode, roster))+'\n')
    print(len(roster), hashlib.sha256(raw.encode()).hexdigest())

if __name__ == '__main__':
    main()
