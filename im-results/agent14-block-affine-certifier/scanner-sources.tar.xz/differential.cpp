#define main scanner_main
#include "scan5.cpp"
#undef main
#include <cassert>
#include <random>
#include <set>

// Primitive implementation deliberately does not call Machine::get, step,
// or any run-length or affine arithmetic.
struct Primitive {
  int q=0, head=0;
  set<int> tape;
  bool step(const array<Tr,12>& table) {
    auto t=table[2*q+tape.count(head)];
    if(t.q<0) return false;
    if(t.w) tape.insert(head); else tape.erase(head);
    head+=t.d; q=t.q; return true;
  }
};
long long comparisons=0,primitives=0;
void check(const Config<N>& c,const Primitive& p,int k) {
  int base=p.head-(p.head%k+k)%k;
  assert(p.head==base+(c.side?k-1:0)); assert(c.q==p.q);
  set<int> tape;
  auto word=[&](int addr,int w){for(int i=0;i<k;i++)if(w>>i&1)tape.insert(addr+i);};
  word(base,c.w);
  for(auto side:{-1,1}) {
    const auto& runs=side<0?c.l:c.r;
    int addr=base+side*k;
    for(auto i=runs.rbegin();i!=runs.rend();++i) {
      assert(i->n>0 && i->n<1000000);int n=i->n.convert_to<int>();
      for(int j=0;j<n;j++,addr+=side*k) word(addr,i->w);
    }
  }
  assert(tape==p.tape);
}
void exercise(string enc,int width,int cap) {
  Machine m(enc,width);Config<N> c;Primitive p;N cost=0;
  for(int i=0;i<cap;i++) {
    N prev=cost;int status=step(m,c,cost);N delta=cost-prev;
    if(status!=0&&status!=1)break; // rays and local cycles have separate soundness obligations
    if(delta>100000||cost>1000000)break;
    int n=delta.convert_to<int>();
    for(int j=0;j<n;j++){assert(p.step(m.t));primitives++;}
    if(status==1){assert(!p.step(m.t));break;}
    check(c,p,width);comparisons++;
  }
}
int main(int argc,char**argv){
  mt19937 rng(141124);uniform_int_distribution<int> tr(0,24);
  for(int width=1;width<=6;width++) {
    for(int i=0;i<300;i++){string enc;for(int j=0;j<11;j++)enc+=char('A'+tr(rng));exercise(enc,width,300);}
    ifstream f(argc>1?argv[1]:"roster.enc");string roster;f>>roster;
    assert(roster.size()%11==0);
    for(size_t i=0;i<roster.size();i+=11)exercise(roster.substr(i,11),width,300);
  }
  cout<<"successful macro comparisons="<<comparisons<<"; primitive steps replayed="<<primitives<<"\n";
}
