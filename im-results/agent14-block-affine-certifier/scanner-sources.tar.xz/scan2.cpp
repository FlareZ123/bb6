#include <algorithm>
#include <array>
#include <boost/multiprecision/cpp_int.hpp>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
using namespace std; using N=boost::multiprecision::cpp_int;
struct Aff{N a=0,b=0; Aff(){} Aff(N b):b(b){} Aff(N a,N b):a(a),b(b){} Aff(int b):b(b){} friend bool operator==(const Aff&x,const Aff&y){return x.a==y.a&&x.b==y.b;} friend Aff operator+(const Aff&x,const Aff&y){return {x.a+y.a,x.b+y.b};} friend Aff operator-(const Aff&x,const Aff&y){return {x.a-y.a,x.b-y.b};}};
struct Tr{int w,d,q;};
struct Exit{int w,q,d,status; unsigned long long steps;}; // 0 exit, 1 halt, 2 internal cycle, 3 budget
struct Machine{array<Tr,12> t; int k; unordered_map<uint32_t,Exit> cache; vector<uint32_t> stamps;uint32_t stamp=0;Machine(string enc,int k):k(k){enc="T"+enc;for(int i=0;i<12;i++){int x=enc[i]-'A';t[i]={x/12,(x/6)%2?1:-1,x==24?-1:x%6};}if(k<=12) stamps.resize(6*k*(1<<k));}
 Exit get(int q,int side,int w){uint32_t key=(w*6+q)*2+side;auto it=cache.find(key);if(it!=cache.end())return it->second;int p=side?k-1:0;unsigned long long n=0;unordered_set<uint32_t> seen;++stamp;Exit e;while(true){uint32_t z=(w*6+q)*k+p;if(stamps.empty()){if(!seen.insert(z).second){e={w,q,0,2,n};break;}}else{if(stamps[z]==stamp){e={w,q,0,2,n};break;}stamps[z]=stamp;}auto tr=t[2*q+((w>>p)&1)];if(tr.q<0){e={w,q,0,1,n};break;}w=(w&~(1<<p))|(tr.w<<p);q=tr.q;p+=tr.d;++n;if(p<0||p>=k){e={w,q,tr.d,0,n};break;}if(n>1000000){e={w,q,0,3,n};break;}}cache.emplace(key,e);return e;}
};
template<class C> struct Run{int w;C n;};
template<class C> struct Config{int q=0,side=0,w=0;vector<Run<C>> l,r;};
template<class C> void push(vector<Run<C>>&s,int w,C n){if(s.empty()&&w==0)return;if(!s.empty()&&s.back().w==w)s.back().n=s.back().n+n;else s.push_back({w,n});}
// Only batch identical-block exits with the same state and entry side.
int step(Machine&m,Config<N>&c,N&time){auto e=m.get(c.q,c.side,c.w);time+=e.steps;if(e.status)return e.status;auto&src=e.d==1?c.r:c.l;auto&dst=e.d==1?c.l:c.r;N n=1;bool straight=(e.d==1&&c.side==0)||(e.d==-1&&c.side==1);if(straight&&e.q==c.q){if(src.empty()&&c.w==0)return 4;if(!src.empty()&&src.back().w==c.w){n+=src.back().n;src.pop_back();time+=(n-1)*e.steps;if(src.empty()&&c.w==0)return 4;}}push(dst,e.w,n);if(src.empty())c.w=0;else{c.w=src.back().w;if(--src.back().n==0)src.pop_back();}c.q=e.q;c.side=e.d==1?0:1;return 0;}
// Uniform symbolic replay on a maximal initial interval t>=0.
// A count test is resolved at t=0, then the entire interval is constrained.
struct Dom{optional<N> hi;void cap(N x){if(!hi||x<*hi)hi=x;}bool ge(Aff x,int k){if(x.b<k)return false;if(x.a<0)cap((x.b-k)/(-x.a));return true;}bool eq(Aff x,int k){if(x.b!=k)return false;if(x.a!=0)cap(0);return true;}};
int stepAff(Machine&m,Config<Aff>&c,Dom&dom,Aff&cost){auto e=m.get(c.q,c.side,c.w);if(e.status)return e.status;auto&src=e.d==1?c.r:c.l;auto&dst=e.d==1?c.l:c.r;Aff n(1);bool straight=(e.d==1&&c.side==0)||(e.d==-1&&c.side==1);if(straight&&e.q==c.q){if(src.empty()&&c.w==0)return 4;if(!src.empty()&&src.back().w==c.w){n=n+src.back().n;src.pop_back();if(src.empty()&&c.w==0)return 4;}}
 cost=cost+Aff(n.a*e.steps,n.b*e.steps);push(dst,e.w,n);if(src.empty())c.w=0;else{c.w=src.back().w;auto a=src.back().n;if(a.b==1){if(!dom.eq(a,1))return 5;src.pop_back();}else{if(!dom.ge(a,2))return 5;src.back().n=a-Aff(1);}}c.q=e.q;c.side=e.d==1?0:1;return 0;}
template<class C> string shape(const Config<C>&c){string s;auto put=[&](int x){s.push_back(x&255);s.push_back((x>>8)&255);};put(c.q*2+c.side);put(c.w);put(c.l.size());for(auto&x:c.l)put(x.w);for(auto&x:c.r)put(x.w);return s;}
template<class C> vector<C> counts(const Config<C>&c){vector<C>a;for(auto&x:c.l)a.push_back(x.n);for(auto&x:c.r)a.push_back(x.n);return a;}
struct Seen{int step;vector<N>a;optional<vector<N>>d;};
string dump(const Config<N>&c){ostringstream o;o<<c.q<<":"<<c.side<<":"<<c.w<<":";for(auto x:c.l)o<<x.w<<"^"<<x.n<<",";o<<"|";for(auto x:c.r)o<<x.w<<"^"<<x.n<<",";return o.str();}
struct Rule{Dom dom;Aff cost;};
optional<Rule> prove(Machine&m,const Config<N>&c,const vector<N>&d,int period){Config<Aff>a;a.q=c.q;a.side=c.side;a.w=c.w;size_t i=0;Rule rule;for(auto x:c.l){a.l.push_back({x.w,{d[i++],x.n}});if(!rule.dom.ge(a.l.back().n,1))return nullopt;}for(auto x:c.r){a.r.push_back({x.w,{d[i++],x.n}});if(!rule.dom.ge(a.r.back().n,1))return nullopt;}auto s=shape(a);auto v=counts(a);for(int j=0;j<period;j++){if(stepAff(m,a,rule.dom,rule.cost))return nullopt;if(a.l.size()+a.r.size()>256)return nullopt;if(rule.dom.hi&&*rule.dom.hi==0)return nullopt;}if(shape(a)!=s)return nullopt;auto w=counts(a);for(size_t j=0;j<v.size();j++){if(w[j].a!=v[j].a||w[j].b!=v[j].b+v[j].a)return nullopt;}return rule;}
string decode(string enc){enc="T"+enc;string s;for(int i=0;i<12;i++){if(i&&i%2==0)s+='_';int x=enc[i]-'A';if(x==24)s+="---";else{s+=char('0'+x/12);s+=(x/6)%2?'R':'L';s+=char('A'+x%6);}}return s;}
struct Outcome{int status,macro;N time;int runs;};
Outcome scan(string enc,int k,int cap,int row,int maxruns){Machine m(enc,k);Config<N>c;N time=0;unordered_map<string,Seen>seen;int best=0,tries=0,jumps=0;N skipped=0;for(int j=0;j<cap;j++){int nr=c.l.size()+c.r.size();best=max(best,nr);if(nr>maxruns)return {6,j,time,best};bool jumped=false;if(nr<=32){auto s=shape(c);auto a=counts(c);auto it=seen.find(s);if(it!=seen.end()){auto&p=it->second;vector<N>d;bool strict=false;for(size_t i=0;i<a.size();i++){N x=a[i]-p.a[i];if(x!=0)strict=true;d.push_back(x);}int period=j-p.step;if(!strict){cout<<"CYCLE row="<<row<<" width="<<k<<" macro="<<j<<" period="<<period<<" steps="<<time<<" config="<<dump(c)<<" jumps="<<jumps<<"\n"<<flush;return {7,j,time,best};}if(period<=2000&&tries<20000&&p.d&&*p.d==d){tries++;auto r=prove(m,c,d,period);if(r){if(!r->dom.hi){cout<<"AFFINE row="<<row<<" width="<<k<<" macro="<<j<<" period="<<period<<" steps="<<time<<" config="<<dump(c)<<" delta=";for(auto x:d)cout<<x<<",";cout<<" jumps="<<jumps<<"\n"<<flush;return {8,j,time,best};}N T=*r->dom.hi+1;if(T>=2){size_t i=0;for(auto&x:c.l){x.n+=d[i++]*T;if(x.n<=0)abort();}for(auto&x:c.r){x.n+=d[i++]*T;if(x.n<=0)abort();}time+=r->cost.b*T+r->cost.a*T*(T-1)/2;skipped+=T*period;jumps++;jumped=true;seen.clear();}}}if(!jumped)p={j,a,d};}else if(seen.size()<10000)seen.emplace(s,Seen{j,a,nullopt});}if(jumped)continue;int status=step(m,c,time);if(status){cout<<"EVENT row="<<row<<" width="<<k<<" status="<<status<<" macro="<<j<<" steps="<<time<<" config="<<dump(c)<<" jumps="<<jumps<<"\n"<<flush;return {status,j,time,best};}}return {0,cap,time,best};}
int main(int argc,char**argv){string file=argc>1?argv[1]:"roster.enc";int cap=argc>2?stoi(argv[2]):10000,k=argc>3?stoi(argv[3]):1,start=argc>4?stoi(argv[4]):1,end=argc>5?stoi(argv[5]):608,maxruns=argc>6?stoi(argv[6]):10000;ifstream f(file);string s;f>>s;if(s.size()%11){cerr<<"bad roster";return 1;}for(int i=start-1;i<end&&i<int(s.size()/11);i++){auto enc=s.substr(i*11,11);auto o=scan(enc,k,cap,i+1,maxruns);cerr<<i+1<<"\t"<<k<<"\t"<<o.status<<"\t"<<o.macro<<"\t"<<o.time<<"\t"<<o.runs<<"\t"<<decode(enc)<<"\n";}}
