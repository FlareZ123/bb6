#include <memory>
#include <algorithm>
#include <array>
#include <boost/multiprecision/cpp_int.hpp>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
using namespace std; using N=boost::multiprecision::cpp_int;
struct Aff{N a=0,b=0; Aff(){} Aff(N b):b(b){} Aff(N a,N b):a(a),b(b){} Aff(int b):b(b){} friend bool operator==(const Aff&x,const Aff&y){return x.a==y.a&&x.b==y.b;} friend Aff operator+(const Aff&x,const Aff&y){return {x.a+y.a,x.b+y.b};} friend Aff operator-(const Aff&x,const Aff&y){return {x.a-y.a,x.b-y.b};}};
struct Tr{int w,d,q;};
struct Exit{int w,q,d,status; unsigned long long steps;}; // 0 exit, 1 halt, 2 internal cycle, 3 budget
struct Machine{array<Tr,12> t; int k; unordered_map<uint32_t,Exit> cache; vector<uint32_t> stamps;uint32_t stamp=0;Machine(string enc,int k):k(k){enc="T"+enc;for(int i=0;i<12;i++){int x=enc[i]-'A';t[i]={x/12,(x/6)%2?1:-1,x==24?-1:x%6};}if(k<=12) stamps.resize(6*k*(1<<k));}
 Exit get(int q,int side,int w){uint32_t key=(w*6+q)*2+side;auto it=cache.find(key);if(it!=cache.end())return it->second;int p=side?k-1:0;unsigned long long n=0;unordered_set<uint32_t> seen;++stamp;Exit e;while(true){uint32_t z=(w*6+q)*k+p;if(stamps.empty()){if(!seen.insert(z).second){e={w,q,0,2,n};break;}}else{if(stamps[z]==stamp){e={w,q,0,2,n};break;}stamps[z]=stamp;}auto tr=t[2*q+((w>>p)&1)];if(tr.q<0){e={w,q,0,1,n};break;}w=(w&~(1<<p))|(tr.w<<p);q=tr.q;p+=tr.d;++n;if(p<0||p>=k){e={w,q,tr.d,0,n};break;}if(n>1000000){e={w,q,0,3,n};break;}}cache.emplace(key,e);return e;}
};
template<class C> struct Run{int w;C n;};
template<class C> struct Config{int q=0,side=0,w=0;vector<Run<C>> l,r;};
template<class C> void push(vector<Run<C>>&s,int w,C n){if(s.empty()&&w==0)return;if(!s.empty()&&s.back().w==w)s.back().n=s.back().n+n;else s.push_back({w,n});}
// Only batch identical-block exits with the same state and entry side.
int step(Machine&m,Config<N>&c,N&time){auto e=m.get(c.q,c.side,c.w);time+=e.steps;if(e.status)return e.status;auto&src=e.d==1?c.r:c.l;auto&dst=e.d==1?c.l:c.r;N n=1;bool straight=(e.d==1&&c.side==0)||(e.d==-1&&c.side==1);if(straight&&e.q==c.q){if(src.empty()&&c.w==0)return 4;if(!src.empty()&&src.back().w==c.w){n+=src.back().n;src.pop_back();time+=(n-1)*e.steps;if(src.empty()&&c.w==0)return 4;}}push(dst,e.w,n);if(src.empty())c.w=0;else{c.w=src.back().w;if(--src.back().n==0)src.pop_back();}c.q=e.q;c.side=e.d==1?0:1;return 0;}
template<class C> string shape(const Config<C>&c){string s;auto put=[&](int x){s.push_back(x&255);s.push_back((x>>8)&255);};put(c.q*2+c.side);put(c.w);put(c.l.size());for(auto&x:c.l)put(x.w);for(auto&x:c.r)put(x.w);return s;}
template<class C> vector<C> counts(const Config<C>&c){vector<C>a;for(auto&x:c.l)a.push_back(x.n);for(auto&x:c.r)a.push_back(x.n);return a;}
// A linear expression in nonnegative symbolic loop indices.
struct Lin{N b=0;vector<N>a;Lin(){}Lin(int x):b(x){}Lin(N x):b(x){}N coef(int i)const{return i<int(a.size())?a[i]:N(0);}void set(int i,N v){if(i>=int(a.size()))a.resize(i+1);a[i]=v;while(!a.empty()&&a.back()==0)a.pop_back();}friend bool operator==(const Lin&x,const Lin&y){return x.b==y.b&&x.a==y.a;}friend Lin operator+(Lin x,const Lin&y){x.b+=y.b;if(x.a.size()<y.a.size())x.a.resize(y.a.size());for(size_t i=0;i<y.a.size();i++)x.a[i]+=y.a[i];while(!x.a.empty()&&x.a.back()==0)x.a.pop_back();return x;}friend Lin operator*(Lin x,const N&k){x.b*=k;for(auto&v:x.a)v*=k;while(!x.a.empty()&&x.a.back()==0)x.a.pop_back();return x;}friend Lin operator-(Lin x,const Lin&y){return x+y*N(-1);}bool nonneg()const{return b>=0&&all_of(a.begin(),a.end(),[](const N&x){return x>=0;});}};
struct Rule;
struct Op{shared_ptr<Rule> rule;}; // null = primitive block sweep
struct Rule{string key;vector<N>d;vector<Op>body;int depth=1;};
struct Guard{vector<Lin>v;bool add(Lin x){if(x.b<0)return false;if(x.nonneg())return true;v.push_back(move(x));return true;}bool universal()const{return all_of(v.begin(),v.end(),[](const Lin&x){return x.nonneg();});}};
// IMPORTANT: a guard with positive coefficients is tautological for all
// nonnegative variables; dropping it is sound, including when inner indices
// are later eliminated. All remaining guards are exact linear inequalities.
int stepLin(Machine&m,Config<Lin>&c,Guard&g){auto e=m.get(c.q,c.side,c.w);if(e.status)return e.status;auto&src=e.d==1?c.r:c.l;auto&dst=e.d==1?c.l:c.r;Lin n(1);bool straight=(e.d==1&&c.side==0)||(e.d==-1&&c.side==1);if(straight&&e.q==c.q){if(src.empty()&&c.w==0)return 4;if(!src.empty()&&src.back().w==c.w){n=n+src.back().n;src.pop_back();if(src.empty()&&c.w==0)return 4;}}
 push(dst,e.w,n);if(src.empty())c.w=0;else{c.w=src.back().w;auto a=src.back().n;if(a.b==1){if(!g.add(a-Lin(1))||!g.add(Lin(1)-a))return 5;src.pop_back();}else{if(!g.add(a-Lin(2)))return 5;src.back().n=a-Lin(1);}}c.q=e.q;c.side=e.d==1?0:1;return 0;}
Config<Lin> lift(const Config<N>&c){Config<Lin>a;a.q=c.q;a.side=c.side;a.w=c.w;for(auto x:c.l)a.l.push_back({x.w,Lin(x.n)});for(auto x:c.r)a.r.push_back({x.w,Lin(x.n)});return a;}
void setCounts(Config<Lin>&c,const vector<Lin>&v){size_t i=0;for(auto&x:c.l)x.n=v[i++];for(auto&x:c.r)x.n=v[i++];}
void setCounts(Config<N>&c,const vector<N>&v){size_t i=0;for(auto&x:c.l)x.n=v[i++];for(auto&x:c.r)x.n=v[i++];}
N floordiv(N a,const N&b){N q=a/b;if(a<0&&a%b!=0)--q;return q;}
// apply result: 0 failure, 1 finite (output and T), 2 infinite at origin.
struct App{int status=0;Lin T;};
App apply(Machine&m,Config<Lin>&c,const Rule&r,int dim,Guard&outer,int&budget);
bool replay(Machine&m,Config<Lin>&c,const vector<Op>&body,int dim,Guard&g,int&budget){for(auto&op:body){if(--budget<0||c.l.size()+c.r.size()>256)return false;if(op.rule){auto a=apply(m,c,*op.rule,dim,g,budget);if(a.status!=1)return false;}else if(stepLin(m,c,g))return false;}return true;}
App apply(Machine&m,Config<Lin>&c,const Rule&r,int dim,Guard&outer,int&budget){if(dim>5||r.depth>5||shape(c)!=r.key)return {};auto base=counts(c);if(base.size()!=r.d.size())return {};auto init=base;Guard g;for(size_t i=0;i<init.size();i++){init[i].set(dim,r.d[i]);if(!g.add(init[i]-Lin(1)))return {};}auto x=c;setCounts(x,init);if(!replay(m,x,r.body,dim+1,g,budget)||shape(x)!=r.key)return {};auto end=counts(x);for(size_t i=0;i<end.size();i++)if(!(end[i]==init[i]+Lin(r.d[i])))return {};
 // The maximum number of repetitions at the origin is determined by a
 // negative coefficient of the new loop index in one guard.
 optional<N> bound;Lin T;for(auto&v:g.v){N d=v.coef(dim);if(d>=0)continue;N z=v.b/(-d);if(!bound||z<*bound){bound=z;T=Lin(z+1);for(int k=0;k<dim;k++)T.set(k,floordiv(v.coef(k),-d));}}
 if(!bound)return {2,Lin()};
 // Eliminate the inner loop index by checking its minimizing endpoint.
 // Even when coefficient division is not exact, T is only a candidate;
 // these explicit guards prove it valid over the full outer domain.
 if(!outer.add(T-Lin(1)))return {};for(auto v:g.v){N d=v.coef(dim);v.set(dim,0);if(d<0)v=v+(T-Lin(1))*d;if(!outer.add(v))return {};}
 for(size_t i=0;i<base.size();i++)base[i]=base[i]+T*r.d[i];setCounts(c,base);return {1,T};}
struct Seen{int step;vector<N>a;optional<vector<N>>d;};
string dump(const Config<N>&c){ostringstream o;o<<c.q<<":"<<c.side<<":"<<c.w<<":";for(auto x:c.l)o<<x.w<<"^"<<x.n<<",";o<<"|";for(auto x:c.r)o<<x.w<<"^"<<x.n<<",";return o.str();}
// Nonnegative affine cone, with each strictly growing count independent.
bool proveCone(Machine&m,const Config<N>&c,const vector<N>&d,const Rule&r){auto a=lift(c);auto v=counts(a);int dim=0;for(size_t i=0;i<v.size();i++)if(d[i]>0)v[i].set(dim++,1);setCounts(a,v);Guard g;int budget=30000;if(!replay(m,a,r.body,dim,g,budget)||shape(a)!=r.key||!g.universal())return false;auto w=counts(a);for(size_t j=0;j<v.size();j++){if(d[j]>0){if(!(w[j]-Lin(v[j].b)).nonneg())return false;}else if(!(w[j]==v[j]))return false;}return true;}
// An invariant affine line, allowing t -> alpha*t+beta (geometric growth).
N gcdN(N a,N b){while(b!=0){N c=a%b;a=b;b=c;}return a;}
bool proveLine(Machine&m,const Config<N>&c,vector<N>d,const Rule&r){N g=0;for(auto x:d)g=gcdN(g,x);if(g==0)return false;for(auto&x:d)x/=g;auto a=lift(c);auto v=counts(a);for(size_t i=0;i<v.size();i++)v[i].set(0,d[i]);setCounts(a,v);Guard guards;int budget=30000;if(!replay(m,a,r.body,1,guards,budget)||shape(a)!=r.key||!guards.universal())return false;auto w=counts(a);N alpha=-1,beta=-1;for(size_t i=0;i<v.size();i++)if(d[i]>0){N db=w[i].b-v[i].b,da=w[i].coef(0);if(db<0||da<0||db%d[i]!=0||da%d[i]!=0)return false;alpha=da/d[i];beta=db/d[i];break;}if(alpha<0||beta<0)return false;for(size_t i=0;i<v.size();i++){Lin e(v[i].b+d[i]*beta);e.set(0,d[i]*alpha);if(!(w[i]==e))return false;}return true;}
string decode(string enc){enc="T"+enc;string s;for(int i=0;i<12;i++){if(i&&i%2==0)s+='_';int x=enc[i]-'A';if(x==24)s+="---";else{s+=char('0'+x/12);s+=(x/6)%2?'R':'L';s+=char('A'+x%6);}}return s;}
struct Outcome{int status,macro;N time;int runs;};
Outcome scan(string enc,int k,int cap,int row,int maxruns){Machine m(enc,k);Config<N>c;N time=0;unordered_map<string,Seen>seen;vector<Op>trace;int best=0,tries=0,jumps=0,maxdepth=0;for(int j=0;j<cap;j++){int nr=c.l.size()+c.r.size();best=max(best,nr);if(nr>maxruns)return {6,j,time,best};bool jumped=false;if(nr<=32){auto s=shape(c);auto a=counts(c);auto it=seen.find(s);if(it!=seen.end()){auto&p=it->second;vector<N>d;bool strict=false,inc=true;for(size_t i=0;i<a.size();i++){N x=a[i]-p.a[i];if(x!=0)strict=true;if(x<0)inc=false;d.push_back(x);}int period=j-p.step;if(!strict){cout<<"CYCLE row="<<row<<" width="<<k<<" macro="<<j<<" period="<<period<<" steps_lb="<<time<<" config="<<dump(c)<<" jumps="<<jumps<<" depth="<<maxdepth<<"\n"<<flush;return {7,j,time,best};}if(period<=1000&&tries<30000&&(period<=30||(p.d&&*p.d==d)||inc)){auto rule=make_shared<Rule>();rule->key=s;rule->d=d;rule->body.assign(trace.begin()+p.step,trace.end());for(auto&op:rule->body)if(op.rule)rule->depth=max(rule->depth,op.rule->depth+1);if(rule->depth<=5){tries++;if(inc&&(proveLine(m,c,d,*rule)||proveCone(m,c,d,*rule))){cout<<"INVARIANT row="<<row<<" width="<<k<<" macro="<<j<<" period="<<period<<" steps_lb="<<time<<" config="<<dump(c)<<" delta=";for(auto x:d)cout<<x<<",";cout<<" jumps="<<jumps<<" depth="<<rule->depth<<"\n"<<flush;return {9,j,time,best};}auto x=lift(c);Guard g;int budget=30000;auto ap=apply(m,x,*rule,0,g,budget);if(ap.status==2){cout<<"AFFINE row="<<row<<" width="<<k<<" macro="<<j<<" period="<<period<<" steps_lb="<<time<<" config="<<dump(c)<<" delta=";for(auto x:d)cout<<x<<",";cout<<" jumps="<<jumps<<" depth="<<rule->depth<<"\n"<<flush;return {8,j,time,best};}if(ap.status==1&&ap.T.b>=2&&g.universal()){auto v=counts(x);vector<N>out;for(auto&z:v){if(!z.a.empty()||z.b<=0)abort();out.push_back(z.b);}setCounts(c,out);time+=ap.T.b; // lower bound only: every loop contains a positive primitive step
 trace.push_back({rule});jumps++;maxdepth=max(maxdepth,rule->depth);jumped=true;}}}p={j,a,d};}else if(seen.size()<10000)seen.emplace(s,Seen{j,a,nullopt});}if(jumped)continue;int status=step(m,c,time);trace.push_back({});if(status){cout<<"EVENT row="<<row<<" width="<<k<<" status="<<status<<" macro="<<j<<" steps_lb="<<time<<" config="<<dump(c)<<" jumps="<<jumps<<" depth="<<maxdepth<<"\n"<<flush;return {status,j,time,best};}}return {0,cap,time,best};}
int main(int argc,char**argv){string file=argc>1?argv[1]:"roster.enc";int cap=argc>2?stoi(argv[2]):10000,k=argc>3?stoi(argv[3]):1,start=argc>4?stoi(argv[4]):1,end=argc>5?stoi(argv[5]):608,maxruns=argc>6?stoi(argv[6]):10000;ifstream f(file);string s;f>>s;if(s.size()%11){cerr<<"bad roster";return 1;}for(int i=start-1;i<end&&i<int(s.size()/11);i++){auto enc=s.substr(i*11,11);auto o=scan(enc,k,cap,i+1,maxruns);cerr<<i+1<<"\t"<<k<<"\t"<<o.status<<"\t"<<o.macro<<"\t"<<o.time<<"\t"<<o.runs<<"\t"<<decode(enc)<<"\n";}}
