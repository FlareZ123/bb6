import SweepPumping
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent24Raw45.Re0Grammar
open BB6Coverage BB6Coverage.Agent31Pump

def table : PartialMachine := fun s =>
  match s.1.val,s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 0,true => some (some ⟨true,false,1⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨false,false,0⟩)
  | 2,false => some (some ⟨false,true,3⟩)
  | 2,true => some (some ⟨false,true,4⟩)
  | 3,false => some (some ⟨true,false,3⟩)
  | 3,true => some (some ⟨true,true,1⟩)
  | 4,false => some (some ⟨true,true,5⟩)
  | 5,false => some (some ⟨false,false,1⟩)
  | 5,true => some (some ⟨true,false,5⟩)
  | _,_ => none

def ones (n : Nat) : List Bool := List.replicate n true
private def P : List Bool := [true,false]
private def Q : List Bool := [false,true]
def sep (L : List Bool) : List Bool := if L = [] then [] else false::L
private theorem sep_ne {L : List Bool} (h : L ≠ []) : sep L = false::L := by simp [sep,h]
private theorem ones_add (a b : Nat) : ones a ++ ones b = ones (a+b) := by
  induction a with
  | zero => simp [ones]
  | succ a ih =>
    rw [show a+1+b=(a+b)+1 by omega]
    change true :: (ones a ++ ones b) = true :: ones (a+b)
    rw [ih]
private theorem rep_add' (P : List Bool) (a b : Nat) : rep P a ++ rep P b = rep P (a+b) := by
  induction a with
  | zero => simp [rep]
  | succ a ih => simp only [rep,List.append_assoc,ih,show a+1+b=a+b+1 by omega]
private theorem ones_pair (n : Nat) : rep [true,true] n = ones (2*n) := by
  induction n with
  | zero => rfl
  | succ n ih => rw [rep,ih,show 2*(n+1)=2+2*n by omega,←ones_add]; rfl
private theorem bPair (L R : List Bool) :
    run0 table 2 ⟨1,[true,true]++L,R⟩ = some ⟨1,L,P++R⟩ := by rfl
private theorem bSweep (n : Nat) (L R : List Bool) :
    run0 table (2*n) ⟨1,ones (2*n)++L,R⟩ = some ⟨1,L,rep P n++R⟩ := by
  simpa only [List.nil_append,ones_pair] using sweepL table 1 [] [] [true,true] P 2 bPair n L R
private theorem bTurn (e : Bool) (L R : List Bool) :
    run0 table (6+2*e.toNat) ⟨1,ones e.toNat++sep L,[true,false,true]++R⟩ =
      some ⟨1,ones (1+e.toNat)++L,[false,true,true]++R⟩ := by
  cases e <;> cases L <;> rfl
private theorem bTransfer (m : Nat) (e : Bool) (L R S : List Bool)
    (h : rep P m++R = [true,false,true]++S) :
    run0 table (2*m+(6+2*e.toNat)) ⟨1,ones (2*m+e.toNat)++sep L,R⟩ =
      some ⟨1,ones (1+e.toNat)++L,[false,true,true]++S⟩ := by
  have hs := bSweep m (ones e.toNat++sep L) R
  rw [h] at hs
  simpa only [←List.append_assoc,ones_add] using join0 hs (bTurn e L S)
private theorem firstWord (m : Nat) : rep P (m+1)++[true] = [true,false,true]++rep Q m := by
  have h := rotate true [false] m
  change [true] ++ rep Q m = rep P m ++ [true] at h
  rw [rep, List.append_assoc, ←h]
  rfl
private theorem innerWord (m : Nat) (S : List Bool) :
    rep P (m+2)++([false,true,true]++S) = [true,false,true]++(rep Q m++[false,false,true,true]++S) := by
  have h := congrArg (fun t => t++[false,false,true,true]++S) (firstWord m)
  rw [rep, ←rep_snoc P (m+1)]
  simp only [List.append_assoc] at h ⊢
  exact h

private theorem bFinish (e : Bool) (S : List Bool) :
    run0 table (4+6*e.toNat) ⟨1,ones (1+e.toNat),[false,true,true]++S⟩ =
      some ⟨3,[true,false]++ones (2+e.toNat),true::S⟩ := by cases e <;> rfl
private theorem dPacket (L R : List Bool) :
    run0 table 28 ⟨3,[true,false]++L,[true]++[false,true,false,true,false,true]++R⟩ =
      some ⟨3,[true,false]++ones 6++L,[true]++R⟩ := by rfl
private theorem dSweep (k : Nat) (L R : List Bool) :
    run0 table (28*k) ⟨3,[true,false]++L,[true]++rep [false,true,false,true,false,true] k++R⟩ =
      some ⟨3,[true,false]++rep (ones 6) k++L,[true]++R⟩ :=
  sweepR table 3 [true,false] [true] [false,true,false,true,false,true] (ones 6) 28 dPacket k L R
private theorem rep_ones6 (k : Nat) : rep (ones 6) k = ones (6*k) := by
  induction k with
  | zero => rfl
  | succ k ih => rw [rep,ih,ones_add]; congr 1; omega
private theorem rep_Q3 (k : Nat) : rep [false,true,false,true,false,true] k = rep Q (3*k) := by
  induction k with
  | zero => rfl
  | succ k ih => rw [rep,ih,show 3*(k+1)=3+3*k by omega,←rep_add']; rfl
private theorem dSweep' (k : Nat) (L R : List Bool) :
    run0 table (28*k) ⟨3,[true,false]++L,[true]++rep Q (3*k)++R⟩ =
      some ⟨3,[true,false]++ones (6*k)++L,[true]++R⟩ := by
  simpa only [rep_ones6,rep_Q3] using dSweep k L R
private theorem dMarker (e : Bool) (L S : List Bool) :
    run0 table (14+6*e.toNat) ⟨3,[true,false]++L,[true]++rep Q (1+e.toNat)++[false,false,true,true]++S⟩ =
      some ⟨3,[true,false]++ones (2+2*e.toNat)++[false]++ones 3++L,true::S⟩ := by cases e <;> rfl
private theorem dDecode (k : Nat) (e : Bool) (b : Nat) (L S : List Bool) :
    run0 table (28*k+(14+6*e.toNat)) ⟨3,[true,false]++ones b++sep L,[true]++rep Q (3*k+1+e.toNat)++[false,false,true,true]++S⟩ =
      some ⟨3,[true,false]++ones (2+2*e.toNat)++[false]++ones (b+6*k+3)++sep L,true::S⟩ := by
  have h := dSweep' k (ones b++sep L) (rep Q (1+e.toNat)++[false,false,true,true]++S)
  have h' := dMarker e (ones (6*k)++ones b++sep L) S
  have hh := join0 (by simpa only [List.append_assoc] using h) (by simpa only [List.append_assoc] using h')
  have hR : rep Q (3*k+1+e.toNat)++[false,false,true,true]++S =
      rep Q (3*k)++(rep Q (1+e.toNat)++[false,false,true,true]++S) := by
    rw [show 3*k+1+e.toNat=3*k+(1+e.toNat) by omega,←rep_add']
    simp only [List.append_assoc]
  have hL : ones 3++(ones (6*k)++ones b++sep L) = ones (b+6*k+3)++sep L := by
    simp only [←List.append_assoc,ones_add]
    congr 2
    omega
  simp only [List.append_assoc] at hR hL ⊢
  rw [hR,←hL]
  exact hh

/-- All noninitial runs. The last is 5 or 0 modulo 6; interior ones
    are 5 or 1 modulo 6. There is no bound on the number or sizes of runs. -/
inductive Tail : List Bool → Prop
  | nil : Tail []
  | last (k : Nat) (e : Bool) : Tail (ones (6*k+5+e.toNat))
  | more (k : Nat) (e : Bool) (L : List Bool) (h : Tail L) (hn : L ≠ []) :
      Tail (ones (6*k+5+2*e.toNat)++sep L)

def Base (b : Nat) (L : List Bool) : Prop :=
  (L=[] ∧ (b=2 ∨ b=3)) ∨ (L≠[] ∧ (b=2 ∨ b=4))

private theorem extendTail (b k : Nat) (L : List Bool) (h : Tail L) (hb : Base b L) :
    Tail (ones (b+6*k+3)++sep L) ∧ ones (b+6*k+3)++sep L ≠ [] := by
  have hn : 0 < b+6*k+3 := by omega
  constructor
  · rcases hb with ⟨rfl,hb⟩ | ⟨hne,hb⟩
    · rcases hb with rfl | rfl
      · simpa [sep,show 2+6*k+3=6*k+5+false.toNat by simp; omega] using Tail.last k false
      · simpa [sep,show 3+6*k+3=6*k+5+true.toNat by simp; omega] using Tail.last k true
    · rcases hb with rfl | rfl
      · simpa only [show 2+6*k+3=6*k+5+2*false.toNat by simp; omega] using Tail.more k false L h hne
      · simpa only [show 4+6*k+3=6*k+5+2*true.toNat by simp; omega] using Tail.more k true L h hne
  · intro he
    have hh := congrArg List.length he
    simp [ones] at hh

/-- Encode one or more remaining unary runs leftwards, then decode them
    rightwards. The arbitrary untouched right tail S is preserved. -/
def Result (L : List Bool) (c : Bool) (S : List Bool) : Prop :=
  ∃ t b T, Tail T ∧ Base b T ∧
    run0 table t ⟨1,ones (1+c.toNat)++L,[false,true,true]++S⟩ =
      some ⟨3,[true,false]++ones b++sep T,true::S⟩

private theorem resultNil (c : Bool) (S : List Bool) : Result [] c S := by
  refine ⟨4+6*c.toNat,2+c.toNat,[],Tail.nil,Or.inl ⟨rfl,?_⟩,?_⟩
  · cases c <;> simp
  · simpa [sep] using bFinish c S

private theorem resultStep (a k : Nat) (c e d : Bool) (L S : List Bool)
    (ha : 1+c.toNat+a = 2*(3*k+3+e.toNat)+d.toNat)
    (rec : ∀ c S, Result L c S) : Result (ones a++sep L) c S := by
  let m := 3*k+3+e.toNat
  let S' := rep Q (3*k+1+e.toNat)++[false,false,true,true]++S
  have hword : rep P m++([false,true,true]++S) = [true,false,true]++S' := by
    simpa only [m,S',show 3*k+1+e.toNat+2=3*k+3+e.toNat by omega] using innerWord (3*k+1+e.toNat) S
  have h1 := bTransfer m d L ([false,true,true]++S) S' hword
  obtain ⟨t,b,T,hT,hb,h2⟩ := rec d S'
  have h3 := dDecode k e b T S
  have h12 := join0 h1 h2
  have h3' : run0 table (28*k+(14+6*e.toNat)) ⟨3,[true,false]++ones b++sep T,true::S'⟩ =
      some ⟨3,[true,false]++ones (2+2*e.toNat)++[false]++ones (b+6*k+3)++sep T,true::S⟩ := by
    simp only [S',List.append_assoc] at h3 ⊢
    exact h3
  have hh := join0 h12 h3'
  obtain ⟨hT',hne⟩ := extendTail b k T hT hb
  unfold Result
  refine ⟨2*m+(6+2*d.toNat)+t+(28*k+(14+6*e.toNat)),2+2*e.toNat,ones (b+6*k+3)++sep T,hT',Or.inr ⟨hne,?_⟩,?_⟩
  · cases e <;> simp
  · rw [←List.append_assoc,ones_add,ha]
    rw [sep_ne hne]
    simp only [List.append_assoc] at hh ⊢
    exact hh

private theorem result (L : List Bool) (h : Tail L) : ∀ c S, Result L c S := by
  induction h with
  | nil => exact resultNil
  | last k e =>
    intro c S
    cases e <;> cases c
    · simpa [sep] using resultStep (6*k+5) k false false false [] S (by simp; omega) resultNil
    · simpa [sep] using resultStep (6*k+5) k true false true [] S (by simp; omega) resultNil
    · simpa [sep] using resultStep (6*k+6) k false false true [] S (by simp; omega) resultNil
    · simpa [sep] using resultStep (6*k+6) k true true false [] S (by simp; omega) resultNil
  | more k e L h hn ih =>
    intro c S
    exact resultStep (6*k+5+2*e.toNat) k c e c L S (by omega) ih

private theorem dStart (L : List Bool) :
    run0 table 3 ⟨3,[false,false,true]++L,[]⟩ = some ⟨1,true::true::L,[true]⟩ := by rfl
private theorem dEnd0 (L : List Bool) :
    run0 table 11 ⟨3,[true,false]++L,[true]⟩ = some ⟨3,[false,false]++ones 3++L,[]⟩ := by rfl
private theorem dEnd1 (L : List Bool) :
    run0 table 14 ⟨3,[true,false]++L,[true,false,true]⟩ =
      some ⟨3,[false,false]++ones 2++[false]++ones 3++L,[]⟩ := by rfl
private theorem dEnd2 (L : List Bool) :
    run0 table 20 ⟨3,[true,false]++L,[true,false,true,false,true]⟩ =
      some ⟨3,[false,false]++ones 4++[false]++ones 3++L,[]⟩ := by rfl

def Good (z : Z0) : Prop := ∃ a L, 0<a ∧ Tail L ∧ z=⟨3,[false,false]++ones a++sep L,[]⟩

private theorem finish (n b : Nat) (L : List Bool) (h : Tail L) (hb : Base b L) :
    ∃ t z, 0<t ∧ Good z ∧
    run0 table t ⟨3,[true,false]++ones b++sep L,[true]++rep Q n⟩ = some z := by
  let k := n/3
  let r := n%3
  have hn : n=3*k+r := by dsimp [k,r]; omega
  have hr : r<3 := by dsimp [r]; omega
  have hs := dSweep' k (ones b++sep L) (rep Q r)
  have hR : [true]++rep Q (3*k)++rep Q r = [true]++rep Q n := by
    rw [List.append_assoc,rep_add',←hn]
  rw [hR] at hs
  let W := ones (6*k)++ones b++sep L
  have hs' : run0 table (28*k) ⟨3,[true,false]++ones b++sep L,[true]++rep Q n⟩ =
      some ⟨3,[true,false]++W,[true]++rep Q r⟩ := by simpa only [W,List.append_assoc] using hs
  have hL : ones 3++W = ones (b+6*k+3)++sep L := by
    simp only [W,←List.append_assoc,ones_add]
    congr 2
    omega
  obtain ⟨hT,hne⟩ := extendTail b k L h hb
  have hr' : r=0 ∨ r=1 ∨ r=2 := by omega
  rcases hr' with hr'|hr'|hr'
  · have h1 := hs'
    rw [hr'] at h1
    have h2 := dEnd0 W
    have hh := join0 h1 h2
    refine ⟨28*k+11,_,by omega,⟨b+6*k+3,L,by omega,h,?_⟩,hh⟩
    simp only [List.append_assoc] at hL ⊢
    rw [hL]
  · have h1 := hs'
    rw [hr'] at h1
    have hh := join0 h1 (dEnd1 W)
    refine ⟨28*k+14,_,by omega,⟨2,ones (b+6*k+3)++sep L,by omega,hT,?_⟩,hh⟩
    rw [sep_ne hne]
    simp only [List.append_assoc] at hL ⊢
    rw [hL]
    rfl
  · have h1 := hs'
    rw [hr'] at h1
    have hh := join0 h1 (dEnd2 W)
    refine ⟨28*k+20,_,by omega,⟨4,ones (b+6*k+3)++sep L,by omega,hT,?_⟩,hh⟩
    rw [sep_ne hne]
    simp only [List.append_assoc] at hL ⊢
    rw [hL]
    rfl

/-- Every member of the unbounded grammar returns to another member. -/
theorem returns (z : Z0) (h : Good z) : ∃ t z', 0<t ∧ Good z' ∧ run0 table t z=some z' := by
  obtain ⟨a,L,ha,hL,rfl⟩ := h
  let m := (a+1)/2-1
  have hm : a+1=2*(m+1)+(a+1)%2 := by dsimp [m]; omega
  let e := (a+1)%2=1
  let c : Bool := decide e
  have hc : a+1=2*(m+1)+c.toNat := by
    dsimp [c,e]
    by_cases h : (a+1)%2=1 <;> simp [h] <;> omega
  have ha' : a=1+(a-1) := by omega
  have h1 := dStart (ones (a-1)++sep L)
  have h2 := bTransfer (m+1) c L [true] (rep Q m) (firstWord m)
  have h12 : run0 table (3+(2*(m+1)+(6+2*c.toNat))) ⟨3,[false,false]++ones a++sep L,[]⟩ =
      some ⟨1,ones (1+c.toNat)++L,[false,true,true]++rep Q m⟩ := by
    rw [←hc] at h2
    have h1' : run0 table 3 ⟨3,[false,false]++ones a++sep L,[]⟩ = some ⟨1,ones (a+1)++sep L,[true]⟩ := by
      rw [ha',←ones_add,show 1+(a-1)+1=2+(a-1) by omega,←ones_add]
      simp only [List.append_assoc] at h1 ⊢
      exact h1
    exact join0 h1' h2
  obtain ⟨t,b,T,hT,hb,h3⟩ := result L hL c (rep Q m)
  obtain ⟨u,z,hu,hz,h4⟩ := finish m b T hT hb
  exact ⟨_,z,by omega,hz,join0 (join0 h12 h3) h4⟩

/-- All 25 completions avoid the E1 hole forever. -/
theorem never (m : Machine) (hm : compatible table m) : NeverHalts m := by
  have arbitrary : ∀ n, ∃ t z, n≤t ∧ Good z ∧ run0 table t ⟨0,[],[]⟩ = some z := by
    intro n
    induction n with
    | zero => exact ⟨3,⟨3,[false,false,true,true],[]⟩,by omega,⟨2,[],by omega,Tail.nil,rfl⟩,rfl⟩
    | succ n ih =>
      obtain ⟨t,z,ht,hz,hr⟩ := ih
      obtain ⟨u,z',hu,hz',hr'⟩ := returns z hz
      exact ⟨t+u,z',by omega,hz',join0 hr hr'⟩
  intro n
  obtain ⟨t,z,ht,_,hr⟩ := arbitrary n
  have hz : (BB6Coverage.Agent50Zipper.zrun table t start).map project = some z :=
    (run_project table t start).trans hr
  cases h : BB6Coverage.Agent50Zipper.zrun table t start with
  | none => simp [h] at hz
  | some z =>
    have H := BB6Coverage.Agent50Zipper.zrun_sound table m hm t start z h
    rw [start_embed] at H
    rw [show t=n+(t-n) by omega,run_append] at H
    cases he : run m n blank with
    | none => simp [he] at H
    | some c => rfl

#print axioms returns
#print axioms never
end BB6.Agent24Raw45.Re0Grammar
