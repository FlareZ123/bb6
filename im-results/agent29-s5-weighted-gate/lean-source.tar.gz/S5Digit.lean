import S5Rank

/- Exact positive-run restatement of the D/FR rules in the pinned
   google-deepmind/cryptids S5 acceleration. The raw source module proves
   the individual rules; this file proves the arithmetic grouping, not
   a second raw-TM simulation. D ⟨L,p,R⟩ corresponds to source cfg_D
   (p :: L.map (·-1)) (R.map (·-1)). FR stores both positive-length lists. -/
namespace S5Rank

inductive Digit where
  | D (c : Cfg)
  | FR (L R : List Nat)
  | haltC | haltE
  deriving DecidableEq, Repr

def finishFR (L : List Nat) (R : List Nat) : Digit :=
  .D ⟨L.tail, L.headD 1 - 1, R⟩

def digitStep : Digit → Digit
  | .D ⟨L,0,[]⟩ => .D ⟨L.tail,L.headD 0+2,[]⟩
  | .D ⟨L,0,[1]⟩ => .D ⟨L.tail,L.headD 0+5,[]⟩
  | .D ⟨_,0,1::_::_⟩ => .haltC
  | .D ⟨L,0,2::T⟩ => .D ⟨L.tail,L.headD 0+3,bump 1 T⟩
  | .D ⟨L,0,(r+3)::T⟩ => .FR ((r+1)::bump 4 L) (bump 1 T)
  | .D ⟨_,0,0::_⟩ => .haltE -- invalid run length; outside source representation
  | .D ⟨L,1,R⟩ => .D ⟨L.tail,L.headD 0,1::R⟩
  | .D ⟨L,p+2,R⟩ => .FR ((p+1)::bump 1 L) (1::R)
  | .FR [] _ => .haltE
  | .FR L [] => finishFR L [1]
  | .FR L (0::_) => .haltE -- invalid run length
  | .FR L (1::R) => finishFR L (bump 1 R)
  | .FR L ((r+2)::R) => .FR ((r+1)::L) (bump 1 R)
  | .haltC => .haltC
  | .haltE => .haltE

inductive DReach : Nat → Digit → Digit → Prop
  | zero (s) : DReach 0 s s
  | succ {n s t} : DReach n (digitStep s) t → DReach (n+1) s t

theorem DReach.trans {n m s t u} (h : DReach n s t) (h' : DReach m t u) :
    DReach (n+m) s u := by
  induction h with
  | zero => simpa using h'
  | succ h ih => rw [Nat.succ_add]; exact .succ (ih h')

theorem DReach.one (s : Digit) : DReach 1 s (digitStep s) := .succ (.zero _)

theorem bump_zero (L : List Nat) : bump 0 L = L := by cases L <;> simp [bump]

theorem bump_add (n m : Nat) (L : List Nat) : bump n (bump m L) = bump (n+m) L := by
  cases L with
  | nil => by_cases hm : m=0 <;> by_cases hn : n=0 <;> simp [bump, hm, hn, Nat.add_comm]
  | cons x xs => simp [bump,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm]

theorem bump_head (n : Nat) (L : List Nat) : (bump n L).headD 0 = L.headD 0+n := by
  cases L with
  | nil => by_cases hn : n=0 <;> simp [bump, hn]
  | cons x xs => rfl

theorem bump_tail (n : Nat) (L : List Nat) : (bump n L).tail = L.tail := by
  cases L with
  | nil => by_cases hn : n=0 <;> simp [bump, hn]
  | cons x xs => rfl

theorem transfer (L R : List Nat) (p : Nat) :
    DReach 2 (.D ⟨L,p+2,R⟩) (.D ⟨bump 1 L,p,bump 1 R⟩) := by
  apply DReach.succ
  apply DReach.succ
  simp [digitStep, finishFR]
  exact .zero _

theorem transfer_many (k e : Nat) (L R : List Nat) :
    DReach (2*k) (.D ⟨L,2*k+e,R⟩) (.D ⟨bump k L,e,bump k R⟩) := by
  induction k generalizing L R with
  | zero => simpa [bump_zero] using DReach.zero (.D ⟨L,e,R⟩)
  | succ k ih =>
    have h1 := transfer L R (2*k+e)
    have h2 := ih (bump 1 L) (bump 1 R)
    have h := h1.trans h2
    simpa [bump_add, show 2+2*k=2*(k+1) by omega,
      show 2*k+e+2=2*(k+1)+e by omega] using h

theorem odd_digit_sound (s : Cfg) (h : s.p%2=1) :
    DReach (2*(s.p/2)+1) (.D s) (.D (oddNext s)) := by
  rcases s with ⟨L,p,R⟩
  have hp : 2*(p/2)+1=p := by simp at h; omega
  have h1 := transfer_many (p/2) 1 L R
  rw [hp] at h1
  have h2 := DReach.one (.D ⟨bump (p/2) L,1,bump (p/2) R⟩)
  have hh := h1.trans h2
  simpa only [digitStep, oddNext, bump_head, bump_tail] using hh

theorem fr_sweep (T : List Nat) (hT : pos T) (a : Nat) (A : List Nat) :
    DReach (T.length+1) (.FR (a::A) (bump 1 T))
      (finishFR (T.reverse ++ a::A) [1]) := by
  induction T generalizing a A with
  | nil => exact .succ (.zero _)
  | cons t ts ih =>
    have ht := hT t (by simp)
    have hts : pos ts := fun x hx => hT x (by simp [hx])
    have h1 := ih hts t (a::A)
    apply DReach.succ
    have he : digitStep (.FR (a::A) (bump 1 (t::ts))) = .FR (t::a::A) (bump 1 ts) := by
      obtain ⟨u,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : t≠0)
      simp [digitStep,bump,Nat.succ_eq_add_one,Nat.add_assoc]
    rw [he]
    simpa [List.reverse_cons,List.append_assoc] using h1

theorem bounce_digit_sound (L : List Nat) (r : Nat) (T : List Nat)
    (hr : r≥3) (hT : pos T) :
    DReach (T.length+2) (.D ⟨L,0,r::T⟩) (.D (bounce L r T)) := by
  apply DReach.succ
  have he : digitStep (.D ⟨L,0,r::T⟩) = .FR ((r-2)::bump 4 L) (bump 1 T) := by
    have h : r=(r-3)+3 := by omega
    conv => lhs; rw [h]
    simp [digitStep]
    omega
  rw [he]
  have h := fr_sweep T hT (r-2) (bump 4 L)
  cases ht : T.reverse with
  | nil =>
    have hsub : r-2-1=r-3 := by omega
    simpa [bounce,ht,finishFR,hsub] using h
  | cons z Z => simpa [bounce,ht,finishFR] using h

theorem fatal_digit_sound (s : Cfg) (hf : fatal s) : DReach 2 (.D s) .haltC := by
  rcases s with ⟨L,p,R⟩
  rcases hf with ⟨hL,hp,hR⟩
  simp at hL hp hR
  subst L; subst p
  cases R with
  | nil => contradiction
  | cons x xs => exact .succ (.succ (.zero _))

theorem oddReach_digit_sound {n s t} (h : OddReach n s t) :
    ∃ k, DReach k (.D s) (.D t) := by
  induction h with
  | zero => exact ⟨0,.zero _⟩
  | succ ho h ih =>
    obtain ⟨k,hk⟩ := ih
    exact ⟨_,(odd_digit_sound _ ho).trans hk⟩

theorem fatal_gate_digit (s : Cfg) (hs : valid s)
    (hp : ∃ n, s.P+1=2^(n+1) ∧ (n>0 ∨ s.R≠[])) : ∃ k, DReach k (.D s) .haltC := by
  obtain ⟨n,t,hr,hf⟩ := (odd_phase_fatal_iff s hs).mpr hp
  obtain ⟨k,hk⟩ := oddReach_digit_sound hr
  exact ⟨k+2,hk.trans (fatal_digit_sound _ hf)⟩

#print axioms odd_digit_sound
#print axioms bounce_digit_sound
#print axioms fatal_gate_digit

end S5Rank
