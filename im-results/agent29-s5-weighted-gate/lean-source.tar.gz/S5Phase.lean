import S5Digit

namespace S5Rank

/-- Group all transfers and the odd shift; group the entire FR bounce. -/
def macroNext (s : Cfg) : Option Cfg :=
  if s.p % 2 = 1 then some (oddNext s)
  else if s.p > 0 then some ⟨bump (s.p/2) s.L,0,bump (s.p/2) s.R⟩
  else match s.R with
    | [] => some ⟨s.L.tail,s.L.headD 0+2,[]⟩
    | [1] => some ⟨s.L.tail,s.L.headD 0+5,[]⟩
    | 1::_::_ => none
    | 2::T => some ⟨s.L.tail,s.L.headD 0+3,bump 1 T⟩
    | (r+3)::T => some (bounce s.L (r+3) T)
    | 0::_ => none

def bad (s : Cfg) : Prop := ∃ n, s.P+1=2^(n+1) ∧ (n>0 ∨ s.R≠[])

theorem pos_tail (L : List Nat) (h : pos L) : pos L.tail := by
  cases L with
  | nil => simp [pos]
  | cons x xs => exact fun y hy => h y (List.mem_cons_of_mem _ hy)

theorem macro_valid {s t : Cfg} (hs : valid s) (h : macroNext s = some t) : valid t := by
  unfold macroNext at h
  split at h
  · obtain rfl := Option.some.inj h
    exact oddNext_valid s hs
  split at h
  · obtain rfl := Option.some.inj h
    exact ⟨bump_pos _ _ hs.1,bump_pos _ _ hs.2⟩
  split at h
  next he =>
    obtain rfl := Option.some.inj h
    exact ⟨pos_tail _ hs.1,by simp [pos]⟩
  next he =>
    obtain rfl := Option.some.inj h
    exact ⟨pos_tail _ hs.1,by simp [pos]⟩
  next => contradiction
  next T he =>
    obtain rfl := Option.some.inj h
    have hr : pos T := fun x hx => hs.2 x (by rw [he]; exact List.mem_cons_of_mem _ hx)
    exact ⟨pos_tail _ hs.1,bump_pos 1 T hr⟩
  next r T he =>
    obtain rfl := Option.some.inj h
    have hr : pos T := fun x hx => hs.2 x (by rw [he]; exact List.mem_cons_of_mem _ hx)
    exact bounce_valid _ _ _ (by omega) hs.1 hr
  next => contradiction

theorem macro_digit_some {s t : Cfg} (hs : valid s) (h : macroNext s = some t) :
    ∃ n>0, DReach n (.D s) (.D t) := by
  rcases s with ⟨L,p,R⟩
  unfold macroNext at h
  split at h
  next ho =>
    obtain rfl := Option.some.inj h
    exact ⟨_,by omega,odd_digit_sound _ ho⟩
  split at h
  next hp =>
    obtain rfl := Option.some.inj h
    have he : p%2=0 := by simp at *; omega
    have hpn : 0<p := hp
    have h1 := transfer_many (p/2) 0 L R
    have hpeq : 2*(p/2)+0=p := by omega
    rw [hpeq] at h1
    exact ⟨_,by omega,h1⟩
  next hn =>
    have hp : p=0 := by simp at hn; omega
    subst p
    split at h
    next he =>
      obtain rfl := Option.some.inj h
      refine ⟨1,by decide,?_⟩
      change R = _ at he
      rw [he]
      exact .succ (.zero _)
    next he =>
      obtain rfl := Option.some.inj h
      refine ⟨1,by decide,?_⟩
      change R = _ at he
      rw [he]
      exact .succ (.zero _)
    next => contradiction
    next T he =>
      obtain rfl := Option.some.inj h
      refine ⟨1,by decide,?_⟩
      change R = _ at he
      rw [he]
      exact .succ (.zero _)
    next r T he =>
      obtain rfl := Option.some.inj h
      have hr : pos T := fun x hx => hs.2 x (by rw [he]; exact List.mem_cons_of_mem _ hx)
      refine ⟨T.length+2,by omega,?_⟩
      change R = _ at he
      rw [he]
      exact bounce_digit_sound L (r+3) T (by omega) hr
    next => contradiction

theorem macro_none_shape {s : Cfg} (hs : valid s) (h : macroNext s = none) :
    s.p=0 ∧ ∃ r T, s.R=1::r::T := by
  unfold macroNext at h
  split at h
  · contradiction
  split at h
  · contradiction
  next hn =>
    have hp : s.p=0 := by omega
    split at h
    · contradiction
    · contradiction
    next r T he => exact ⟨hp,r,T,he⟩
    · contradiction
    · contradiction
    next T he =>
      have hz := hs.2 0 (by rw [he]; simp)
      omega

theorem macro_none_digit {s : Cfg} (hs : valid s) (h : macroNext s = none) :
    DReach 1 (.D s) .haltC := by
  obtain ⟨hp,r,T,hR⟩ := macro_none_shape hs h
  rcases s with ⟨L,p,R⟩
  simp at hp hR
  subst p; subst R
  exact .succ (.zero _)

inductive MReach (s : Cfg) : Cfg → Prop
  | refl : MReach s s
  | step {t u} : MReach s t → macroNext t = some u → MReach s u

theorem MReach.trans {s t u} (h : MReach s t) (h' : MReach t u) : MReach s u := by
  induction h' with
  | refl => exact h
  | step ht hu ih => exact .step ih hu

theorem MReach.valid {s t} (h : MReach s t) (hs : valid s) : valid t := by
  induction h with
  | refl => exact hs
  | step ht hu ih => exact macro_valid ih hu

def MHalt (s : Cfg) : Prop := ∃ t, MReach s t ∧ macroNext t = none

theorem odd_macro (s : Cfg) (h : s.p%2=1) : macroNext s = some (oddNext s) := by simp [macroNext,h]

theorem oddReach_macro {n s t} (h : OddReach n s t) : MReach s t := by
  induction h with
  | zero => exact .refl
  | succ ho h ih => exact (MReach.step MReach.refl (odd_macro _ ho)).trans ih

theorem fatal_macro_halt (s : Cfg) (h : fatal s) : MHalt s := by
  rcases s with ⟨L,p,R⟩
  rcases h with ⟨hL,hp,hR⟩
  simp at hL hp hR
  subst L; subst p
  cases R with
  | nil => contradiction
  | cons r T =>
    refine ⟨oddNext ⟨[],1,r::T⟩,.step .refl (by rfl),?_⟩
    simp [macroNext,oddNext,bump]

theorem bad_macro_halt (s : Cfg) (hs : valid s) (h : bad s) : MHalt s := by
  obtain ⟨n,t,hr,hf⟩ := (odd_phase_fatal_iff s hs).mpr h
  obtain ⟨u,hu,hend⟩ := fatal_macro_halt t hf
  exact ⟨u,(oddReach_macro hr).trans hu,hend⟩

theorem even_not_bad (s : Cfg) (h : s.p%2=0) : ¬bad s := by
  rintro ⟨n,hn,_⟩
  rw [Nat.pow_succ] at hn
  have hp := rank_parity s
  omega

theorem bad_back_odd (s : Cfg) (ho : s.p%2=1) (h : bad (oddNext s)) : bad s := by
  obtain ⟨n,hn,_⟩ := h
  refine ⟨n+1,?_,Or.inl (by omega)⟩
  rw [rank_odd s ho,hn,Nat.pow_succ]
  omega

theorem head_zero_empty (L : List Nat) (h : pos L) (hz : L.headD 0=0) : L=[] := by
  cases L with
  | nil => rfl
  | cons x xs =>
    have hx := h x (by simp)
    simp at hz
    omega

theorem bump_positive_not_halt (n : Nat) (R : List Nat) (hn : 0<n) (hR : pos R) :
    ∀ r T, bump n R ≠ 1::r::T := by
  intro r T h
  cases R with
  | nil => simp [bump,show n≠0 by omega] at h
  | cons x xs =>
    have hx := hR x (by simp)
    simp [bump] at h
    omega

/-- The only way to enter the C1 terminal shape by a macroNext is a fatal
    odd phase; all zero-cursor reset/bounce images are nonterminal. -/
theorem macro_none_predecessor {s t : Cfg} (hs : valid s)
    (h : macroNext s = some t) (hn : macroNext t = none) : fatal s := by
  have ht := macro_valid hs h
  obtain ⟨hp,r,T,hR⟩ := macro_none_shape ht hn
  unfold macroNext at h
  split at h
  next ho =>
    obtain rfl := Option.some.inj h
    simp [oddNext] at hp hR
    have hz : s.L.headD 0=0 := by simpa using hp.1
    have hL := head_zero_empty s.L hs.1 hz
    have hq : s.p/2=0 := by have := hp.2; omega
    have h1 : s.p=1 := by have := hp.2; omega
    have hne : s.R≠[] := by
      intro he
      simp [bump,hq,he] at hR
    exact ⟨hL,h1,hne⟩
  split at h
  next hp' =>
    obtain rfl := Option.some.inj h
    have hk : 0<s.p/2 := by omega
    exact False.elim (bump_positive_not_halt (s.p/2) s.R hk hs.2 r T hR)
  split at h
  · obtain rfl := Option.some.inj h; simp at hp
  · obtain rfl := Option.some.inj h; simp at hp
  · contradiction
  · obtain rfl := Option.some.inj h; simp at hp
  · obtain rfl := Option.some.inj h; rw [bounce_R] at hR; simp at hR
  · contradiction

/-- S5 initial section after the three-step raw prefix proved upstream. -/
def seed : Cfg := ⟨[],2,[]⟩

theorem seed_valid : valid seed := by simp [seed,valid,pos]

theorem seed_not_bad : ¬bad seed := even_not_bad _ (by decide)

theorem fatal_bad (s : Cfg) (h : fatal s) : bad s := by
  rcases h with ⟨hL,hp,hR⟩
  exact ⟨0,by simp [Cfg.P,rank,hL,hp,weight],Or.inr hR⟩

/-- Complete root stopping criterion for the grouped arithmetic model. -/
theorem seed_halts_iff_bad : MHalt seed ↔ ∃ t, MReach seed t ∧ bad t := by
  constructor
  · rintro ⟨t,ht,hn⟩
    cases ht with
    | refl => contradiction
    | step hprev hstep =>
      exact ⟨_,hprev,fatal_bad _ (macro_none_predecessor (hprev.valid seed_valid) hstep hn)⟩
  · rintro ⟨t,ht,hb⟩
    obtain ⟨u,hu,hend⟩ := bad_macro_halt t (ht.valid seed_valid) hb
    exact ⟨u,ht.trans hu,hend⟩

/-- The earliest bad rank must be created by a zero-cursor reset. -/
theorem first_bad_reset {t : Cfg} (h : MReach seed t) (hb : bad t) :
    ∃ s u, MReach seed s ∧ s.p=0 ∧ macroNext s=some u ∧ bad u := by
  induction h with
  | refl => exact False.elim (seed_not_bad hb)
  | @step t u ht hu ih =>
    by_cases hbprev : bad t
    · exact ih hbprev
    by_cases ho : t.p%2=1
    · have he : u=oddNext t := Option.some.inj (hu.symm.trans (odd_macro t ho))
      subst u
      exact False.elim (hbprev (bad_back_odd _ ho hb))
    by_cases hp : t.p>0
    · simp [macroNext,ho,hp] at hu
      subst u
      exact False.elim (even_not_bad _ (by rfl) hb)
    exact ⟨t,u,ht,by omega,hu,hb⟩

def pow2 (x : Nat) : Prop := ∃ k : Nat, x=2^k

theorem bad_iff_pow2_of_large (s : Cfg) (h : s.P+1>2) : bad s ↔ pow2 (s.P+1) := by
  constructor
  · rintro ⟨n,hn,_⟩
    exact ⟨n+1,hn⟩
  · rintro ⟨k,hk⟩
    cases k with
    | zero => simp at hk; omega
    | succ k =>
      refine ⟨k,hk,Or.inl ?_⟩
      cases k with
      | zero => simp at hk; omega
      | succ k => omega

theorem rank_pop_add (L : List Nat) (n : Nat) :
    rank L.tail (L.headD 0+n) = weight L+n := by
  cases L <;> simp [rank,weight] <;> omega

def resetGate (s : Cfg) : Prop :=
  match s.R with
  | [] => pow2 (weight s.L+3)
  | [1] => pow2 (weight s.L+6)
  | 1::_::_ => False
  | 2::_ => pow2 (weight s.L+4)
  | (r+3)::T => (2^T.length ∣ rweight T) ∧
      pow2 (rank s.L 0 + (r+3)+6+rweight T/2^T.length)
  | 0::_ => False

theorem bad_reset_rank (L R : List Nat) (n : Nat) (hn : n≥2) :
    bad ⟨L.tail,L.headD 0+n,R⟩ ↔ pow2 (weight L+n+1) := by
  have h : (Cfg.P ⟨L.tail,L.headD 0+n,R⟩)+1 = weight L+n+1 := by
    simp only [Cfg.P,rank_pop_add]
  rw [bad_iff_pow2_of_large _ (by rw [h]; omega),h]

theorem resetGate_iff (s : Cfg) (hs : valid s) (hp : s.p=0) :
    resetGate s ↔ ∃ u, macroNext s=some u ∧ bad u := by
  rcases s with ⟨L,p,R⟩
  simp at hp; subst p
  cases R with
  | nil =>
    simp only [resetGate,macroNext,show (0:Nat)%2≠1 by decide,ite_false,show ¬(0:Nat)>0 by decide]
    simp only [Option.some.injEq]
    rw [exists_eq_left']
    exact (bad_reset_rank L [] 2 (by decide)).symm
  | cons r T =>
    have hr := hs.2 r (by simp)
    have hT : pos T := fun x hx => hs.2 x (by simp [hx])
    rcases r with _ | _ | _ | r
    · simp at hr
    · cases T with
      | nil =>
        simp only [resetGate,macroNext,show (0:Nat)%2≠1 by decide,ite_false,show ¬(0:Nat)>0 by decide]
        simp only [Option.some.injEq,exists_eq_left']
        exact (bad_reset_rank L [] 5 (by decide)).symm
      | cons t T => simp [resetGate,macroNext]
    · simp only [resetGate,macroNext,show (0:Nat)%2≠1 by decide,ite_false,show ¬(0:Nat)>0 by decide]
      simp only [Option.some.injEq,exists_eq_left']
      exact (bad_reset_rank L (bump 1 T) 3 (by decide)).symm
    · simp only [resetGate,macroNext,show (0:Nat)%2≠1 by decide,ite_false,show ¬(0:Nat)>0 by decide]
      simp only [Option.some.injEq,exists_eq_left']
      unfold pow2
      rw [← bounce_fatal_iff L (r+3) T (by omega) hs.1 hT]
      exact odd_phase_fatal_iff _ (bounce_valid L _ T (by omega) hs.1 hT)

theorem bump_nonempty (n : Nat) (L : List Nat) (hn : 0<n) : bump n L ≠ [] := by
  cases L <;> simp [bump,show n≠0 by omega]

theorem reachable_empty_right {t : Cfg} (h : MReach seed t) : t.R=[] → t.p≥2 := by
  induction h with
  | refl => simp [seed]
  | @step s t hs ht ih =>
    intro hr
    unfold macroNext at ht
    split at ht
    · obtain rfl := Option.some.inj ht; simp [oddNext] at hr
    split at ht
    · obtain rfl := Option.some.inj ht
      have hk : 0<s.p/2 := by omega
      exact False.elim (bump_nonempty _ _ hk hr)
    split at ht
    · obtain rfl := Option.some.inj ht; simp
    · obtain rfl := Option.some.inj ht; simp
    · contradiction
    · obtain rfl := Option.some.inj ht; exact False.elim (bump_nonempty _ _ (by decide) hr)
    · obtain rfl := Option.some.inj ht; rw [bounce_R] at hr; contradiction
    · contradiction

/-- All-time exact stopping reduction: only the three nonempty-right
    zero-cursor reset families require exclusion along the root orbit. -/
theorem seed_halts_iff_reset : MHalt seed ↔
    ∃ s, MReach seed s ∧ s.p=0 ∧ s.R≠[] ∧ resetGate s := by
  constructor
  · intro h
    obtain ⟨t,ht,hb⟩ := seed_halts_iff_bad.mp h
    obtain ⟨s,u,hs,hp,hu,hbad⟩ := first_bad_reset ht hb
    have hR : s.R≠[] := by intro he; have := reachable_empty_right hs he; omega
    exact ⟨s,hs,hp,hR,(resetGate_iff s (hs.valid seed_valid) hp).mpr ⟨u,hu,hbad⟩⟩
  · rintro ⟨s,hs,hp,_,hg⟩
    obtain ⟨u,hu,hbad⟩ := (resetGate_iff s (hs.valid seed_valid) hp).mp hg
    exact seed_halts_iff_bad.mpr ⟨u,.step hs hu,hbad⟩

#print axioms seed_halts_iff_reset

theorem DReach.compare {n m : Nat} {s t u : Digit}
    (h : DReach n s t) (h' : DReach m s u) (hn : n≤m) : DReach (m-n) t u := by
  induction h generalizing m u with
  | zero => simpa using h'
  | @succ n s t hs ih =>
    cases m with
    | zero => omega
    | succ m =>
      cases h' with
      | succ hu =>
        have hmn : n≤m := by omega
        simpa using ih hu hmn

theorem DReach.from_haltC {n : Nat} {t : Digit} (h : DReach n .haltC t) : t=.haltC := by
  induction n with
  | zero => cases h; rfl
  | succ n ih => cases h with | succ h => exact ih h

theorem MReach.digit {s t : Cfg} (h : MReach s t) (hs : S5Rank.valid s) :
    ∃ n, DReach n (.D s) (.D t) := by
  induction h with
  | refl => exact ⟨0,.zero _⟩
  | step hprev hstep ih =>
    obtain ⟨n,hn⟩ := ih
    obtain ⟨m,hm,hreach⟩ := macro_digit_some (hprev.valid hs) hstep
    exact ⟨n+m,hn.trans hreach⟩

theorem digit_halt_to_macro (n : Nat) (s : Cfg) (hs : valid s)
    (h : DReach n (.D s) .haltC) : MHalt s := by
  induction n using Nat.strongRecOn generalizing s with
  | ind n ih =>
    cases he : macroNext s with
    | none => exact ⟨s,.refl,he⟩
    | some t =>
      obtain ⟨m,hm,hd⟩ := macro_digit_some hs he
      have hmn : m<n := by
        by_cases hc : m<n
        · exact hc
        have hnt : n≤m := by omega
        have ht := (h.compare hd hnt).from_haltC
        contradiction
      have hd' := hd.compare h (by omega : m≤n)
      obtain ⟨u,hu,hn⟩ := ih (n-m) (by omega) t (macro_valid hs he) hd'
      exact ⟨u,(MReach.step MReach.refl he).trans hu,hn⟩

theorem digit_halts_iff_macro (s : Cfg) (hs : valid s) :
    (∃ n, DReach n (.D s) .haltC) ↔ MHalt s := by
  constructor
  · rintro ⟨n,hn⟩; exact digit_halt_to_macro n s hs hn
  · rintro ⟨t,ht,hn⟩
    obtain ⟨n,hd⟩ := ht.digit hs
    exact ⟨n+1,hd.trans (macro_none_digit (ht.valid hs) hn)⟩

/-- The other undefined transition E0 cannot occur from any valid D seed.
    Use the same macro segmentation: each positive segment ends in D or C. -/
theorem DReach.from_haltE {n : Nat} {t : Digit} (h : DReach n .haltE t) : t=.haltE := by
  induction n with
  | zero => cases h; rfl
  | succ n ih => cases h with | succ h => exact ih h

theorem no_haltE (n : Nat) (s : Cfg) (hs : valid s) : ¬DReach n (.D s) .haltE := by
  intro h
  induction n using Nat.strongRecOn generalizing s with
  | ind n ih =>
    cases he : macroNext s with
    | none =>
      have hc := macro_none_digit hs he
      by_cases hn : n≤1
      · have hh := (h.compare hc hn).from_haltE; contradiction
      · have hh := (hc.compare h (by omega : 1≤n)).from_haltC; contradiction
    | some t =>
      obtain ⟨m,hm,hd⟩ := macro_digit_some hs he
      by_cases hn : n≤m
      · have hh := (h.compare hd hn).from_haltE; contradiction
      · exact ih (n-m) (by omega) t (macro_valid hs he) (hd.compare h (by omega))

theorem seed_digit_halts_iff_reset :
    (∃ n, DReach n (.D seed) .haltC ∨ DReach n (.D seed) .haltE) ↔
    ∃ s, MReach seed s ∧ s.p=0 ∧ s.R≠[] ∧ resetGate s := by
  constructor
  · rintro ⟨n,hc|he⟩
    · exact seed_halts_iff_reset.mp (digit_halt_to_macro n seed seed_valid hc)
    · exact False.elim (no_haltE n seed seed_valid he)
  · intro h
    obtain ⟨n,hn⟩ := (digit_halts_iff_macro seed seed_valid).mpr (seed_halts_iff_reset.mpr h)
    exact ⟨n,Or.inl hn⟩

#print axioms seed_digit_halts_iff_reset
#print axioms no_haltE

end S5Rank
