import Lean

/- Arithmetic of the exact run-stack model of Cryptid S5.
   Source D stack [p, l₀-1, l₁-1, ...], R stack [r₀-1, ...].
   Positive run lengths on both auxiliary lists; cursor p is a natural.
   See the published D/FR separator rules. No raw-source theorem is asserted here. -/
namespace S5Rank

def weight : List Nat → Nat
  | [] => 0
  | x :: xs => x + 2 * weight xs

def rank (L : List Nat) (p : Nat) : Nat := p + 2 * weight L

def pos (L : List Nat) : Prop := ∀ x ∈ L, 0 < x

def bump (n : Nat) : List Nat → List Nat
  | [] => if n = 0 then [] else [n]
  | x :: xs => (x + n) :: xs

structure Cfg where
  L : List Nat
  p : Nat
  R : List Nat
  deriving Repr, DecidableEq

def Cfg.P (s : Cfg) : Nat := rank s.L s.p

def valid (s : Cfg) : Prop := pos s.L ∧ pos s.R

/-- Bulk p≥2 transfer, then the shift p=1. Defined exactly on odd p. -/
def oddNext (s : Cfg) : Cfg :=
  ⟨s.L.tail, s.L.headD 0 + s.p / 2, 1 :: bump (s.p / 2) s.R⟩

theorem bump_pos (n : Nat) (L : List Nat) (h : pos L) : pos (bump n L) := by
  cases L with
  | nil => by_cases hn : n = 0 <;> simp [bump, hn, pos] <;> omega
  | cons x xs =>
    intro y hy
    simp [bump] at hy
    rcases hy with rfl | hy
    · have := h x (by simp); omega
    · exact h y (by simp [hy])

theorem oddNext_valid (s : Cfg) (h : valid s) : valid (oddNext s) := by
  rcases s with ⟨L,p,R⟩
  rcases h with ⟨hl,hr⟩
  constructor
  · cases L with
    | nil => simp [oddNext, pos]
    | cons x xs => exact fun y hy => hl y (by simp [oddNext] at hy ⊢; exact Or.inr hy)
  · intro y hy
    simp [oddNext] at hy
    rcases hy with rfl | hy
    · decide
    · exact bump_pos (p/2) R hr y hy

theorem rank_odd (s : Cfg) (h : s.p % 2 = 1) :
    s.P + 1 = 2 * ((oddNext s).P + 1) := by
  rcases s with ⟨L,p,R⟩
  cases L <;> simp [Cfg.P, rank, weight, oddNext] at h ⊢ <;> omega

theorem rank_parity (s : Cfg) : s.P % 2 = s.p % 2 := by
  simp [Cfg.P, rank]

theorem weight_positive {x : Nat} {L : List Nat} (h : 0 < x) : 0 < weight (x::L) := by
  simp [weight]; omega

theorem rank_one (s : Cfg) (h : valid s) : s.P = 1 ↔ s.L = [] ∧ s.p = 1 := by
  rcases s with ⟨L,p,R⟩
  cases L with
  | nil => simp [Cfg.P, rank, weight]
  | cons x xs =>
    have hx := h.1 x (by simp)
    simp [Cfg.P, rank, weight]
    omega

/-- Each odd phase strips one trailing 1 from P. Fatal p=1 with empty
    L and nonempty R is reached immediately before the C1 gate. -/
inductive OddReach : Nat → Cfg → Cfg → Prop
  | zero (s) : OddReach 0 s s
  | succ {n s t} : s.p % 2 = 1 → OddReach n (oddNext s) t → OddReach (n+1) s t

theorem oddReach_valid {n s t} (h : OddReach n s t) (hs : valid s) : valid t := by
  induction h with
  | zero => exact hs
  | succ ho ht ih => exact ih (oddNext_valid _ hs)

theorem oddReach_rank {n s t} (h : OddReach n s t) :
    s.P + 1 = 2^n * (t.P + 1) := by
  induction h with
  | zero => simp
  | succ ho ht ih =>
    rw [rank_odd _ ho, ih, Nat.pow_succ]
    ac_rfl

def fatal (s : Cfg) : Prop := s.L = [] ∧ s.p = 1 ∧ s.R ≠ []

theorem fatal_power {n s t} (h : OddReach n s t) (hf : fatal t) :
    s.P + 1 = 2^(n+1) := by
  rcases hf with ⟨hL,hp,hR⟩
  have hr : t.P + 1 = 2 := by simp [Cfg.P, rank, hL, hp, weight]
  rw [oddReach_rank h, hr, Nat.pow_succ]

theorem power_reaches_rank_one (n : Nat) (s : Cfg) (hs : valid s)
    (hp : s.P + 1 = 2^(n+1)) : ∃ t, OddReach n s t ∧ t.P = 1 := by
  induction n generalizing s with
  | zero => exact ⟨s, .zero s, by simp at hp; omega⟩
  | succ n ih =>
    have hp' : s.P + 1 = 2^(n+1)*2 := by simpa [Nat.pow_succ] using hp
    have ho : s.p % 2 = 1 := by
      have hpar := rank_parity s
      omega
    have hn := rank_odd s ho
    have hnext : (oddNext s).P + 1 = 2^(n+1) := by omega
    obtain ⟨t, ht, hr⟩ := ih (oddNext s) (oddNext_valid s hs) hnext
    exact ⟨t, .succ ho ht, hr⟩

theorem oddReach_R_nonempty {n s t} (h : OddReach n s t) (hs : s.R ≠ []) : t.R ≠ [] := by
  induction h with
  | zero => exact hs
  | succ ho ht ih => apply ih; simp [oddNext]

theorem positive_oddReach_R_nonempty {n s t} (h : OddReach (n+1) s t) : t.R ≠ [] := by
  cases h with
  | succ ho ht => exact oddReach_R_nonempty ht (by simp [oddNext])

/-- Complete arbitrary-depth odd-phase hazard criterion. The one exceptional
    P=1 case with R=[] is safe at this phase (its next R=[1]). -/
theorem odd_phase_fatal_iff (s : Cfg) (hs : valid s) :
    (∃ n t, OddReach n s t ∧ fatal t) ↔
      (∃ n, s.P + 1 = 2^(n+1) ∧ (n > 0 ∨ s.R ≠ [])) := by
  constructor
  · rintro ⟨n,t,hr,hf⟩
    refine ⟨n,fatal_power hr hf,?_⟩
    cases n with
    | zero => cases hr; exact Or.inr hf.2.2
    | succ n => exact Or.inl (by omega)
  · rintro ⟨n,hp,hside⟩
    obtain ⟨t,hr,h1⟩ := power_reaches_rank_one n s hs hp
    have ht := oddReach_valid hr hs
    obtain ⟨hL,hp⟩ := (rank_one t ht).mp h1
    refine ⟨n,t,hr,hL,hp,?_⟩
    cases n with
    | zero => cases hr; exact hside.resolve_left (by omega)
    | succ n => exact positive_oddReach_R_nonempty hr

#print axioms odd_phase_fatal_iff

/-- Reversed weight: nearest right run receives the largest power. -/
def rweight : List Nat → Nat
  | [] => 0
  | x :: xs => x * 2^xs.length + rweight xs

theorem weight_append (A B : List Nat) :
    weight (A ++ B) = weight A + 2^A.length * weight B := by
  induction A with
  | nil => simp [weight]
  | cons x xs ih =>
    simp [weight, ih, Nat.pow_succ, Nat.mul_add]
    ac_rfl

theorem weight_reverse (A : List Nat) : weight A.reverse = rweight A := by
  induction A with
  | nil => rfl
  | cons x xs ih => simp [List.reverse_cons, weight_append, weight, ih, rweight, Nat.mul_comm, Nat.add_comm]

/-- Bounce of the p=0, r≥3 branch, after the entire FR right sweep. -/
def bounce (L : List Nat) (r : Nat) (T : List Nat) : Cfg :=
  match T.reverse with
  | [] => ⟨bump 4 L, r-3, [1]⟩
  | z :: Z => ⟨Z ++ (r-2) :: bump 4 L, z-1, [1]⟩

theorem bump_weight_four (L : List Nat) : weight (bump 4 L) = weight L + 4 := by
  cases L <;> simp [bump, weight] <;> omega

/-- A whole arbitrary-depth right sweep collapses to one weighted expression. -/
theorem bounce_rank (L : List Nat) (r : Nat) (T : List Nat)
    (hr : r ≥ 3) (hT : pos T) :
    (bounce L r T).P + 1 = 2^T.length * (rank L 0 + r + 6) + rweight T := by
  cases h : T.reverse with
  | nil =>
    have he : T = [] := List.reverse_eq_nil_iff.mp h
    subst T
    simp [bounce, Cfg.P, rank, bump_weight_four, rweight]
    omega
  | cons z Z =>
    have hzmem : z ∈ T.reverse := by simp [h]
    have hz : 0 < z := hT z (List.mem_reverse.mp hzmem)
    have hl : T.length = Z.length+1 := by simpa using congrArg List.length h
    have hw : rweight T = z + 2 * weight Z := by rw [← weight_reverse, h]; rfl
    simp [bounce, h, Cfg.P, rank, weight_append, weight, bump_weight_four, hl, hw, Nat.pow_succ]
    have hi : r-2+2*(weight L+4) = 2*weight L+r+6 := by omega
    rw [hi]
    simp only [Nat.mul_add, ← Nat.mul_assoc]
    rw [Nat.mul_comm 2 (2^Z.length)]
    omega

#print axioms bounce_rank

theorem bounce_valid (L : List Nat) (r : Nat) (T : List Nat)
    (hr : r ≥ 3) (hL : pos L) (hT : pos T) : valid (bounce L r T) := by
  cases h : T.reverse with
  | nil =>
    constructor
    · simpa [bounce, h] using bump_pos 4 L hL
    · simp [bounce, h, pos]
  | cons z Z =>
    constructor
    · intro x hx
      simp [bounce, h] at hx
      rcases hx with hz | hr' | hb
      · apply hT x
        apply List.mem_reverse.mp
        rw [h]
        exact List.mem_cons_of_mem z hz
      · omega
      · exact bump_pos 4 L hL x hb
    · simp [bounce, h, pos]

theorem bounce_R (L : List Nat) (r : Nat) (T : List Nat) :
    (bounce L r T).R = [1] := by
  cases h : T.reverse <;> simp [bounce,h]

/-- Factoring the weighted right-sweep successor gives an exact arithmetic
    gate. It excludes every tail whose reversed weight is not a multiple
    of 2^length, and replaces the remaining test by one scalar quotient. -/
theorem bounce_fatal_iff (L : List Nat) (r : Nat) (T : List Nat)
    (hr : r ≥ 3) (hL : pos L) (hT : pos T) :
    (∃ n t, OddReach n (bounce L r T) t ∧ fatal t) ↔
    (2^T.length ∣ rweight T) ∧
    (∃ k, rank L 0 + r + 6 + rweight T / 2^T.length = 2^k) := by
  rw [odd_phase_fatal_iff _ (bounce_valid L r T hr hL hT)]
  simp [bounce_R]
  rw [bounce_rank L r T hr hT]
  let m := T.length
  let v := rank L 0 + r + 6
  let w := rweight T
  change (∃ n, 2^m*v+w = 2^(n+1)) ↔ (2^m ∣ w) ∧ (∃ k, v+w/2^m=2^k)
  have hpow : 0 < 2^m := Nat.pow_pos (by decide)
  have hv : 2 ≤ v := by dsimp [v]; omega
  constructor
  · rintro ⟨n,hn⟩
    have hlt : 2^m < 2^(n+1) := by
      have h1 := Nat.mul_lt_mul_of_pos_left (n:=1) (m:=v) (by omega) hpow
      rw [Nat.mul_one] at h1
      omega
    have hmn : m < n+1 := by
      by_cases hm : m < n+1
      · exact hm
      have hc : n+1 ≤ m := by omega
      have := Nat.pow_le_pow_right (n:=2) (by decide) hc
      omega
    have hdiv : 2^m ∣ w := by
      apply (Nat.dvd_add_iff_right (Nat.dvd_mul_right (2^m) v)).mpr
      rw [hn]
      exact Nat.pow_dvd_pow 2 (by omega)
    refine ⟨hdiv,n+1-m,?_⟩
    have hfac : 2^(n+1) = 2^m * 2^(n+1-m) := by
      rw [← Nat.pow_add, Nat.add_sub_of_le (by omega)]
    have hw : w = 2^m * (w/2^m) := by
      rw [Nat.mul_comm, Nat.div_mul_cancel hdiv]
    apply Nat.mul_left_cancel hpow
    calc
      _ = 2^m*v+w := by rw [Nat.mul_add (2^m) v (w/2^m), ← hw]
      _ = 2^(n+1) := hn
      _ = _ := hfac
  · rintro ⟨hdiv,k,hk⟩
    have hkpos : 0 < k := by
      cases k with
      | zero =>
        change v+w/2^m=1 at hk
        have hq : 0 ≤ w/2^m := Nat.zero_le _
        omega
      | succ k => omega
    refine ⟨m+k-1,?_⟩
    have hw : w = 2^m * (w/2^m) := by
      rw [Nat.mul_comm, Nat.div_mul_cancel hdiv]
    calc
      _ = 2^m*(v+w/2^m) := by
        change 2^m*v+w = 2^m*(v+w/2^m)
        rw [Nat.mul_add (2^m) v (w/2^m), ← hw]
      _ = 2^(m+k) := by rw [hk, Nat.pow_add]
      _ = _ := by congr 1; omega

#print axioms bounce_fatal_iff

end S5Rank
