import W7Sweep

open BB6Row146Conjugacy
namespace W7

abbrev Env := Nat → Nat

def dot : List Int → Env → Int
  | [], _ => 0
  | a::as, e => a*(e 0 : Int)+dot as (fun i => e (i+1))

def padAdd : List Int → List Int → List Int
  | [], ys => ys
  | xs, [] => xs
  | a::as, b::bs => (a+b)::padAdd as bs

theorem dot_add (xs ys : List Int) (e : Env) :
    dot (padAdd xs ys) e = dot xs e + dot ys e := by
  induction xs generalizing ys e with
  | nil => simp [padAdd,dot]
  | cons x xs ih =>
    cases ys with
    | nil => simp [padAdd,dot]
    | cons y ys =>
      simp only [padAdd,dot,ih,Int.add_mul]
      omega

theorem dot_scale (xs : List Int) (k : Int) (e : Env) :
    dot (xs.map (k*·)) e = k*dot xs e := by
  induction xs generalizing e with
  | nil => simp [dot]
  | cons x xs ih =>
    simp only [List.map_cons,dot,ih,Int.mul_add,Int.mul_assoc]

theorem dot_nonneg (xs : List Int) (e : Env)
    (h : ∀ x ∈ xs, 0≤x) : 0≤dot xs e := by
  induction xs generalizing e with
  | nil => simp [dot]
  | cons x xs ih =>
    have hx := h x (by simp)
    have ht : ∀ a ∈ xs, 0≤a := fun a ha => h a (by simp [ha])
    have h₁ : 0≤x*(e 0 : Int) := Int.mul_nonneg hx (Int.natCast_nonneg _)
    have h₂ := ih (fun i => e (i+1)) ht
    simp only [dot]
    omega

theorem dot_zero (xs : List Int) (e : Env)
    (h : ∀ x ∈ xs, x=0) : dot xs e=0 := by
  induction xs generalizing e with
  | nil => rfl
  | cons x xs ih =>
    have hx := h x (by simp)
    have ht : ∀ a ∈ xs, a=0 := fun a ha => h a (by simp [ha])
    simp [dot,hx,ih (fun i => e (i+1)) ht]

structure Aff where
  c : Int
  cs : List Int
  deriving DecidableEq, Repr

def Aff.eval (a : Aff) (e : Env) : Int := a.c+dot a.cs e
def Aff.const (x : Int) : Aff := ⟨x,[]⟩
def Aff.var (i : Nat) : Aff := ⟨0,List.replicate i 0 ++ [1]⟩
def Aff.add (a b : Aff) : Aff := ⟨a.c+b.c,padAdd a.cs b.cs⟩
def Aff.scale (k : Int) (a : Aff) : Aff := ⟨k*a.c,a.cs.map (k*·)⟩
def Aff.sub (a b : Aff) : Aff := a.add (b.scale (-1))
def Aff.nonneg (a : Aff) : Bool := decide (0≤a.c) && a.cs.all (fun x => decide (0≤x))
def Aff.pos (a : Aff) : Bool := decide (0<a.c) && a.cs.all (fun x => decide (0≤x))
def Aff.isZero (a : Aff) : Bool := decide (a.c=0) && a.cs.all (fun x => decide (x=0))

@[simp] theorem Aff.eval_const (x : Int) (e : Env) : (Aff.const x).eval e=x := by simp [eval,const,dot]
@[simp] theorem Aff.eval_add (a b : Aff) (e : Env) :
    (a.add b).eval e = a.eval e+b.eval e := by
  simp only [add,eval,dot_add]
  omega
@[simp] theorem Aff.eval_scale (k : Int) (a : Aff) (e : Env) :
    (a.scale k).eval e = k*a.eval e := by
  simp only [scale,eval,dot_scale,Int.mul_add]
@[simp] theorem Aff.eval_sub (a b : Aff) (e : Env) :
    (a.sub b).eval e = a.eval e-b.eval e := by
  simp [sub]
  omega
@[simp] theorem Aff.eval_var (i : Nat) (e : Env) :
    (Aff.var i).eval e=(e i : Int) := by
  induction i generalizing e with
  | zero => simp [var,eval,dot]
  | succ n ih =>
    simp only [var,List.replicate_succ,List.cons_append,eval,dot,Int.zero_mul,Int.zero_add]
    have h := ih (fun i => e (i+1))
    simpa [var,eval] using h

theorem Aff.eval_nonneg {a : Aff} (h : a.nonneg=true) (e : Env) : 0≤a.eval e := by
  simp [nonneg,List.all_eq_true] at h
  have hd := dot_nonneg a.cs e h.2
  simp only [eval]
  omega
theorem Aff.eval_pos {a : Aff} (h : a.pos=true) (e : Env) : 0<a.eval e := by
  simp [pos,List.all_eq_true] at h
  have hd := dot_nonneg a.cs e h.2
  simp only [eval]
  omega
theorem Aff.eval_isZero {a : Aff} (h : a.isZero=true) (e : Env) : a.eval e=0 := by
  simp [isZero,List.all_eq_true] at h
  simp [eval,h.1,dot_zero a.cs e h.2]

#print axioms Aff.eval_pos
#print axioms Aff.eval_var
end W7
