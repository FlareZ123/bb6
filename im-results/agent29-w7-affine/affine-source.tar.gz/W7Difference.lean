import W7Symbolic

open BB6Row146Conjugacy
namespace W7

structure Slot where
  word : Word
  bound : Int
  delta : Int
  free : Bool
  deriving DecidableEq, Repr

structure Pair where
  slot : Slot
  value : Aff
  deriving Repr

def align : List Slot → Side → Option (List Pair)
  | [], [] => some []
  | s::ss, (w,a)::as =>
    if s.word=w then (align ss as).map (fun xs => ⟨s,a⟩::xs) else none
  | _,_ => none

theorem align_sound (ss : List Slot) (as : Side) (xs : List Pair)
    (h : align ss as=some xs) :
    xs.map Pair.slot=ss ∧ xs.map (fun a => (a.slot.word,a.value))=as := by
  induction ss generalizing as xs with
  | nil =>
    cases as <;> simp [align] at h
    subst xs
    simp
  | cons s ss ih =>
    cases as with
    | nil => simp [align] at h
    | cons a as =>
      rcases a with ⟨w,v⟩
      by_cases hw : s.word=w
      · simp [align,hw] at h
        cases ht : align ss as with
        | none => simp [ht] at h
        | some ys =>
          simp [ht] at h
          subst xs
          obtain ⟨h₁,h₂⟩ := ih as ys ht
          simp [h₁,h₂,hw]
      · simp [align,hw] at h

def pack (q : State) (d : Bool) (l : Nat) (xs : Side) : SConf :=
  ⟨q,d,xs.take l,xs.drop l⟩

theorem pack_append (q : State) (d : Bool) (L R : Side) :
    pack q d L.length (L++R)=⟨q,d,L,R⟩ := by
  simp [pack]

def concretes (e : Env) (s : Side) : List (Word × Int) :=
  s.map fun (w,a) => (w,a.eval e)

theorem evalSide_eq (e f : Env) (s t : Side)
    (h : concretes e s=concretes f t) :
    evalSide e s=evalSide f t := by
  induction s generalizing t with
  | nil =>
    cases t <;> simp [concretes] at h
    rfl
  | cons a s ih =>
    rcases a with ⟨w,v⟩
    cases t with
    | nil => simp [concretes] at h
    | cons b t =>
      rcases b with ⟨w',v'⟩
      simp only [concretes,List.map_cons,List.cons.injEq,Prod.mk.injEq] at h
      obtain ⟨⟨rfl,hv⟩,ht⟩:=h
      have hh := ih t ht
      simp [evalSide,hv,hh]

theorem pack_eval_eq (q : State) (d : Bool) (l : Nat) (s t : Side) (e f : Env)
    (h : concretes e s=concretes f t) :
    (pack q d l s).eval e=(pack q d l t).eval f := by
  have hl : concretes e (s.take l)=concretes f (t.take l) := by
    simpa [concretes,List.map_take] using congrArg (fun a : List (Word×Int) => a.take l) h
  have hr : concretes e (s.drop l)=concretes f (t.drop l) := by
    simpa [concretes,List.map_drop] using congrArg (fun a : List (Word×Int) => a.drop l) h
  simp only [pack,SConf.eval,BC.mk.injEq,true_and]
  exact ⟨evalSide_eq e f _ _ hl,evalSide_eq e f _ _ hr⟩

def shift (xs : List Pair) (t : Aff) : Side :=
  xs.map fun a => (a.slot.word,a.value.add (t.scale a.slot.delta))

def atCount (a : Pair) (e : Env) (i : Nat) : Int :=
  a.value.eval e+a.slot.delta*(i:Int)

def seedAff (s : Slot) (j : Nat) (out : Bool) : Aff :=
  let base:=Aff.const (s.bound+(if out then s.delta else 0))
  if s.free then base.add (Aff.var j) else base

def seedList (slots : List Slot) (j : Nat) (out : Bool) : Side :=
  match slots with
  | [] => []
  | s::ss => (s.word,seedAff s j out)::seedList ss (j+1) out

def offsets (xs : List Pair) (e : Env) (i : Nat) : List Nat :=
  xs.map fun a => (atCount a e i-a.slot.bound).toNat

def envFor (xs : List Pair) (e : Env) (i : Nat) : Env :=
  fun j => ((offsets xs e i)[j]?).getD 0

def Meets (a : Pair) (e : Env) (i : Nat) : Prop :=
  if a.slot.free then a.slot.bound≤atCount a e i
  else atCount a e i=a.slot.bound

theorem seedAff_eval (a : Pair) (e f : Env) (i j : Nat) (out : Bool)
    (h : Meets a e i)
    (hf : f j=(atCount a e i-a.slot.bound).toNat) :
    (seedAff a.slot j out).eval f =
      a.value.eval e+a.slot.delta*((i+(if out then 1 else 0):Nat):Int) := by
  have hstep : a.slot.delta*((i+1:Nat):Int)=a.slot.delta*(i:Int)+a.slot.delta := by
    simp [Int.mul_add]
  cases hg : a.slot.free <;> cases out <;>
    simp [Meets,hg] at h <;>
    simp [seedAff,hg,hf,atCount] at *
  · omega
  · omega
  · omega
  · omega

theorem seedList_eq (xs : List Pair) (e f : Env) (i j : Nat) (out : Bool)
    (h : ∀ a ∈ xs, Meets a e i)
    (hf : ∀ k, f (j+k)=((offsets xs e i)[k]?).getD 0) :
    concretes f (seedList (xs.map Pair.slot) j out) =
    concretes e (shift xs (Aff.const (i+(if out then 1 else 0)))) := by
  induction xs generalizing j with
  | nil => rfl
  | cons a xs ih =>
    have ha : Meets a e i := h a (by simp)
    have hhead : f j=(atCount a e i-a.slot.bound).toNat := by
      simpa [offsets] using hf 0
    have htail : ∀ k, f (j+1+k)=((offsets xs e i)[k]?).getD 0 := by
      intro k
      have hh := hf (k+1)
      simpa [offsets,show j+1+k=j+(k+1) by omega] using hh
    have ht := ih (j+1) (fun b hb => h b (by simp [hb])) htail
    simp only [seedList,List.map_cons,concretes,shift]
    rw [seedAff_eval a e f i j out ha hhead]
    simp only [Aff.eval_add,Aff.eval_scale,Aff.eval_const]
    congr 1
    cases out <;> simp

structure Diff where
  state : State
  right : Bool
  leftLen : Nat
  slots : List Slot
  deriving Repr

def Diff.seed (r : Diff) (out : Bool) : SConf :=
  pack r.state r.right r.leftLen (seedList r.slots 0 out)

def Diff.Valid (r : Diff) : Prop :=
  ∀ e : Env, Reach ((r.seed false).eval e) ((r.seed true).eval e)

theorem valid_at (r : Diff) (h : r.Valid) (xs : List Pair) (e : Env) (i : Nat)
    (hs : xs.map Pair.slot=r.slots)
    (hm : ∀ a ∈ xs, Meets a e i) :
    Reach ((pack r.state r.right r.leftLen (shift xs (Aff.const i))).eval e)
      ((pack r.state r.right r.leftLen (shift xs (Aff.const (i+1)))).eval e) := by
  let f:=envFor xs e i
  have hf : ∀ k, f (0+k)=((offsets xs e i)[k]?).getD 0 := by simp [f,envFor]
  have h₀ := seedList_eq xs e f i 0 false hm hf
  have h₁ := seedList_eq xs e f i 0 true hm hf
  rw [hs] at h₀ h₁
  have he₀ := pack_eval_eq r.state r.right r.leftLen _ _ f e h₀
  have he₁ := pack_eval_eq r.state r.right r.leftLen _ _ f e h₁
  have hh := h f
  unfold Diff.seed at hh
  rw [he₀,he₁] at hh
  simpa using hh

-- A finite repeat count is sufficient; maximality is not required for soundness.
-- Check both ends of every threshold interval and fixed-slot stability.
def safe (a : Pair) (t : Aff) : Bool :=
  if a.slot.free then
    (a.value.sub (Aff.const a.slot.bound)).nonneg &&
    ((a.value.add ((t.sub (Aff.const 1)).scale a.slot.delta)).sub (Aff.const a.slot.bound)).nonneg
  else
    (a.value.sub (Aff.const a.slot.bound)).isZero && decide (a.slot.delta=0)

theorem linear_between (a b d : Int) (i n : Nat)
    (hi : i<n) (h₀ : b≤a) (h₁ : b≤a+d*((n:Int)-1)) :
    b≤a+d*(i:Int) := by
  by_cases hd : 0≤d
  · have hh := Int.mul_nonneg hd (Int.natCast_nonneg i)
    omega
  · have hin : (i:Int)≤(n:Int)-1 := by omega
    have hh := Int.mul_le_mul_of_nonneg_left hin (show 0≤-d by omega)
    simp only [Int.neg_mul] at hh
    omega

theorem safe_meets (a : Pair) (t : Aff) (e : Env) (n i : Nat)
    (ht : t.eval e=(n:Int)) (hi : i<n) (h : safe a t=true) :
    Meets a e i := by
  cases hf : a.slot.free
  · simp [safe,hf] at h
    have he := Aff.eval_isZero h.1 e
    simp [Meets,hf,atCount,h.2] 
    simp at he
    omega
  · simp [safe,hf] at h
    have h₀ := Aff.eval_nonneg h.1 e
    have h₁ := Aff.eval_nonneg h.2 e
    simp only [Aff.eval_sub,Aff.eval_const,Aff.eval_add,Aff.eval_scale,ht] at h₀ h₁
    simp [Meets,hf,atCount]
    exact linear_between _ _ _ i n hi (by omega) (by omega)

theorem repeatReach (F : Nat → BC) (n : Nat) (hn : 0<n)
    (h : ∀ i<n, Reach (F i) (F (i+1))) : Reach (F 0) (F n) := by
  induction n with
  | zero => omega
  | succ n ih =>
    cases n with
    | zero => exact h 0 (by omega)
    | succ n =>
      exact (ih (by omega) (fun i hi => h i (by omega))).trans (h (n+1) (by omega))

theorem shift_zero_eval (xs : List Pair) (e : Env) :
    concretes e (shift xs (Aff.const 0)) =
    concretes e (xs.map fun a => (a.slot.word,a.value)) := by
  simp [concretes,shift,List.map_map,Function.comp_def]
theorem shift_eval_eq (xs : List Pair) (e : Env) (t u : Aff)
    (h : t.eval e=u.eval e) :
    concretes e (shift xs t)=concretes e (shift xs u) := by
  simp [concretes,shift,List.map_map,Function.comp_def,h]

theorem apply_with_sound (r : Diff) (hr : r.Valid) (s : SConf) (xs : List Pair) (t : Aff)
    (hq : s.state=r.state) (hd : s.right=r.right) (hl : s.L.length=r.leftLen)
    (ha : align r.slots (s.L++s.R)=some xs)
    (hp : t.pos=true) (hs : xs.all (fun a => safe a t)=true) (e : Env) :
    Reach (s.eval e) ((pack r.state r.right r.leftLen (shift xs t)).eval e) := by
  obtain ⟨hslots,hvals⟩ := align_sound _ _ _ ha
  let n := (t.eval e).toNat
  have hn : 0<n := by have hh:=Aff.eval_pos hp e; omega
  have ht : t.eval e=(n:Int) := by
    have hh:=Aff.eval_pos hp e
    omega
  let F := fun i : Nat => (pack r.state r.right r.leftLen (shift xs (Aff.const i))).eval e
  have hrun : Reach (F 0) (F n) := by
    apply repeatReach F n hn
    intro i hi
    apply valid_at r hr xs e i hslots
    intro a hm
    exact safe_meets a t e n i ht hi (List.all_eq_true.mp hs a hm)
  have h₀ := shift_zero_eval xs e
  rw [hvals] at h₀
  have he₀ := pack_eval_eq r.state r.right r.leftLen _ _ e e h₀
  have hpack : pack r.state r.right r.leftLen (s.L++s.R)=s := by
    rcases s with ⟨q,d,L,R⟩
    simp at hq hd hl
    rw [←hq,←hd,←hl,pack_append]
  rw [hpack] at he₀
  have h₁ := shift_eval_eq xs e (Aff.const n) t (by simp [ht])
  have he₁ := pack_eval_eq r.state r.right r.leftLen _ _ e e h₁
  dsimp only [F] at hrun
  change Reach ((pack r.state r.right r.leftLen (shift xs (Aff.const 0))).eval e) _ at hrun
  rw [he₀,he₁] at hrun
  exact hrun

#print axioms apply_with_sound
end W7
