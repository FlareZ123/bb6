import W7Affine
import W7Table

open BB6Row146Conjugacy
namespace W7

abbrev Side := List (Word × Aff)

def evalSide (e : Env) : Side → Stack
  | [] => empty
  | (w,n)::xs => rep w (n.eval e).toNat (evalSide e xs)

def readSide : Side → Word
  | [] => Word.zero
  | (w,_)::_ => w

def push (w : Word) (n : Aff) (s : Side) : Option Side :=
  if n.pos then
    match s with
    | [] => some (if w=Word.zero then [] else [(w,n)])
    | (v,m)::xs =>
      if w=v then
        if m.pos then some ((w,m.add n)::xs) else none
      else some ((w,n)::s)
  else none

theorem push_sound (w : Word) (n : Aff) (s t : Side) (e : Env)
    (h : push w n s=some t) :
    evalSide e t=rep w (n.eval e).toNat (evalSide e s) := by
  by_cases hn : n.pos=true
  · cases s with
    | nil =>
      by_cases hw : w=Word.zero
      · simp [push,hn,hw] at h
        subst t
        simp [evalSide,hw]
      · simp [push,hn,hw] at h
        subst t
        rfl
    | cons a xs =>
      rcases a with ⟨v,m⟩
      by_cases hw : w=v
      · subst v
        by_cases hm : m.pos=true
        · simp [push,hn,hm] at h
          subst t
          have h₁ := Aff.eval_pos hn e
          have h₂ := Aff.eval_pos hm e
          have he : ((m.add n).eval e).toNat=(n.eval e).toNat+(m.eval e).toNat := by
            rw [Aff.eval_add]
            omega
          simp only [evalSide,he,rep_add]
        · simp [push,hn,hm] at h
      · simp [push,hn,hw] at h
        subst t
        rfl
  · simp [push,hn] at h

-- Consume either the whole positive run (same-state sweep), or one block.
def take (s : Side) (sweep : Bool) : Option (Aff × Side) :=
  match s with
  | [] => some (Aff.const 1,[])
  | (w,n)::xs =>
    if n.pos then
      if sweep then some (n,xs)
      else
        let r:=n.sub (Aff.const 1)
        if r.isZero then some (Aff.const 1,xs)
        else if r.pos then some (Aff.const 1,(w,r)::xs)
        else none
    else none

theorem take_sound (s t : Side) (sw : Bool) (n : Aff) (e : Env)
    (h : take s sw=some (n,t)) :
    0<(n.eval e).toNat ∧
    evalSide e s=rep (readSide s) (n.eval e).toNat (evalSide e t) ∧
    (sw=false → (n.eval e).toNat=1) := by
  cases s with
  | nil =>
    simp [take] at h
    obtain ⟨rfl,rfl⟩:=h
    simp only [evalSide,readSide,Aff.eval_const,rep_zero_empty]
    simp
  | cons a xs =>
    rcases a with ⟨w,m⟩
    by_cases hm : m.pos=true
    · have hp := Aff.eval_pos hm e
      cases sw with
      | true =>
        simp [take,hm] at h
        obtain ⟨rfl,rfl⟩:=h
        exact ⟨by omega,rfl,by simp⟩
      | false =>
        by_cases hz : (m.sub (Aff.const 1)).isZero=true
        · have he := Aff.eval_isZero hz e
          simp at he
          simp [take,hm,hz] at h
          obtain ⟨rfl,rfl⟩:=h
          have hh : (m.eval e).toNat=1 := by omega
          simp [evalSide,readSide,hh]
        · by_cases hr : (m.sub (Aff.const 1)).pos=true
          · have he := Aff.eval_pos hr e
            simp only [Aff.eval_sub,Aff.eval_const] at he
            simp [take,hm,hz,hr] at h
            obtain ⟨rfl,rfl⟩:=h
            have hh : (m.eval e).toNat=1+((m.sub (Aff.const 1)).eval e).toNat := by
              simp only [Aff.eval_sub,Aff.eval_const]
              omega
            simp only [evalSide,readSide,Aff.eval_const,hh,rep_add]
            exact ⟨by decide,rfl,by simp⟩
          · simp [take,hm,hz,hr] at h
    · simp [take,hm] at h

structure SConf where
  state : State
  right : Bool
  L : Side
  R : Side
  deriving DecidableEq, Repr

def SConf.eval (s : SConf) (e : Env) : BC :=
  ⟨s.state,s.right,evalSide e s.L,evalSide e s.R⟩

def read (s : SConf) : Side := if s.right then s.R else s.L

def isSweep (s : SConf) (r : BlockResult) : Bool :=
  decide (r.state=s.state ∧ r.right=s.right)

def finish (s : SConf) (r : BlockResult) (n : Aff) (rest : Side) : Option SConf :=
  if s.right then
    if r.right then (push r.word n s.L).map (fun l => ⟨r.state,true,l,rest⟩)
    else (push r.word n rest).map (fun t => ⟨r.state,false,s.L,t⟩)
  else
    if r.right then (push r.word n rest).map (fun t => ⟨r.state,true,t,s.R⟩)
    else (push r.word n s.R).map (fun t => ⟨r.state,false,rest,t⟩)

def ordinary (s : SConf) : Option SConf :=
  match blockFast s.state s.right (readSide (read s)) with
  | none => none
  | some r =>
    match take (read s) (isSweep s r) with
    | none => none
    | some (n,rest) => finish s r n rest

theorem block_or_sweepR (q : State) (w : Word) (r : BlockResult) (n : Nat)
    (hb : block q true w=some r) (hn : 0<n)
    (hk : (r.state=q ∧ r.right=true) ∨ n=1) (L R : Stack) :
    Reach ⟨q,true,L,rep w n R⟩
      (if r.right then ⟨r.state,true,rep r.word n L,R⟩
       else ⟨r.state,false,L,rep r.word n R⟩) := by
  rcases hk with hk|hk
  · rcases r with ⟨q',d,v,k⟩
    simp at hk
    obtain ⟨rfl,rfl⟩:=hk
    simpa using sweepRight q' w v k hb n hn L R
  · subst n
    let c : BC:=⟨q,true,L,rep w 1 R⟩
    have hs : block c.state c.right (peek c)=some r := by
      simpa [c,peek] using hb
    cases hr : r.right <;>
      simpa [c,next,hr] using rawBlock_sound c r hs

theorem block_or_sweepL (q : State) (w : Word) (r : BlockResult) (n : Nat)
    (hb : block q false w=some r) (hn : 0<n)
    (hk : (r.state=q ∧ r.right=false) ∨ n=1) (L R : Stack) :
    Reach ⟨q,false,rep w n L,R⟩
      (if r.right then ⟨r.state,true,rep r.word n L,R⟩
       else ⟨r.state,false,L,rep r.word n R⟩) := by
  rcases hk with hk|hk
  · rcases r with ⟨q',d,v,k⟩
    simp at hk
    obtain ⟨rfl,rfl⟩:=hk
    simpa using sweepLeft q' w v k hb n hn L R
  · subst n
    let c : BC:=⟨q,false,rep w 1 L,R⟩
    have hs : block c.state c.right (peek c)=some r := by
      simpa [c,peek] using hb
    cases hr : r.right <;>
      simpa [c,next,hr] using rawBlock_sound c r hs

theorem ordinary_sound (s t : SConf) (e : Env)
    (h : ordinary s=some t) : Reach (s.eval e) (t.eval e) := by
  unfold ordinary at h
  rw [blockFast_eq] at h
  cases hb : block s.state s.right (readSide (read s)) with
  | none => simp [hb] at h
  | some r =>
    simp only [hb] at h
    cases ht : take (read s) (isSweep s r) with
    | none => simp [ht] at h
    | some nr =>
      rcases nr with ⟨n,rest⟩
      simp only [ht] at h
      obtain ⟨hn,hdecomp,hs⟩:=take_sound (read s) rest (isSweep s r) n e ht
      have hk : (r.state=s.state ∧ r.right=s.right) ∨ (n.eval e).toNat=1 := by
        cases he : isSweep s r
        · exact Or.inr (hs he)
        · exact Or.inl (of_decide_eq_true he)
      rcases s with ⟨q,d,L,R⟩
      cases d
      · have hb' : block q false (readSide L)=some r := hb
        have hd : evalSide e L=rep (readSide L) (n.eval e).toNat (evalSide e rest) := hdecomp
        have hr := block_or_sweepL q (readSide L) r (n.eval e).toNat hb' hn hk (evalSide e rest) (evalSide e R)
        cases he : r.right
        · simp [finish,he] at h
          cases hp : push r.word n R with
          | none => simp [hp] at h
          | some u =>
            simp [hp] at h
            subst t
            have hh := push_sound r.word n R u e hp
            simpa [SConf.eval,hd,hh,he] using hr
        · simp [finish,he] at h
          cases hp : push r.word n rest with
          | none => simp [hp] at h
          | some u =>
            simp [hp] at h
            subst t
            have hh := push_sound r.word n rest u e hp
            simpa [SConf.eval,hd,hh,he] using hr
      · have hb' : block q true (readSide R)=some r := hb
        have hd : evalSide e R=rep (readSide R) (n.eval e).toNat (evalSide e rest) := hdecomp
        have hr := block_or_sweepR q (readSide R) r (n.eval e).toNat hb' hn hk (evalSide e L) (evalSide e rest)
        cases he : r.right
        · simp [finish,he] at h
          cases hp : push r.word n rest with
          | none => simp [hp] at h
          | some u =>
            simp [hp] at h
            subst t
            have hh := push_sound r.word n rest u e hp
            simpa [SConf.eval,hd,hh,he] using hr
        · simp [finish,he] at h
          cases hp : push r.word n L with
          | none => simp [hp] at h
          | some u =>
            simp [hp] at h
            subst t
            have hh := push_sound r.word n L u e hp
            simpa [SConf.eval,hd,hh,he] using hr

#print axioms ordinary_sound
end W7
