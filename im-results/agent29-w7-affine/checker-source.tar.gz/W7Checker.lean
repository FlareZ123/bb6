import W7Difference

open BB6Row146Conjugacy
namespace W7

def candidate (a : Pair) : Option Aff :=
  let d := -a.slot.delta
  let v := a.value.sub (Aff.const a.slot.bound)
  if 0<d ∧ v.cs.all (fun x => decide (x%d=0))=true then
    some ⟨v.c/d+1,v.cs.map (·/d)⟩
  else none

def selectT (xs : List Pair) : Option Aff :=
  match (xs.filter (fun a => decide (a.slot.delta<0))).mapM candidate with
  | none => none
  | some ts => ts.find? fun t => ts.all fun u => (u.sub t).nonneg

def Diff.apply (r : Diff) (s : SConf) : Option SConf :=
  if s.state=r.state ∧ s.right=r.right ∧ s.L.length=r.leftLen then
    match align r.slots (s.L++s.R) with
    | none => none
    | some xs =>
      match selectT xs with
      | none => none
      | some t =>
        if t.pos && xs.all (fun a => safe a t) &&
          (shift xs t).all (fun a => a.2.pos) then
          some (pack r.state r.right r.leftLen (shift xs t))
        else none
  else none

theorem Diff.apply_sound (r : Diff) (hr : r.Valid) (s t : SConf)
    (h : r.apply s=some t) (e : Env) : Reach (s.eval e) (t.eval e) := by
  unfold Diff.apply at h
  split at h
  next he =>
    cases ha : align r.slots (s.L++s.R) with
    | none => simp [ha] at h
    | some xs =>
      simp only [ha] at h
      cases ht : selectT xs with
      | none => simp [ht] at h
      | some u =>
        simp only [ht] at h
        split at h
        next hs =>
          simp only [Bool.and_eq_true] at hs
          cases h
          exact apply_with_sound r hr s xs u he.1 he.2.1 he.2.2 ha hs.1.1 hs.1.2 e
        next hs => contradiction
  next he => contradiction

def sideEq : Side → Side → Bool
  | [],[] => true
  | (w,a)::xs,(v,b)::ys => decide (w=v) && (a.sub b).isZero && sideEq xs ys
  | _,_ => false

theorem sideEq_sound (s t : Side) (h : sideEq s t=true) (e : Env) :
    evalSide e s=evalSide e t := by
  induction s generalizing t with
  | nil =>
    cases t <;> simp [sideEq] at h
    rfl
  | cons x xs ih =>
    rcases x with ⟨w,a⟩
    cases t with
    | nil => simp [sideEq] at h
    | cons y ys =>
      rcases y with ⟨v,b⟩
      simp [sideEq] at h
      obtain ⟨⟨hw,ha⟩,ht⟩:=h
      have hv := Aff.eval_isZero ha e
      simp at hv
      have he : a.eval e=b.eval e := by omega
      simp [evalSide,hw,he,ih ys ht]

def SConf.equiv (s t : SConf) : Bool :=
  decide (s.state=t.state) && decide (s.right=t.right) && sideEq s.L t.L && sideEq s.R t.R

theorem SConf.equiv_sound (s t : SConf) (h : s.equiv t=true) (e : Env) :
    s.eval e=t.eval e := by
  simp [SConf.equiv] at h
  obtain ⟨⟨⟨hq,hd⟩,hl⟩,hr⟩:=h
  simp only [SConf.eval,BC.mk.injEq]
  exact ⟨hq,hd,sideEq_sound _ _ hl e,sideEq_sound _ _ hr e⟩

def RulesValid (rs : Array Diff) : Prop :=
  ∀ (i : Nat) (r : Diff), rs[i]?=some r → r.Valid

theorem emptyRules_valid : RulesValid #[] := by
  intro i r h
  simp at h

theorem RulesValid.push {rs : Array Diff} {r : Diff} (h : RulesValid rs) (hr : r.Valid) :
    RulesValid (rs.push r) := by
  intro i x hx
  rw [Array.getElem?_push] at hx
  split at hx
  · cases hx
    exact hr
  · exact h i x hx

def execOp (rs : Array Diff) (s : SConf) (id : Nat) : Option SConf :=
  if id=0 then ordinary s
  else match rs[id-1]? with
       | none => none
       | some r => r.apply s

theorem execOp_sound (rs : Array Diff) (hv : RulesValid rs)
    (s t : SConf) (id : Nat) (h : execOp rs s id=some t) (e : Env) :
    Reach (s.eval e) (t.eval e) := by
  unfold execOp at h
  split at h
  · exact ordinary_sound s t e h
  · cases hr : rs[id-1]? with
    | none => simp [hr] at h
    | some r =>
      simp only [hr] at h
      exact r.apply_sound (hv _ _ hr) s t h e

def execOps (rs : Array Diff) : SConf → List Nat → Option SConf
  | s, [] => some s
  | s, id::ids =>
    match execOp rs s id with
    | none => none
    | some t => execOps rs t ids

theorem execOps_sound (rs : Array Diff) (hv : RulesValid rs)
    (s t : SConf) (ops : List Nat) (hn : ops≠[]) (h : execOps rs s ops=some t) (e : Env) :
    Reach (s.eval e) (t.eval e) := by
  induction ops generalizing s t with
  | nil => contradiction
  | cons id ids ih =>
    simp only [execOps] at h
    cases he : execOp rs s id with
    | none => simp [he] at h
    | some u =>
      simp only [he] at h
      have h₁ := execOp_sound rs hv s u id he e
      cases ids with
      | nil =>
        simp [execOps] at h
        subst t
        exact h₁
      | cons a as =>
        exact h₁.trans (ih u t (by simp) h)

def validateDiff (rs : Array Diff) (r : Diff) (ops : List Nat) : Bool :=
  if ops.isEmpty then false
  else match execOps rs (r.seed false) ops with
       | none => false
       | some t => t.equiv (r.seed true)

theorem validateDiff_sound (rs : Array Diff) (hv : RulesValid rs)
    (r : Diff) (ops : List Nat) (h : validateDiff rs r ops=true) :
    r.Valid := by
  intro e
  unfold validateDiff at h
  split at h
  · contradiction
  next hn =>
    cases he : execOps rs (r.seed false) ops with
    | none => simp [he] at h
    | some t =>
      simp only [he] at h
      have h₁ := execOps_sound rs hv _ _ ops (by simpa using hn) he e
      rw [SConf.equiv_sound t (r.seed true) h e] at h₁
      exact h₁

inductive Record where
  | rule (r : Diff) (ops : List Nat)
  | path (ops : List Nat)
  deriving Repr

structure ReplayState where
  rules : Array Diff
  current : SConf
  progress : Bool

def stepRecord (s : ReplayState) : Record → Option ReplayState
  | .rule r ops =>
    if validateDiff s.rules r ops then
      some {s with rules:=s.rules.push r}
    else none
  | .path ops =>
    if ops.isEmpty then none
    else match execOps s.rules s.current ops with
         | none => none
         | some t => some {s with current:=t,progress:=true}

def StateInv (start : SConf) (s : ReplayState) : Prop :=
  RulesValid s.rules ∧
    ∀ e : Env, if s.progress then Reach (start.eval e) (s.current.eval e)
                else start.eval e=s.current.eval e

theorem stepRecord_sound (start : SConf) (s t : ReplayState)
    (hInv : StateInv start s) (r : Record) (h : stepRecord s r=some t) :
    StateInv start t := by
  obtain ⟨hv,hp⟩:=hInv
  cases r with
  | rule r ops =>
    simp only [stepRecord] at h
    split at h
    next hr =>
      cases h
      exact ⟨hv.push (validateDiff_sound _ hv r ops hr),hp⟩
    next hr => contradiction
  | path ops =>
    simp only [stepRecord] at h
    split at h
    · contradiction
    next hn =>
      cases he : execOps s.rules s.current ops with
      | none => simp [he] at h
      | some u =>
        simp only [he] at h
        cases h
        refine ⟨hv,?_⟩
        intro e
        have hnew := execOps_sound s.rules hv s.current u ops (by simpa using hn) he e
        have hold := hp e
        cases hs : s.progress
        · simp [hs] at hold
          simpa [←hold] using hnew
        · simp [hs] at hold
          exact hold.trans hnew

def replay : ReplayState → List Record → Option ReplayState
  | s, [] => some s
  | s, r::rs =>
    match stepRecord s r with
    | none => none
    | some t => replay t rs

theorem replay_sound (start : SConf) (s t : ReplayState) (rs : List Record)
    (hi : StateInv start s) (h : replay s rs=some t) : StateInv start t := by
  induction rs generalizing s t with
  | nil =>
    simp [replay] at h
    subst t
    exact hi
  | cons r rs ih =>
    simp only [replay] at h
    cases he : stepRecord s r with
    | none => simp [he] at h
    | some u =>
      simp only [he] at h
      exact ih u t (stepRecord_sound start s u hi r he) h

def initialReplay (start : SConf) : ReplayState := ⟨#[],start,false⟩

def check (start target : SConf) (rs : List Record) : Bool :=
  match replay (initialReplay start) rs with
  | none => false
  | some t => t.progress && t.current.equiv target

theorem check_sound (start target : SConf) (rs : List Record)
    (h : check start target rs=true) (e : Env) :
    Reach (start.eval e) (target.eval e) := by
  unfold check at h
  cases he : replay (initialReplay start) rs with
  | none => simp [he] at h
  | some t =>
    simp only [he,Bool.and_eq_true] at h
    have hi : StateInv start (initialReplay start) := by
      exact ⟨emptyRules_valid,fun _ => rfl⟩
    have hp := (replay_sound start _ _ rs hi he).2 e
    simp only [h.1,ite_true] at hp
    rw [SConf.equiv_sound t.current target h.2 e] at hp
    exact hp

#print axioms check_sound
end W7
