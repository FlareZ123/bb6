import W7Checker
import Lean.Data.Json

open BB6Row146Conjugacy Lean
namespace W7

def decodeState : Nat → Except String State
  | 0 => .ok .A | 1 => .ok .B | 2 => .ok .C
  | 3 => .ok .D | 4 => .ok .E | 5 => .ok .F
  | _ => .error "bad state"

def decodeWord (j : Json) : Except String Word := do
  let n ← j.getNat?
  if n<16 then return wordOfNat n else throw "bad word"

def arrayList (f : Json → Except String α) (j : Json) : Except String (List α) := do
  let a ← j.getArr?
  let b ← a.toList.mapM f
  return b

def parseRule (j : Json) : Except String Record := do
  let sh ← j.getArrVal? 1
  let q ← decodeState (← (← sh.getArrVal? 0).getNat?)
  let d ← (← sh.getArrVal? 1).getNat?
  if d>1 then throw "bad direction"
  let l ← arrayList decodeWord (← sh.getArrVal? 2)
  let r ← arrayList decodeWord (← sh.getArrVal? 3)
  let b ← arrayList Json.getInt? (← j.getArrVal? 2)
  let v ← arrayList Json.getInt? (← j.getArrVal? 3)
  let f ← arrayList Json.getBool? (← j.getArrVal? 4)
  let ops ← arrayList Json.getNat? (← j.getArrVal? 5)
  let ws := l++r
  if ws.length != b.length || ws.length != v.length || ws.length != f.length then
    throw "bad arity"
  let slots := List.zipWith (fun (w,b) (v,f) => Slot.mk w b v f)
    (ws.zip b) (v.zip f)
  return .rule ⟨q,d==1,l.length,slots⟩ ops

def parseLine (line : String) : Except String Record := do
  let j ← Json.parse line
  let tag ← (← j.getArrVal? 0).getStr?
  match tag with
  | "R" => parseRule j
  | "B" =>
    let n ← (← j.getArrVal? 1).getNat?
    return .path (List.replicate n 0)
  | "A" => return .path [(← (← j.getArrVal? 1).getNat?)]
  | "P" => return .path (← arrayList Json.getNat? (← j.getArrVal? 1))
  | _ => throw "bad record tag"

def c (n : Int) : Aff := Aff.const n
def a (n : Int) (cs : List Int) : Aff := ⟨n,cs⟩
def side (xs : List (Nat×Aff)) : Side := xs.map fun (w,n) => (wordOfNat w,n)
def N (y : Aff) : SConf :=
  ⟨.A,false,side [(11,y),(1,c 1)],side [(1,c 28),(3,c 1),(0,c 1),(8,c 1)]⟩
def Q (w : Aff) : SConf :=
  ⟨.F,true,side [(13,c 1),(3,c 1)],
   side [(10,c 1),(2,w),(0,c 1),(2,c 28),(0,c 1),(8,c 1),(4,c 1)]⟩
def D (x y₂ y₁ : Aff) : SConf :=
  ⟨.C,true,side [(7,y₁),(15,c 1),(13,y₂),(7,x),(15,c 1),(13,c 17)],[]⟩
def blankA : SConf := ⟨.A,true,[],[]⟩
def blankD : SConf := ⟨.D,true,[],[]⟩

def casesFor : String → Option (SConf×SConf)
  | "N" => some (N (a 22 [1]),N (a 38626190 [262144]))
  | "A" => some (blankA,N (c 508932094))
  | "Q" => some (Q (a 14 [1]),Q (a 38101896 [262144]))
  | "D" => some (D (a 100 [1,0,0]) (a 130 [0,1,0]) (a 30 [0,0,1]),
     D (a 454337500 [1048576,0,0]) (a 10 [0,1,0]) (a 6 [0,0,1]))
  | "E" => some (D (a 349479900 [1048576]) (c 5759218639205926131) (c 13),
     Q (a 23036877419765819664 [8589934592]))
  | "Dentry" => some (blankD,D (c 70691118354036414594808423388)
     (c 10456559309013950571) (c 939468133961604901))
  | _ => none

def verifyFile (name path : String) : IO Unit := do
  let some (start,target) := casesFor name | throw (IO.userError "bad case")
  let f ← IO.FS.Handle.mk path .read
  let mut s := initialReplay start
  let mut lines := 0
  let mut moves := 0
  repeat
    let line ← f.getLine
    if line.isEmpty then break
    lines := lines+1
    let r ← match parseLine line with
      | .ok r => pure r
      | .error e => throw (IO.userError s!"line {lines}: {e}")
    match r with
    | .path ops => moves:=moves+ops.length
    | .rule _ _ => pure ()
    match stepRecord s r with
    | some t => s:=t
    | none => throw (IO.userError s!"rejected record {lines}, moves {moves}: {repr r}\ncurrent {repr s.current}")
    if lines%100000=0 then IO.println s!"{name}: {lines} records, {moves} moves, {s.rules.size} rules"
  if s.progress && s.current.equiv target then
    IO.println s!"ACCEPT {name}: {lines} records, {moves} moves, {s.rules.size} rules"
  else throw (IO.userError s!"endpoint mismatch: {repr s.current}")

end W7

def main (args : List String) : IO Unit := do
  for name in args do W7.verifyFile name (name++".jsonl")
