import W7Roots

namespace W7

def checkPath (rs : Array Diff) (s t : SConf) (ops : List Nat) : Bool :=
  if ops.isEmpty then false
  else match execOps rs s ops with
       | none => false
       | some u => u.equiv t

theorem checkPath_sound (rs : Array Diff) (hv : RulesValid rs)
    (s t : SConf) (ops : List Nat) (h : checkPath rs s t ops=true) (e : Env) :
    Reach (s.eval e) (t.eval e) := by
  unfold checkPath at h
  split at h
  · contradiction
  next hn =>
    cases he : execOps rs s ops with
    | none => simp [he] at h
    | some u =>
      simp only [he] at h
      have hr := execOps_sound rs hv s u ops (by simpa using hn) he e
      rw [SConf.equiv_sound u t h e] at hr
      exact hr

#print axioms checkPath_sound
end W7
