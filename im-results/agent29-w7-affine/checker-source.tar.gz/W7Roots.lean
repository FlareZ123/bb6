import W7IO

open BB6Row146Conjugacy
namespace W7

@[simp] theorem toNat_max_zero (x : Int) : (max x 0).toNat=x.toNat := by omega

def zenv : Env := fun _ => 0
def Nnat (y : Nat) : BC := (N (c y)).eval zenv
def Qnat (w : Nat) : BC := (Q (c w)).eval zenv
def Dnat (x y₂ y₁ : Nat) : BC := (D (c x) (c y₂) (c y₁)).eval zenv

theorem N_eval (v : Aff) (e : Env) :
    (N v).eval e=Nnat (v.eval e).toNat := by
  simp [Nnat,N,side,c,SConf.eval,evalSide]
theorem Q_eval (v : Aff) (e : Env) :
    (Q v).eval e=Qnat (v.eval e).toNat := by
  simp [Qnat,Q,side,c,SConf.eval,evalSide]
theorem D_eval (x y₂ y₁ : Aff) (e : Env) :
    (D x y₂ y₁).eval e=Dnat (x.eval e).toNat (y₂.eval e).toNat (y₁.eval e).toNat := by
  simp [Dnat,D,side,c,SConf.eval,evalSide]

structure Evidence where
  entryA : ∀ e : Env, Reach (blankA.eval e) ((N (c 508932094)).eval e)
  cycleN : ∀ e : Env, Reach ((N (a 22 [1])).eval e) ((N (a 38626190 [262144])).eval e)
  cycleQ : ∀ e : Env, Reach ((Q (a 14 [1])).eval e) ((Q (a 38101896 [262144])).eval e)
  entryD : ∀ e : Env, Reach (blankD.eval e) ((D (c 70691118354036414594808423388)
    (c 10456559309013950571) (c 939468133961604901)).eval e)
  cycleD : ∀ e : Env, Reach ((D (a 100 [1,0,0]) (a 130 [0,1,0]) (a 30 [0,0,1])).eval e)
    ((D (a 454337500 [1048576,0,0]) (a 10 [0,1,0]) (a 6 [0,0,1])).eval e)
  exhaustion : ∀ e : Env, Reach ((D (a 349479900 [1048576]) (c 5759218639205926131) (c 13)).eval e)
    ((Q (a 23036877419765819664 [8589934592])).eval e)

theorem evidenceFromChecks (ra rn rq rd re rx : List Record)
    (ha : check blankA (N (c 508932094)) ra=true)
    (hn : check (N (a 22 [1])) (N (a 38626190 [262144])) rn=true)
    (hq : check (Q (a 14 [1])) (Q (a 38101896 [262144])) rq=true)
    (hd : check blankD (D (c 70691118354036414594808423388)
       (c 10456559309013950571) (c 939468133961604901)) rd=true)
    (he : check (D (a 100 [1,0,0]) (a 130 [0,1,0]) (a 30 [0,0,1]))
       (D (a 454337500 [1048576,0,0]) (a 10 [0,1,0]) (a 6 [0,0,1])) re=true)
    (hx : check (D (a 349479900 [1048576]) (c 5759218639205926131) (c 13))
       (Q (a 23036877419765819664 [8589934592])) rx=true) : Evidence :=
  ⟨check_sound _ _ ra ha,check_sound _ _ rn hn,check_sound _ _ rq hq,
   check_sound _ _ rd hd,check_sound _ _ re he,check_sound _ _ rx hx⟩

theorem nloop (ev : Evidence) (y : Nat) (hy : 22≤y) :
    Reach (Nnat y) (Nnat (262144*y+32859022)) := by
  let e : Env := fun _=>y-22
  have h:=ev.cycleN e
  rw [N_eval,N_eval] at h
  have h₁ : ((a 22 [1]).eval e).toNat=y := by
    simp [a,Aff.eval,dot,e]; omega
  have h₂ : ((a 38626190 [262144]).eval e).toNat=262144*y+32859022 := by
    simp [a,Aff.eval,dot,e]; omega
  rw [h₁,h₂] at h
  exact h

theorem qloop (ev : Evidence) (w : Nat) (hw : 14≤w) :
    Reach (Qnat w) (Qnat (262144*w+34431880)) := by
  let e : Env := fun _=>w-14
  have h:=ev.cycleQ e
  rw [Q_eval,Q_eval] at h
  have h₁ : ((a 14 [1]).eval e).toNat=w := by
    simp [a,Aff.eval,dot,e]; omega
  have h₂ : ((a 38101896 [262144]).eval e).toNat=262144*w+34431880 := by
    simp [a,Aff.eval,dot,e]; omega
  rw [h₁,h₂] at h
  exact h

def fX (x : Nat) : Nat := 1048576*x+349479900

theorem dloop (ev : Evidence) (x y₂ y₁ : Nat)
    (hx : 100≤x) (h₂ : 130≤y₂) (h₁ : 30≤y₁) :
    Reach (Dnat x y₂ y₁) (Dnat (fX x) (y₂-120) (y₁-24)) := by
  let e : Env := fun i=>if i=0 then x-100 else if i=1 then y₂-130 else y₁-30
  have h:=ev.cycleD e
  rw [D_eval,D_eval] at h
  have hxa : ((a 100 [1,0,0]).eval e).toNat=x := by simp [a,Aff.eval,dot,e]; omega
  have hya : ((a 130 [0,1,0]).eval e).toNat=y₂ := by simp [a,Aff.eval,dot,e]; omega
  have hza : ((a 30 [0,0,1]).eval e).toNat=y₁ := by simp [a,Aff.eval,dot,e]; omega
  have hxb : ((a 454337500 [1048576,0,0]).eval e).toNat=fX x := by simp [a,Aff.eval,dot,e,fX]; omega
  have hyb : ((a 10 [0,1,0]).eval e).toNat=y₂-120 := by simp [a,Aff.eval,dot,e]; omega
  have hzb : ((a 6 [0,0,1]).eval e).toNat=y₁-24 := by simp [a,Aff.eval,dot,e]; omega
  rw [hxa,hya,hza,hxb,hyb,hzb] at h
  exact h

theorem exhaust (ev : Evidence) (z : Nat) :
    Reach (Dnat (fX z) 5759218639205926131 13)
      (Qnat (8589934592*z+23036877419765819664)) := by
  let e : Env := fun _=>z
  have h:=ev.exhaustion e
  rw [D_eval,Q_eval] at h
  have h₁ : ((a 349479900 [1048576]).eval e).toNat=fX z := by simp [a,Aff.eval,dot,e,fX]; omega
  have h₂ : ((a 23036877419765819664 [8589934592]).eval e).toNat=8589934592*z+23036877419765819664 := by
    simp [a,Aff.eval,dot,e]; omega
  rw [h₁,h₂] at h
  simpa [c] using h

def iterX : Nat → Nat → Nat
  | 0,x => x
  | n+1,x => fX (iterX n x)

theorem iterX_ge (n x : Nat) (hx : 100≤x) : 100≤iterX n x := by
  induction n with
  | zero => exact hx
  | succ n ih =>
    change 100 ≤ 1048576 * iterX n x + 349479900
    omega

theorem dloop_repeat (ev : Evidence) (n x y₂ y₁ : Nat)
    (hn : 0<n) (hx : 100≤x) (h₂ : 10≤y₂) (h₁ : 6≤y₁) :
    Reach (Dnat x (y₂+120*n) (y₁+24*n)) (Dnat (iterX n x) y₂ y₁) := by
  induction n generalizing y₂ y₁ with
  | zero => omega
  | succ n ih =>
    cases n with
    | zero =>
      have h := dloop ev x (y₂+120) (y₁+24) hx (by omega) (by omega)
      simpa [iterX] using h
    | succ m =>
      have hp := ih (y₂+120) (y₁+24) (by omega) (by omega) (by omega)
      have hq := dloop ev (iterX (m+1) x) (y₂+120) (y₁+24)
        (iterX_ge _ _ hx) (by omega) (by omega)
      have ht := hp.trans (by simpa using hq)
      have e₂ : y₂+120+120*(m+1)=y₂+120*(m+1+1) := by omega
      have e₁ : y₁+24+24*(m+1)=y₁+24*(m+1+1) := by omega
      rw [e₂,e₁] at ht
      simpa only [iterX] using ht

def Never (b : BC) : Prop := ∀ h : Int, ∀ n : Nat, run row146 n (raw b h)≠none

theorem invariant_never (P : BC → Prop)
    (hp : ∀ b, P b → ∃ c, P c ∧ Reach b c) (b : BC) (hb : P b) :
    Never b := by
  intro h n
  induction n using Nat.strongRecOn generalizing b h with
  | ind n ih =>
    obtain ⟨c,hc,hr⟩:=hp b hb
    obtain ⟨k,h',hk,hk'⟩:=hr h
    intro hnone
    by_cases hnk : n≤k
    · have hs := run_add row146 n (k-n) (raw b h)
      rw [show n+(k-n)=k by omega,hnone] at hs
      rw [hk'] at hs
      contradiction
    · have hs := run_add row146 k (n-k) (raw b h)
      rw [show k+(n-k)=n by omega,hk',hnone] at hs
      exact (ih (n-k) (by omega) c hc h') hs.symm

theorem reach_never {a b : BC} (hr : Reach a b) (hb : Never b) : Never a := by
  intro h n hnone
  obtain ⟨k,h',hk,hk'⟩:=hr h
  by_cases hnk : n≤k
  · have hs := run_add row146 n (k-n) (raw a h)
    rw [show n+(k-n)=k by omega,hnone,hk'] at hs
    contradiction
  · have hs := run_add row146 k (n-k) (raw a h)
    rw [show k+(n-k)=n by omega,hk',hnone] at hs
    exact hb h' (n-k) hs.symm

theorem N_never (ev : Evidence) (y : Nat) (hy : 22≤y) : Never (Nnat y) := by
  apply invariant_never (fun b=>∃ y,22≤y ∧ b=Nnat y) _ _ ⟨y,hy,rfl⟩
  intro b hb
  obtain ⟨z,hz,rfl⟩:=hb
  exact ⟨Nnat (262144*z+32859022),⟨_,by omega,rfl⟩,nloop ev z hz⟩

theorem Q_never (ev : Evidence) (w : Nat) (hw : 14≤w) : Never (Qnat w) := by
  apply invariant_never (fun b=>∃ w,14≤w ∧ b=Qnat w) _ _ ⟨w,hw,rfl⟩
  intro b hb
  obtain ⟨z,hz,rfl⟩:=hb
  exact ⟨Qnat (262144*z+34431880),⟨_,by omega,rfl⟩,qloop ev z hz⟩

theorem raw_blank (q : State) : raw ⟨q,true,empty,empty⟩ 0=blank q := by
  simp only [raw,blank,ite_true]
  apply congrArg (fun t=>Config.mk q 0 t)
  funext x
  simp [tape,empty,Word.zero,Word.read]

theorem blankA_never (ev : Evidence) : ∀ n, run row146 n (blank .A)≠none := by
  have h:=ev.entryA zenv
  rw [N_eval] at h
  have hn : Never ((blankA).eval zenv) := reach_never h (N_never ev _ (by decide))
  intro n
  have hh:=hn 0 n
  simpa [blankA,SConf.eval,evalSide,raw_blank] using hh

theorem blankD_never (ev : Evidence) : ∀ n, run row146 n (blank .D)≠none := by
  let n : Nat := 39144505581733537
  let x : Nat := 70691118354036414594808423388
  let y₂ : Nat := 5759218639205926131
  let y₁ : Nat := 13
  let z : Nat := iterX (n-1) x
  have h:=ev.entryD zenv
  rw [D_eval] at h
  have h₂ : y₂+120*n=10456559309013950571 := by decide
  have h₁ : y₁+24*n=939468133961604901 := by decide
  have hr := dloop_repeat ev n x y₂ y₁ (by decide) (by decide) (by decide) (by decide)
  rw [h₂,h₁] at hr
  have hx : iterX n x=fX z := by
    have he : n=(n-1)+1 := by decide
    calc
      iterX n x = iterX ((n-1)+1) x := congrArg (fun m=>iterX m x) he
      _ = fX z := rfl
  rw [hx] at hr
  have h' : Reach (blankD.eval zenv) (Dnat x 10456559309013950571 939468133961604901) := by
    simpa [c,x] using h
  have he : Reach (Dnat (fX z) y₂ y₁) (Qnat (8589934592*z+23036877419765819664)) :=
    exhaust ev z
  have hq := Q_never ev (8589934592*z+23036877419765819664) (by omega)
  have hn := reach_never (h'.trans (hr.trans he)) hq
  intro k
  have hh:=hn 0 k
  simpa [blankD,SConf.eval,evalSide,raw_blank] using hh

theorem row411_never (ev : Evidence) : ∀ n, run row411 n (blank .A)≠none := by
  intro n hn
  obtain ⟨k,hk⟩:=rooted_halts_iff.mp ⟨n,hn⟩
  exact blankD_never ev k hk

#print axioms blankA_never
#print axioms row411_never
end W7
