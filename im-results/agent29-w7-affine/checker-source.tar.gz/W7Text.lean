import W7Path
import Lean.Elab.Tactic.Decide

namespace W7

def replayLines : ReplayState → List String → Option ReplayState
  | s,[] => some s
  | s,line::lines =>
    if line.isEmpty then replayLines s lines
    else match parseLine line with
         | .error _ => none
         | .ok r =>
           match stepRecord s r with
           | none => none
           | some t => replayLines t lines

theorem replayLines_sound (start : SConf) (s t : ReplayState) (lines : List String)
    (hi : StateInv start s) (h : replayLines s lines=some t) : StateInv start t := by
  induction lines generalizing s t with
  | nil =>
    simp [replayLines] at h
    subst t
    exact hi
  | cons line lines ih =>
    simp only [replayLines] at h
    split at h
    · exact ih s t hi h
    · cases hp : parseLine line with
      | error e => simp [hp] at h
      | ok r =>
        simp only [hp] at h
        cases hr : stepRecord s r with
        | none => simp [hr] at h
        | some u =>
          simp only [hr] at h
          exact ih u t (stepRecord_sound start s u hi r hr) h

def checkText (start target : SConf) (text : String) : Bool :=
  match replayLines (initialReplay start) (text.splitOn "\n") with
  | none => false
  | some t => t.progress && t.current.equiv target

theorem checkText_sound (start target : SConf) (text : String)
    (h : checkText start target text=true) (e : Env) :
    Reach (start.eval e) (target.eval e) := by
  unfold checkText at h
  cases he : replayLines (initialReplay start) (text.splitOn "\n") with
  | none => simp [he] at h
  | some t =>
    simp only [he,Bool.and_eq_true] at h
    have hi : StateInv start (initialReplay start) := by
      exact ⟨emptyRules_valid,fun _=>rfl⟩
    have hp := (replayLines_sound start _ _ _ hi he).2 e
    simp only [h.1,ite_true] at hp
    rw [SConf.equiv_sound t.current target h.2 e] at hp
    exact hp

#print axioms checkText_sound
end W7
