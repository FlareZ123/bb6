import Row146Conjugacy
import Lean.Elab.Tactic.Omega

open BB6Row146Conjugacy

namespace W7

structure Word where
  b0 : Bool
  b1 : Bool
  b2 : Bool
  b3 : Bool
  deriving DecidableEq, Repr

def Word.zero : Word := ⟨false,false,false,false⟩

def Word.read (w : Word) (i : Int) : Bool :=
  if i=0 then w.b0 else if i=1 then w.b1 else if i=2 then w.b2 else w.b3

def Word.write (w : Word) (i : Int) (b : Bool) : Word :=
  if i=0 then {w with b0:=b} else if i=1 then {w with b1:=b}
  else if i=2 then {w with b2:=b} else {w with b3:=b}

def place (t : Int → Bool) (h : Int) (w : Word) : Int → Bool :=
  fun x => if 0 ≤ x-h ∧ x-h < 4 then w.read (x-h) else t x

theorem place_read (t : Int → Bool) (h i : Int) (w : Word)
    (hi : 0 ≤ i ∧ i < 4) : place t h w (h+i) = w.read i := by
  simp [place, show h+i-h=i by omega, hi]

theorem word_write_read (w : Word) (i j : Int) (b : Bool)
    (hi : 0 ≤ i ∧ i < 4) (hj : 0 ≤ j ∧ j < 4) :
    (w.write i b).read j = if j=i then b else w.read j := by
  have hi' : i=0 ∨ i=1 ∨ i=2 ∨ i=3 := by omega
  have hj' : j=0 ∨ j=1 ∨ j=2 ∨ j=3 := by omega
  rcases hi' with h|h|h|h <;> rcases hj' with k|k|k|k <;> simp [Word.read, Word.write,h,k]

theorem place_write (t : Int → Bool) (h i : Int) (w : Word) (b : Bool)
    (hi : 0 ≤ i ∧ i < 4) :
    place t h (w.write i b) = fun x => if x=h+i then b else place t h w x := by
  funext x
  by_cases hx : 0 ≤ x-h ∧ x-h < 4
  · simp only [place,ite_eq_left hx]
    rw [word_write_read w i (x-h) b hi hx]
    by_cases he : x=h+i
    · have hs : x-h=i := by omega
      simp only [ite_eq_left hs,ite_eq_left he]
    · have hs : x-h≠i := by omega
      simp only [ite_eq_right hs,ite_eq_right he]
  · have he : x≠h+i := by omega
    simp only [place,ite_eq_right hx,ite_eq_right he]

structure Local where
  state : State
  pos : Int
  word : Word
  deriving DecidableEq, Repr

def realize (t : Int → Bool) (h : Int) (l : Local) : Config :=
  ⟨l.state,h+l.pos,place t h l.word⟩

def localStep (l : Local) : Option Local :=
  (row146 l.state (l.word.read l.pos)).map fun r =>
    ⟨r.next,l.pos+delta r.dir,l.word.write l.pos r.write⟩

theorem localStep_sound (t : Int → Bool) (h : Int) (l : Local)
    (hi : 0 ≤ l.pos ∧ l.pos < 4) :
    step row146 (realize t h l) = (localStep l).map (realize t h) := by
  dsimp only [step,realize,localStep]
  rw [place_read t h l.pos l.word hi]
  cases he : row146 l.state (l.word.read l.pos) with
  | none => rfl
  | some r =>
    simp only [Option.map_some]
    dsimp only [realize]
    rw [place_write t h l.pos l.word r.write hi]
    apply congrArg some
    simp only [Config.mk.injEq, true_and, and_true]
    omega

def inside (l : Local) : Bool := decide (0 ≤ l.pos ∧ l.pos < 4)

-- At the first departure, return the positive primitive time and local result.
def evalLocal : Nat → Local → Option (Nat × Local)
  | 0, l => if inside l then none else some (0,l)
  | n+1, l =>
    if inside l then
      match localStep l with
      | none => none
      | some l' =>
        match evalLocal n l' with
        | none => none
        | some (k,o) => some (k+1,o)
    else some (0,l)

theorem evalLocal_sound (t : Int → Bool) (h : Int)
    (fuel : Nat) (l : Local) (k : Nat) (o : Local)
    (he : evalLocal fuel l = some (k,o)) :
    run row146 k (realize t h l) = some (realize t h o) := by
  induction fuel generalizing l k o with
  | zero =>
    simp [evalLocal] at he
    obtain ⟨_,rfl,rfl⟩ := he
    rfl
  | succ n ih =>
    simp only [evalLocal] at he
    split at he
    next hin =>
      have hi : 0 ≤ l.pos ∧ l.pos < 4 := of_decide_eq_true hin
      cases hs : localStep l with
      | none => simp [hs] at he
      | some l' =>
        simp only [hs] at he
        cases hr : evalLocal n l' with
        | none => simp [hr] at he
        | some ko =>
          rcases ko with ⟨j,o'⟩
          simp only [hr, Option.some.injEq, Prod.mk.injEq] at he
          obtain ⟨rfl,rfl⟩ := he
          simp only [run,localStep_sound t h l hi,hs,Option.map_some,Option.bind_some]
          exact ih l' j o' hr
    next hout =>
      simp only [Option.some.injEq,Prod.mk.injEq] at he
      obtain ⟨rfl,rfl⟩ := he
      rfl

structure BlockResult where
  state : State
  right : Bool
  word : Word
  steps : Nat
  deriving DecidableEq, Repr

def initial (q : State) (right : Bool) (w : Word) : Local :=
  ⟨q,if right then 0 else 3,w⟩

def block (q : State) (right : Bool) (w : Word) : Option BlockResult :=
  match evalLocal 384 (initial q right w) with
  | none => none
  | some (k,o) =>
    if k=0 then none
    else if o.pos=4 then some ⟨o.state,true,o.word,k⟩
    else if o.pos = -1 then some ⟨o.state,false,o.word,k⟩
    else none

theorem block_sound (q : State) (right : Bool) (w : Word) (r : BlockResult)
    (he : block q right w = some r) (t : Int → Bool) (h : Int) :
    0 < r.steps ∧
    run row146 r.steps (realize t h (initial q right w)) =
      some (realize t h ⟨r.state,if r.right then 4 else -1,r.word⟩) := by
  unfold block at he
  cases hs : evalLocal 384 (initial q right w) with
  | none => simp [hs] at he
  | some ko =>
    rcases ko with ⟨k,q',i',w'⟩
    simp only [hs] at he
    split at he
    · contradiction
    next hk =>
      split at he
      next hp =>
        injection he with hr
        subst r
        have hk' : 0 < k := Nat.pos_of_ne_zero hk
        exact ⟨hk',by simpa [hp] using evalLocal_sound t h 384 (initial q right w) k ⟨q',i',w'⟩ hs⟩
      next hp =>
        split at he
        next hm =>
          injection he with hr
          subst r
          have hk' : 0 < k := Nat.pos_of_ne_zero hk
          exact ⟨hk',by simpa [hm] using evalLocal_sound t h 384 (initial q right w) k ⟨q',i',w'⟩ hs⟩
        · contradiction

#print axioms block_sound
end W7
