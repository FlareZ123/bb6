import W7Local
import Lean.Elab.Tactic.Omega

open BB6Row146Conjugacy

namespace W7

abbrev Stack := Nat → Word

def empty : Stack := fun _ => Word.zero
def cons (w : Word) (s : Stack) : Stack := fun n => if n=0 then w else s (n-1)
def tail (s : Stack) : Stack := fun n => s (n+1)

@[simp] theorem cons_zero (w : Word) (s : Stack) : cons w s 0 = w := by rfl
@[simp] theorem tail_cons (w : Word) (s : Stack) : tail (cons w s) = s := by
  funext n
  simp [tail,cons]
@[simp] theorem cons_tail (s : Stack) : cons (s 0) (tail s) = s := by
  funext n
  cases n <;> simp [cons,tail]

def tape (L R : Stack) (h : Int) : Int → Bool :=
  fun x =>
    (if h≤x then R ((x-h)/4).toNat else L ((h-1-x)/4).toNat).read ((x-h)%4)

theorem writeR (L R : Stack) (h : Int) (w : Word) :
    place (tape L R h) h w = tape L (cons w (tail R)) h := by
  funext x
  by_cases hx : h≤x
  · by_cases hy : x<h+4
    · have hi : 0≤x-h ∧ x-h<4 := by omega
      have hj : ((x-h)/4).toNat=0 := by omega
      have hk : (x-h)%4=x-h := by omega
      simp only [place,ite_eq_left hi,tape,ite_eq_left hx,hj,cons_zero,hk]
    · have hi : ¬ (0≤x-h ∧ x-h<4) := by omega
      have hj : ((x-h)/4).toNat≠0 := by omega
      have hk : ((x-h)/4).toNat-1+1=((x-h)/4).toNat := by omega
      simp only [place,ite_eq_right hi,tape,ite_eq_left hx,cons,ite_eq_right hj,tail,hk]
  · have hi : ¬ (0≤x-h ∧ x-h<4) := by omega
    simp only [place,ite_eq_right hi,tape,ite_eq_right hx]

theorem writeL (L R : Stack) (h : Int) (w : Word) :
    place (tape L R h) (h-4) w = tape (cons w (tail L)) R h := by
  funext x
  by_cases hx : h≤x
  · have hi : ¬ (0≤x-(h-4) ∧ x-(h-4)<4) := by omega
    simp only [place,ite_eq_right hi,tape,ite_eq_left hx]
  · by_cases hy : h-4≤x
    · have hi : 0≤x-(h-4) ∧ x-(h-4)<4 := by omega
      have hj : ((h-1-x)/4).toNat=0 := by omega
      have hk : (x-h)%4=x-(h-4) := by omega
      simp only [place,ite_eq_left hi,tape,ite_eq_right hx,hj,cons_zero,hk]
    · have hi : ¬ (0≤x-(h-4) ∧ x-(h-4)<4) := by omega
      have hj : ((h-1-x)/4).toNat≠0 := by omega
      have hk : ((h-1-x)/4).toNat-1+1=((h-1-x)/4).toNat := by omega
      simp only [place,ite_eq_right hi,tape,ite_eq_right hx,cons,ite_eq_right hj,tail,hk]

theorem shiftR (L R : Stack) (h : Int) :
    tape L R h = tape (cons (R 0) L) (tail R) (h+4) := by
  funext x
  have hm : (x-(h+4))%4=(x-h)%4 := by omega
  by_cases hx : h≤x
  · by_cases hy : h+4≤x
    · have hj : ((x-(h+4))/4).toNat+1=((x-h)/4).toNat := by omega
      simp only [tape,ite_eq_left hx,ite_eq_left hy,tail,hj,hm]
    · have hj : ((x-h)/4).toNat=0 := by omega
      have hk : ((h+4-1-x)/4).toNat=0 := by omega
      simp only [tape,ite_eq_left hx,ite_eq_right hy,hj,hk,cons_zero,hm]
  · have hy : ¬ h+4≤x := by omega
    have hj : ((h+4-1-x)/4).toNat≠0 := by omega
    have hk : ((h+4-1-x)/4).toNat-1=((h-1-x)/4).toNat := by omega
    simp only [tape,ite_eq_right hx,ite_eq_right hy,cons,ite_eq_right hj,hk,hm]

theorem shiftL (L R : Stack) (h : Int) :
    tape L R h = tape (tail L) (cons (L 0) R) (h-4) := by
  have hh := shiftR (tail L) (cons (L 0) R) (h-4)
  simpa only [cons_zero,tail_cons,cons_tail,show h-4+4=h by omega] using hh.symm

structure BC where
  state : State
  right : Bool
  L : Stack
  R : Stack

def raw (c : BC) (h : Int) : Config :=
  ⟨c.state,if c.right then h else h-1,tape c.L c.R h⟩

def peek (c : BC) : Word := if c.right then c.R 0 else c.L 0

def next (c : BC) (r : BlockResult) : BC :=
  if c.right then
    if r.right then ⟨r.state,true,cons r.word c.L,tail c.R⟩
    else ⟨r.state,false,c.L,cons r.word (tail c.R)⟩
  else
    if r.right then ⟨r.state,true,cons r.word (tail c.L),c.R⟩
    else ⟨r.state,false,tail c.L,cons r.word c.R⟩

def Reach (a b : BC) : Prop :=
  ∀ h : Int, ∃ k : Nat, ∃ h' : Int, 0<k ∧ run row146 k (raw a h)=some (raw b h')

theorem rawBlock_sound (c : BC) (r : BlockResult)
    (he : block c.state c.right (peek c)=some r) :
    Reach c (next c r) := by
  intro h
  rcases c with ⟨q,d,L,R⟩
  rcases r with ⟨q',d',w,k⟩
  cases d <;> cases d'
  · have hb := block_sound q false (L 0) ⟨q',false,w,k⟩ he (tape L R h) (h-4)
    refine ⟨k,h-4,hb.1,?_⟩
    have hi : place (tape L R h) (h-4) (L 0)=tape L R h := by rw [writeL,cons_tail]
    have ho : place (tape L R h) (h-4) w=tape (tail L) (cons w R) (h-4) := by
      rw [writeL,shiftL (cons w (tail L)) R h,tail_cons,cons_zero]
    simpa [realize,initial,raw,next,hi,ho,show h-4+3=h-1 by omega,
      show h-4+(-1)=h-4-1 by omega] using hb.2
  · have hb := block_sound q false (L 0) ⟨q',true,w,k⟩ he (tape L R h) (h-4)
    refine ⟨k,h,hb.1,?_⟩
    have hi : place (tape L R h) (h-4) (L 0)=tape L R h := by rw [writeL,cons_tail]
    simpa [realize,initial,raw,next,hi,writeL,show h-4+3=h-1 by omega,
      show h-4+4=h by omega] using hb.2
  · have hb := block_sound q true (R 0) ⟨q',false,w,k⟩ he (tape L R h) h
    refine ⟨k,h,hb.1,?_⟩
    have hi : place (tape L R h) h (R 0)=tape L R h := by rw [writeR,cons_tail]
    simpa [realize,initial,raw,next,hi,writeR,show h+(-1)=h-1 by omega] using hb.2
  · have hb := block_sound q true (R 0) ⟨q',true,w,k⟩ he (tape L R h) h
    refine ⟨k,h+4,hb.1,?_⟩
    have hi : place (tape L R h) h (R 0)=tape L R h := by rw [writeR,cons_tail]
    have ho : place (tape L R h) h w=tape (cons w L) (tail R) (h+4) := by
      rw [writeR,shiftR L (cons w (tail R)) h,tail_cons,cons_zero]
    simpa [realize,initial,raw,next,hi,ho] using hb.2

theorem run_add (M : Machine) (n m : Nat) (c : Config) :
    run M (n+m) c = (run M n c).bind (run M m) := by
  induction n generalizing c with
  | zero => simp [run]
  | succ n ih =>
    simp only [Nat.succ_add,run]
    cases hs : step M c with
    | none => rfl
    | some c' => exact ih c'

theorem Reach.trans {a b c : BC} (h₁ : Reach a b) (h₂ : Reach b c) : Reach a c := by
  intro h
  obtain ⟨n,h',hn,hr⟩ := h₁ h
  obtain ⟨m,h'',hm,hs⟩ := h₂ h'
  exact ⟨n+m,h'',by omega,by rw [run_add,hr]; exact hs⟩

#print axioms rawBlock_sound
#print axioms Reach.trans
end W7
