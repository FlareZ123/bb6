import W7Stack

open BB6Row146Conjugacy
namespace W7

def rep (w : Word) (n : Nat) (s : Stack) : Stack :=
  fun i => if i<n then w else s (i-n)

@[simp] theorem rep_zero (w : Word) (s : Stack) : rep w 0 s = s := by
  funext i
  simp [rep]
@[simp] theorem rep_one (w : Word) (s : Stack) : rep w 1 s = cons w s := by
  funext i
  have hi : i<1 ↔ i=0 := by omega
  simp [rep,cons,hi]
theorem rep_add (w : Word) (m n : Nat) (s : Stack) :
    rep w (m+n) s = rep w m (rep w n s) := by
  funext i
  by_cases hm : i<m
  · have h : i<m+n := by omega
    simp only [rep,ite_eq_left hm,ite_eq_left h]
  · by_cases hn : i-m<n
    · have h : i<m+n := by omega
      simp only [rep,ite_eq_right hm,ite_eq_left hn,ite_eq_left h]
    · have h : ¬ i<m+n := by omega
      simp only [rep,ite_eq_right hm,ite_eq_right hn,ite_eq_right h]
      congr 1
      omega
theorem rep_succ (w : Word) (n : Nat) (s : Stack) :
    rep w (n+1) s = cons w (rep w n s) := by
  rw [Nat.add_comm,rep_add,rep_one]
@[simp] theorem rep_head (w : Word) (n : Nat) (s : Stack) :
    rep w (n+1) s 0 = w := by rw [rep_succ,cons_zero]
@[simp] theorem rep_tail (w : Word) (n : Nat) (s : Stack) :
    tail (rep w (n+1) s) = rep w n s := by rw [rep_succ,tail_cons]
@[simp] theorem rep_zero_empty (n : Nat) : rep Word.zero n empty = empty := by
  funext i
  simp [rep,empty]

theorem sweepRight (q : State) (w v : Word) (k : Nat)
    (hb : block q true w = some ⟨q,true,v,k⟩) (n : Nat) (hn : 0<n)
    (L R : Stack) :
    Reach ⟨q,true,L,rep w n R⟩ ⟨q,true,rep v n L,R⟩ := by
  induction n generalizing L R with
  | zero => omega
  | succ n ih =>
    let c : BC := ⟨q,true,L,rep w (n+1) R⟩
    have hfirst : Reach c ⟨q,true,cons v L,rep w n R⟩ := by
      have hh : block c.state c.right (peek c)=some ⟨q,true,v,k⟩ := by
        simpa [c,peek] using hb
      simpa [c,next] using rawBlock_sound c ⟨q,true,v,k⟩ hh
    cases n with
    | zero => simpa [c] using hfirst
    | succ m =>
      have hs := ih (by omega) (cons v L) R
      have ht := hfirst.trans hs
      rw [←rep_one v L,←rep_add] at ht
      simpa [c] using ht

theorem sweepLeft (q : State) (w v : Word) (k : Nat)
    (hb : block q false w = some ⟨q,false,v,k⟩) (n : Nat) (hn : 0<n)
    (L R : Stack) :
    Reach ⟨q,false,rep w n L,R⟩ ⟨q,false,L,rep v n R⟩ := by
  induction n generalizing L R with
  | zero => omega
  | succ n ih =>
    let c : BC := ⟨q,false,rep w (n+1) L,R⟩
    have hfirst : Reach c ⟨q,false,rep w n L,cons v R⟩ := by
      have hh : block c.state c.right (peek c)=some ⟨q,false,v,k⟩ := by
        simpa [c,peek] using hb
      simpa [c,next] using rawBlock_sound c ⟨q,false,v,k⟩ hh
    cases n with
    | zero => simpa [c] using hfirst
    | succ m =>
      have hs := ih (by omega) L (cons v R)
      have ht := hfirst.trans hs
      rw [←rep_one v R,←rep_add] at ht
      simpa [c] using ht

#print axioms sweepRight
#print axioms sweepLeft
end W7
