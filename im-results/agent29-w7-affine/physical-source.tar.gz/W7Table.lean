import W7Local
open BB6Row146Conjugacy
namespace W7

def stateCode : State → Nat
  | .A=>0 | .B=>1 | .C=>2 | .D=>3 | .E=>4 | .F=>5

def wordCode (w : Word) : Nat :=
  (if w.b0 then 8 else 0)+(if w.b1 then 4 else 0)+
  (if w.b2 then 2 else 0)+(if w.b3 then 1 else 0)

def wordOfNat (n : Nat) : Word :=
  ⟨n.testBit 3,n.testBit 2,n.testBit 1,n.testBit 0⟩

def blockTable : Array (Option BlockResult) := #[
  some ⟨.B,true,⟨false,false,false,true⟩,1⟩, some ⟨.E,true,⟨false,false,true,false⟩,3⟩, some ⟨.B,true,⟨false,false,true,true⟩,1⟩, some ⟨.E,true,⟨false,true,true,false⟩,5⟩,
  some ⟨.B,true,⟨false,true,false,true⟩,1⟩, some ⟨.E,true,⟨false,true,true,false⟩,3⟩, some ⟨.B,true,⟨false,true,true,true⟩,1⟩, some ⟨.A,false,⟨false,true,false,false⟩,14⟩,
  some ⟨.B,true,⟨true,false,false,true⟩,1⟩, some ⟨.E,true,⟨true,false,true,false⟩,3⟩, some ⟨.B,true,⟨true,false,true,true⟩,1⟩, some ⟨.E,true,⟨true,true,true,false⟩,5⟩,
  some ⟨.B,true,⟨true,true,false,true⟩,1⟩, some ⟨.E,true,⟨true,true,true,false⟩,3⟩, some ⟨.B,true,⟨true,true,true,true⟩,1⟩, some ⟨.A,false,⟨false,true,false,true⟩,4⟩,
  some ⟨.B,false,⟨true,false,true,true⟩,7⟩, some ⟨.A,false,⟨false,true,false,false⟩,7⟩, some ⟨.F,true,⟨true,true,false,true⟩,4⟩, none,
  some ⟨.B,false,⟨true,false,false,false⟩,3⟩, some ⟨.B,false,⟨true,false,false,true⟩,3⟩, some ⟨.B,false,⟨true,false,true,false⟩,3⟩, some ⟨.B,false,⟨true,false,true,true⟩,3⟩,
  some ⟨.B,false,⟨true,false,false,false⟩,1⟩, some ⟨.B,false,⟨true,false,false,true⟩,1⟩, some ⟨.B,false,⟨true,false,true,false⟩,1⟩, some ⟨.B,false,⟨true,false,true,true⟩,1⟩,
  some ⟨.B,false,⟨true,true,false,false⟩,1⟩, some ⟨.B,false,⟨true,true,false,true⟩,1⟩, some ⟨.B,false,⟨true,true,true,false⟩,1⟩, some ⟨.B,false,⟨true,true,true,true⟩,1⟩,
  some ⟨.C,true,⟨false,false,false,true⟩,1⟩, some ⟨.C,true,⟨false,false,true,true⟩,3⟩, some ⟨.C,true,⟨false,false,true,true⟩,1⟩, some ⟨.F,true,⟨false,true,false,true⟩,5⟩,
  some ⟨.C,true,⟨false,true,false,true⟩,1⟩, some ⟨.C,true,⟨false,true,true,true⟩,3⟩, some ⟨.C,true,⟨false,true,true,true⟩,1⟩, some ⟨.F,true,⟨true,true,false,true⟩,7⟩,
  some ⟨.C,true,⟨true,false,false,true⟩,1⟩, some ⟨.C,true,⟨true,false,true,true⟩,3⟩, some ⟨.C,true,⟨true,false,true,true⟩,1⟩, some ⟨.F,true,⟨true,true,false,true⟩,5⟩,
  some ⟨.C,true,⟨true,true,false,true⟩,1⟩, some ⟨.C,true,⟨true,true,true,true⟩,3⟩, some ⟨.C,true,⟨true,true,true,true⟩,1⟩, some ⟨.B,false,⟨true,false,true,false⟩,4⟩,
  some ⟨.A,false,⟨false,true,true,false⟩,5⟩, some ⟨.A,false,⟨false,true,true,true⟩,5⟩, some ⟨.B,false,⟨true,false,false,false⟩,5⟩, some ⟨.B,false,⟨true,false,false,true⟩,5⟩,
  some ⟨.B,true,⟨true,false,true,true⟩,4⟩, some ⟨.A,false,⟨false,true,false,false⟩,11⟩, none, none,
  some ⟨.A,false,⟨false,false,false,false⟩,1⟩, some ⟨.A,false,⟨false,false,false,true⟩,1⟩, some ⟨.A,false,⟨false,false,true,false⟩,1⟩, some ⟨.A,false,⟨false,false,true,true⟩,1⟩,
  some ⟨.A,false,⟨false,true,false,false⟩,1⟩, some ⟨.A,false,⟨false,true,false,true⟩,1⟩, some ⟨.A,false,⟨false,true,true,false⟩,1⟩, some ⟨.A,false,⟨false,true,true,true⟩,1⟩,
  some ⟨.D,true,⟨false,false,false,true⟩,1⟩, some ⟨.E,true,⟨false,false,false,false⟩,1⟩, some ⟨.D,true,⟨false,false,true,true⟩,1⟩, some ⟨.E,true,⟨false,false,true,false⟩,1⟩,
  some ⟨.D,true,⟨false,true,false,true⟩,1⟩, some ⟨.E,true,⟨false,true,false,false⟩,1⟩, some ⟨.D,true,⟨false,true,true,true⟩,1⟩, some ⟨.E,true,⟨false,true,true,false⟩,1⟩,
  some ⟨.D,true,⟨true,false,false,true⟩,1⟩, some ⟨.E,true,⟨true,false,false,false⟩,1⟩, some ⟨.D,true,⟨true,false,true,true⟩,1⟩, some ⟨.E,true,⟨true,false,true,false⟩,1⟩,
  some ⟨.D,true,⟨true,true,false,true⟩,1⟩, some ⟨.E,true,⟨true,true,false,false⟩,1⟩, some ⟨.D,true,⟨true,true,true,true⟩,1⟩, some ⟨.E,true,⟨true,true,true,false⟩,1⟩,
  some ⟨.B,false,⟨true,true,false,false⟩,3⟩, some ⟨.B,false,⟨true,true,false,true⟩,3⟩, some ⟨.B,false,⟨true,true,true,false⟩,3⟩, some ⟨.B,false,⟨true,true,true,true⟩,3⟩,
  some ⟨.A,false,⟨false,false,false,false⟩,3⟩, some ⟨.A,false,⟨false,false,false,true⟩,3⟩, some ⟨.A,false,⟨false,false,true,false⟩,3⟩, some ⟨.A,false,⟨false,false,true,true⟩,3⟩,
  some ⟨.C,true,⟨false,true,true,true⟩,4⟩, some ⟨.F,true,⟨true,true,false,true⟩,10⟩, some ⟨.B,false,⟨true,false,false,false⟩,9⟩, some ⟨.B,false,⟨true,false,false,true⟩,9⟩,
  none, none, none, none,
  some ⟨.F,true,⟨false,true,false,true⟩,7⟩, some ⟨.D,true,⟨false,false,true,true⟩,3⟩, none, some ⟨.D,true,⟨false,true,true,true⟩,5⟩,
  some ⟨.F,true,⟨true,true,false,true⟩,9⟩, some ⟨.D,true,⟨false,true,true,true⟩,3⟩, none, some ⟨.B,true,⟨true,false,true,true⟩,7⟩,
  some ⟨.F,true,⟨true,true,false,true⟩,7⟩, some ⟨.D,true,⟨true,false,true,true⟩,3⟩, none, some ⟨.D,true,⟨true,true,true,true⟩,5⟩,
  some ⟨.B,false,⟨true,false,true,false⟩,6⟩, some ⟨.D,true,⟨true,true,true,true⟩,3⟩, some ⟨.B,false,⟨true,false,true,true⟩,4⟩, some ⟨.A,false,⟨false,true,false,false⟩,4⟩,
  some ⟨.A,false,⟨true,false,false,false⟩,1⟩, some ⟨.A,false,⟨true,false,false,true⟩,1⟩, some ⟨.A,false,⟨true,false,true,false⟩,1⟩, some ⟨.A,false,⟨true,false,true,true⟩,1⟩,
  some ⟨.A,false,⟨true,true,false,false⟩,1⟩, some ⟨.A,false,⟨true,true,false,true⟩,1⟩, some ⟨.A,false,⟨true,true,true,false⟩,1⟩, some ⟨.A,false,⟨true,true,true,true⟩,1⟩,
  some ⟨.B,false,⟨false,false,false,false⟩,1⟩, some ⟨.B,false,⟨false,false,false,true⟩,1⟩, some ⟨.B,false,⟨false,false,true,false⟩,1⟩, some ⟨.B,false,⟨false,false,true,true⟩,1⟩,
  some ⟨.B,false,⟨false,true,false,false⟩,1⟩, some ⟨.B,false,⟨false,true,false,true⟩,1⟩, some ⟨.B,false,⟨false,true,true,false⟩,1⟩, some ⟨.B,false,⟨false,true,true,true⟩,1⟩,
  some ⟨.F,true,⟨false,false,false,true⟩,1⟩, none, some ⟨.F,true,⟨false,false,true,true⟩,1⟩, none,
  some ⟨.F,true,⟨false,true,false,true⟩,1⟩, none, some ⟨.F,true,⟨false,true,true,true⟩,1⟩, none,
  some ⟨.F,true,⟨true,false,false,true⟩,1⟩, none, some ⟨.F,true,⟨true,false,true,true⟩,1⟩, none,
  some ⟨.F,true,⟨true,true,false,true⟩,1⟩, none, some ⟨.F,true,⟨true,true,true,true⟩,1⟩, none,
  some ⟨.D,true,⟨true,true,true,true⟩,4⟩, some ⟨.E,true,⟨true,true,true,false⟩,4⟩, some ⟨.A,false,⟨false,true,false,false⟩,5⟩, some ⟨.A,false,⟨false,true,false,true⟩,5⟩,
  some ⟨.B,false,⟨false,true,false,false⟩,3⟩, some ⟨.B,false,⟨false,true,false,true⟩,3⟩, some ⟨.B,false,⟨false,true,true,false⟩,3⟩, some ⟨.B,false,⟨false,true,true,true⟩,3⟩,
  none, none, none, none,
  none, none, none, none,
  some ⟨.B,true,⟨false,false,false,true⟩,1⟩, some ⟨.A,false,⟨false,true,false,false⟩,16⟩, some ⟨.B,true,⟨false,false,true,true⟩,1⟩, some ⟨.B,true,⟨true,false,true,true⟩,11⟩,
  some ⟨.B,true,⟨false,true,false,true⟩,1⟩, none, some ⟨.B,true,⟨false,true,true,true⟩,1⟩, some ⟨.A,false,⟨false,true,false,false⟩,10⟩,
  some ⟨.B,true,⟨true,false,false,true⟩,1⟩, some ⟨.A,false,⟨false,true,false,true⟩,6⟩, some ⟨.B,true,⟨true,false,true,true⟩,1⟩, some ⟨.A,false,⟨false,true,false,false⟩,8⟩,
  some ⟨.B,true,⟨true,true,false,true⟩,1⟩, some ⟨.A,false,⟨false,true,true,true⟩,4⟩, some ⟨.B,true,⟨true,true,true,true⟩,1⟩, some ⟨.B,false,⟨true,false,false,true⟩,4⟩,
  some ⟨.B,false,⟨true,false,true,true⟩,7⟩, some ⟨.A,false,⟨false,true,false,false⟩,7⟩, some ⟨.F,true,⟨true,true,false,true⟩,4⟩, none,
  some ⟨.B,false,⟨true,false,false,false⟩,3⟩, some ⟨.B,false,⟨true,false,false,true⟩,3⟩, some ⟨.B,false,⟨true,false,true,false⟩,3⟩, some ⟨.B,false,⟨true,false,true,true⟩,3⟩,
  some ⟨.D,false,⟨true,false,false,false⟩,1⟩, some ⟨.D,false,⟨true,false,false,true⟩,1⟩, some ⟨.D,false,⟨true,false,true,false⟩,1⟩, some ⟨.D,false,⟨true,false,true,true⟩,1⟩,
  some ⟨.D,false,⟨true,true,false,false⟩,1⟩, some ⟨.D,false,⟨true,true,false,true⟩,1⟩, some ⟨.D,false,⟨true,true,true,false⟩,1⟩, some ⟨.D,false,⟨true,true,true,true⟩,1⟩
]

def blockFast (q : State) (d : Bool) (w : Word) : Option BlockResult :=
  (blockTable[stateCode q*32+(if d then 16 else 0)+wordCode w]?).join

set_option maxHeartbeats 0 in
set_option maxRecDepth 10000 in
theorem blockFast_eq (q : State) (d : Bool) (w : Word) :
    blockFast q d w=block q d w := by
  cases q <;> cases d <;> rcases w with ⟨b0,b1,b2,b3⟩ <;>
    cases b0 <;> cases b1 <;> cases b2 <;> cases b3 <;> decide

#print axioms blockFast_eq
end W7
