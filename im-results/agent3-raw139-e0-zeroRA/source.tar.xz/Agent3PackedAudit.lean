import ZipAuditCore
import FastThreeHoleAudit

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace BB6.Agent3PackedAudit
open BB6Coverage BB6Coverage.Agent50Zipper BB6Coverage.Agent31Pump BB6Coverage.Agent10ZipAudit BB6Coverage.Agent50SideCycle
open BB6.Agent13BlankDelay BB6.Agent50TNFPilot BB6.Agent31ThreeHole

def pack : List Bool → Nat
  | [] => 0
  | b::bs => b.toNat + 2 * pack bs

theorem pack_head (xs : List Bool) : pack xs % 2 = (xs.headD false).toNat := by
  cases xs with
  | nil => rfl
  | cons b bs => cases b <;> simp [pack,Bool.toNat] <;> omega

theorem pack_tail (xs : List Bool) : pack xs / 2 = pack xs.tail := by
  cases xs with
  | nil => rfl
  | cons b bs => cases b <;> simp [pack,Bool.toNat] <;> omega

theorem pack_head_eq (xs : List Bool) : (pack xs % 2 == 1) = xs.headD false := by
  rw [pack_head]
  cases xs.headD false <;> rfl

theorem pack_zero (xs : List Bool) (h : pack xs = 0) : xs.all (!·) = true := by
  induction xs with
  | nil => rfl
  | cons b bs ih =>
    cases b with
    | false =>
      have hb : pack bs = 0 := by simp [pack,Bool.toNat] at h; omega
      simpa only [List.all_cons,Bool.not_false,Bool.true_and] using ih hb
    | true => simp [pack,Bool.toNat] at h

theorem pack_eq_padEq (xs ys : List Bool) (h : pack xs = pack ys) : padEq xs ys = true := by
  induction xs generalizing ys with
  | nil => exact pack_zero ys h.symm
  | cons b bs ih =>
    cases ys with
    | nil =>
      have hh : b.toNat + 2*pack bs = 0 := h
      cases b <;> simp [padEq,Bool.toNat] at hh ⊢
      · exact ih [] (by simp [pack]; omega)
    | cons c cs =>
      have hb : b = c := by
        have hh := congrArg (fun a => a % 2 == 1) h
        rw [pack_head_eq,pack_head_eq] at hh
        exact hh
      subst c
      have ht : pack bs = pack cs := by
        have hh := congrArg (fun a => a / 2) h
        rwa [pack_tail,pack_tail] at hh
      simp [padEq,ih cs ht]

def takePacked : Nat → Nat → Nat
  | 0,_ => 0
  | n+1,x => x % 2 + 2 * takePacked n (x / 2)

theorem pack_take (n : Nat) (xs : List Bool) : pack (xs.take n) = takePacked n (pack xs) := by
  induction n generalizing xs with
  | zero => rfl
  | succ n ih =>
    cases xs with
    | nil =>
      have h := ih []
      simp [pack,takePacked] at h ⊢
      omega
    | cons b bs =>
      rw [takePacked,pack_head,pack_tail]
      simp only [List.take_succ_cons,pack,List.headD_cons,List.tail_cons]
      rw [ih]

structure PZ where
  q : Fin 6
  h : Int
  l : Nat
  r : Nat
  deriving DecidableEq, Repr

def enc (z : Z) : PZ := ⟨z.q,z.h,pack z.l,pack z.r⟩
def pstart : PZ := ⟨0,0,0,0⟩
def pmove (mv : Move) (z : PZ) : PZ :=
  if mv.right then ⟨mv.next,z.h+1,z.r % 2 + 2*(mv.write.toNat+2*(z.l/2)),z.r/2⟩
  else ⟨mv.next,z.h-1,z.l/2,mv.write.toNat+2*z.r⟩

def pstep (p : PartialMachine) (z : PZ) : Option PZ :=
  ((p (z.q,z.l % 2 == 1)).bind id).map (fun mv => pmove mv z)

theorem enc_move (mv : Move) (z : Z) : enc (move mv z) = pmove mv (enc z) := by
  cases h : mv.right <;> simp [enc,move,pmove,h,pack,pack_head,pack_tail]

theorem enc_step (p : PartialMachine) (z : Z) : (step p z).map enc = pstep p (enc z) := by
  unfold step pstep
  change (Option.map (fun mv => move mv z) ((p (z.q,z.l.headD false)).bind id)).map enc =
    (((p (z.q,pack z.l % 2 == 1)).bind id)).map (fun mv => pmove mv (enc z))
  rw [pack_head_eq]
  cases h : p (z.q,z.l.headD false) with
  | none => rfl
  | some op => cases op with
    | none => rfl
    | some mv => simp [enc_move]

def prun (p : PartialMachine) : Nat → PZ → Option PZ
  | 0,z => some z
  | n+1,z => (pstep p z).bind (prun p n)

theorem prun_add (p : PartialMachine) (n k : Nat) (z : PZ) :
    prun p (n+k) z = (prun p n z).bind (prun p k) := by
  induction n generalizing z with
  | zero => simp [prun]
  | succ n ih =>
    rw [show n+1+k=n+k+1 by omega,prun,prun]
    cases h : pstep p z <;> simp [h,ih]

theorem pjoin {p : PartialMachine} {n k : Nat} {a b c : PZ}
    (h : prun p n a = some b) (g : prun p k b = some c) : prun p (n+k) a = some c := by
  rw [prun_add,h]; exact g

theorem enc_run (p : PartialMachine) (n : Nat) (z : Z) :
    (zrun p n z).map enc = prun p n (enc z) := by
  induction n generalizing z with
  | zero => rfl
  | succ n ih =>
    rw [zrun,prun,← enc_step]
    cases h : step p z <;> simp [h,ih]

theorem packed_read {p : PartialMachine} {n : Nat} {z : PZ}
    (h : prun p n pstart = some z) :
    (knownRun p n).map readSlot = some (z.q,z.l % 2 == 1) := by
  have H := (enc_run p n start).trans h
  rw [← zipRead_eq]
  unfold zipRead
  cases hs : zrun p n start with
  | none => simp [hs] at H
  | some t =>
    have hz : enc t = z := Option.some.inj (by simpa [hs] using H)
    subst z
    simp [enc,pack_head_eq]

def pwindow (p : PartialMachine) (right : Bool) (boundary : Int) : Nat → PZ → Option PZ
  | 0,z => some z
  | n+1,z => if side right boundary z.h then (pstep p z).bind (pwindow p right boundary n) else none

theorem enc_window (p : PartialMachine) (right : Bool) (boundary : Int) (n : Nat) (z : Z) :
    (zipWindow p right boundary n z).map enc = pwindow p right boundary n (enc z) := by
  induction n generalizing z with
  | zero => rfl
  | succ n ih =>
    rw [zipWindow,pwindow]
    change (if side right boundary z.h then (step p z).bind (zipWindow p right boundary n) else none).map enc =
      if side right boundary z.h then (pstep p (enc z)).bind (pwindow p right boundary n) else none
    by_cases h : side right boundary z.h
    · rw [if_pos h,if_pos h,← enc_step]
      cases hs : step p z <;> simp [hs,ih]
    · simp [h]

def ptailEq (right : Bool) (boundary : Int) (c d : PZ) : Bool :=
  decide (c.q = d.q) && decide (side right 0 (d.h-c.h)) &&
  if right then
    decide (takePacked ((c.h-boundary).toNat+1) c.l = takePacked ((c.h-boundary).toNat+1) d.l) && decide (c.r = d.r)
  else decide (c.l = d.l) && decide (takePacked (boundary-c.h).toNat c.r = takePacked (boundary-c.h).toNat d.r)

theorem ptailEq_sound (right : Bool) (boundary : Int) (c d : Z)
    (h : ptailEq right boundary (enc c) (enc d) = true) : zipTailEq right boundary c d = true := by
  cases right <;> simp only [ptailEq,zipTailEq,enc,Bool.false_eq_true,ite_false,ite_true,Bool.and_eq_true,decide_eq_true_eq] at h ⊢
  · exact ⟨⟨of_decide_eq_true h.1.1,of_decide_eq_true h.1.2⟩,pack_eq_padEq _ _ (of_decide_eq_true h.2.1),pack_eq_padEq _ _ (by simpa only [pack_take] using of_decide_eq_true h.2.2)⟩
  · exact ⟨⟨of_decide_eq_true h.1.1,of_decide_eq_true h.1.2⟩,pack_eq_padEq _ _ (by simpa only [pack_take] using of_decide_eq_true h.2.1),pack_eq_padEq _ _ (of_decide_eq_true h.2.2)⟩

def pcycle (p : PartialMachine) (entry period : Nat) (right : Bool) (boundary : Int) : Bool :=
  match prun p entry pstart with
  | none => false
  | some c => match pwindow p right boundary period c with
    | none => false
    | some d => ptailEq right boundary c d

theorem pcycle_sound (p : PartialMachine) (entry period : Nat) (right : Bool) (boundary : Int)
    (h : pcycle p entry period right boundary = true) : zipCycle p entry period right boundary = true := by
  rw [pcycle,← show enc start = pstart from rfl,← enc_run] at h
  cases hc : zrun p entry start with
  | none => simp [hc] at h
  | some c =>
    simp only [hc,Option.map_some] at h
    rw [← enc_window] at h
    cases hd : zipWindow p right boundary period c with
    | none => simp [hd] at h
    | some d =>
      have ht : ptailEq right boundary (enc c) (enc d) = true := by simpa [hd] using h
      simp [zipCycle,hc,hd,ptailEq_sound _ _ _ _ ht]

def pqueryOK (B : Nat) (p : PartialMachine) (n : Nat) (s : Slot) : Bool :=
  (match prun p n pstart with | none => false | some z => decide ((z.q,z.l % 2 == 1) = s)) &&
    (decide (p s = none) && weightOK p s n B)

theorem pquery_sound {B p n s} (h : pqueryOK B p n s = true) : queryOK B p n s = true := by
  simp only [pqueryOK,Bool.and_eq_true] at h
  cases hr : prun p n pstart with
  | none => simp [hr] at h
  | some z =>
    have hs : (z.q,z.l % 2 == 1) = s := by simpa [hr] using h.1
    simp only [queryOK,Bool.and_eq_true]
    exact ⟨by rw [packed_read hr,hs]; simp,h.2⟩

/-- A checked local weighted proof can serve as a terminal, but only at an exact
    twelve-slot match. This enables small compositional kernel checks. -/
inductive PAudit (B : Nat) where
  | last (n : Nat) (s : Slot)
  | cycle (entry period : Nat) (right : Bool) (boundary : Int)
  | far (rev : Bool) (d : Nat) (C : FAR.Data d)
  | proven (p : PartialMachine) (safe : ∀ m, compatible p m → NeverHalts m)
  | bound (p : PartialMachine) (safe : ∀ m, compatible p m → WeightedBound B m)
  | split (n : Nat) (s : Slot) (kids : Move → PAudit B)

def pcheck (B : Nat) (p : PartialMachine) : PAudit B → Bool
  | .last n s => pqueryOK B p n s && restOK p s
  | .cycle e k r b => decide (0 < k) && pcycle p e k r b
  | .far rev _ C => C.fastValid (if rev then FAR.reflectPartial p else p)
  | .proven q _ => tableOK p q
  | .bound q _ => tableOK p q
  | .split n s kids => pqueryOK B p n s &&
      allMoves (fun mv => pcheck B (refine p s (some mv)) (kids mv))
termination_by structural t => t

def pbyMove {B : Nat} (xs : List (PAudit B)) (mv : Move) : PAudit B :=
  xs[12*mv.write.toNat+6*mv.right.toNat+mv.next.val]?.getD (.last 0 (0,false))

theorem haltCoverOfRead (B : Nat) (p : PartialMachine) (n : Nat) (s : Slot)
    (hroot : p initialSlot = some (some ⟨true,true,1⟩))
    (hr : (knownRun p n).map readSlot = some s) (hu : p s = none)
    (hb : weightOK p s n B = true) :
    Cover (WeightedBound B) (refine p s none) := by
  cases he : knownRun p n with
  | none => simp [he] at hr
  | some c =>
    have hs : readSlot c = s := by simpa [he] using hr
    have hh : p (readSlot c) = none := by rw [hs]; exact hu
    have hw : ∀ d ∈ possibleDelays (refine p (readSlot c) none) 0, d+n+1 ≤ B := by
      rw [hs]; exact weightOK_sound p s n B hb
    exact .leaf _ (by simpa only [hs] using first_hole_weighted_halt B p n c hroot he hh hw)

theorem lastCoverOfRead (B : Nat) (p : PartialMachine) (n : Nat) (s : Slot)
    (hroot : p initialSlot = some (some ⟨true,true,1⟩))
    (hr : (knownRun p n).map readSlot = some s) (hu : p s = none)
    (hb : weightOK p s n B = true) (hrest : restOK p s = true) :
    Cover (WeightedBound B) p := by
  cases he : knownRun p n with
  | none => simp [he] at hr
  | some c =>
    have hs : readSlot c = s := by simpa [he] using hr
    apply Cover.leaf
    exact last_hole_sound B p n c hroot he (by simpa only [hs] using hu)
      (by simpa only [hs] using restOK_sound p s hrest)
      (by simpa only [hs] using weightOK_sound p s n B hb)

theorem pcheck_sound (B : Nat) (p : PartialMachine) (t : PAudit B)
    (hroot : p initialSlot = some (some ⟨true,true,1⟩))
    (h : pcheck B p t = true) : Cover (WeightedBound B) p := by
  induction t generalizing p with
  | last n s =>
    simp only [pcheck,Bool.and_eq_true] at h
    obtain ⟨hr,hu,hb⟩ := queryOK_sound (pquery_sound h.1)
    exact lastCoverOfRead B p n s hroot hr hu hb h.2
  | cycle e k r b =>
    simp only [pcheck,Bool.and_eq_true] at h
    exact .leaf _ (fun m hm => weighted_never B m (zipCycle_sound p e k r b (of_decide_eq_true h.1) (pcycle_sound _ _ _ _ _ h.2) m hm))
  | far rev d C =>
    exact .leaf _ (fun m hm => weighted_never B m (farSound p rev C (by simpa only [pcheck] using h) m hm))
  | proven q safe =>
    have he : p = q := tableOK_sound p q (by simpa only [pcheck] using h)
    subst q
    exact .leaf _ (fun m hm => weighted_never B m (safe m hm))
  | bound q safe =>
    have he : p = q := tableOK_sound p q (by simpa only [pcheck] using h)
    subst q
    exact .leaf _ safe
  | split n s kids ih =>
    simp only [pcheck,Bool.and_eq_true] at h
    obtain ⟨hr,hu,hb⟩ := queryOK_sound (pquery_sound h.1)
    apply Cover.branch p s hu
    intro t _
    cases t with
    | none => exact haltCoverOfRead B p n s hroot hr hu hb
    | some mv =>
      exact ih mv (refine p s (some mv)) (refine_preserves_firstOne p s (some mv) hu hroot) (allMoves_sound _ h.2 mv)

#print axioms packed_read
#print axioms pcycle_sound
#print axioms pcheck_sound
end BB6.Agent3PackedAudit
