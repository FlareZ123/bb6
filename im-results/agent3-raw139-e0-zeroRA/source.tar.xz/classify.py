import sys,json
from pathlib import Path
from pathlib import Path
root=Path(__file__).resolve().parent.parent
sys.path[:0]=[str(root/'agent48-raw139-f1-oneLA'),str(root/'agent48-raw139-f1-oneRA'),str(root/'agent3-raw139-c1-zeroLA')]
from scan import scan,find_far
from blockcert import generate
from itertools import product
from multiprocessing import Pool
from collections import Counter
params=[(2,1,2,1,False),(2,1,2,2,False),(2,2,4,2,False),(2,1,2,3,True),(3,1,2,1,False),(3,1,2,2,False),(3,2,4,2,False),(2,1,4,4,True),(2,2,2,3,False),(3,1,2,3,True)]
def task(p):
 a=scan(p,600)
 if a[0]=='cycle' or a[0]=='hole':return p,a
 f=find_far(p,3)
 if f:return p,('far',f[0],f[2])
 for w,c,m,r,ph in params:
  a=generate(p,w,c,m,r,False,40000,ph)
  if a:return p,('block',w,c,m,r,ph,a['left_states'],a['right_nodes'])
 a=scan(p,2000)
 return p,a
if __name__=='__main__':
 paths=sorted(Path('.').glob('e0_1_*.txt'),key=lambda p:int(p.stem.split('_')[-1]))
 jobs=[list(map(int,l.split(','))) for f in paths for l in f.read_text().splitlines()];print(len(jobs),flush=True)
 c=Counter()
 with Pool(4) as pool,open('recipes.jsonl','w') as f:
  for i,(p,a) in enumerate(pool.imap_unordered(task,jobs,chunksize=1)):
   c[a[0]]+=1;f.write(json.dumps([p,a])+'\n');f.flush()
   if i%100==0 or a[0]=='open':print(i+1,c,p if a[0]=='open' else '',flush=True)
 print(c,flush=True)
