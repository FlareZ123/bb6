import json,sys,pathlib
from collections import Counter
from pathlib import Path
root=Path(__file__).resolve().parent.parent
sys.path[:0]=[str(root/'agent48-raw139-f1-oneLA'),str(root/'agent48-raw139-f1-oneRA'),str(root/'agent3-raw139-c1-zeroLA')]
from scan import tree,far,ORDER
from blockcert import generate
from emit import block_source,bl,slot
BASE='A3E0RA'; NS='BB6.Agent3E0RA'; OPT='set_option maxRecDepth 1000000\nset_option maxHeartbeats 0\n'; OPEN='open BB6Coverage BB6Coverage.FAR BB6.Agent13BlankDelay BB6.Agent31ThreeHole BB6.Agent3PackedAudit\n'; import os
out=pathlib.Path(os.environ.get('A3_BUILD','generated'));out.mkdir(parents=True,exist_ok=True)
B=321796
records={tuple(p):a for p,a in map(json.loads,open('recipes.jsonl'))};records.update({tuple(p):a for p,a in map(json.loads,open('hard.jsonl'))});records[(7,2,11,19,14,20,13,16,1,11,24,10)]=['hole',321790,10]
late={tuple(p):a for p,a in json.load(open('latechildren.json'))};late.update({tuple(p):a for p,a in map(json.loads,open('latehard.jsonl'))});records.update(late)

def emit(b,limit=400):
 prefix=BASE+f'B{b:02}';ns=NS+f'.B{b:02}';p0=[7,24,11,b,14,24,24,16,1,11,24,24]
 if pathlib.Path(f'partition{b}.json').exists():j=json.load(open(f'partition{b}.json'));tr=j['tree'];opens=j['open'];counts=j['counts']
 else:
  counts=Counter();opens=[];tr=tree(p0,counts,opens,250,2);json.dump(dict(parent=p0,counts=counts,tree=tr,open=opens),open(f'partition{b}.json','w'))
 assert all(tuple(p) in records for p in opens),[p for p in opens if tuple(p) not in records]
 # Expand the single multi-hole late query in the witness tree.
 def resolve(t):
  if t[0]=='split':return (*t[:3],[resolve(c) for c in t[3]])
  if t[0]!='open':return t
  p=t[1];a=records[tuple(p)]
  if a[0]=='hole' and p.count(24)>1:
   n,s=a[1:];return ('split',n,s,[resolve(('open',p[:s]+[v]+p[s+1:])) for v in ORDER])
  return t
 tr=resolve(tr)
 def collect(t):
  if t[0]=='split':
   for c in t[3]:yield from collect(c)
  if t[0]=='open':yield t[1]
 opens=list(collect(tr));ids={tuple(p):i for i,p in enumerate(opens)}
 blocks=[p for p in opens if records[tuple(p)][0]=='block']; bmods={}; modules=[]
 for a in range(0,len(blocks),8):
  name=prefix+f'Block{a//8:03}';modules.append((name,[]));source='import BlockFAR2\nimport BlockFARBridge\nimport FastThreeHoleAudit\n'+OPT
  for p in blocks[a:a+8]:
   i=ids[tuple(p)];r=records[tuple(p)];_,w,c,m,runs,phase,d,n,*ext=r;flip,ev=ext if ext else (False,40000)
   cert=generate(p,w,c,m,runs,flip,ev,phase);assert cert and (cert['left_states'],cert['right_nodes'])==(d,n)
   tgt=[x^1 if x<24 else x for x in p] if flip else p
   old='BB6.Agent3Raw139C1ZeroLABlocks';new=ns+'Blocks';source+=block_source(i,tgt,cert).replace(old,new)
   if flip:
    nsp=f'{new}.H{i}';source+=f'''namespace {nsp}
def orig : BB6Coverage.PartialMachine := BB6Coverage.FAR.fromCodes {p}
theorem reftab : BB6Coverage.FAR.reflectPartial orig = ctr := BB6.Agent31ThreeHole.tableOK_sound _ _ (by decide)
theorem origNever (m : BB6Coverage.Machine) (hm : BB6Coverage.compatible orig m) : BB6Coverage.NeverHalts m := by
  apply BB6Coverage.FAR.reflectNever m
  apply never
  rw [← reftab]
  exact BB6Coverage.FAR.reflectCompatible orig m hm
#print axioms origNever
end {nsp}
'''
   bmods[i]=(name,flip)
  (out/(name+'.lean')).write_text(source)
 def size(t):return 1+sum(map(size,t[3])) if t[0]=='split' else 1
 def render(t,p,deps):
  k,*a=t
  if k=='cycle':e,s,r,x=a;return f'.cycle {e} {s} {bl(r)} ({x})'
  if k=='last':return f'.last {a[0]} {slot(a[1])}'
  if k=='far':rev,d,dfa,t0,t1,z=a;return f'.far {bl(rev)} {d} ⟨0,{dfa},{t0},{t1},{z}⟩'
  if k=='bound':name,nsp=a;deps.add(name);return f'.bound {nsp}.parent {nsp}.cover.sound'
  if k=='split':n,s,kids=a;return f'.split {n} {slot(s)} (pbyMove [\n'+',\n'.join(render(t,p[:s]+[v]+p[s+1:],deps) for t,v in zip(kids,ORDER))+'])'
  if k=='open':
   i=ids[tuple(a[0])];r=records[tuple(a[0])]
   if r[0]=='block':name,flip=bmods[i];deps.add(name);nsp=f'{ns}Blocks.H{i}';return f'.proven {nsp}.orig {nsp}.origNever' if flip else f'.proven {nsp}.ctr {nsp}.never'
   if r[0]=='far':v=far(a[0],*r[1:]);assert v;return render(('far',*v),p,deps)
   if r[0]=='cycle':return render(r,p,deps)
   if r[0]=='hole':
    n,s=r[1:]
    if n==321790:deps.add('A3E0RALongCover');return '.bound BB6.Agent3E0RALong.parent BB6.Agent3E0RALong.cover.sound'
    assert p.count(24)==1;return render(('last',n,s),p,deps)
  raise ValueError(t)
 seq=0;stats=[]
 def make(t,p):
  nonlocal seq
  if t[0]=='split' and size(t)>limit:
   _,n,s,children=t;children=list(children);sizes=list(map(size,children));total=1+sum(sizes)
   for i in sorted(range(24),key=lambda i:-sizes[i]):
    if total<=limit:break
    if sizes[i]<=1:break
    q=p.copy();q[s]=ORDER[i];name,nsp=make(children[i],q);children[i]=('bound',name,nsp);total-=sizes[i]-1
   assert total<=limit,(total,limit)
   t=('split',n,s,children)
  deps=set();st=render(t,p,deps);name=prefix+f'Part{seq:04}';nsp=ns+f'.Part{seq:04}';seq+=1
  source='import Agent3PackedAudit\n'+''.join(f'import {m}\n' for m in sorted(deps))+OPT+OPEN+f'''namespace {nsp}
def parent : PartialMachine := fromCodes {p}
def tree : PAudit {B} := {st}
theorem checked : pcheck {B} parent tree = true := by decide +kernel
theorem cover : Cover (WeightedBound {B}) parent := pcheck_sound {B} parent tree (by decide) checked
#print axioms cover
end {nsp}
'''
  (out/(name+'.lean')).write_text(source);modules.append((name,sorted(deps)));stats.append(size(t));return name,nsp
 name,nsp=make(tr,p0)
 root=prefix+'Cover';(out/(root+'.lean')).write_text(f'import {name}\n'+OPEN+f'''namespace {ns}
def parent : PartialMachine := {nsp}.parent
theorem cover : Cover (WeightedBound {B}) parent := {nsp}.cover
#print axioms cover
end {ns}
''');modules.append((root,[name]))
 print(b,counts,'chunks',len(stats),'max',max(stats),'block shards',len(set(n for n,f in bmods.values())),flush=True)
 json.dump(modules,open(f'modules{b}.json','w'))
if __name__=='__main__':
 for b in map(int,sys.argv[1:]):emit(b)
