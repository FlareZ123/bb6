import sys,json
from pathlib import Path
root=Path(__file__).resolve().parent.parent
sys.path[:0]=[str(root/'agent48-raw139-f1-oneLA'),str(root/'agent48-raw139-f1-oneRA'),str(root/'agent3-raw139-c1-zeroLA')]
from blockcert import generate
from scan import scan
from itertools import product
from multiprocessing import Pool
# Broader invariant vocabulary after ordinary FAR and cheap block pass.
params=[(w,c,m,r,flip,ph) for w in (2,3) for flip in (True,False) for ph in (False,True) for r,m,c in product(range(1,5),range(2,8),range(1,3)) if not ph or c==1]
def task(p):
 for w,c,m,r,flip,ph in params:
  a=generate(p,w,c,m,r,flip,60000,ph)
  if a:return p,['block',w,c,m,r,ph,a['left_states'],a['right_nodes'],flip,60000]
 a=scan(p,6000)
 return p,a
if __name__=='__main__':
 jobs=[p for p,a in map(json.loads,open('recipes.jsonl')) if a[0]=='open']
 with Pool(4) as pool,open('hard.jsonl','w') as f:
  for i,(p,a) in enumerate(pool.imap_unordered(task,jobs,chunksize=1)):
   print(i+1,p,a,flush=True);f.write(json.dumps([p,a])+'\n');f.flush()
