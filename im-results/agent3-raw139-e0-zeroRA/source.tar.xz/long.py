from pathlib import Path
p=[7,2,11,19,14,20,13,16,1,11,24,10]
N=321790; B=N+6
import os
out=Path(os.environ.get('A3_BUILD','generated'));out.mkdir(parents=True,exist_ok=True)
base='A3E0RALong'; ns='BB6.Agent3E0RALong'
header='set_option maxRecDepth 1000000\nset_option maxHeartbeats 0\nopen BB6Coverage BB6Coverage.FAR BB6.Agent13BlankDelay BB6.Agent3PackedAudit\n'
(out/(base+'Base.lean')).write_text('import Agent3PackedAudit\n'+header+f'namespace {ns}\ndef parent : PartialMachine := fromCodes {p}\nend {ns}\n')
q=h=l=r=0; states=[(q,h,l,r)]; lengths=[]; chunk=1024
for n in range(N):
 v=p[2*q+(l&1)]; assert v!=24
 if v&1:l,r=(r&1)+2*((v>>1&1)+2*(l>>1)),r>>1;h+=1
 else:l,r=l>>1,(v>>1&1)+2*r;h-=1
 q=v>>2
 if (n+1)%chunk==0 or n+1==N:states.append((q,h,l,r));lengths.append(min(chunk,n+1-(len(states)-2)*chunk))
assert p[2*q+(l&1)]==24 and q==5 and not l&1
assert sum(lengths)==N
fmt=lambda z:f'⟨{z[0]},({z[1]}),{hex(z[2])},{hex(z[3])}⟩'
mods=[]
for a in range(0,len(lengths),16):
 name=base+f'Part{a//16:03}';mods.append(name);text=f'import {base}Base\n'+header+f'namespace {ns}\n'
 for i in range(a,min(a+16,len(lengths))):
  text+=f'theorem seg{i} : prun parent {lengths[i]} {fmt(states[i])} = some {fmt(states[i+1])} := by decide +kernel\n'
 (out/(name+'.lean')).write_text(text+f'end {ns}\n')
# Explicit indices prevent elaboration from reducing a large prun while unifying.
def joined(a,b,m,ha,hb):
 return f"@pjoin parent {sum(lengths[a:m])} {sum(lengths[m:b])} {fmt(states[a])} {fmt(states[m])} {fmt(states[b])} {ha} {hb}"
joins=[]
for a in range(0,len(lengths),16):
 b=min(a+16,len(lengths));name=base+f'Join{a//16:03}';joins.append(name)
 text=f'import {mods[a//16]}\n'+header+f'namespace {ns}\n'
 def subtree(a,b):
  if b-a==1:return f'seg{a}', ''
  m=(a+b)//2;ha,sa=subtree(a,m);hb,sb=subtree(m,b);h=f'join{a}_{b}'
  return h,sa+sb+f'theorem {h} : prun parent {sum(lengths[a:b])} {fmt(states[a])} = some {fmt(states[b])} := {joined(a,b,m,ha,hb)}\n'
 h,src=subtree(a,b);text+=src
 (out/(name+'.lean')).write_text(text+f'end {ns}\n')
text=''.join(f'import {m}\n' for m in joins)+header+f'namespace {ns}\n'
# Join the twenty prechecked group theorems using explicit indices.
starts=list(range(0,len(lengths),16))+[len(lengths)]
def finalsub(i,j):
 if j-i==1:return f'join{starts[i]}_{starts[j]}',''
 m=(i+j)//2;ha,sa=finalsub(i,m);hb,sb=finalsub(m,j);a,b,c=starts[i],starts[m],starts[j];h=f'group{i}_{j}'
 return h,sa+sb+f'theorem {h} : prun parent {sum(lengths[a:c])} {fmt(states[a])} = some {fmt(states[c])} := {joined(a,c,b,ha,hb)}\n'
h,src=finalsub(0,len(joins));text+=src
text+=f'''theorem trace : prun parent {N} pstart = some {fmt(states[-1])} := {h}
theorem cover : Cover (WeightedBound {B}) parent :=
  lastCoverOfRead {B} parent {N} (5,false) (by decide) (by simpa using packed_read trace) (by decide) (by decide) (by decide)
#print axioms trace
#print axioms cover
end {ns}
'''
(out/(base+'Cover.lean')).write_text(text)
print('segments',len(lengths),'modules',len(mods),'end',states[-1])
