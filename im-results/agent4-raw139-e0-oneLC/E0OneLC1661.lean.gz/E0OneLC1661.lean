import SweepPumping

import Hybrid

open BB6Coverage BB6Coverage.FAR BB6Coverage.Agent31Pump BB6.Agent13BlankDelay

set_option maxRecDepth 1000000

set_option maxHeartbeats 0

namespace BB6.Agent4E0OneLC1661

def p : PartialMachine := fromCodes [7, 5, 11, 19, 14, 1, 20, 16, 10, 11, 6, 24]

def s0 (n : Nat) : Z0 := ⟨0, [false, false, true], [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, true, true, false, true, true, false, true, true, false, true, true, false] ++ rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, true, false, true]⟩

def s1 (n : Nat) : Z0 := ⟨0, [false, false, true] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, true, true, false, true, true, false, true, true, false, true, true, false] ++ rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, true, false, true]⟩

def s2 (n : Nat) : Z0 := ⟨2, [true, true, true, false, false, false, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, [true, false, true, true, false, true, true, false, true, true, false] ++ rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, true, false, true]⟩

def s3 (n : Nat) : Z0 := ⟨2, [true] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n ++ [true, true, false, false, false, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, [true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, true, false, true]⟩

def s4 (n : Nat) : Z0 := ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n ++ [true, true, false, false, false, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, [true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true]⟩

def s5 (n : Nat) : Z0 := ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, true, false, false, false, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true]⟩

def s6 (n : Nat) : Z0 := ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true]⟩

def s7 (n : Nat) : Z0 := ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true]⟩

def s8 (n : Nat) : Z0 := ⟨0, [false, false, true], [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true]⟩

def s9 (n : Nat) : Z0 := ⟨0, [false, false, true] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true]⟩

def s10 (n : Nat) : Z0 := ⟨1, [true, false, false, false, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true]⟩

def s11 (n : Nat) : Z0 := ⟨1, [true] ++ rep [false, false, true, false, false, true, false, false, true, false, false, true] n ++ [false, false, false, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true]⟩

def s12 (n : Nat) : Z0 := ⟨4, [false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true] ++ rep [false, false, true, false, false, true, false, false, true, false, false, true] n ++ [false, false, false, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, [false, true, true, false, true, true, true, true, false, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩

def s13 (n : Nat) : Z0 := ⟨4, [false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, false, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, rep [false, true, true, false, true, true, false, true, true, false, true, true] n ++ [false, true, true, false, true, true, true, true, false, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩

def s14 (n : Nat) : Z0 := ⟨0, [true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, [false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true] ++ rep [false, true, true, false, true, true, false, true, true, false, true, true] n ++ [false, true, true, false, true, true, true, true, false, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩

def s15 (n : Nat) : Z0 := ⟨0, [true] ++ rep [false, true, false, false, true, false, false, true, false, false, true, false] n ++ [false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, [false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩

def s16 (n : Nat) : Z0 := ⟨2, [false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false] ++ rep [false, true, false, false, true, false, false, true, false, false, true, false] n ++ [false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, [true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩

def s17 (n : Nat) : Z0 := ⟨2, [false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, rep [true, false, true, true, false, true, true, false, true, true, false, true] n ++ [true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩

def s18 (n : Nat) : Z0 := ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true] ++ rep [true, false, true, true, false, true, true, false, true, true, false, true] n ++ [true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩

def s19 (n : Nat) : Z0 := ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true] ++ rep [true, false, true, true, false, true, true, false, true, true, false, true] n ++ [true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩

def s20 (n : Nat) : Z0 := ⟨0, [false, false, true], [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true] ++ rep [true, false, true, true, false, true, true, false, true, true, false, true] n ++ [true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩

def s21 (n : Nat) : Z0 := ⟨0, [false, false, true] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true] ++ rep [true, false, true, true, false, true, true, false, true, true, false, true] n ++ [true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩

def s22 (n : Nat) : Z0 := ⟨4, [true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, [true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true] ++ rep [true, false, true, true, false, true, true, false, true, true, false, true] n ++ [true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩

def s23 (n : Nat) : Z0 := ⟨4, [true] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n ++ [true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, [true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩

def s24 (n : Nat) : Z0 := ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n ++ [true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, [true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, true, false, true]⟩

def s25 (n : Nat) : Z0 := ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, true, false, true]⟩

def s26 (n : Nat) : Z0 := ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n, [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, true, false, true]⟩

def s27 (n : Nat) : Z0 := ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, true, false, true]⟩

def s28 (n : Nat) : Z0 := ⟨0, [false, false, true], [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, true, false, true]⟩

theorem one0 (L R : List Bool) : run0 p 40 ⟨0, [false, false, true] ++ L, [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ [true, true, false, true, true, false, true, true, false, true, true, false] ++ R⟩ = some ⟨0, [false, false, true] ++ [true, false, false, true, false, false, true, false, false, true, false, false] ++ L, [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ R⟩ := by
  rfl

theorem t0 (n : Nat) : run0 p (40 * n) (s0 n) = some (s1 n) := by
  simpa only [s0, s1, List.append_assoc, List.append_nil, List.nil_append, List.cons_append] using sweepR p 0 [false, false, true] [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] [true, true, false, true, true, false, true, true, false, true, true, false] [true, false, false, true, false, false, true, false, false, true, false, false] 40 one0 n ([]) ([true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, true, true, false, true, true, false, true, true, false, true, true, false] ++ rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, true, false, true])

theorem t1 (n : Nat) : run0 p 187 (s1 n) = some (s2 n) := by
  rfl

theorem one2 (L R : List Bool) : run0 p 12 ⟨2, [true] ++ L, [true, false, true, true, false, true, true, false, true, true, false] ++ [true, true, false, true, true, false, true, true, false, true, true, false] ++ R⟩ = some ⟨2, [true] ++ [true, false, false, true, false, false, true, false, false, true, false, false] ++ L, [true, false, true, true, false, true, true, false, true, true, false] ++ R⟩ := by
  rfl

theorem t2 (n : Nat) : run0 p (12 * n) (s2 n) = some (s3 n) := by
  simpa only [s2, s3, List.append_assoc, List.append_nil, List.nil_append, List.cons_append] using sweepR p 2 [true] [true, false, true, true, false, true, true, false, true, true, false] [true, true, false, true, true, false, true, true, false, true, true, false] [true, false, false, true, false, false, true, false, false, true, false, false] 12 one2 n ([true, true, false, false, false, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n) ([true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, true, false, true])

theorem t3 (n : Nat) : run0 p 125 (s3 n) = some (s4 n) := by
  rfl

theorem one4 (L R : List Bool) : run0 p 12 ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ [true, false, false, true, false, false, true, false, false, true, false, false] ++ L, [] ++ R⟩ = some ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ L, [] ++ [true, true, false, true, true, false, true, true, false, true, true, false] ++ R⟩ := by
  rfl

theorem t4 (n : Nat) : run0 p (12 * n) (s4 n) = some (s5 n) := by
  simpa only [s4, s5, List.append_assoc, List.append_nil, List.nil_append, List.cons_append] using sweepL p 3 [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] [] [true, false, false, true, false, false, true, false, false, true, false, false] [true, true, false, true, true, false, true, true, false, true, true, false] 12 one4 n ([true, true, false, false, false, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n) ([true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true])

theorem t5 (n : Nat) : run0 p 71 (s5 n) = some (s6 n) := by
  rfl

theorem one6 (L R : List Bool) : run0 p 12 ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ [true, false, false, true, false, false, true, false, false, true, false, false] ++ L, [] ++ R⟩ = some ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ L, [] ++ [true, true, false, true, true, false, true, true, false, true, true, false] ++ R⟩ := by
  rfl

theorem t6 (n : Nat) : run0 p (12 * n) (s6 n) = some (s7 n) := by
  simpa only [s6, s7, List.append_assoc, List.append_nil, List.nil_append, List.cons_append] using sweepL p 3 [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] [] [true, false, false, true, false, false, true, false, false, true, false, false] [true, true, false, true, true, false, true, true, false, true, true, false] 12 one6 n ([]) ([true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true])

theorem t7 (n : Nat) : run0 p 34 (s7 n) = some (s8 n) := by
  rfl

theorem one8 (L R : List Bool) : run0 p 40 ⟨0, [false, false, true] ++ L, [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ [true, true, false, true, true, false, true, true, false, true, true, false] ++ R⟩ = some ⟨0, [false, false, true] ++ [true, false, false, true, false, false, true, false, false, true, false, false] ++ L, [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ R⟩ := by
  rfl

theorem t8 (n : Nat) : run0 p (40 * n) (s8 n) = some (s9 n) := by
  simpa only [s8, s9, List.append_assoc, List.append_nil, List.nil_append, List.cons_append] using sweepR p 0 [false, false, true] [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] [true, true, false, true, true, false, true, true, false, true, true, false] [true, false, false, true, false, false, true, false, false, true, false, false] 40 one8 n ([]) ([true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true])

theorem t9 (n : Nat) : run0 p 189 (s9 n) = some (s10 n) := by
  rfl

theorem one10 (L R : List Bool) : run0 p 40 ⟨1, [true] ++ L, [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ [true, true, false, true, true, false, true, true, false, true, true, false] ++ R⟩ = some ⟨1, [true] ++ [false, false, true, false, false, true, false, false, true, false, false, true] ++ L, [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ R⟩ := by
  rfl

theorem t10 (n : Nat) : run0 p (40 * n) (s10 n) = some (s11 n) := by
  simpa only [s10, s11, List.append_assoc, List.append_nil, List.nil_append, List.cons_append] using sweepR p 1 [true] [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] [true, true, false, true, true, false, true, true, false, true, true, false] [false, false, true, false, false, true, false, false, true, false, false, true] 40 one10 n ([false, false, false, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n) ([true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true])

theorem t11 (n : Nat) : run0 p 209 (s11 n) = some (s12 n) := by
  rfl

theorem one12 (L R : List Bool) : run0 p 12 ⟨4, [false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true] ++ [false, false, true, false, false, true, false, false, true, false, false, true] ++ L, [] ++ R⟩ = some ⟨4, [false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true] ++ L, [] ++ [false, true, true, false, true, true, false, true, true, false, true, true] ++ R⟩ := by
  rfl

theorem t12 (n : Nat) : run0 p (12 * n) (s12 n) = some (s13 n) := by
  simpa only [s12, s13, List.append_assoc, List.append_nil, List.nil_append, List.cons_append] using sweepL p 4 [false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true] [] [false, false, true, false, false, true, false, false, true, false, false, true] [false, true, true, false, true, true, false, true, true, false, true, true] 12 one12 n ([false, false, false, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n) ([false, true, true, false, true, true, true, true, false, true, true, true, true, true, true, true, true, false, true, true, false, true])

theorem t13 (n : Nat) : run0 p 56 (s13 n) = some (s14 n) := by
  rfl

theorem one14 (L R : List Bool) : run0 p 12 ⟨0, [true] ++ L, [false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true] ++ [false, true, true, false, true, true, false, true, true, false, true, true] ++ R⟩ = some ⟨0, [true] ++ [false, true, false, false, true, false, false, true, false, false, true, false] ++ L, [false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true] ++ R⟩ := by
  rfl

theorem t14 (n : Nat) : run0 p (12 * n) (s14 n) = some (s15 n) := by
  simpa only [s14, s15, List.append_assoc, List.append_nil, List.nil_append, List.cons_append] using sweepR p 0 [true] [false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true] [false, true, true, false, true, true, false, true, true, false, true, true] [false, true, false, false, true, false, false, true, false, false, true, false] 12 one14 n ([false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n) ([false, true, true, false, true, true, true, true, false, true, true, true, true, true, true, true, true, false, true, true, false, true])

theorem t15 (n : Nat) : run0 p 51 (s15 n) = some (s16 n) := by
  rfl

theorem one16 (L R : List Bool) : run0 p 12 ⟨2, [false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false] ++ [false, true, false, false, true, false, false, true, false, false, true, false] ++ L, [] ++ R⟩ = some ⟨2, [false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false] ++ L, [] ++ [true, false, true, true, false, true, true, false, true, true, false, true] ++ R⟩ := by
  rfl

theorem t16 (n : Nat) : run0 p (12 * n) (s16 n) = some (s17 n) := by
  simpa only [s16, s17, List.append_assoc, List.append_nil, List.nil_append, List.cons_append] using sweepL p 2 [false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false] [] [false, true, false, false, true, false, false, true, false, false, true, false] [true, false, true, true, false, true, true, false, true, true, false, true] 12 one16 n ([false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n) ([true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true])

theorem t17 (n : Nat) : run0 p 64 (s17 n) = some (s18 n) := by
  rfl

theorem one18 (L R : List Bool) : run0 p 12 ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ [true, false, false, true, false, false, true, false, false, true, false, false] ++ L, [] ++ R⟩ = some ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ L, [] ++ [true, true, false, true, true, false, true, true, false, true, true, false] ++ R⟩ := by
  rfl

theorem t18 (n : Nat) : run0 p (12 * n) (s18 n) = some (s19 n) := by
  simpa only [s18, s19, List.append_assoc, List.append_nil, List.nil_append, List.cons_append] using sweepL p 3 [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] [] [true, false, false, true, false, false, true, false, false, true, false, false] [true, true, false, true, true, false, true, true, false, true, true, false] 12 one18 n ([]) ([true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true] ++ rep [true, false, true, true, false, true, true, false, true, true, false, true] n ++ [true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true])

theorem t19 (n : Nat) : run0 p 34 (s19 n) = some (s20 n) := by
  rfl

theorem one20 (L R : List Bool) : run0 p 40 ⟨0, [false, false, true] ++ L, [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ [true, true, false, true, true, false, true, true, false, true, true, false] ++ R⟩ = some ⟨0, [false, false, true] ++ [true, false, false, true, false, false, true, false, false, true, false, false] ++ L, [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ R⟩ := by
  rfl

theorem t20 (n : Nat) : run0 p (40 * n) (s20 n) = some (s21 n) := by
  simpa only [s20, s21, List.append_assoc, List.append_nil, List.nil_append, List.cons_append] using sweepR p 0 [false, false, true] [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] [true, true, false, true, true, false, true, true, false, true, true, false] [true, false, false, true, false, false, true, false, false, true, false, false] 40 one20 n ([]) ([true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true] ++ rep [true, false, true, true, false, true, true, false, true, true, false, true] n ++ [true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true])

theorem t21 (n : Nat) : run0 p 202 (s21 n) = some (s22 n) := by
  rfl

theorem one22 (L R : List Bool) : run0 p 40 ⟨4, [true] ++ L, [true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true] ++ [true, false, true, true, false, true, true, false, true, true, false, true] ++ R⟩ = some ⟨4, [true] ++ [true, false, false, true, false, false, true, false, false, true, false, false] ++ L, [true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true] ++ R⟩ := by
  rfl

theorem t22 (n : Nat) : run0 p (40 * n) (s22 n) = some (s23 n) := by
  simpa only [s22, s23, List.append_assoc, List.append_nil, List.nil_append, List.cons_append] using sweepR p 4 [true] [true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true] [true, false, true, true, false, true, true, false, true, true, false, true] [true, false, false, true, false, false, true, false, false, true, false, false] 40 one22 n ([true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n) ([true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true])

theorem t23 (n : Nat) : run0 p 177 (s23 n) = some (s24 n) := by
  rfl

theorem one24 (L R : List Bool) : run0 p 12 ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ [true, false, false, true, false, false, true, false, false, true, false, false] ++ L, [] ++ R⟩ = some ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ L, [] ++ [true, true, false, true, true, false, true, true, false, true, true, false] ++ R⟩ := by
  rfl

theorem t24 (n : Nat) : run0 p (12 * n) (s24 n) = some (s25 n) := by
  simpa only [s24, s25, List.append_assoc, List.append_nil, List.nil_append, List.cons_append] using sweepL p 3 [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] [] [true, false, false, true, false, false, true, false, false, true, false, false] [true, true, false, true, true, false, true, true, false, true, true, false] 12 one24 n ([true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ rep [true, false, false, true, false, false, true, false, false, true, false, false] n) ([true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, true, false, true])

theorem t25 (n : Nat) : run0 p 94 (s25 n) = some (s26 n) := by
  rfl

theorem one26 (L R : List Bool) : run0 p 12 ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ [true, false, false, true, false, false, true, false, false, true, false, false] ++ L, [] ++ R⟩ = some ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] ++ L, [] ++ [true, true, false, true, true, false, true, true, false, true, true, false] ++ R⟩ := by
  rfl

theorem t26 (n : Nat) : run0 p (12 * n) (s26 n) = some (s27 n) := by
  simpa only [s26, s27, List.append_assoc, List.append_nil, List.nil_append, List.cons_append] using sweepL p 3 [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false] [] [true, false, false, true, false, false, true, false, false, true, false, false] [true, true, false, true, true, false, true, true, false, true, true, false] 12 one26 n ([]) ([true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false] ++ rep [true, true, false, true, true, false, true, true, false, true, true, false] n ++ [true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, true, false, true])

theorem t27 (n : Nat) : run0 p 34 (s27 n) = some (s28 n) := by
  rfl

theorem rep_add_local (w : List Bool) (a b : Nat) : rep w (a+b) = rep w a ++ rep w b := by

  induction a with

  | zero => simp [rep]

  | succ a ih => rw [Nat.succ_add, rep, rep, ih]; simp only [List.append_assoc]

theorem rep_four (w : List Bool) (n : Nat) : rep (rep w 4) n = rep w (4*n) := by

  induction n with

  | zero => rfl

  | succ n ih => rw [rep, ih, ← rep_add_local, Nat.mul_succ, Nat.add_comm]

def w : List Bool := [true, true, false]

def family (n : Nat) : Z0 := ⟨0, [false, false, true], rep w (4*n+17) ++ [true,true,true,true,false,true,true] ++ rep w (4*n+8) ++ [true,true,true,true,true,false,true,true,true,true,false,true]⟩

theorem splice (w : List Bool) (n a b : Nat) :
  (rep w a ++ rep (rep w 4) n) ++ rep w b = rep w (4*n+a+b) := by
  rw [rep_four, ← rep_add_local, ← rep_add_local]
  congr 1
  omega

theorem start_eq (n : Nat) : s0 n = family (n) := by
  have hs : s0 n = (⟨0, [false,false,true], ((rep w 8 ++ rep (rep w 4) n) ++ rep w 9) ++ ([true,true,true,true,false,true,true] ++ (((rep w 4 ++ rep (rep w 4) n) ++ rep w 4) ++ [true,true,true,true,true,false,true,true,true,true,false,true]))⟩ : Z0) := by
    simp only [s0, w, rep, List.append_assoc, List.cons_append, List.nil_append]
  rw [hs, splice, splice]
  unfold family
  have h1 : 4*n+8+9 = 4*(n)+17 := by omega
  have h2 : 4*n+4+4 = 4*(n)+8 := by omega
  rw [h1,h2]
  simp only [List.append_assoc]

theorem end_eq (n : Nat) : s28 n = family (n+1) := by
  have hs : s28 n = (⟨0, [false,false,true], ((rep w 10 ++ rep (rep w 4) n) ++ rep w 11) ++ ([true,true,true,true,false,true,true] ++ (((rep w 8 ++ rep (rep w 4) n) ++ rep w 4) ++ [true,true,true,true,true,false,true,true,true,true,false,true]))⟩ : Z0) := by
    simp only [s28, w, rep, List.append_assoc, List.cons_append, List.nil_append]
  rw [hs, splice, splice]
  unfold family
  have h1 : 4*n+10+11 = 4*(n+1)+17 := by omega
  have h2 : 4*n+8+4 = 4*(n+1)+8 := by omega
  rw [h1,h2]
  simp only [List.append_assoc]

theorem grow (n : Nat) : run0 p (1527 + 308*n) (family n) = some (family (n+1)) := by

  have h0 := t0 n

  have h1 := join0 h0 (t1 n)

  have h2 := join0 h1 (t2 n)

  have h3 := join0 h2 (t3 n)

  have h4 := join0 h3 (t4 n)

  have h5 := join0 h4 (t5 n)

  have h6 := join0 h5 (t6 n)

  have h7 := join0 h6 (t7 n)

  have h8 := join0 h7 (t8 n)

  have h9 := join0 h8 (t9 n)

  have h10 := join0 h9 (t10 n)

  have h11 := join0 h10 (t11 n)

  have h12 := join0 h11 (t12 n)

  have h13 := join0 h12 (t13 n)

  have h14 := join0 h13 (t14 n)

  have h15 := join0 h14 (t15 n)

  have h16 := join0 h15 (t16 n)

  have h17 := join0 h16 (t17 n)

  have h18 := join0 h17 (t18 n)

  have h19 := join0 h18 (t19 n)

  have h20 := join0 h19 (t20 n)

  have h21 := join0 h20 (t21 n)

  have h22 := join0 h21 (t22 n)

  have h23 := join0 h22 (t23 n)

  have h24 := join0 h23 (t24 n)

  have h25 := join0 h24 (t25 n)

  have h26 := join0 h25 (t26 n)

  have h27 := join0 h26 (t27 n)

  have hcost : (40 * n) + 187 + (12 * n) + 125 + (12 * n) + 71 + (12 * n) + 34 + (40 * n) + 189 + (40 * n) + 209 + (12 * n) + 56 + (12 * n) + 51 + (12 * n) + 64 + (12 * n) + 34 + (40 * n) + 202 + (40 * n) + 177 + (12 * n) + 94 + (12 * n) + 34 = 1527 + 308*n := by omega

  rw [hcost, start_eq, end_eq] at h27
  exact h27

theorem e0 : run0 p 64 ⟨0, [], []⟩ = some ⟨0, [false, false, true], [true, true, false, true, true, false, true, true, false, true, true, false, true]⟩ := by rfl

theorem e1 : run0 p 64 ⟨0, [false, false, true], [true, true, false, true, true, false, true, true, false, true, true, false, true]⟩ = some ⟨2, [false, true, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true]⟩ := by rfl

theorem e2 : run0 p 64 ⟨2, [false, true, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true]⟩ = some ⟨1, [true, true, false, true, true, false, false, true, false, false], [true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e3 : run0 p 64 ⟨1, [true, true, false, true, true, false, false, true, false, false], [true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, false, true]⟩ = some ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, true, true, false, true, true, true]⟩ := by rfl

theorem e4 : run0 p 64 ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, true, true, false, true, true, true]⟩ = some ⟨4, [true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, false, true, true, true, true, true, false, true, true, true]⟩ := by rfl

theorem e5 : run0 p 64 ⟨4, [true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, false, true, true, true, true, true, false, true, true, true]⟩ = some ⟨2, [false, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, true, false, true, true, false, true, true, false, true]⟩ := by rfl

theorem e6 : run0 p 64 ⟨2, [false, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, true, false, true, true, false, true, true, false, true]⟩ = some ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, false, true, true, true, false, true, true, false, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e7 : run0 p 64 ⟨3, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, false, true, true, true, false, true, true, false, true, true, true, true, false, true, true, false, true]⟩ = some ⟨2, [true, true, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e8 : run0 p 64 ⟨2, [true, true, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, true, true, false, true, true, false, true]⟩ = some ⟨2, [true, true, true, false, false, true, false, false, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, false, true, true, false, true]⟩ := by rfl

theorem e9 : run0 p 64 ⟨2, [true, true, true, false, false, true, false, false, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, false, true, true, false, true]⟩ = some ⟨4, [false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, true, true, false, true, true, true, true, true, true, true, false, true, true, true]⟩ := by rfl

theorem e10 : run0 p 64 ⟨4, [false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, true, true, false, true, true, true, true, true, true, true, false, true, true, true]⟩ = some ⟨1, [false, false, false, true, false, false, true, false, false], [true, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, true, true, true, true, true, false, true, true, true]⟩ := by rfl

theorem e11 : run0 p 64 ⟨1, [false, false, false, true, false, false, true, false, false], [true, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, true, true, true, true, true, false, true, true, true]⟩ = some ⟨4, [true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, false, true, true, true, true, true, true, true, false, true, true, true]⟩ := by rfl

theorem e12 : run0 p 64 ⟨4, [true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, false, true, true, true, true, true, true, true, false, true, true, true]⟩ = some ⟨1, [true, false, false, true, false, false, true, true, false, false, false, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, false, true, true, false, true, true, true]⟩ := by rfl

theorem e13 : run0 p 64 ⟨1, [true, false, false, true, false, false, true, true, false, false, false, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, false, true, true, false, true, true, true]⟩ = some ⟨1, [true, true, false, true], [true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, false, true, true, false, true, true, true, true, false, true, true, true]⟩ := by rfl

theorem e14 : run0 p 64 ⟨1, [true, true, false, true], [true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, false, true, true, false, true, true, true, true, false, true, true, true]⟩ = some ⟨4, [true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, false, true, true, false, true, true, true, true, false, true, true, true]⟩ := by rfl

theorem e15 : run0 p 64 ⟨4, [true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, false, true, true, false, true, true, true, true, false, true, true, true]⟩ = some ⟨1, [true, false, false, true, false, false, true, false, false, false, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, true, false, true, true, true]⟩ := by rfl

theorem e16 : run0 p 64 ⟨1, [true, false, false, true, false, false, true, false, false, false, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, true, false, true, true, true]⟩ = some ⟨4, [true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, false, true, true, false, true]⟩ := by rfl

theorem e17 : run0 p 64 ⟨4, [true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, false, true, true, false, true]⟩ = some ⟨0, [true, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true]⟩ := by rfl

theorem e18 : run0 p 64 ⟨0, [true, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true]⟩ = some ⟨2, [false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e19 : run0 p 64 ⟨2, [false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, false, true]⟩ = some ⟨2, [true, true, false, false, true, false, false], [true, false, true, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e20 : run0 p 64 ⟨2, [true, true, false, false, true, false, false], [true, false, true, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, false, true]⟩ = some ⟨0, [true, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e21 : run0 p 64 ⟨0, [true, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, false, true]⟩ = some ⟨0, [true, false, true, false, false, true, false, false, true, false, false, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e22 : run0 p 64 ⟨0, [true, false, true, false, false, true, false, false, true, false, false, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, false, true]⟩ = some ⟨4, [false, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e23 : run0 p 64 ⟨4, [false, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, true, true, false, true, true, false, true]⟩ = some ⟨2, [false, true, false, false, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e24 : run0 p 64 ⟨2, [false, true, false, false, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, true, false, true, true, false, true]⟩ = some ⟨2, [false, true, false, true], [true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e25 : run0 p 64 ⟨2, [false, true, false, true], [true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, true, false, true, true, false, true]⟩ = some ⟨0, [true, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e26 : run0 p 64 ⟨0, [true, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, true, false, true, true, false, true]⟩ = some ⟨1, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, true, false, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e27 : run0 p 64 ⟨1, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, true, false, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, true, false, true, true, false, true]⟩ = some ⟨2, [false, true, true, false, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, true, false, false, false, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, false, true, true, false, true]⟩ := by rfl

theorem e28 : run0 p 64 ⟨2, [false, true, true, false, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, true, false, false, false, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, false, true, true, false, true]⟩ = some ⟨4, [false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e29 : run0 p 64 ⟨4, [false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true]⟩ = some ⟨1, [false, false, false, true, false, false, true, false, false], [true, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e30 : run0 p 64 ⟨1, [false, false, false, true, false, false, true, false, false], [true, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true]⟩ = some ⟨4, [true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e31 : run0 p 64 ⟨4, [true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true]⟩ = some ⟨3, [true, false, true, true, false, false, false, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e32 : run0 p 64 ⟨3, [true, false, true, true, false, false, false, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, true, true, false, true, true, false, true]⟩ = some ⟨0, [false, false, true, false, false, true, false, false, true, true, true, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, false, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], []⟩ := by rfl

theorem e33 : run0 p 64 ⟨0, [false, false, true, false, false, true, false, false, true, true, true, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, false, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], []⟩ = some ⟨1, [false, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, false, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, false, true, true, false, true, true, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e34 : run0 p 64 ⟨1, [false, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, false, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, false, true, true, false, true, true, true, true, true, true, false, true, true, false, true]⟩ = some ⟨2, [true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, false, true, true, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e35 : run0 p 64 ⟨2, [true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, false, true, true, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩ = some ⟨4, [false, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e36 : run0 p 64 ⟨4, [false, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩ = some ⟨3, [true, true, false, true], [true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e37 : run0 p 64 ⟨3, [true, true, false, true], [true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩ = some ⟨4, [false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e38 : run0 p 64 ⟨4, [false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩ = some ⟨2, [true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e39 : run0 p 64 ⟨2, [true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, true, false, true, true, false, true, true, false, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩ = some ⟨2, [true, true, false, false, true, false, false, true, false, false, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩ := by rfl

theorem e40 : run0 p 64 ⟨2, [true, true, false, false, true, false, false, true, false, false, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, true, true, true, true, true, false, true, true, false, true]⟩ = some ⟨4, [true, false, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, false, true, true, true, true, false, true]⟩ := by rfl

theorem e41 : run0 p 64 ⟨4, [true, false, false, true, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, true, false, true, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, false, true, true, true, true, false, true]⟩ = some ⟨1, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, true, false, true]⟩ := by rfl

theorem e42 : run0 p 64 ⟨1, [true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false, true, false, false], [false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, true, false, true]⟩ = some ⟨4, [false, false, true, false, false, true, false, false], [false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, true, false, true]⟩ := by rfl

theorem e43 : run0 p 12 ⟨4, [false, false, true, false, false, true, false, false], [false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, true, false, true]⟩ = some ⟨0, [false, false, true], [true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, false, true, true, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true, true, true, true, false, true, true, true, true, false, true]⟩ := by rfl

theorem first : run0 p 2764 ⟨0, [], []⟩ = some (family 0) := by
  have h0 := e0

  have h1 := join0 h0 e1

  have h2 := join0 h1 e2

  have h3 := join0 h2 e3

  have h4 := join0 h3 e4

  have h5 := join0 h4 e5

  have h6 := join0 h5 e6

  have h7 := join0 h6 e7

  have h8 := join0 h7 e8

  have h9 := join0 h8 e9

  have h10 := join0 h9 e10

  have h11 := join0 h10 e11

  have h12 := join0 h11 e12

  have h13 := join0 h12 e13

  have h14 := join0 h13 e14

  have h15 := join0 h14 e15

  have h16 := join0 h15 e16

  have h17 := join0 h16 e17

  have h18 := join0 h17 e18

  have h19 := join0 h18 e19

  have h20 := join0 h19 e20

  have h21 := join0 h20 e21

  have h22 := join0 h21 e22

  have h23 := join0 h22 e23

  have h24 := join0 h23 e24

  have h25 := join0 h24 e25

  have h26 := join0 h25 e26

  have h27 := join0 h26 e27

  have h28 := join0 h27 e28

  have h29 := join0 h28 e29

  have h30 := join0 h29 e30

  have h31 := join0 h30 e31

  have h32 := join0 h31 e32

  have h33 := join0 h32 e33

  have h34 := join0 h33 e34

  have h35 := join0 h34 e35

  have h36 := join0 h35 e36

  have h37 := join0 h36 e37

  have h38 := join0 h37 e38

  have h39 := join0 h38 e39

  have h40 := join0 h39 e40

  have h41 := join0 h40 e41

  have h42 := join0 h41 e42

  have h43 := join0 h42 e43

  exact h43

theorem never (m : Machine) (hm : compatible p m) : NeverHalts m := never_of_growth p family 2764 (fun n => 1527 + 308*n) first (by intro n; omega) grow m hm

theorem cover (B : Nat) : Cover (WeightedBound B) p := Cover.leaf p (fun m hm => weighted_never B m (never m hm))

#print axioms grow

#print axioms cover

end BB6.Agent4E0OneLC1661
