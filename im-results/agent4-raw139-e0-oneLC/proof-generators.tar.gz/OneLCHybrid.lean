import Hybrid
import ZipThreeHoleAudit
import BlockFAR2
import BlockFARBridge
import BlockFARBridge4
set_option maxHeartbeats 0
set_option maxRecDepth 1000000
namespace BB6.Agent4OneLCHybrid
open BB6Coverage BB6Coverage.FAR BB6.Agent13BlankDelay BB6.Agent31ThreeHole BB6.Agent50TNFPilot BB6.Agent10ZipAudit

def table3 (p : PartialMachine) : BB6BlockFAR.Table := fun q b => ((p (q,b)).bind id).map fun mv => ⟨mv.write,mv.right,mv.next⟩
def table4 (p : PartialMachine) : BB6BlockFAR4.Table := fun q b => ((p (q,b)).bind id).map fun mv => ⟨mv.write,mv.right,mv.next⟩

def block2OK (p : PartialMachine) {d n : Nat} (c : BB6BlockFAR2.Data d n) : Bool :=
  let m := table3 p
  tableOK p (BB6BlockFAR.partialTable m) && (c.baseCheck && c.predCheck && c.rowsCheck m)
def block3OK (p : PartialMachine) {d n : Nat} (c : BB6BlockFAR.Data d n) : Bool :=
  let m := table3 p
  tableOK p (BB6BlockFAR.partialTable m) && (c.baseCheck && c.predCheck && c.rowsCheck m)
def block4OK (p : PartialMachine) {d n : Nat} (c : BB6BlockFAR4.Data d n) : Bool :=
  let m := table4 p
  tableOK p (BB6BlockFAR4.partialTable m) && (c.baseCheck && c.predCheck && c.rowsCheck m)

theorem block2Sound (p : PartialMachine) {d n : Nat} (c : BB6BlockFAR2.Data d n) (h : block2OK p c = true) :
    ∀ m, compatible p m → NeverHalts m := by
  simp only [block2OK,Bool.and_eq_true] at h
  have hv : c.Valid (table3 p) := ⟨h.2.1.1,h.2.1.2,h.2.2⟩
  have he := tableOK_sound _ _ h.1
  intro m hm
  exact BB6BlockFAR.transfer_never _ m (by simpa only [← he] using hm) (c.sound _ hv)
theorem block3Sound (p : PartialMachine) {d n : Nat} (c : BB6BlockFAR.Data d n) (h : block3OK p c = true) :
    ∀ m, compatible p m → NeverHalts m := by
  simp only [block3OK,Bool.and_eq_true] at h
  have hv : c.Valid (table3 p) := ⟨h.2.1.1,h.2.1.2,h.2.2⟩
  have he := tableOK_sound _ _ h.1
  intro m hm
  exact BB6BlockFAR.transfer_never _ m (by simpa only [← he] using hm) (c.sound _ hv)
theorem block4Sound (p : PartialMachine) {d n : Nat} (c : BB6BlockFAR4.Data d n) (h : block4OK p c = true) :
    ∀ m, compatible p m → NeverHalts m := by
  simp only [block4OK,Bool.and_eq_true] at h
  have hv : c.Valid (table4 p) := ⟨h.2.1.1,h.2.1.2,h.2.2⟩
  have he := tableOK_sound _ _ h.1
  intro m hm
  exact BB6BlockFAR4.transfer_never _ m (by simpa only [← he] using hm) (c.sound _ hv)

theorem unmirror (p : PartialMachine) (f : Bool)
    (h : ∀ m, compatible (if f then reflectPartial p else p) m → NeverHalts m) :
    ∀ m, compatible p m → NeverHalts m := by
  intro m hm
  cases f with
  | false => exact h m hm
  | true => exact reflectNever m (h _ (reflectCompatible p m hm))

inductive Branch (B : Nat) where
  | closed (tree : Audit)
  | b2 (rev : Bool) (d n : Nat) (cert : BB6BlockFAR2.Data d n)
  | b3 (rev : Bool) (d n : Nat) (cert : BB6BlockFAR.Data d n)
  | b4 (rev : Bool) (d n : Nat) (cert : BB6BlockFAR4.Data d n)
  | covered (q : PartialMachine) (safe : Cover (WeightedBound B) q)
  | split (n : Nat) (s : Slot) (kids : Move → Branch B)

def check (B : Nat) (p : PartialMachine) : Branch B → Bool
  | .closed t => zipCheck B p t
  | .b2 f _ _ c => block2OK (if f then reflectPartial p else p) c
  | .b3 f _ _ c => block3OK (if f then reflectPartial p else p) c
  | .b4 f _ _ c => block4OK (if f then reflectPartial p else p) c
  | .covered q _ => tableOK p q
  | .split n s kids => zipQueryOK B p n s && allMoves (fun mv => check B (refine p s (some mv)) (kids mv))
termination_by structural t => t

theorem sound (B : Nat) (p : PartialMachine) (t : Branch B)
    (hf : p initialSlot = some (some ⟨true,true,1⟩))
    (hn : weightedTNFNoAssignedHalt p) (h : check B p t = true) : Cover (WeightedBound B) p := by
  induction t generalizing p with
  | closed t => exact .leaf p (certifiedZip B p t hf hn h).sound
  | b2 f d n c => exact .leaf p (fun m hm => weighted_never B m (unmirror p f (block2Sound _ c h) m hm))
  | b3 f d n c => exact .leaf p (fun m hm => weighted_never B m (unmirror p f (block3Sound _ c h) m hm))
  | b4 f d n c => exact .leaf p (fun m hm => weighted_never B m (unmirror p f (block4Sound _ c h) m hm))
  | covered q safe =>
    have he : p = q := tableOK_sound p q h
    subst q; exact safe
  | split n s kids ih =>
    have hv : zipQueryOK B p n s = true ∧ allMoves (fun mv => check B (refine p s (some mv)) (kids mv)) = true := by
      simpa only [check,Bool.and_eq_true] using h
    obtain ⟨hread,hhole,hw⟩ := zipQueryOK_sound hv.1
    apply Cover.leaf
    intro m hm
    cases ht : m s with
    | none =>
      cases hr : knownRun p n with
      | none => simp [hr] at hread
      | some c =>
        have hs : readSlot c = s := by simpa [hr] using hread
        have hc : compatible (refine p s none) m := by
          simpa [ht] using compatible_refine p m s hm
        exact first_hole_weighted_halt B p n c hf hr
          (by simpa [hs] using hhole)
          (by simpa [hs] using weightOK_sound p s n B hw) m
          (by simpa [hs] using hc)
    | some mv =>
      have hc : compatible (refine p s (some mv)) m := by
        simpa [ht] using compatible_refine p m s hm
      exact (ih mv (refine p s (some mv))
        (refine_preserves_firstOne p s (some mv) hhole hf)
        (weightedTNFNoAssignedHalt_refine p s mv hn) (allMoves_sound _ hv.2 mv)).sound m hc

def byBranchMove {B : Nat} (xs : List (Branch B)) (mv : Move) : Branch B :=
  xs[12*mv.write.toNat+6*mv.right.toNat+mv.next.val]?.getD (.closed (.last 0 (0,false)))

#print axioms sound
end BB6.Agent4OneLCHybrid
