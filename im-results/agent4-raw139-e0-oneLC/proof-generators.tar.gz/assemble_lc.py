"""Generate proof source using a checked compact block-aware Hybrid tree."""
import argparse, json, pathlib, sys, functools, collections, multiprocessing
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'im-results/agent48-raw139-f1-oneRA'))
from blockcert import generate
P=[7,24,11,24,14,24,24,16,10,11,24,24]
B=204890
ORDER=[4*q+2*w+r for w in range(2) for r in range(2) for q in range(6)]
NS='BB6.Agent4E0OneLCParent'
CYC={12481,12482,12487,12490,13444,13445,13447,18563,18570}
def bl(x):return str(bool(x)).lower()
def slot(s):return f'({s//2},{bl(s%2)})'
def pack(xs,b):return sum(v<<(b*i) for i,v in enumerate(xs))
def vec(xs,b,stride=16):return f'⟨{b},{stride},#['+','.join(hex(pack(xs[i:i+stride],b)) for i in range(0,len(xs),stride))+']⟩'
def rows(xs,b):
    k=max(1,max(map(len,xs)))
    return f'⟨{vec([pack([v+1 for v in x],b) for x in xs],b*k,8)},{b},{k}⟩'
def block_term(t,r):
    _,w,cap,mod,z,f,ph,*_=r
    c=generate(t,w,cap,mod,z,f,event_limit=150000,phase=ph)
    assert c is not None,(t,r)
    d,n=c['left_states'],c['right_nodes'];b=max(d,n).bit_length();pb=(2**w*d).bit_length()
    data=','.join(['0',vec(c['push'],b),vec(c['ctrl'],b),vec(c['aux'],b),rows(c['pred'],pb),rows(c['edges'],b),str(sum(1<<x for x in c['zero_states'])),vec(c['zeroNext'],b)])
    return (f'.b{w} {bl(f)} {d-1} {n-1} ⟨{data}⟩',max(1,d*(2**w)//20))
def ordinary(n):
    k,*a=n
    if k=='cycle':e,s,r,x=a;return f'.cycle {e} {s} {bl(r)} ({x})'
    if k=='last':return f'.last {a[0]} {slot(a[1])}'
    if k=='far':
        rev,d,dfa,t0,t1,z=a;return f'.far {bl(rev)} {d} ⟨0,{dfa},{t0},{t1},{z}⟩'
    raise ValueError(n)
def make(root,partition,recipes,children,out,cap=185,block_cap=8):
    idx={tuple(t):i for i,t in enumerate(partition['open'])};assert len(idx)==19595
    blocks={};special={}
    def finish(r,i,t):
        if r[0]=='block':blocks[i]=block_term(t,r);return ('block',i)
        if r[0]=='late':
            assert t.count(24)==1
            if r[1]>=1000:
                special[i]=('late',i);return ('special',i)
            return ('last',*r[1:])
        if r[0] in ('wide','sweep') or i in CYC:
            special[i]=(r[0],i);return ('special',i)
        assert r[0]=='cycle',(i,r)
        return tuple(r)
    def expand(n,t):
        if n[0]=='split':
            _,k,s,kids=n;assert t[s]==24 and len(kids)==24
            return ('split',k,s,tuple(expand(ch,t[:s]+[v]+t[s+1:]) for ch,v in zip(kids,ORDER)))
        if n[0]!='open':return tuple(n)
        i=idx[tuple(t)];r=recipes[str(i)];assert t==n[1]
        if r[0]=='late' and t.count(24)>1:
            _,k,s=r
            return ('split',k,s,tuple(finish(children[i,v],100000+i*24+v,t[:s]+[v]+t[s+1:]) for v in ORDER))
        return finish(r,i,t)
    _,k,s,kids=partition['tree'];assert (k,s)==(9,6)
    t=P[:s]+[ORDER[root]]+P[s+1:];tree=expand(kids[root],t)
    # Compute the trusted checks only in Lean. These costs just choose cuts.
    def cost(n):
        if n[0]=='split':
            c=[cost(ch) for ch in n[3]];return (sum(x[0] for x in c),sum(x[1] for x in c),sum(x[2] for x in c)+n[1])
        if n[0]=='block':
            return (1,blocks[n[1]][1],0)
        if n[0]=='last':return (1,0,n[1])
        if n[0]=='cycle':return (1,0,n[1]+n[2])
        return (1,0,0)
    def leaf(n,deps):
        if n[0]=='block':return blocks[n[1]][0]
        if n[0]=='special':
            i=n[1];k,_=special[i]
            if i in CYC:
                deps.add('E0OneLCCycles');prefix='BB6.Agent4E0OneLC';return f'.covered {prefix}.p{i} ({prefix}.cover{i} {B})'
            if i==1661:
                deps.add('E0OneLC1661');prefix='BB6.Agent4E0OneLC1661';return f'.covered {prefix}.p ({prefix}.cover {B})'
            if i in (134,15474):
                deps.add(f'E0OneLC{i}Proof');w=6 if i==134 else 12;prefix=f'BB6.Agent4WideBlock{w}.E0OneLC{i}';return f'.closed (.proven {prefix}.ctr {prefix}.never)'
            if k=='late':
                deps.add(f'OneLCLate{i}');prefix=f'BB6.Agent4E0OneLCLate.H{i}';return f'.covered {prefix}.p {prefix}.cover'
            raise ValueError(n)
        return f'.closed ({ordinary(n)})'
    def inline(n,deps):
        if n[0]!='split':return leaf(n,deps)
        return f'.split {n[1]} {slot(n[2])} (byBranchMove [\n'+',\n'.join(inline(ch,deps) for ch in n[3])+'])'
    declarations=[]
    hdr='set_option maxRecDepth 1000000\nset_option maxHeartbeats 0\nnamespace '+NS+'\nopen BB6Coverage BB6Coverage.FAR BB6.Agent13BlankDelay BB6.Agent31ThreeHole BB6.Agent50TNFPilot BB6.Agent10ZipAudit BB6.Agent4OneLCHybrid\n'
    def emit(n,t,name):
        deps={'OneLCHybrid'};l,b,c=cost(n)
        if n[0]!='split' or (l<=cap and b<=block_cap and c<=12000):term=inline(n,deps)
        else:
            _,k,s,kids=n;terms=[]
            for j,(ch,v) in enumerate(zip(kids,ORDER)):
                t2=t[:s]+[v]+t[s+1:];a,bb,cc=cost(ch)
                if ch[0]=='split' and (a>cap or bb>block_cap or cc>12000):
                    cn=f'{name}_{j}';emit(ch,t2,cn);deps.add(cn);terms.append(f'.covered p{cn} c{cn}')
                elif ch[0]=='split' and (l>cap or b>block_cap or c>12000):
                    cn=f'{name}_{j}';emit(ch,t2,cn);deps.add(cn);terms.append(f'.covered p{cn} c{cn}')
                elif ch[0]=='block' and (bb>block_cap or b>block_cap):
                    cn=f'{name}_{j}';emit(ch,t2,cn);deps.add(cn);terms.append(f'.covered p{cn} c{cn}')
                else:terms.append(inline(ch,deps))
            term=f'.split {k} {slot(s)} (byBranchMove [\n'+',\n'.join(terms)+'])'
        src=f'def p{name} : PartialMachine := fromCodes {t}\ndef t{name} : Branch {B} := {term}\ntheorem c{name} : Cover (WeightedBound {B}) p{name} :=\n  sound {B} p{name} t{name} (by decide +kernel) (BB6.Agent6Hybrid.fromCodes_nohalt _) (by decide +kernel)\n'
        declarations.append((name,src,deps))
    name=f'OLCRoot{root:02d}';emit(tree,t,name)
    # Batch consecutive declarations; retain independent checks and topological order.
    out.mkdir(exist_ok=True,parents=True);groups={};pending=[];weight=0;batches=[]
    def flush():
        nonlocal weight,pending
        if not pending:return
        nm=f'{name}Batch{len(batches):04d}';here={n for n,_,_ in pending};deps=set();sources=[]
        for n,src,d in pending:
            deps|={groups.get(x,x) for x in d if x not in here};sources.append(src);groups[n]=nm
        (out/(nm+'.lean')).write_text(''.join('import '+x+'\n' for x in sorted(deps))+hdr+'\n'.join(sources)+f'end {NS}\n')
        batches.append(nm);pending=[];weight=0
    for n,src,deps in declarations:
        if len(pending)>=12 or weight+len(src)>35000:flush()
        pending.append((n,src,deps));weight+=len(src)
    flush()
    (out/(name+'.lean')).write_text(f'import {groups[name]}\n#print axioms {NS}.c{name}\n')
    (out/(name+'.txt')).write_text('\n'.join(batches+[name])+'\n')
    print(name,'leaf count',cost(tree)[0],'block',len(blocks),'special',len(special),'declarations',len(declarations),'batches',len(batches),flush=True)

def final(out):
    name='E0OneLCParent'
    src='import OneLCHybrid\n'+''.join(f'import OLCRoot{i:02d}\n' for i in range(24))
    src+=f'''set_option maxHeartbeats 0
namespace {NS}
open BB6Coverage BB6Coverage.FAR BB6.Agent13BlankDelay BB6.Agent31ThreeHole BB6.Agent50TNFPilot BB6.Agent10ZipAudit BB6.Agent4OneLCHybrid
def parent : PartialMachine := fromCodes {P}
def root : Branch {B} := .split 9 (3,false) (byBranchMove [
'''+',\n'.join(f'.covered pOLCRoot{i:02d} cOLCRoot{i:02d}' for i in range(24))+f'''])
theorem weighted : Cover (WeightedBound {B}) parent :=
  sound {B} parent root (by decide +kernel) (BB6.Agent6Hybrid.fromCodes_nohalt _) (by decide +kernel)
#print axioms weighted
end {NS}
'''
    (out/(name+'.lean')).write_text(src)
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('directory',type=pathlib.Path);a.add_argument('out',type=pathlib.Path);a.add_argument('--roots',nargs='+',type=int,default=list(range(24)));a.add_argument('--jobs',type=int,default=4);a.add_argument('--cap',type=int,default=185);a.add_argument('--block-cap',type=int,default=8);a=a.parse_args()
    p=json.loads((a.directory/'partition.json').read_text());r=json.loads((a.directory/'recipes.json').read_text());ch={(i,m):v for i,m,v in json.loads((a.directory/'children.json').read_text())}
    with multiprocessing.Pool(a.jobs) as pool:pool.starmap(make,[(i,p,r,ch,a.out,a.cap,a.block_cap) for i in a.roots])
    final(a.out)
