import json,sys
from pathlib import Path
P=Path(sys.argv[1]); out=Path(sys.argv[2]); out.mkdir(exist_ok=True,parents=True)
p=json.loads((P/'partition.json').read_text())['open']; rec=json.loads((P/'recipes.json').read_text())
head='''import Hybrid
import ZipThreeHoleAudit
set_option maxHeartbeats 0
set_option maxRecDepth 1000000
namespace BB6.Agent4E0OneLCLate
open BB6Coverage BB6Coverage.Agent31Pump BB6Coverage.Agent10ZipAudit BB6Coverage.Agent50Zipper BB6.Agent13BlankDelay BB6.Agent31ThreeHole BB6.Agent50TNFPilot

def word : Nat → Nat → List Bool
  | 0,_ => []
  | n+1,x => (x%2 == 1)::word n (x/2)

theorem read_of_run0 {p : PartialMachine} {n : Nat} {z : Z0}
    (h : run0 p n ⟨0,[],[]⟩ = some z) :
    (knownRun p n).map readSlot = some (z.q,z.l.headD false) := by
  have hh : (zrun p n BB6Coverage.Agent31Pump.start).map project = some z := (run_project p n _).trans h
  cases hz : zrun p n BB6Coverage.Agent31Pump.start with
  | none => simp [hz] at hh
  | some v =>
    have he : project v = z := by simpa [hz] using hh
    subst z
    simp [knownRun_zip,hz,read_embed,project]

theorem last_of_read (B : Nat) (p : PartialMachine) (n : Nat) (s : Slot)
    (hr : (knownRun p n).map readSlot = some s)
    (hf : p initialSlot = some (some ⟨true,true,1⟩))
    (hh : p s = none) (hrest : restOK p s = true) (hw : weightOK p s n B = true) : Cover (WeightedBound B) p := by
  cases h : knownRun p n with
  | none => simp [h] at hr
  | some c =>
    have hs : readSlot c = s := by simpa [h] using hr
    apply Cover.leaf
    exact (WeightedTNFCertificate.lastHole hf (support6 p) (by decide) h
      (by simpa [hs] using hh) (by simpa [hs] using restOK_sound p s hrest)
      (by simpa [hs] using weightOK_sound p s n B hw)).sound
'''
(out/'OneLCLateCore.lean').write_text(head+'\nend BB6.Agent4E0OneLCLate\n')
for i,r in rec.items():
    if r[0]!='late' or r[1]<1000:continue
    i=int(i);n,s=r[1:]; t=p[i];assert t.count(24)==1
    S='''import OneLCLateCore
set_option maxHeartbeats 0
set_option maxRecDepth 1000000
namespace BB6.Agent4E0OneLCLate
open BB6Coverage BB6Coverage.Agent31Pump BB6Coverage.Agent10ZipAudit BB6Coverage.Agent50Zipper BB6.Agent13BlankDelay BB6.Agent31ThreeHole BB6.Agent50TNFPilot
'''+f'namespace H{i}\ndef p : PartialMachine := FAR.fromCodes {t}\n'
    q=0;l=[];rr=[];chunk=256
    def bits(w):return hex(sum(x<<j for j,x in enumerate(w)))
    def cfg():return f'⟨{q},word {len(l)} {bits(l)},word {len(rr)} {bits(rr)}⟩'
    S+='def c0 : Z0 := ⟨0,[],[]⟩\n'; cuts=[0];j=0
    for k in range(n):
        v=t[2*q+(l[0] if l else 0)]; assert v!=24
        w=(v>>1)&1;q=v>>2
        if v&1:l=[rr[0] if rr else 0,w]+l[1:];rr=rr[1:]
        else:l=l[1:];rr=[w]+rr
        if (k+1)%chunk==0 or k+1==n:
            j+=1;cuts.append(k+1)
            S+=f'def c{j} : Z0 := {cfg()}\ntheorem e{j} : run0 p {cuts[j]-cuts[j-1]} c{j-1} = some c{j} := by decide +kernel\n'
    assert 2*q+(l[0] if l else 0)==s
    def combine(a,b):
        nonlocal_dummy=None
        if b-a==1:return '',f'e{b}'
        mid=(a+b)//2;u,un=combine(a,mid);v,vn=combine(mid,b);nm=f'join_{a}_{b}'
        return u+v+f'theorem {nm} : run0 p {cuts[b]-cuts[a]} c{a} = some c{b} := join0 {un} {vn}\n',nm
    u,un=combine(0,j);S+=u+f'theorem whole : run0 p {n} ⟨0,[],[]⟩ = some c{j} := {un}\n'
    S+=f'theorem read : (knownRun p {n}).map readSlot = some ({s//2},{str(bool(s%2)).lower()}) := read_of_run0 whole\n'
    S+=f'theorem cover : Cover (WeightedBound 204890) p := last_of_read 204890 p {n} ({s//2},{str(bool(s%2)).lower()}) read (by decide) (by decide) (by decide) (by decide)\n#print axioms cover\nend H{i}\nend BB6.Agent4E0OneLCLate\n'
    (out/f'OneLCLate{i}.lean').write_text(S)
