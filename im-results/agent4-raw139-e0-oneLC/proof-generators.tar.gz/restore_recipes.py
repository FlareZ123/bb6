"""Restore exact discovery recipe selection without repeating search."""
import json,zlib,base64,sys,pathlib
p=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);out.mkdir(exist_ok=True,parents=True)
r=json.loads(p.read_text());codes=zlib.decompress(base64.b64decode(r['codes']));assert len(codes)==19595
rec={str(i):r['classes'][v-1] if v else r['misc'][str(i)] for i,v in enumerate(codes)}
assert len(rec)==19595 and not any(x[0]=='open' for x in rec.values())
(out/'recipes.json').write_text(json.dumps(rec));(out/'children.json').write_text(json.dumps(r['children']))
