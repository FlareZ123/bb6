import re,sys,tarfile
from pathlib import Path
src=Path(sys.argv[1]); out=Path(sys.argv[2]); out.mkdir(parents=True,exist_ok=True)
if src.is_file():
    orig=out/'wideorig'; orig.mkdir(exist_ok=True)
    with tarfile.open(src) as t:t.extractall(orig,filter='data')
else:orig=src
B=(orig/'WideBlock.lean').read_text(); S=(orig/'WideSparse.lean').read_text(); E=(orig/'emit_wide.py').read_text()
(out/'widegraph.py').write_text((orig/'widegraph.py').read_text())
for W,T,num,params in [(6,[7,22,11,5,14,1,0,16,10,11,4,24],134,(1,1,2,True,100000,False)),(12,[7,22,11,21,14,3,7,16,10,11,24,17],15474,(2,1,2,True,100000,False))]:
    A=2**W; ns=f'BB6.Agent4WideBlock{W}'; P=range(W); fuel=256
    def tup(xs):return '⟨'+','.join(xs)+'⟩'
    def ray(xs,rest):
        for x in reversed(list(xs)):rest=f'cons {x} ({rest})'
        return rest
    def hb():return ''.join(f'  have hb{i} : s.b{i}.toNat ≤ 1 := by cases s.b{i} <;> decide\n' for i in P)
    head=B.split('structure Sym where')[0]
    head+='structure Sym where\n'+''.join(f'  b{i} : Bool\n' for i in P)+'  deriving DecidableEq, Repr\n\n'
    head+='def Sym.zero : Sym := '+tup(['false']*W)+'\n\n'
    head+='def Sym.code (s : Sym) : Nat := '+' + '.join(f'{2**i}*s.b{i}.toNat' for i in P)+'\n\n'
    head+='def Sym.ofCode (n : Nat) : Sym := '+tup(f'n/{2**i}%2 == 1' for i in P)+'\n\n'
    head+=f'def symbols : List Sym := (List.range {A}).map Sym.ofCode\n\n'
    head+=f'theorem code_lt (s : Sym) : s.code < {A} := by\n'+hb()+'  unfold Sym.code\n  omega\n\n'
    head+='theorem ofCode_code (s : Sym) : Sym.ofCode s.code = s := by\n'+hb()
    for i in P:head+=f'  have h{i} : (s.code / {2**i} % 2 == 1) = s.b{i} := by\n    have he : s.code / {2**i} % 2 = s.b{i}.toNat := by\n      unfold Sym.code\n      omega\n    rw [he]\n    cases s.b{i} <;> rfl\n'
    head+='  cases s\n  simp only [Sym.ofCode,Sym.mk.injEq]\n  exact '+tup(f'h{i}' for i in P)+'\n\n'
    head+=B[B.index('theorem symbols_complete'):B.index('inductive Pos where')]
    head+='inductive Pos where '+' '.join(f'| p{i}' for i in P)+'\n  deriving DecidableEq, Repr\n\n'
    head+='def Sym.read (s : Sym) : Pos → Bool\n'+''.join(f'  | .p{i} => s.b{i}\n' for i in P)+'\n'
    head+='def Sym.write (s : Sym) (p : Pos) (w : Bool) : Sym :=\n  match p with\n'+''.join(f'  | .p{i} => '+tup('w' if i==j else f's.b{j}' for j in P)+'\n' for i in P)+'\n'
    for side,inds in [('left',list(reversed(P))),('right',list(P))]:
        head+=f'def {side}Ray : List Sym → Ray\n  | [] => blankRay\n  | a::r => '+ray((f'a.b{i}' for i in inds),f'{side}Ray r')+'\n\n'
    for side,var,inds in [('left','l',list(reversed(P))),('right','r',list(P))]:
        head+=f'theorem {side}Ray_unfold ({var} : List Sym) :\n    {side}Ray {var} = '+ray((f'({var}.headD Sym.zero).b{i}' for i in inds),f'{side}Ray {var}.tail')+f' := by\n  cases {var} with\n  | nil => simp [{side}Ray,Sym.zero,blank_cons]\n  | cons a r => rfl\n\n'
    head+='def render (q : Q) (p : Pos) (a : Sym) (l r : List Sym) : Prim :=\n  match p with\n'
    for i in P:head+=f'  | .p{i} => ⟨q,'+ray((f'a.b{j}' for j in reversed(range(i))),'leftRay l')+','+ray((f'a.b{j}' for j in range(i,W)),'rightRay r')+'⟩\n'
    tail=B[B.index('structure BlockConfig where'):]; tail=tail.replace('else .p7',f'else .p{W-1}').replace('12289',str(fuel))
    start=tail.index('    | .p0,false'); end=tail.index('\ndef blockExit',start)
    branches=[]; cases=[]
    for i in P:
        for d in [-1,1]:
            b=str(d==1).lower(); j=i+d
            branches.append(f'    | .p{i},{b} => '+(f'more .p{j}' if 0<=j<W else f'return ⟨1,mv.next,{b},w⟩'))
            if 0<=j<W:cases.append(f"      · obtain ⟨e',he',rfl⟩ := h\n        obtain ⟨hpos,hrun⟩ := ih mv.next .p{j} (a.write .p{i} mv.write) e' he'\n        refine ⟨by simp,?_⟩\n        simpa [run,primStep,render,Sym.write,hm,hd] using hrun\n")
    tail=tail[:start]+'\n'.join(branches)+'\n'+tail[end:]
    start=tail.index("      · obtain ⟨e',he',rfl⟩ := h"); end=tail.index('      · subst e',start)
    tail=tail[:start]+''.join(cases)+tail[end:]
    (out/f'WideBlock{W}.lean').write_text((head+'\n'+tail).replace('BB6.Agent1WideBlock',ns))
    sparse=re.sub(r'\b1536\b',str(6*A),S); sparse=re.sub(r'\b256\b',str(A),sparse)
    (out/f'WideSparse{W}.lean').write_text(sparse.replace('import WideBlock',f'import WideBlock{W}').replace('BB6.Agent1WideBlock',ns))
    emit=E.replace('T=[7,8,11,3,14,5,22,16,15,11,24,0]',f'T={T}\nW={W}\nA=2**W')
    emit=emit.replace('generate(T,8,1,2,3,True,100000,True)',f'generate(T,{W},'+','.join(map(str,params))+')').replace('256*l+a','A*l+a').replace('A=256;K=256','K=A')
    emit=emit.replace('pairbits=8+','pairbits=W+').replace('ebits=8+','ebits=W+').replace("name='E0OneRD4267';ns='BB6.Agent1WideBlock.'+name",f"name='E0OneLC{num}';ns='{ns}.'+name").replace("s=f'import WideSparse\\n",f"s=f'import WideSparse{W}\\n")
    emit=emit.replace("s+='''def unpack","s+=f'''def unpack").replace('(x%256,x/256)','(x%{A},x/{A})').replace('if length<=16:',f'if length<={4 if W==12 else 16}:')
    emit=emit.replace('pairs {A} {pairbits} (pushData l)','pairs {max(map(len,push.values()))} {pairbits} (pushData l)').replace('pairs {A} {pairbits} (auxData (i/{A}))','pairs {max(map(len,auxr.values()))} {pairbits} (auxData (i/{A}))').replace('unpack {A} {ebits} (edgeData v)','unpack {max(map(len,edge.values()))} {ebits} (edgeData v)')
    (out/f'emit_wide{W}.py').write_text(emit)
