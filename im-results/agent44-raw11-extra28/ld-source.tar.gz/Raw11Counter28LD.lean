import SweepPumping
import PhaseFrontier
namespace BB6.Agent44Counter28LD
open BB6Coverage BB6Coverage.Agent31Pump

def table (d : Bool) : PartialMachine := fun s => match s.1.val, s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 0,true => some (some ⟨false,false,1⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨true,false,2⟩)
  | 2,false => some (some ⟨false,false,0⟩)
  | 2,true => some (some ⟨false,false,3⟩)
  | 3,false => some (some ⟨false,true,4⟩)
  | 3,true => some (some ⟨false,false,3⟩)
  | 4,false => some (some ⟨true,true,5⟩)
  | 5,false => some (some ⟨true,false,if d then 3 else 2⟩)
  | 5,true => some (some ⟨true,true,4⟩)
  | _,_ => none

inductive Digits : List Bool → Prop
  | nil : Digits []
  | single (b : Bool) : Digits [b]
  | pair (b : Bool) {r : List Bool} : Digits r → Digits (b :: false :: r)

def cfg (k : Nat) (r : List Bool) : Z0 := ⟨4,false :: (rep [true,true] k ++ [false]),r⟩

theorem zeros (k : Nat) {r : List Bool} (h : Digits r) : Digits (rep [false,false] k ++ r) := by
  induction k with
  | zero => exact h
  | succ k ih => exact Digits.pair false ih

theorem erase (d : Bool) (k : Nat) (r : List Bool) :
    run0 (table d) (2*k) ⟨3,rep [true,true] k ++ [false],r⟩ =
      some ⟨3,[false],rep [false,false] k ++ r⟩ := by
  induction k generalizing r with
  | zero => rfl
  | succ k ih =>
    rw [show 2*(k+1)=2+2*k by omega]
    have h1 : run0 (table d) 2 ⟨3,rep [true,true] (k+1) ++ [false],r⟩ =
      some ⟨3,rep [true,true] k ++ [false],false::false::r⟩ := rfl
    have h2 := ih (false::false::r)
    have h := join0 h1 h2
    have he : rep [false,false] k ++ (false::false::r) = rep [false,false] (k+1) ++ r := by
      change rep [false,false] k ++ ([false,false] ++ r) = _
      rw [← List.append_assoc,rep_snoc]
      rfl
    rw [he] at h
    exact h

theorem carry (d : Bool) (k : Nat) (r : List Bool) :
    run0 (table d) 2 (cfg k (true :: false :: r)) = some (cfg (k+1) r) := by
  rfl

theorem carryLast (d : Bool) (k : Nat) :
    run0 (table d) 2 (cfg k [true]) = some (cfg (k+1) []) := by rfl

theorem reset (d : Bool) (k : Nat) (r : List Bool) :
    run0 (table d) (2*k+4) (cfg k (false :: r)) =
      some (cfg 0 (rep [false,false] k ++ true :: r)) := by
  have h1 : run0 (table d) 3 (cfg k (false :: r)) =
    some ⟨3,rep [true,true] k ++ [false],false::true::r⟩ := by cases d <;> rfl
  have h2 := erase d k (false::true::r)
  have h3 : run0 (table d) 1 ⟨3,[false],rep [false,false] k ++ false::true::r⟩ =
    some (cfg 0 (rep [false,false] k ++ true::r)) := by
    cases k with
    | zero => rfl
    | succ k =>
      change some (⟨4,[false,false],false :: (rep [false,false] k ++ false::true::r)⟩ : Z0) = _
      congr 2
      change false :: (rep [false,false] k ++ false::true::r) = false::false::(rep [false,false] k ++ true::r)
      congr 1
      change rep [false,false] k ++ ([false] ++ (true::r)) = false :: (rep [false,false] k ++ true::r)
      have hh : ∀ j : Nat, rep [false,false] j ++ [false] = false :: rep [false,false] j := by
        intro j
        induction j with
        | zero => rfl
        | succ j ih => simp only [rep,List.cons_append,List.nil_append,ih]
      rw [← List.append_assoc,hh]
      rfl
  rw [show 2*k+4=3+2*k+1 by omega]
  exact join0 (join0 h1 h2) h3

theorem resetNil (d : Bool) (k : Nat) :
    run0 (table d) (2*k+4) (cfg k []) = some (cfg 0 (rep [false,false] k ++ [true])) := by
  have h1 : run0 (table d) 1 (cfg k []) = run0 (table d) 1 (cfg k [false]) := rfl
  rw [show 2*k+4=1+(2*k+3) by omega,run0_add,h1,← run0_add,show 1+(2*k+3)=2*k+4 by omega]
  exact reset d k []

theorem advance (d : Bool) (k : Nat) {r : List Bool} (h : Digits r) :
    ∃ n j s, 0 < n ∧ Digits s ∧ run0 (table d) n (cfg k r) = some (cfg j s) := by
  cases h with
  | nil => exact ⟨2*k+4,0,_,by omega,zeros k (.single true),resetNil d k⟩
  | single b =>
    cases b with
    | false => exact ⟨2*k+4,0,_,by omega,zeros k (.single true),reset d k []⟩
    | true => exact ⟨2,k+1,[],by decide,.nil,carryLast d k⟩
  | @pair b r h =>
    cases b with
    | false => exact ⟨2*k+4,0,_,by omega,zeros k (.pair true h),reset d k (false::r)⟩
    | true => exact ⟨2,k+1,r,by decide,h,carry d k r⟩

theorem arbitrary (d : Bool) (n : Nat) :
    ∃ t k r, n ≤ t ∧ Digits r ∧ run0 (table d) t ⟨0,[],[]⟩ = some (cfg k r) := by
  induction n with
  | zero => exact ⟨12,0,[false,false,false,false],by decide,.pair false (.pair false .nil),by cases d <;> rfl⟩
  | succ n ih =>
    obtain ⟨t,k,r,ht,hr,h⟩ := ih
    obtain ⟨u,j,s,hu,hs,g⟩ := advance d k hr
    exact ⟨t+u,j,s,by omega,hs,join0 h g⟩

open BB6Coverage.Agent50Zipper BB6.Agent13BlankDelay

theorem never (d : Bool) (m : Machine) (hm : compatible (table d) m) : NeverHalts m := by
  intro n
  obtain ⟨t,k,r,ht,_,hr⟩ := arbitrary d n
  have hz : (zrun (table d) t start).map project = some (cfg k r) :=
    (run_project (table d) t start).trans hr
  cases h : zrun (table d) t start with
  | none => simp [h] at hz
  | some z =>
    have H := zrun_sound (table d) m hm t start z h
    rw [start_embed] at H
    rw [show t=n+(t-n) by omega,run_append] at H
    change (run m n blank).bind (run m (t-n)) = some (embed z) at H
    cases he : run m n blank with
    | none => rw [he] at H; contradiction
    | some c => rfl

theorem safe (B : Nat) (d : Bool) (m : Machine) (hm : compatible (table d) m) : WeightedBound B m :=
  weighted_never B m (never d m hm)

#print axioms arbitrary
#print axioms never
#print axioms safe
end BB6.Agent44Counter28LD
