import Raw11Extra28LDJoin

set_option maxHeartbeats 0
namespace BB6.Agent44Extra28LDRefine
open BB6Coverage BB6.Agent13BlankDelay BB6.Agent47PhaseFrontier

def parent : PartialMachine := (fun s => match s.1.val,s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 0,true => some (some ⟨false,false,1⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨true,false,2⟩)
  | 2,false => some (some ⟨false,false,0⟩)
  | 2,true => some (some ⟨false,false,3⟩)
  | _,_ => none)

def pLC : PartialMachine := refine parent (3,true) (some ⟨false,false,2⟩)

def route (hLC : ∀ m, compatible pLC m → WeightedBound 64 m) : Route 64 :=
 BB6.Agent47PhaseFrontier.split 9 (3,true) 4 #[
(.closed (.side 10 3 false (-2))),
(.closed (.side 15 3 false (-1))),
(.closed (.side 10 3 false (-2))),
(.closed (.side 14 4 true (-2))),
(.closed (.side 4 6 false (0))),
(.closed (.side 1 12 false (2))),
(.closed (.side 4 6 false (0))),
.pending,
(.certified pLC hLC),
.pending,
.pending,
(.closed (.side 2 8 false (2))),
(.certified BB6.Agent44Extra28LD.parent BB6.Agent44Extra28LD.safe),
.pending,
.pending,
.pending,
.pending,
.pending,
.pending,
.pending]

-- Compute the actual residual list without imposing a decision procedure for function equality.
theorem exactCodes (hLC : ∀ m, compatible pLC m → WeightedBound 64 m) :
 (residuals 64 parent (route hLC)).map tableCode = [26318896598422296, 26318896599336248, 26318896599793224, 26318896601164152, 26318896601621128, 26318896602078104, 26318896602535080, 26318896602992056, 26318896603449032, 26318896603906008] := by
  rfl

theorem checked (hLC : ∀ m, compatible pLC m → WeightedBound 64 m) :
 check 64 parent (route hLC) = true := by rfl

theorem consume (hLC : ∀ m, compatible pLC m → WeightedBound 64 m)
    (B : Nat) (hB : 64 ≤ B)
    (hr : ∀ q ∈ residuals 64 parent (route hLC), ∀ m, compatible q m → WeightedBound B m) : Cover (WeightedBound B) parent :=
   .leaf _ (consumeAt 64 B hB parent (route hLC) (by decide) (checked hLC) hr)

#print axioms exactCodes
#print axioms checked
#print axioms consume
end BB6.Agent44Extra28LDRefine
