'use strict';
// Reproducible discovery. Run from the checked source directory, or supply
// BB6_Q0_AUTOMATA pointing to agent5's existing q0-open-automata.cjs.
const fs=require('node:fs'),path=require('node:path');
const {search}=require(process.env.BB6_Q0_AUTOMATA||path.join(__dirname,'../agent5-weighted-tnf-queue/q0-open-automata.cjs'));
const moves=Array.from({length:24},(_,i)=>`${i%4>>1}${i%2?'R':'L'}${String.fromCharCode(65+(i>>2))}`);
const parse=s=>s.replaceAll('_','').match(/.../g).map(t=>t==='---'?-1:moves.indexOf(t));
const fmt=p=>p.map(i=>i<0?'---':moves[i]).join('');
const bit=b=>b?'true':'false',arr=xs=>'#['+xs.join(',')+']',ls=xs=>'['+xs.join(',')+']',slot=i=>`(${i>>1},${bit(i%2)})`,move=i=>`⟨${bit(i%4>>1)},${bit(i%2)},${i>>2}⟩`;
const table=p=>'(fun s => match s.1.val,s.2 with\n'+p.map((m,i)=>m<0?'':`  | ${i>>1},${bit(i%2)} => some (some ${move(m)})\n`).join('')+'  | _,_ => none)';
function stack(s){return `⟨${arr(s.pop.map(es=>ls(es.map(([b,i])=>`(${bit(b)},${i})`))))},${arr(s.push.map(([a,b])=>`(${a},${b})`))}⟩`}
function trie(xs){if(!xs.length)return '.empty';if(xs.length===1&&xs[0]===0)return '.leaf';return `(.branch ${trie(xs.filter(x=>x%2===0).map(x=>x>>1))} ${trie(xs.filter(x=>x%2===1).map(x=>x>>1))})`}
function cert(c){let rows=Array.from({length:12},()=>[]),n=c.right.push.length;for(const [q,a,l,r] of c.rows)rows[2*q+a].push(l*n+r);return `⟨${stack(c.left)},${stack(c.right)},${arr(rows.map(xs=>trie(xs.sort((a,b)=>a-b))))}⟩`}
function classify(a,limit=512){let l=0n,r=0n,q=0,h=0;const hist=[];for(let t=0;t<=limit;t++){let s=2*q+Number(r&1n),m=a[s];if(m<0)return ['h',t,s];for(let e=t-1;e>=Math.max(0,t-256);e--){let z=hist[e];if(z.q!==q)continue;for(const d of [1,-1]){if(d*(h-z.h)<0)continue;if(d===1?z.r!==r:(z.l!==l||((z.r^r)&1n)!==0n))continue;let k=0;for(let j=e;j<t;j++)k=Math.max(k,d*(z.h-hist[j].h));if(k>=128)continue;let mask=(1n<<BigInt(k))-1n;if(((d===1?z.l^l:(z.r^r)>>1n)&mask)===0n)return ['s',e,t-e,d===1,z.h-d*k]}}if(t===limit)break;hist.push({q,l,r,h});let w=BigInt((m>>1)&1);q=m>>2;if(m&1){if(l>>127n)break;l=(l<<1n)|w;r>>=1n;h++;}else{if(r>>127n)break;r=((r>>1n)<<2n)|(w<<1n)|(l&1n);l>>=1n;h--;}}return ['u'];}
const parent=parse('1RB0LB_1RC1LC_0LA0LD_---0LD_------_------');
const stats={side:0,last:0,split:0,automata:0,counter:0,maxq:0};const leaves=[];
function go(a,f,holes){const c=classify(a);if(c[0]==='s'){stats.side++;return c}if(c[0]==='u'){let t=fmt(a);if(t==='1RB0LB1RC1LC0LA0LD0RE0LD1RF---1LC1RE'||t==='1RB0LB1RC1LC0LA0LD0RE0LD1RF---1LD1RE'){stats.counter++;leaves.push({table:t,method:'counter'});return ['c',t.endsWith('1LD1RE')]}let x=search(t);if(!x)throw Error('unclosed '+t);stats.automata++;leaves.push({table:t,method:[x.kind,x.k,x.mirror],sizes:[x.left.push.length,x.right.push.length,x.rows.length]});return ['a',cert(x)]}let [,n,s]=c;stats.maxq=Math.max(stats.maxq,n);if(holes===1){stats.last++;return ['l',n,s]}stats.split++;let kids=[];for(let m=0;m<4*Math.min(f+1,6);m++){let b=a.slice();b[s]=m;kids.push(go(b,Math.max(f,1+(m>>2)),holes-1))}return ['h',n,s,f,kids]}
const tree=go(parent,4,5),B=stats.maxq+6;
const count=t=>1+(t[0]==='h'?t[4].reduce((s,k)=>s+count(k),0):0);
if(count(tree)!==3357||B!==64||stats.automata!==5||stats.counter!==2)throw Error(JSON.stringify(stats));
const prefix='Raw11Extra28LD', ns='BB6.Agent44Extra28LD';
const open='set_option maxHeartbeats 0\nset_option maxRecDepth 100000\nnamespace '+ns+'\nopen BB6Coverage BB6.Agent13BlankDelay BB6.Agent47PhaseFrontier\nopen BB6.Agent5PhaseTree (statesCases split_safe)\n';
const base='import Raw11Counter28LD\n'+open+'def parent : PartialMachine := '+table(parent)+'\nend '+ns+'\n';
fs.writeFileSync(prefix+'Base.lean',base);
function emit(t){switch(t[0]){case 's':return `(.closed (.side ${t[1]} ${t[2]} ${bit(t[3])} (${t[4]})))`;case 'l':return `(.closed (.last ${t[1]} ${slot(t[2])}))`;case 'a':return `(.closed (.automata ${t[1]}))`;case 'c':return `(.certified (BB6.Agent44Counter28LD.table ${bit(t[1])}) (BB6.Agent44Counter28LD.safe ${B} ${bit(t[1])}))`;case 'h':return `(BB6.Agent47PhaseFrontier.split ${t[1]} ${slot(t[2])} ${t[3]} #[\n${t[4].map(emit).join(',\n')}])`;default:throw Error('bad tree')}}
function defChild(p,t,j,nm){return `def p_${nm} := refine ${p} ${slot(t[2])} (some ${move(j)})\n`}
function join(t,p,nm,kids){return `theorem safe${nm} : ∀ m, compatible ${p} m → WeightedBound ${B} m := by\n  apply split_safe ${B} ${p} ${t[1]} ${slot(t[2])} ${t[3]} (by decide) (by decide +kernel) (by decide) (by decide)\n  intro mv h\n  rcases mv with ⟨w,r,q⟩\n  have hcut : q.val ≤ ${t[3]} := by simpa using h\n  rcases statesCases q with hq|hq|hq|hq|hq|hq <;> subst q <;> cases w <;> cases r <;> first | ${kids.map(k=>'exact safe_'+k).join(' | ')} | omega\n`}
function prove(t,p,nm){if(count(t)<=49){return `def cert_${nm} : Route ${B} := ${emit(t)}\ntheorem checked_${nm} : BB6.Agent47PhaseFrontier.check ${B} ${p} cert_${nm} = true := by decide +kernel\ntheorem safe_${nm} : ∀ m, compatible ${p} m → WeightedBound ${B} m := by\n  apply consume ${B} ${p} cert_${nm} (by decide) checked_${nm}\n  intro q h\n  have he : residuals ${B} ${p} cert_${nm} = [] := rfl\n  simp [he] at h\n`}
let kids=t[4].map((_,j)=>nm+'_'+j);let out='';for(let j=0;j<kids.length;j++){out+=defChild(p,t,j,kids[j])+prove(t[4][j],'p_'+kids[j],kids[j])}return out+join(t,p,'_'+nm,kids)}
const groups=[];for(let i=0;i<tree[4].length;i+=4){let part='import '+prefix+'Base\n'+open;for(let j=i;j<Math.min(i+4,tree[4].length);j++){part+=defChild('parent',tree,j,''+j)+prove(tree[4][j],'p_'+j,''+j)}let name=prefix+'Part'+groups.length;fs.writeFileSync(name+'.lean',part+'end '+ns+'\n');groups.push(name)}
fs.writeFileSync(prefix+'Join.lean',groups.map(g=>'import '+g).join('\n')+'\n'+open+join(tree,'parent','',tree[4].map((_,j)=>''+j))+`theorem cover : Cover (WeightedBound ${B}) parent := .leaf _ safe\n#print axioms cover\nend ${ns}\n`);
fs.writeFileSync('manifest.json',JSON.stringify({parent:fmt(parent),nodes:count(tree),bound:B,stats,leaves,groups},null,2)+'\n');console.log({B,stats,groups});
