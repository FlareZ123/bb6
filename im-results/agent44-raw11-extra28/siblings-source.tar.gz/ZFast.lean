import PhaseTree
import SparseZipper
set_option maxHeartbeats 0
namespace BB6.Agent44ZFast
open BB6Coverage BB6Coverage.Agent50Zipper BB6Coverage.Agent50SideCycle

def start : Z := ⟨0,0,[],[]⟩
theorem start_embed : embed start = blank := by
  unfold embed start blank
  congr 1
  funext x
  simp [atCell]

def prefixEq (a b : List Bool) (n : Nat) : Bool :=
  (List.range n).all fun j => a.getD j false == b.getD j false

def padEq (a b : List Bool) : Bool := prefixEq a b (max a.length b.length)

theorem prefixEq_sound {a b n} (h : prefixEq a b n = true) (j : Nat) (hj : j < n) :
    a.getD j false = b.getD j false := by
  exact beq_iff_eq.mp (List.all_eq_true.mp h j (List.mem_range.mpr hj))

theorem getD_out (a : List Bool) (j : Nat) (h : a.length ≤ j) : a.getD j false = false := by
  induction a generalizing j with
  | nil => cases j <;> rfl
  | cons x a ih =>
    cases j with
    | zero => simp at h
    | succ j => exact ih j (by simpa using h)

theorem padEq_sound {a b} (h : padEq a b = true) (j : Nat) :
    a.getD j false = b.getD j false := by
  by_cases hj : j < max a.length b.length
  · exact prefixEq_sound h j hj
  · rw [getD_out a j (by omega),getD_out b j (by omega)]

def ztail (right : Bool) (boundary : Int) (c d : Z) : Bool :=
  decide (c.q = d.q) && decide (side right 0 (d.h-c.h)) &&
  (if right then
    decide (boundary ≤ c.h) && prefixEq c.l d.l ((c.h-boundary).toNat+1) && padEq c.r d.r
  else
    decide (c.h ≤ boundary) && padEq c.l d.l && prefixEq c.r d.r (boundary-c.h).toNat)

theorem ztail_sound (right : Bool) (boundary : Int) (c d : Z) (h : ztail right boundary c d = true) :
    side right 0 (d.h-c.h) ∧ TailRel right boundary (d.h-c.h) (embed c) (embed d) := by
  simp only [ztail, Bool.and_eq_true, decide_eq_true_eq] at h
  refine ⟨h.1.2, h.1.1, ?_, ?_⟩
  · change d.h = c.h+(d.h-c.h); omega
  · intro x hx
    change atCell d (x+(d.h-c.h)) = atCell c x
    have he : x+(d.h-c.h) ≤ d.h ↔ x ≤ c.h := by omega
    have hl : (d.h-(x+(d.h-c.h))).toNat = (c.h-x).toNat := by omega
    have hr : (x+(d.h-c.h)-d.h-1).toNat = (x-c.h-1).toNat := by omega
    simp only [atCell,he,hl,hr]
    cases right with
    | true =>
      have hh : (boundary ≤ c.h ∧ prefixEq c.l d.l ((c.h-boundary).toNat+1) = true) ∧ padEq c.r d.r = true := by simpa using h.2
      have hx' : boundary ≤ x := hx
      split
      · exact (prefixEq_sound hh.1.2 _ (by omega)).symm
      · exact (padEq_sound hh.2 _).symm
    | false =>
      have hh : (c.h ≤ boundary ∧ padEq c.l d.l = true) ∧ prefixEq c.r d.r (boundary-c.h).toNat = true := by simpa using h.2
      have hx' : x ≤ boundary := hx
      split
      · exact (padEq_sound hh.1.2 _).symm
      · exact (prefixEq_sound hh.2 _ (by omega)).symm

def zwindow (p : PartialMachine) (right : Bool) (boundary : Int) : Nat → Z → Option Z
  | 0,c => some c
  | n+1,c => (zwindow p right boundary n c).bind fun e =>
      if side right boundary e.h then step p e else none

theorem zwindow_sound (p : PartialMachine) (right : Bool) (boundary : Int)
    (n : Nat) (c d : Z) (h : zwindow p right boundary n c = some d) :
    zrun p n c = some d ∧ ∀ j < n, ∀ e, zrun p j c = some e → side right boundary e.h := by
  induction n generalizing d with
  | zero => exact ⟨h,fun j hj => by omega⟩
  | succ n ih =>
    cases he : zwindow p right boundary n c with
    | none => simp [zwindow,he] at h
    | some a =>
      have hh := ih a he
      by_cases hs : side right boundary a.h
      · have hstep : step p a = some d := by simpa [zwindow,he,hs] using h
        refine ⟨?_,?_⟩
        · rw [show n+1=n+1 by rfl,zrun_add,hh.1]; simpa [zrun] using hstep
        · intro j hj e hjrun
          by_cases hjn : j = n
          · subst j; rw [hh.1] at hjrun; have ha : a = e := Option.some.inj hjrun; simpa [← ha] using hs
          · exact hh.2 j (by omega) e hjrun
      · simp [zwindow,he,hs] at h

def zipSideCheck (p : PartialMachine) (entry period : Nat) (right : Bool) (boundary : Int) : Bool :=
  match zrun p entry start with
  | none => false
  | some c => match zwindow p right boundary period c with
    | none => false
    | some d => ztail right boundary c d

theorem zipSideCheck_sound (p : PartialMachine) (entry period : Nat) (right : Bool) (boundary : Int)
    (hn : 0 < period) (h : zipSideCheck p entry period right boundary = true) :
    ∀ m, compatible p m → NeverHalts m := by
  cases hc : zrun p entry start with
  | none => simp [zipSideCheck,hc] at h
  | some c =>
    cases hd : zwindow p right boundary period c with
    | none => simp [zipSideCheck,hc,hd] at h
    | some d =>
      have htail : ztail right boundary c d = true := by simpa [zipSideCheck,hc,hd] using h
      obtain ⟨hδ,hrel⟩ := ztail_sound right boundary c d htail
      obtain ⟨hloop,hwindow⟩ := zwindow_sound p right boundary period c d hd
      intro m hm
      have hstart := zrun_sound p m hm entry start c hc
      rw [start_embed] at hstart
      have hrun := zrun_sound p m hm period c d hloop
      apply sideCycle_never m right boundary (d.h-c.h) (embed c) (embed d) entry period hn hδ hstart ?_ hrun hrel
      intro j hj e he
      cases hf : zrun p j c with
      | none =>
        rw [show period=j+(period-j) by omega,zrun_add,hf] at hloop
        contradiction
      | some f =>
        have hsource := zrun_sound p m hm j c f hf
        have heq : e = embed f := Option.some.inj (he.symm.trans hsource)
        subst e
        exact hwindow j hj f hf

#print axioms zipSideCheck_sound
end BB6.Agent44ZFast
