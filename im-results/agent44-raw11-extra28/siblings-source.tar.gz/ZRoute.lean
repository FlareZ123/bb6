import ZTree
import PhaseFrontier
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace BB6.Agent44ZRoute
open BB6Coverage BB6.Agent13BlankDelay BB6.Agent1NGram BB6.Agent5PhaseTree BB6.Agent47PhaseFrontier
open BB6.Agent44ZTree (zipHoleOK zipHoleOK_sound)
def check (B : Nat) (p : PartialMachine) : Route B → Bool
  | .pending => true
  | .closed t => BB6.Agent44ZTree.check B p t
  | .certified q _ => sameTable p q
  | .split n s cut kids => zipHoleOK B p n s && decide (0 < cut) && supportOK p cut &&
      (choices cut).all fun mv => check B (refine p s (some mv)) (kids mv)

theorem consume (B : Nat) (p : PartialMachine) (t : Route B)
    (hf : p initialSlot = some (some ⟨true,true,1⟩)) (hc : check B p t = true)
    (hr : ∀ q ∈ residuals B p t, ∀ m, compatible q m → WeightedBound B m) :
    ∀ m, compatible p m → WeightedBound B m := by
  induction t generalizing p with
  | pending => exact hr p (by simp [residuals])
  | closed t => exact BB6.Agent44ZTree.sound B p t hf hc
  | certified q safe =>
    have he : p = q := sameTable_sound hc
    subst q
    exact safe
  | split n s cut kids ih =>
    simp only [check,Bool.and_eq_true,decide_eq_true_eq] at hc
    apply split_safe B p n s cut hf (zipHoleOK_sound hc.1.1.1) hc.1.1.2 hc.1.2
    intro mv hmv
    have hm := choice_mem cut mv hmv
    obtain ⟨c,_,_,hu,_⟩ := firstHoleOK_sound (zipHoleOK_sound hc.1.1.1)
    apply ih mv _ (refine_preserves_firstOne p s (some mv) hu hf) (List.all_eq_true.mp hc.2 mv hm)
    intro q hq
    exact hr q (List.mem_flatMap.mpr ⟨mv,hm,hq⟩)

#print axioms consume
end BB6.Agent44ZRoute
