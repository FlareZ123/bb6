import ZFast
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace BB6.Agent44ZTree
open BB6Coverage BB6.Agent13BlankDelay BB6.Agent5PhaseTree BB6Coverage.Agent50Zipper BB6.Agent44ZFast BB6.Agent1NGram

theorem step_known (p : PartialMachine) (z : Z) :
    (step p z).map embed = knownStep p (embed z) := by
  rw [knownStep,read_embed]
  unfold step
  cases hp : p (z.q,z.l.headD false) with
  | none => rfl
  | some t =>
    cases t with
    | none => rfl
    | some mv => simp [embed_move]

theorem run_known (p : PartialMachine) (n : Nat) :
    (zrun p n start).map embed = knownRun p n := by
  induction n with
  | zero => simp [zrun,knownRun,start_embed]
  | succ n ih =>
    rw [show n+1=n+1 by rfl,zrun_add]
    unfold knownRun
    cases h : zrun p n start with
    | none => rw [h] at ih; simp [← ih]
    | some z =>
      rw [h] at ih
      rw [← ih]
      simp only [Option.bind_some,Option.map_some]
      rw [← step_known]
      cases hs : step p z <;> simp [zrun,hs]

def zipHoleOK (B : Nat) (p : PartialMachine) (n : Nat) (s : Slot) : Bool :=
  (match zrun p n start with
    | none => false
    | some z => decide ((z.q,z.l.headD false) = s)) &&
  decide (p s = none) && decide (n+6 ≤ B)

theorem zipHoleOK_sound {B p n s} (h : zipHoleOK B p n s = true) : firstHoleOK B p n s = true := by
  simp only [zipHoleOK,Bool.and_eq_true,decide_eq_true_eq] at h
  cases hz : zrun p n start with
  | none => simp [hz] at h
  | some z =>
    have hh : (z.q,z.l.headD false) = s := by simpa [hz] using h.1.1
    have hk : knownRun p n = some (embed z) := by rw [← run_known,hz]; rfl
    simp only [firstHoleOK,hk,Option.map_some,read_embed,hh,decide_true,h.1.2,h.2,Bool.and_self]

def check (B : Nat) (p : PartialMachine) : Tree → Bool
  | .bad => false
  | .side e n r b => decide (0 < n) && zipSideCheck p e n r b
  | .automata c => BB6.Agent4Automata.check p c
  | .last n s => zipHoleOK B p n s && BB6.Agent50TNFPilot.restOK p s
  | .split n s cut kids => zipHoleOK B p n s && decide (0 < cut) && supportOK p cut &&
      (List.finRange 6).all (fun q => if q.val ≤ cut then bits.all (fun w => bits.all (fun r =>
        check B (refine p s (some ⟨w,r,q⟩)) (kids ⟨w,r,q⟩))) else true)

theorem sound (B : Nat) (p : PartialMachine) (t : Tree)
    (hf : p initialSlot = some (some ⟨true,true,1⟩)) (h : check B p t = true) :
    ∀ m, compatible p m → WeightedBound B m := by
  induction t generalizing p with
  | bad => simp [check] at h
  | side e n r b =>
    simp only [check,Bool.and_eq_true,decide_eq_true_eq] at h
    intro m hm
    exact weighted_never B m (zipSideCheck_sound p e n r b h.1 h.2 m hm)
  | automata c =>
    intro m hm
    exact weighted_never B m (BB6.Agent4Automata.never p c h m hm)
  | last n s =>
    simp only [check,Bool.and_eq_true] at h
    apply BB6.Agent5PhaseTree.sound B p (.last n s) hf
    simpa only [BB6.Agent5PhaseTree.check,Bool.and_eq_true] using And.intro (zipHoleOK_sound h.1) h.2
  | split n s cut kids ih =>
    simp only [check,Bool.and_eq_true,decide_eq_true_eq] at h
    have hhole := zipHoleOK_sound h.1.1.1
    apply split_safe B p n s cut hf hhole h.1.1.2 h.1.2
    intro mv hv
    obtain ⟨c,hr,hs,hu,hb⟩ := firstHoleOK_sound hhole
    apply ih mv _ (refine_preserves_firstOne p s (some mv) hu hf)
    rcases mv with ⟨w,r,q⟩
    have H := List.all_eq_true.mp h.2 q (List.mem_finRange q)
    simp only [hv,ite_true] at H
    exact List.all_eq_true.mp (List.all_eq_true.mp H w (mem_bits w)) r (mem_bits r)

#print axioms run_known
#print axioms sound
end BB6.Agent44ZTree
