#!/usr/bin/env bash
set -euo pipefail
LEAN=${LEAN:-lean}
for m in ZFast ZTree ZRoute; do
  if [ ! -f "$m.olean" ]; then "$LEAN" -o "$m.olean" "$m.lean"; fi
done
for id in "$@"; do
  prefix=Raw11Extra28M$id
  "$LEAN" -o "$prefix"Base.olean "$prefix"Base.lean
  for f in $(ls "$prefix"Part*.lean | sort -V); do
    "$LEAN" -o "${f%.lean}.olean" "$f"
  done
  "$LEAN" -o "$prefix"Join.olean "$prefix"Join.lean
 done
