#!/usr/bin/env bash
set -euo pipefail
export BB6_Q0_AUTOMATA=${BB6_Q0_AUTOMATA:-$PWD/q0-open-automata.cjs}
for id in "$@"; do
  if [ "$id" = 19 ]; then
    node generate-more.cjs "$id"
    sed -i '1i import ZRoute' Raw11Extra28M19Base.lean
    sed -i 's/BB6.Agent47PhaseFrontier.check/BB6.Agent44ZRoute.check/g;s/apply consume /apply BB6.Agent44ZRoute.consume /g' Raw11Extra28M19Part*.lean
  else
    node generate-direct.cjs "$id"
    if [ "$id" -ge 14 ]; then
      sed -i '1i import ZTree' Raw11Extra28M${id}Base.lean
      sed -i 's/BB6.Agent5PhaseTree.check/BB6.Agent44ZTree.check/g;s/BB6.Agent5PhaseTree.sound/BB6.Agent44ZTree.sound/g' Raw11Extra28M${id}Part*.lean
    fi
  fi
done
