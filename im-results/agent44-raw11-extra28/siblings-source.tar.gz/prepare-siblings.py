from pathlib import Path
s=Path('generate.cjs').read_text()
s=s.replace("const parent=parse('1RB0LB_1RC1LC_0LA0LD_---0LD_------_------');", "const id=Number(process.argv[2]); const parent=parse('1RB0LB_1RC1LC_0LA0LD_---'+moves[id]+'_------_------');")
s=s.replace("let x=search(t);", "if(t==='1RB0LB1RC1LC0LA0LD1LF1RE1RD---0RE0LF'){stats.counter++;return ['r']}let x=t==='1RB0LB1RC1LC0LA0LD1LF0RE1RD1RA---1LE'?JSON.parse(fs.readFileSync('periodic17.json')):search(t);")
s=s.replace('go(parent,4,5)','go(parent,Math.max(4,1+(id>>2)),5)')
s=s.replace("if(count(tree)!==3357||B!==64||stats.automata!==5||stats.counter!==2)throw Error(JSON.stringify(stats));",'')
s=s.replace("const prefix='Raw11Extra28LD', ns='BB6.Agent44Extra28LD';", "const prefix='Raw11Extra28M'+id, ns='BB6.Agent44Extra28M'+id;")
s=s.replace("import Raw11Counter28LD\\n", "import Raw11Counter28RE\\n")
s=s.replace("case 'h':return `(BB6.Agent47PhaseFrontier.split", "case 'r':return `(.certified BB6.Agent44Counter28RE.table (BB6.Agent44Counter28RE.safe ${B}))`;case 'h':return `(BB6.Agent47PhaseFrontier.split")
s=s.replace('for(let i=0;i<tree[4].length;i+=4)','for(let i=0;i<tree[4].length;i+=1)').replace('Math.min(i+4,tree[4].length)','Math.min(i+1,tree[4].length)')
s=s.replace("'manifest.json'","prefix+'Manifest.json'")
Path('generate-more.cjs').write_text(s)
s=s.replace("(.closed (.side ${t[1]} ${t[2]} ${bit(t[3])} (${t[4]})))", "(.side ${t[1]} ${t[2]} ${bit(t[3])} (${t[4]}))").replace('(.closed (.last ${t[1]} ${slot(t[2])}))','(.last ${t[1]} ${slot(t[2])})').replace('(.closed (.automata ${t[1]}))','(.automata ${t[1]})').replace('BB6.Agent47PhaseFrontier.split ${t[1]}','BB6.Agent5PhaseTree.split ${t[1]}')
s=s.replace('Route ${B}', 'BB6.Agent5PhaseTree.Tree').replace('BB6.Agent47PhaseFrontier.check ${B}', 'BB6.Agent5PhaseTree.check ${B}')
s=s.replace(':= by\\n  apply consume ${B} ${p} cert_${nm} (by decide) checked_${nm}\\n  intro q h\\n  have he : residuals ${B} ${p} cert_${nm} = [] := rfl\\n  simp [he] at h\\n',':= BB6.Agent5PhaseTree.sound ${B} ${p} cert_${nm} (by decide) checked_${nm}\\n')
Path('generate-direct.cjs').write_text(s)
# The reduced FAR implementation in ld-source.tar.gz is precisely the ordinary ngram/run code.
# Export its solve function; use the identical width-ten call used by periodic.cjs.
p=Path('q0-open-automata.cjs');s=p.read_text().replace('module.exports={search};','module.exports={search,solve};');Path('solve-width10.cjs').write_text(s)
