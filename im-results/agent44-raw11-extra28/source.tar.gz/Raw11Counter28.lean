import PhaseTree

set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent44Raw11Counter28
open BB6Coverage BB6Coverage.Agent31Pump BB6Coverage.Agent50Zipper BB6.Agent13BlankDelay

def table : PartialMachine := fun s => match s.1.val, s.2 with
  | 0, false => some (some ⟨true,true,1⟩)
  | 0, true => some (some ⟨false,false,1⟩)
  | 1, false => some (some ⟨true,true,2⟩)
  | 1, true => some (some ⟨true,false,2⟩)
  | 2, false => some (some ⟨false,false,0⟩)
  | 2, true => some (some ⟨false,false,3⟩)
  | 3, false => some (some ⟨false,true,4⟩)
  | 3, true => some (some ⟨false,false,2⟩)
  | 4, false => some (some ⟨true,true,5⟩)
  | 5, false => some (some ⟨true,false,2⟩)
  | 5, true => some (some ⟨true,true,4⟩)
  | _, _ => none

/-- Right-hand digits have a zero separator between adjacent bits. The
    finite representation may end immediately after the last bit. -/
inductive Paired : List Bool → Prop
  | nil : Paired []
  | single (b : Bool) : Paired [b]
  | cons (b : Bool) {r : List Bool} : Paired r → Paired (b :: false :: r)

def carry (k z : Nat) (r : List Bool) : Z0 :=
  ⟨4, false :: (rep [true,true] k ++ List.replicate z false), r⟩

def Good (c : Z0) : Prop := ∃ k z r, Paired r ∧ c = carry k z r

theorem zeroPairs (k : Nat) {r : List Bool} (hr : Paired r) :
    Paired (rep [false,false] k ++ r) := by
  induction k with
  | zero => simpa [rep] using hr
  | succ k ih => simpa [rep] using Paired.cons false ih

theorem setBit {r : List Bool} (hr : Paired r) : Paired (true :: r.tail) := by
  cases hr with
  | nil => exact Paired.single true
  | single b => exact Paired.single true
  | cons b h => exact Paired.cons true h

theorem nextBit {r : List Bool} (hr : Paired r) :
    r.tail.headD false = false ∧ Paired r.tail.tail := by
  cases hr with
  | nil => exact ⟨rfl, Paired.nil⟩
  | single b => exact ⟨rfl, Paired.nil⟩
  | cons b h => exact ⟨rfl,h⟩

theorem carry_one (k z : Nat) (r : List Bool) (hr : Paired r)
    (h : r.headD false = true) :
    run0 table 2 (carry k z r) = some (carry (k+1) z r.tail.tail) := by
  have hz := (nextBit hr).1
  cases r with
  | nil => contradiction
  | cons b r =>
    change b = true at h
    subst b
    change r.headD false = false at hz
    cases r with
    | nil => rfl
    | cons a r =>
      change a = false at hz
      subst a
      rfl

theorem erasePairs (k : Nat) (L R : List Bool) :
    run0 table (2*k) ⟨3, rep [true,true] k ++ L,R⟩ =
      some ⟨3,L,rep [false,false] k ++ R⟩ := by
  have one : ∀ L R : List Bool,
      run0 table 2 ⟨3, ([] : List Bool) ++ [true,true] ++ L, [] ++ R⟩ =
        some ⟨3, [] ++ L, [] ++ [false,false] ++ R⟩ := by intro L R; rfl
  simpa using sweepL table 3 [] [] [true,true] [false,false] 2 one k L R

theorem start_clear (k z : Nat) (r : List Bool) (h : r.headD false = false) :
    run0 table 3 (carry k z r) =
      some ⟨3,rep [true,true] k ++ List.replicate z false,false::true::r.tail⟩ := by
  cases r with
  | nil => rfl
  | cons b r =>
    change b = false at h
    subst b
    rfl

theorem zeros_comm (k : Nat) (r : List Bool) :
    rep [false,false] k ++ false :: r = false :: (rep [false,false] k ++ r) := by
  induction k with
  | zero => rfl
  | succ k ih => simp only [rep,List.cons_append,List.nil_append,List.cons.injEq,true_and]; exact ih

theorem finish_clear (k z : Nat) (r : List Bool) :
    run0 table 1 ⟨3,List.replicate z false,rep [false,false] k ++ false :: r⟩ =
      some (carry 0 (max 1 z) (rep [false,false] k ++ r)) := by
  rw [zeros_comm]
  cases z with
  | zero => rfl
  | succ z =>
    rw [Nat.max_eq_right (by omega : 1 ≤ z+1)]
    rfl

theorem clear_zero (k z : Nat) (r : List Bool) (h : r.headD false = false) :
    run0 table (3+2*k+1) (carry k z r) =
      some (carry 0 (max 1 z) (rep [false,false] k ++ true :: r.tail)) := by
  exact join0 (join0 (start_clear k z r h) (erasePairs k _ _)) (finish_clear k z _)

theorem first : run0 table 12 ⟨0,[],[]⟩ = some (carry 0 1 [false,false,false,false]) := by decide

theorem firstGood : Good (carry 0 1 [false,false,false,false]) :=
  ⟨0,1,_,Paired.cons false (Paired.cons false Paired.nil),rfl⟩

theorem advance (c : Z0) (hc : Good c) : ∃ d n, 0 < n ∧ Good d ∧ run0 table n c = some d := by
  obtain ⟨k,z,r,hr,rfl⟩ := hc
  cases h : r.headD false with
  | false => exact ⟨_,_,by omega,⟨0,max 1 z,_,zeroPairs k (setBit hr),rfl⟩,clear_zero k z r h⟩
  | true => exact ⟨_,2,by decide,⟨k+1,z,_,(nextBit hr).2,rfl⟩,carry_one k z r hr h⟩

theorem arbitrarilyLong (n : Nat) : ∃ t c, n ≤ t ∧ Good c ∧ run0 table t ⟨0,[],[]⟩ = some c := by
  induction n with
  | zero => exact ⟨12,_,by decide,firstGood,first⟩
  | succ n ih =>
    obtain ⟨t,c,ht,hc,hr⟩ := ih
    obtain ⟨d,k,hk,hd,hs⟩ := advance c hc
    exact ⟨t+k,d,by omega,hd,join0 hr hs⟩

theorem never (m : Machine) (hm : compatible table m) : NeverHalts m := by
  intro n
  obtain ⟨t,c,ht,_,hr⟩ := arbitrarilyLong n
  have hz : (zrun table t start).map project = some c :=
    (run_project table t start).trans hr
  cases h : zrun table t start with
  | none => simp [h] at hz
  | some z =>
    have H := zrun_sound table m hm t start z h
    rw [start_embed] at H
    rw [show t=n+(t-n) by omega,run_append] at H
    change (run m n blank).bind (run m (t-n)) = some (embed z) at H
    cases he : run m n blank with
    | none => rw [he] at H; contradiction
    | some _ => rfl

theorem safe (B : Nat) : ∀ m, compatible table m → WeightedBound B m := by
  intro m hm
  exact weighted_never B m (never m hm)

theorem cover (B : Nat) : Cover (WeightedBound B) table := .leaf _ (safe B)

#print axioms never
#print axioms cover

end BB6.Agent44Raw11Counter28
