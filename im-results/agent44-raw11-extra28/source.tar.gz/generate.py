from dataclasses import dataclass
from pathlib import Path
import subprocess, sys

ROOT='1RB0LB_1RC1LC_0LA0LD_---0LC_------_------'
SYMBOLIC='1RB0LB_1RC1LC_0LA0LD_0RE0LC_1RF---_1LC1RE'
DFA=[[1,2],[1,2],[3,4],[5,2],[3,2],[3,2]]
MOVES=[w+d+q for q in 'ABCDEF' for w in '01' for d in 'LR']

def parse(t):
    t=t.replace('_',''); return [t[i:i+3] for i in range(0,36,3)]
def fmt(a): return '_'.join(''.join(a[i:i+2]) for i in range(0,12,2))
def bit(b):return 'true' if b else 'false'
def slot(s):return f'({s//2},{bit(s%2)})'
def move(a):return f'⟨{bit(a[0]=="1")},{bit(a[1]=="R")},{ord(a[2])-65}⟩'
def table(a):return '(fun s => match s.1.val,s.2 with\n'+''.join(f'  | {i//2},{bit(i%2)} => some (some {move(x)})\n' for i,x in enumerate(a) if x!='---')+'  | _,_ => none)'
def arr(xs):return '#['+','.join(xs)+']'
def pair(a,b):return f'({a},{b})'

def mitm(a,dl,dr):
    ds=[dl,dr]; E=[[set() for _ in d] for d in ds]; W=[[[] for _ in d] for d in ds]; rows=[]; seen=set()
    def add(row):
        if row not in seen:seen.add(row);rows.append(row)
    def pop(st,e):
        q,b,l,r,n,d,w=st; x,bit0=divmod(e,2)
        add((n,bit0,dl[l][w],x) if d else (n,bit0,x,dr[r][w]))
    E[0][0].add(0); E[1][0].add(0); add((0,0,0,0))
    for q,b,l,r in rows:
        m=a[2*q+b]
        if m=='---':return None
        w=int(m[0]);d=int(m[1]=='R');n=ord(m[2])-65;st=(q,b,l,r,n,d,w)
        old=l if d else r;edge=2*old+w;dest=ds[1-d][old][w]
        if edge not in E[1-d][dest]:
            E[1-d][dest].add(edge)
            for waiter in W[1-d][dest]:pop(waiter,edge)
        target=r if d else l;W[d][target].append(st)
        for e in E[d][target]:pop(st,e)
    def trie(s):
        if not s:return '.empty'
        if s=={0}:return '.leaf'
        return '(.branch '+trie({x//2 for x in s if x%2==0})+' '+trie({x//2 for x in s if x%2==1})+')'
    def stack(d):
        edges=arr('['+','.join(pair(bit(e%2),e//2) for e in sorted(es))+']' for es in E[d])
        pushes=arr(pair(*p) for p in ds[d]);return f'⟨{edges},{pushes}⟩'
    ts=[set() for _ in range(12)]
    for q,b,l,r in rows:ts[2*q+b].add(r+len(dr)*l)
    return f'⟨{stack(0)},{stack(1)},{arr(trie(s) for s in ts)}⟩'

def head(a,n):
    q=h=0;ones=set()
    for _ in range(n):
        m=a[2*q+int(h in ones)]; assert m!='---'
        if m[0]=='1':ones.add(h)
        else:ones.discard(h)
        h+=1 if m[1]=='R' else -1;q=ord(m[2])-65
    return h

@dataclass
class Node:
    kind: str
    a: list
    args: list
    kids: list
    size: int
    symbolic: bool

def read_tree(path):
    lines=iter(Path(path).read_text().splitlines())
    def go(expected):
        k,t,*xs=next(lines).split(); a=parse(t); assert a==expected
        xs=list(map(int,xs)); kids=[]
        if k=='s':
            _,s,f=xs
            for m in MOVES[:4*min(6,f+1)]:
                c=a.copy();c[s]=m;kids.append(go(c))
        symbolic=(k=='u' and t==SYMBOLIC)
        return Node(k,a,xs,kids,1+sum(c.size for c in kids),symbolic or any(c.symbolic for c in kids))
    tree=go(parse(ROOT));assert next(lines,None) is None;return tree

def generate(tree):
    out=['import PhaseFrontier','import Raw11Counter28','set_option maxHeartbeats 0','set_option maxRecDepth 100000','namespace BB6.Agent44Extra28D1LC','open BB6Coverage BB6.Agent13BlankDelay BB6.Agent5PhaseTree BB6.Agent47PhaseFrontier','def bound : Nat := 42','def totalCert (f : Nat) : BB6.Agent4Automata.Cert := ⟨⟨#[[(false,0),(true,0)]],#[(0,0)]⟩,⟨#[[(false,0),(true,0)]],#[(0,0)]⟩,Array.replicate (2*f) .leaf⟩','def parent : PartialMachine := '+table(tree.a)]
    def emit(t):
        x=t.args
        if t.kind=='c':
            e,n,d,k=x;return f'(.side {e} {n} {bit(d==1)} ({head(t.a,e)-d*k}))'
        if t.kind=='t':return f'(.automata (totalCert {x[0]}))'
        if t.kind=='l':return f'(.last {x[0]} {slot(x[1])})'
        if t.kind=='u':
            c=mitm(t.a,DFA,DFA);assert c is not None,fmt(t.a);return '(.automata '+c+')'
        n,s,f=x;return f'(BB6.Agent5PhaseTree.split {n} {slot(s)} {f} #[\n'+',\n'.join(map(emit,t.kids))+'])'
    def prove(t,p,suffix):
        safe='safe'+suffix
        if t.kind=='u' and t.symbolic:
            out.append(f'theorem {safe} : ∀ m, compatible {p} m → WeightedBound bound m := by\n  have h : sameTable {p} BB6.Agent44Raw11Counter28.table = true := by decide +kernel\n  rw [sameTable_sound h]\n  exact BB6.Agent44Raw11Counter28.safe bound');return
        if t.size<=49 and not t.symbolic:
            out.extend([f'def cert{suffix} : Tree := '+emit(t),f'theorem checked{suffix} : BB6.Agent5PhaseTree.check bound {p} cert{suffix} = true := by decide +kernel',f'theorem {safe} : ∀ m, compatible {p} m → WeightedBound bound m := BB6.Agent5PhaseTree.sound bound {p} cert{suffix} (by decide) checked{suffix}']);return
        n,s,f=t.args
        for j,k in enumerate(t.kids):
            suf=suffix+'_'+str(j);kp='p'+suf
            out.append(f'def {kp} : PartialMachine := refine {p} {slot(s)} (some {move(MOVES[j])})');prove(k,kp,suf)
        out.append(f'theorem {safe} : ∀ m, compatible {p} m → WeightedBound bound m := by\n  apply split_safe bound {p} {n} {slot(s)} {f} (by decide) (by decide +kernel) (by decide) (by decide)\n  intro mv h\n  rcases mv with ⟨w,r,q⟩\n  rcases statesCases q with hq|hq|hq|hq|hq|hq <;> subst q <;> cases w <;> cases r <;> first | '+' | '.join('exact safe'+suffix+'_'+str(j) for j in range(len(t.kids)))+' | omega')
    prove(tree,'parent','')
    out.extend(['theorem cover : Cover (WeightedBound bound) parent := .leaf _ safe','#print axioms cover','end BB6.Agent44Extra28D1LC'])
    return '\n\n'.join(out)+'\n'

if __name__=='__main__':
    base=Path(__file__).resolve().parent
    if len(sys.argv)==1:
        subprocess.run(['g++','-std=c++17','-O3',str(base/'scan.cpp'),'-o',str(base/'scan')],check=True)
        subprocess.run([str(base/'scan'),'100000','256',str(base/'r28d1-0LC.tree')],input=ROOT+'\n',text=True,check=True)
    t=read_tree(base/'r28d1-0LC.tree'); assert t.size==3309 and t.symbolic
    (base/'Raw11Extra28D1LC.lean').write_text(generate(t))
