#include <array>
#include <vector>
#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
#include <cstdint>
using namespace std;
using U=__uint128_t;
using T=array<int,12>;
struct C{U l,r;int q,h;};
struct Result{char kind;int n=0,s=0,d=0,e=0,k=0;};
string fmt(T p){string out;for(int i=0;i<12;i++){if(i&&!(i%2))out+='_';int a=p[i];if(a<0)out+="---";else {out+=char('0'+((a>>1)&1));out+=(a&1)?'R':'L';out+=char('A'+(a>>2));}}return out;}
T parse(string x){x.erase(remove(x.begin(),x.end(),'_'),x.end());T p;for(int i=0;i<12;i++){int j=i*3;p[i]=x[j]=='-'?-1:4*(x[j+2]-'A')+2*(x[j]-'0')+(x[j+1]=='R');}return p;}
Result classify(const T& p,int limit){C c={0,0,0,0};vector<C> trace;trace.reserve(limit+1);for(int n=0;n<=limit;n++){int s=2*c.q+(int)(c.r&1),a=p[s];if(a<0)return {'h',n,s};int mn=c.h,mx=c.h;for(int i=n-1;i>=0;i--){auto x=trace[i];mn=min(mn,x.h);mx=max(mx,x.h);if(x.q!=c.q)continue;if(x.l==c.l&&x.r==c.r)return {'c',n,s,c.h>=x.h?1:-1,i,c.h>=x.h?x.h-mn:mx-x.h};if(c.h>=x.h&&x.r==c.r){int k=x.h-mn;if(k<=127&&((x.l^c.l)&((U(1)<<k)-1))==0)return {'c',n,s,1,i,k};}if(c.h<=x.h&&x.l==c.l&&((x.r^c.r)&1)==0){int k=mx-x.h;if(k<=127&&(((x.r^c.r)>>1)&((U(1)<<k)-1))==0)return {'c',n,s,-1,i,k};}}if(n==limit)break;trace.push_back(c);U w=(a>>1)&1;c.q=a>>2;if(a&1){if(c.l>>127)return {'u',n,s};c.l=(c.l<<1)|w;c.r>>=1;c.h++;}else{if(c.r>>127)return {'u',n,s};c.r=((c.r>>1)<<2)|(w<<1)|(c.l&1);c.l>>=1;c.h--;}}return {'u',limit};}
struct Stats{long long nodes=0,cyc=0,last=0,split=0,open=0,total=0;int maxq=0;};
long long cap;int limit; vector<string> open;ofstream cert;
bool visit(T p,int f,int holes,Stats& s){if(++s.nodes>cap)return false;bool total=true;for(int i=0;i<2*f;i++)if(p[i]<0||(p[i]>>2)>=f){total=false;break;}if(total){s.total++;if(cert)cert<<"t "<<fmt(p)<<' '<<f<<'\n';return true;}auto c=classify(p,limit);if(c.kind=='c'){s.cyc++;if(cert)cert<<"c "<<fmt(p)<<' '<<c.e<<' '<<c.n-c.e<<' '<<c.d<<' '<<c.k<<'\n';return true;}if(c.kind=='u'){s.open++;if(open.size()<1000)open.push_back(fmt(p));if(cert)cert<<"u "<<fmt(p)<<'\n';return true;}s.maxq=max(s.maxq,c.n);if(holes==1){s.last++;if(cert)cert<<"l "<<fmt(p)<<' '<<c.n<<' '<<c.s<<'\n';return true;}s.split++;if(cert)cert<<"s "<<fmt(p)<<' '<<c.n<<' '<<c.s<<' '<<f<<'\n';for(int a=0;a<4*min(6,f+1);a++){p[c.s]=a;if(!visit(p,max(f,(a>>2)+1),holes-1,s))return false;}return true;}
int main(int argc,char**argv){cap=argc>1?stoll(argv[1]):100000;limit=argc>2?stoi(argv[2]):128;string t;while(cin>>t){auto p=parse(t);int f=0,h=0;for(auto a:p){if(a<0)h++;else f=max(f,(a>>2)+1);}Stats s;open.clear();if(argc>3)cert.open(argv[3]);bool complete=visit(p,f,h,s);if(cert.is_open())cert.close();cout<<t<<" "<<complete<<" "<<s.nodes<<" "<<s.cyc<<" "<<s.last<<" "<<s.split<<" "<<s.total<<" "<<s.open<<" "<<s.maxq+6<<endl;for(auto& o:open)cout<<"OPEN "<<o<<endl;}}
