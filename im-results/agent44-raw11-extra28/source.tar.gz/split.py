from pathlib import Path
s=Path('Raw11Extra28D1LC.lean').read_text();ns='BB6.Agent44Extra28D1LC';prefix=s[:s.index('def p_0 :')];header='import Raw11Extra28D1LCBase\nset_option maxHeartbeats 0\nset_option maxRecDepth 100000\nnamespace '+ns+'\nopen BB6Coverage BB6.Agent13BlankDelay BB6.Agent5PhaseTree BB6.Agent47PhaseFrontier\n';end='\nend '+ns+'\n';Path('Raw11Extra28D1LCBase.lean').write_text(prefix+end)
starts=[s.index(f'def p_{i} :') for i in range(20)]+[s.index('theorem safe :')];groups=[(0,16),(16,17),(17,18),(18,19),(19,20)]
for j,(a,b) in enumerate(groups):Path(f'Raw11Extra28D1LCPart{j}.lean').write_text(header+s[starts[a]:starts[b]]+end)
Path('Raw11Extra28D1LCJoin.lean').write_text(''.join(f'import Raw11Extra28D1LCPart{j}\n' for j in range(len(groups)))+header.split('\n',1)[1]+s[starts[-1]:].replace(" | omega\n", " | (change 5 ≤ 4 at h; omega)\n"))
