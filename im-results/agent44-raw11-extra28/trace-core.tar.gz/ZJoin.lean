import ZRoute
set_option maxHeartbeats 0
namespace BB6.Agent44ZJoin
open BB6Coverage BB6.Agent13BlankDelay BB6.Agent5PhaseTree BB6.Agent47PhaseFrontier
open BB6.Agent44ZTree (zipHoleOK zipHoleOK_sound)

/-- A proof record is indexed by the exact parent and the first queried slot. -/
structure Child (B : Nat) (p : PartialMachine) (s : Slot) where
  mv : Move
  safe : ∀ m, compatible (refine p s (some mv)) m → WeightedBound B m

/-- The kernel checks the exact finite successor roster. No 24-way tactic
    search or trusted array lookup is required for joining proved children. -/
theorem join (B : Nat) (p : PartialMachine) (n : Nat) (s : Slot) (cut : Nat)
    (hf : p initialSlot = some (some ⟨true,true,1⟩))
    (hh : zipHoleOK B p n s = true) (hc : 0 < cut) (hs : supportOK p cut = true)
    (children : List (Child B p s))
    (hcover : (choices cut).all (fun mv => children.any (fun c => decide (c.mv = mv))) = true) :
    ∀ m, compatible p m → WeightedBound B m := by
  apply split_safe B p n s cut hf (zipHoleOK_sound hh) hc hs
  intro mv hv
  have hmem := choice_mem cut mv hv
  have hex := List.all_eq_true.mp hcover mv hmem
  obtain ⟨c,_,he⟩ := List.any_eq_true.mp hex
  have hmv : c.mv = mv := of_decide_eq_true he
  simpa only [hmv] using c.safe

/-- Build a child proof from an independently defined literal table. -/
def childOf (B : Nat) (p : PartialMachine) (s : Slot) (mv : Move)
    (q : PartialMachine) (h : sameTable (refine p s (some mv)) q = true)
    (safe : ∀ m, compatible q m → WeightedBound B m) : Child B p s :=
  ⟨mv, fun m hm => safe m (sameTable_sound h ▸ hm)⟩

#print axioms join
#print axioms childOf
end BB6.Agent44ZJoin
