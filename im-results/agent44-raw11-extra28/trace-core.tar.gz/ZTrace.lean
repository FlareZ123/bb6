import ZJoin
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace BB6.Agent44ZTrace
open BB6Coverage BB6.Agent13BlankDelay BB6.Agent5PhaseTree BB6.Agent47PhaseFrontier
open BB6Coverage.Agent50Zipper BB6Coverage.Agent50SideCycle BB6.Agent44ZFast
open BB6.Agent44ZTree (run_known)

/-- Reversed persistent history. A child shares its parent's entire known run. -/
structure Trace where
  time : Nat
  rev : List Z

def initial : Trace := ⟨0,[start]⟩
def Trace.at (t : Trace) (j : Nat) : Z := t.rev.getD (t.time-j) start
def Trace.cur (t : Trace) : Z := t.rev.headD start
def Trace.push (t : Trace) (z : Z) : Trace := ⟨t.time+1,z::t.rev⟩

def Good (p : PartialMachine) (t : Trace) : Prop :=
  ∀ j ≤ t.time, zrun p j start = some (t.at j)

theorem initial_good (p : PartialMachine) : Good p initial := by
  intro j hj
  have he : j = 0 := by change j ≤ 0 at hj; omega
  subst j; rfl

theorem at_cur (t : Trace) : t.at t.time = t.cur := by
  unfold Trace.at Trace.cur
  rw [Nat.sub_self]
  cases t.rev <;> rfl

theorem at_push_old (t : Trace) (z : Z) (j : Nat) (h : j ≤ t.time) :
    (t.push z).at j = t.at j := by
  simp only [Trace.push,Trace.at]
  rw [show t.time+1-j = (t.time-j)+1 by omega]
  rfl

theorem at_push_new (t : Trace) (z : Z) : (t.push z).at (t.time+1) = z := by
  simp [Trace.push,Trace.at]

theorem push_good (p : PartialMachine) (t : Trace) (z : Z)
    (h : Good p t) (hs : step p t.cur = some z) : Good p (t.push z) := by
  intro j hj
  change j ≤ t.time+1 at hj
  by_cases hle : j ≤ t.time
  · rw [at_push_old t z j hle]; exact h j hle
  · have hj' : j = t.time+1 := by omega
    subst j
    rw [at_push_new,zrun_add,h t.time (Nat.le_refl _),at_cur]
    simpa [zrun] using hs

def extend (p : PartialMachine) : Nat → Trace → Option Trace
  | 0,t => some t
  | n+1,t => (step p t.cur).bind fun z => extend p n (t.push z)

theorem extend_good (p : PartialMachine) (n : Nat) (t u : Trace)
    (hg : Good p t) (h : extend p n t = some u) : Good p u ∧ u.time = t.time+n := by
  induction n generalizing t with
  | zero => have he : t = u := Option.some.inj h; subst u; exact ⟨hg, by simp⟩
  | succ n ih =>
    cases hs : step p t.cur with
    | none => simp [extend,hs] at h
    | some z =>
      have he : extend p n (t.push z) = some u := by simpa [extend,hs] using h
      obtain ⟨hg',ht⟩ := ih (t.push z) (push_good p t z hg hs) he
      exact ⟨hg',by simp only [Trace.push] at ht; omega⟩

def advance (p : PartialMachine) (n : Nat) (t : Trace) : Option Trace :=
  if t.time ≤ n then extend p (n-t.time) t else none

theorem advance_good (p : PartialMachine) (n : Nat) (t u : Trace)
    (hg : Good p t) (h : advance p n t = some u) : Good p u ∧ u.time = n := by
  by_cases hn : t.time ≤ n
  · have he : extend p (n-t.time) t = some u := by simpa [advance,hn] using h
    obtain ⟨hg',ht⟩ := extend_good p (n-t.time) t u hg he
    exact ⟨hg',by omega⟩
  · simp [advance,hn] at h

theorem step_refine (p : PartialMachine) (s : Slot) (v : Move) (c d : Z)
    (hu : p s = none) (h : step p c = some d) : step (refine p s (some v)) c = some d := by
  by_cases he : (c.q,c.l.headD false) = s
  · unfold step at h
    rw [he,hu] at h
    contradiction
  · unfold step
    rw [refine,if_neg he]
    exact h

theorem run_refine (p : PartialMachine) (s : Slot) (v : Move) (n : Nat) (c d : Z)
    (hu : p s = none) (h : zrun p n c = some d) : zrun (refine p s (some v)) n c = some d := by
  induction n generalizing c with
  | zero => exact h
  | succ n ih =>
    cases hs : step p c with
    | none => simp [zrun,hs] at h
    | some e =>
      have he : zrun p n e = some d := by simpa [zrun,hs] using h
      have hr := step_refine p s v c e hu hs
      simpa [zrun,hr] using ih e he

theorem refine_good (p : PartialMachine) (s : Slot) (v : Move) (t : Trace)
    (hg : Good p t) (hu : p s = none) : Good (refine p s (some v)) t :=
  fun j hj => run_refine p s v j start (t.at j) hu (hg j hj)

def holeOK (B : Nat) (p : PartialMachine) (t : Trace) (s : Slot) : Bool :=
  decide ((t.cur.q,t.cur.l.headD false) = s) && decide (p s = none) && decide (t.time+6 ≤ B)

theorem holeOK_sound (B : Nat) (p : PartialMachine) (t : Trace) (s : Slot)
    (hg : Good p t) (h : holeOK B p t s = true) : firstHoleOK B p t.time s = true := by
  have hz := hg t.time (Nat.le_refl _)
  rw [at_cur] at hz
  have hh : BB6.Agent44ZTree.zipHoleOK B p t.time s = true := by
    simpa [BB6.Agent44ZTree.zipHoleOK,hz,holeOK] using h
  exact BB6.Agent44ZTree.zipHoleOK_sound hh

/-- Entry and every consulted head are recovered from the shared run prefix.
    No separate simulation of the recurrence window is needed. -/
def windowOK (t : Trace) (e n : Nat) (right : Bool) (boundary : Int) : Bool :=
  (List.range n).all fun j => decide (side right boundary (t.at (e+j)).h)

def sideOK (t : Trace) (e n : Nat) (right : Bool) (boundary : Int) : Bool :=
  decide (0 < n) && ztail right boundary (t.at e) t.cur && windowOK t e n right boundary

theorem sideOK_sound (p : PartialMachine) (t : Trace) (e n : Nat) (right : Bool) (boundary : Int)
    (hg : Good p t) (ht : t.time = e+n) (h : sideOK t e n right boundary = true) :
    ∀ m, compatible p m → NeverHalts m := by
  simp only [sideOK,Bool.and_eq_true,decide_eq_true_eq] at h
  have he := hg e (by omega)
  have hn := hg (e+n) (by omega)
  have hend : t.at (e+n) = t.cur := by rw [← ht,at_cur]
  rw [hend] at hn
  obtain ⟨hd,hrel⟩ := ztail_sound right boundary (t.at e) t.cur h.1.2
  intro m hm
  have hr0 := zrun_sound p m hm e start (t.at e) he
  have hr1 := zrun_sound p m hm (e+n) start t.cur hn
  rw [start_embed] at hr0 hr1
  rw [run_append,hr0] at hr1
  apply sideCycle_never m right boundary (t.cur.h-(t.at e).h) (embed (t.at e)) (embed t.cur) e n h.1.1 hd hr0 ?_ hr1 hrel
  intro j hj c hc
  have hjr := hg (e+j) (by omega)
  have hraw := zrun_sound p m hm (e+j) start (t.at (e+j)) hjr
  rw [start_embed,run_append,hr0] at hraw
  have hraw' : run m j (embed (t.at e)) = some (embed (t.at (e+j))) := hraw
  have heq : c = embed (t.at (e+j)) := Option.some.inj (hc.symm.trans hraw')
  subst c
  exact of_decide_eq_true (List.all_eq_true.mp h.2 j (List.mem_range.mpr hj))

def check (B : Nat) (p : PartialMachine) (t : Trace) : Tree → Bool
  | .bad => false
  | .side e n r b => match advance p (e+n) t with
      | none => false
      | some u => sideOK u e n r b
  | .automata c => BB6.Agent4Automata.check p c
  | .last n s => match advance p n t with
      | none => false
      | some u => holeOK B p u s && BB6.Agent50TNFPilot.restOK p s
  | .split n s cut kids => match advance p n t with
      | none => false
      | some u => holeOK B p u s && decide (0 < cut) && supportOK p cut &&
        (choices cut).all fun mv => check B (refine p s (some mv)) u (kids mv)

theorem soundFrom (B : Nat) (p : PartialMachine) (t : Trace) (c : Tree)
    (hf : p initialSlot = some (some ⟨true,true,1⟩)) (hg : Good p t)
    (h : check B p t c = true) : ∀ m, compatible p m → WeightedBound B m := by
  induction c generalizing p t with
  | bad => simp [check] at h
  | side e n r b =>
    cases ha : advance p (e+n) t with
    | none => simp [check,ha] at h
    | some u =>
      obtain ⟨hu,ht⟩ := advance_good p (e+n) t u hg ha
      have hs : sideOK u e n r b = true := by simpa [check,ha] using h
      intro m hm
      exact weighted_never B m (sideOK_sound p u e n r b hu ht hs m hm)
  | automata c =>
    intro m hm
    exact weighted_never B m (BB6.Agent4Automata.never p c h m hm)
  | last n s =>
    cases ha : advance p n t with
    | none => simp [check,ha] at h
    | some u =>
      obtain ⟨hu,ht⟩ := advance_good p n t u hg ha
      simp only [check,ha,Bool.and_eq_true] at h
      have hh := holeOK_sound B p u s hu h.1
      rw [ht] at hh
      apply BB6.Agent5PhaseTree.sound B p (.last n s) hf
      simpa only [BB6.Agent5PhaseTree.check,Bool.and_eq_true] using And.intro hh h.2
  | split n s cut kids ih =>
    cases ha : advance p n t with
    | none => simp [check,ha] at h
    | some u =>
      obtain ⟨hu,ht⟩ := advance_good p n t u hg ha
      simp only [check,ha,Bool.and_eq_true,decide_eq_true_eq] at h
      have hh := holeOK_sound B p u s hu h.1.1.1
      rw [ht] at hh
      apply split_safe B p n s cut hf hh h.1.1.2 h.1.2
      intro mv hv
      have hm := choice_mem cut mv hv
      obtain ⟨z,_,_,hs,_⟩ := firstHoleOK_sound hh
      apply ih mv _ u (refine_preserves_firstOne p s (some mv) hs hf) (refine_good p s mv u hu hs)
      exact List.all_eq_true.mp h.2 mv hm

theorem sound (B : Nat) (p : PartialMachine) (c : Tree)
    (hf : p initialSlot = some (some ⟨true,true,1⟩)) (h : check B p initial c = true) :
    ∀ m, compatible p m → WeightedBound B m := soundFrom B p initial c hf (initial_good p) h

#print axioms sound
end BB6.Agent44ZTrace
