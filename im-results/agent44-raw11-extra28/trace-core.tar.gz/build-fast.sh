#!/bin/bash
set -euo pipefail
cd /tmp/raw11
export PATH=/tmp/lean/lean-4.36.0-rc2-linux/bin:$PATH
export LEAN_PATH=.:a47-raw11-root52
id=$1
pre=FastRaw11M$id
mkdir -p logs
for f in $(node -e 'let m=require("./"+process.argv[1]+"Manifest.json");console.log(m.build.flatMap(b=>[...b.parts,b.join]).concat(process.argv[1]+"Join").join("\n"))' "$pre"); do
  if [ -f "$f.olean" ]; then continue; fi
  echo "$(date -u +%T) $f" >> logs/$pre.progress
  /usr/bin/time -f '%e sec %M KB' lean -o "$f.olean" "$f.lean" > logs/$f.log 2>&1 || { tail -30 logs/$f.log >&2; exit 1; }
done
