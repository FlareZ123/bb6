'use strict';
const fs=require('node:fs'),path=require('node:path');
const {search}=require(process.env.BB6_Q0_AUTOMATA||'./q0-open-automata.cjs');
const src=fs.readFileSync(path.join(__dirname,'generate.cjs'),'utf8');
const helpers=src.slice(src.indexOf('const moves='),src.indexOf('const parent='));
const {moves,parse,fmt,bit,arr,ls,slot,move,table,cert,classify}=new Function(helpers+'\nreturn {moves,parse,fmt,bit,arr,ls,slot,move,table,cert,classify}')();
const nExpected={7:4893,9:4965,10:4893,13:6861,14:6981,15:9957,16:31249,17:22561,18:38545,19:33073};
const bExpected={7:72,9:84,10:101,13:79,14:96,15:119,16:81,17:150,18:141,19:158};
const counter='1RB0LB1RC1LC0LA0LD1LF1RE1RD---0RE0LF', hard='1RB0LB1RC1LC0LA0LD1LF0RE1RD1RA---1LE';
const cap=Number(process.env.TREE_CAP||193),shardCap=Number(process.env.SHARD_CAP||600);
for(const id of process.argv.slice(2).map(Number)){
 const parent=parse('1RB0LB_1RC1LC_0LA0LD_---'+moves[id]+'_------_------'),B=bExpected[id],prefix='FastRaw11M'+id,ns='BB6.Agent44FastM'+id;
 let stats={side:0,last:0,split:0,auto:0,counter:0,maxq:0};
 function go(a,f,holes){let c=classify(a);if(c[0]==='s'){stats.side++;return {c,n:1,a}}if(c[0]==='u'){let t=fmt(a);if(t===counter){stats.counter++;return {c:['c'],n:1,a,hasCounter:true}}let x=t===hard?JSON.parse(fs.readFileSync(path.join(__dirname,'periodic17.json'))):search(t);if(!x)throw Error('unclosed '+t);stats.auto++;return {c:['a',cert(x)],n:1,a}}let [,n,s]=c;stats.maxq=Math.max(stats.maxq,n);if(holes===1){stats.last++;return {c:['l',n,s],n:1,a}}stats.split++;const kids=[];for(let m=0;m<4*Math.min(f+1,6);m++){let b=a.slice();b[s]=m;kids.push(go(b,Math.max(f,1+(m>>2)),holes-1))}return {c:['h',n,s,f],kids,n:1+kids.reduce((v,k)=>v+k.n,0),a,hasCounter:kids.some(k=>k.hasCounter)}}
 const tree=go(parent,Math.max(4,1+(id>>2)),5);if(tree.n!==nExpected[id]||stats.maxq+6!==B)throw Error(JSON.stringify({id,stats,n:tree.n}));
 const open='set_option maxHeartbeats 0\nset_option maxRecDepth 100000\nnamespace '+ns+'\nopen BB6Coverage BB6.Agent13BlankDelay BB6.Agent5PhaseTree BB6.Agent47PhaseFrontier\n';
 const imp='import ZTrace\n'+(id===19?'import Raw11Counter28RE\n':'');
 function emit(t){const c=t.c;switch(c[0]){case 's':return `(.side ${c[1]} ${c[2]} ${bit(c[3])} (${c[4]}))`;case 'l':return `(.last ${c[1]} ${slot(c[2])})`;case 'a':return `(.automata ${c[1]})`;case 'h':return `(BB6.Agent5PhaseTree.split ${c[1]} ${slot(c[2])} ${c[3]} #[\n${t.kids.map(emit).join(',\n')}])`;default:throw Error('bad tree')}}
 function leaf(t,nm){let p='p_'+nm,s='safe_'+nm;let out=`def ${p} : PartialMachine := ${table(t.a)}\n`;if(t.c[0]==='c'){return out+`theorem ${s} : ∀ m, compatible ${p} m → WeightedBound ${B} m := BB6.Agent44Counter28RE.safe ${B}\n`}return out+`def cert_${nm} : Tree := ${emit(t)}\ntheorem checked_${nm} : BB6.Agent44ZTrace.check ${B} ${p} BB6.Agent44ZTrace.initial cert_${nm} = true := by decide +kernel\ntheorem ${s} : ∀ m, compatible ${p} m → WeightedBound ${B} m := BB6.Agent44ZTrace.sound ${B} ${p} cert_${nm} (by decide) checked_${nm}\n`}
 function join(t,nm){let [,n,s,f]=t.c;const p='p_'+nm;return `def ${p} : PartialMachine := ${table(t.a)}\ntheorem safe_${nm} : ∀ m, compatible ${p} m → WeightedBound ${B} m :=\n  BB6.Agent44ZJoin.join ${B} ${p} ${n} ${slot(s)} ${f} (by decide) (by decide +kernel) (by decide) (by decide) [\n${t.kids.map((_,j)=>`    BB6.Agent44ZJoin.childOf ${B} ${p} ${slot(s)} ${move(j)} p_${nm}_${j} (by decide +kernel) safe_${nm}_${j}`).join(',\n')}] (by decide +kernel)\n`}
 let top=[],build=[];
 for(let j=0;j<tree.kids.length;j++){
   const rt=tree.kids[j],root='root_'+j;let modules=[],queue=[],source='',used=0;
   function flush(){if(!source)return;const nm=prefix+'Branch'+j+'Part'+modules.length;fs.writeFileSync(nm+'.lean',imp+open+source+'end '+ns+'\n');modules.push(nm);source='';used=0;}
   function partition(t,nm){if((!t.hasCounter&&t.n<=cap)||t.c[0]==='c'){if(used+t.n>shardCap)flush();source+=leaf(t,nm);used+=t.n;return}if(!t.kids)throw Error('bad cut');t.kids.forEach((k,i)=>partition(k,nm+'_'+i));queue.push({t,nm});}
   partition(rt,root);flush();const name=prefix+'Branch'+j;
   let txt=modules.map(m=>'import '+m).join('\n')+'\n'+open+queue.map(({t,nm})=>join(t,nm)).join('')+'end '+ns+'\n';fs.writeFileSync(name+'.lean',txt);
   top.push(name);build.push({branch:j,nodes:rt.n,parts:modules,join:name});
 }
 const name=prefix+'Join';fs.writeFileSync(name+'.lean',top.map(m=>'import '+m).join('\n')+'\n'+open+join(tree,'root')+`theorem cover : Cover (WeightedBound ${B}) p_root := .leaf _ safe_root\n#print axioms cover\nend ${ns}\n`);
 fs.writeFileSync(prefix+'Manifest.json',JSON.stringify({id,parent:fmt(parent),B,nodes:tree.n,stats,cap,shardCap,build,join:name},null,2));console.log(id,tree.n,B,stats,'shards',build.reduce((a,b)=>a+b.parts.length,0));
}
