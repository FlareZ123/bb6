"""Arbitrary-tail binary counter exhaustion for raw112 holdout 103."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT.parent/'agent47-raw115-cut'),str(ROOT.parent)]
import counter as c
R,W,C=c.R,c.W,c.C

def generate(p):
    ls=[f'''import Raw115CounterBase
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
namespace BB6Coverage.Agent31Pump.Raw112Counter103
open BB6Coverage BB6Coverage.Agent31Pump.Raw115CounterBase''',c.tab(p)]
    ls += [c.macro(p,'resetCore',C(4,W('01011',R('1111'),'0'),W('0000X')),C(0,W('00'),W('0000',R('0000'),'0010X')),True,(34,4)),c.macro(p,'exitCore',C(4,W('01011',R('1111'),'0'),W('0010X')),C(4,W('010111111',R('1111'),'0'),W('X')),True,(22,0)),c.macro(p,'prefixCore',C(3,W('00111111',R('1111'),'0'),W()),C(0,W('00'),W('0000',R('0000'),'001')),False,(13,4)),c.macro(p,'finishCore',C(4,W('01011',R('1111'),'0'),W('001')),C(3,W('001111111111',R('1111'),'0'),W()),False,(43,0))]
    ls.append('''abbrev P (n : Nat) := rep [false,false,false,false] n
abbrev Q (n : Nat) := rep [true,true,true,true] n

def A (n : Nat) (X : List Bool) : Z0 := ⟨0,[false,false],P (n+1) ++ X⟩
def E (n : Nat) (X : List Bool) : Z0 := ⟨4,[false,true,false,true,true] ++ Q n ++ [false],X⟩
def fam (n : Nat) : Z0 := ⟨3,[false,false,true,true,true,true,true,true] ++ Q n ++ [false],[]⟩

theorem reset (n : Nat) (X : List Bool) : run0 table (34+4*n) (E n ([false,false,false,false] ++ X)) = some (A n ([false,false,true,false] ++ X)) := by
  simpa only [A,E,P,Q,rep,List.append_assoc,List.cons_append,List.nil_append,List.append_nil] using resetCore n X

theorem exit (n : Nat) (X : List Bool) : run0 table 22 (E n ([false,false,true,false] ++ X)) = some (E (n+1) X) := by
  simpa only [Nat.zero_mul,Nat.add_zero,E,Q,rep,List.append_assoc,List.cons_append,List.nil_append,List.append_nil] using exitCore n X

theorem exhaust (n : Nat) (X : List Bool) : ∃ t, 0<t ∧ run0 table t (A n X) = some (E n X) := by
  induction n generalizing X with
  | zero => exact ⟨16,by decide,by rfl⟩
  | succ n ih =>
    have hA : A (n+1) X = A n ([false,false,false,false] ++ X) := by
      unfold A P
      rw [rep_add [false,false,false,false] (n+1) 1]
      simp only [rep,List.append_assoc,List.cons_append,List.nil_append,List.append_nil]
    obtain ⟨a,ha,h1⟩ := ih ([false,false,false,false] ++ X)
    obtain ⟨b,hb,h2⟩ := ih ([false,false,true,false] ++ X)
    refine ⟨a+(34+4*n)+b+22,by omega,?_⟩
    rw [hA]
    exact join0 (join0 (join0 h1 (reset n X)) h2) (exit n X)

theorem beginRun (n : Nat) : run0 table (13+4*n) (fam n) = some (A n [false,false,true]) := by
  simpa only [fam,A,P,Q,rep,List.append_assoc,List.cons_append,List.nil_append,List.append_nil] using prefixCore n

theorem finish (n : Nat) : run0 table 43 (E n [false,false,true]) = some (fam (n+1)) := by
  simpa only [Nat.zero_mul,Nat.add_zero,fam,E,Q,rep,List.append_assoc,List.cons_append,List.nil_append,List.append_nil] using finishCore n

theorem entry : run0 table 37 ⟨0,[],[]⟩ = some (fam 0) := by rfl

theorem growth (n : Nat) : ∃ t, 0<t ∧ run0 table t (fam n) = some (fam (n+1)) := by
  obtain ⟨t,ht,h⟩ := exhaust n [false,false,true]
  exact ⟨13+4*n+t+43,by omega,join0 (join0 (beginRun n) h) (finish n)⟩

theorem never (m : Machine) (hm : compatible table m) : NeverHalts m :=
  never_of_returns table fam (fun _ => True) 0 trivial 37 entry
    (fun n _ => by obtain ⟨t,ht,h⟩ := growth n; exact ⟨n+1,t,trivial,ht,h⟩) m hm
#print axioms never
end BB6Coverage.Agent31Pump.Raw112Counter103''')
    return '\n\n'.join(ls)+'\n'
if __name__=='__main__':
    rows=(ROOT/'hard.txt').read_text().splitlines()
    (ROOT/'Raw112Counter103.lean').write_text(generate(c.pump.parse(rows[103])))
