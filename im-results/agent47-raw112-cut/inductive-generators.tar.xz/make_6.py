"""Six-cell binary-word invariant for raw112 holdout 6."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT.parent/'agent47-raw115-cut'),str(ROOT.parent)]
import counter as c
R,W,C=c.R,c.W,c.C

def generate(p):
    ls=['''import Raw115CounterBase
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace BB6Coverage.Agent31Pump.Raw112Counter6
open BB6Coverage BB6Coverage.Agent31Pump.Raw115CounterBase''',c.tab(p)]
    ls += [c.macro(p,'beginCore',C(0,W(),W('0011',R('0011'),'1111X')),C(3,W('10'+'1'*7,R('0111')),W('X')),True,(28,8)),c.macro(p,'beginGCore',C(0,W(),W('0011',R('0011'),'X')),C(3,W('10111',R('0111')),W('X')),True,(8,8))]
    ls.append('''abbrev P (a : Nat) := rep [false,false,true,true] a
abbrev Q (a : Nat) := rep [false,true,true,true] a
abbrev O (m : Nat) := rep [true] m
abbrev Z (m : Nat) := rep [false] m

def enc : List Bool → List Bool
  | [] => []
  | b::bs => [b,b,b,b,b,b] ++ enc bs

def F (a : Nat) (bs : List Bool) : Z0 := ⟨0,[],P (a+1) ++ [true,true,true,true] ++ enc bs⟩
def D (a m : Nat) (X : List Bool) : Z0 := ⟨3,[true,false] ++ O (m+1) ++ Q a,X⟩
def S (a b : Nat) (bs : List Bool) : Z0 := D a (6*(b+1)) (enc bs)

theorem enc_prefix (b : Nat) (bs : List Bool) : enc (List.replicate b false ++ bs) = rep [false,false,false,false,false,false] b ++ enc bs := by
  induction b with
  | zero => rfl
  | succ b ih => simp only [List.replicate_succ,List.cons_append,enc,rep,ih,List.append_assoc]

theorem beginRun (a : Nat) (bs : List Bool) : run0 table (28+8*a) (F a bs) = some (S a 0 bs) := by
  simpa only [F,S,D,P,Q,O,rep,List.append_assoc,List.cons_append,List.nil_append] using beginCore a (enc bs)

theorem beginG (a : Nat) (X : List Bool) : run0 table (8+8*a) ⟨0,[],P (a+1) ++ X⟩ = some (D a 2 X) := by
  simpa only [D,P,Q,O,rep,List.append_assoc,List.cons_append,List.nil_append] using beginGCore a X

theorem oneLocal (L X : List Bool) : run0 table 30 ⟨3,[true,false] ++ L,[true,true,true,true,true,true] ++ X⟩ = some ⟨3,[true,false,true,true,true,true,true,true] ++ L,X⟩ := by rfl

theorem one (a b : Nat) (bs : List Bool) : run0 table 30 (S a b (true::bs)) = some (S a (b+1) bs) := by
  have h := oneLocal (O (6*(b+1)+1) ++ Q a) (enc bs)
  have he : 6*(b+1+1)+1=6+(6*(b+1)+1) := by omega
  unfold S D O
  rw [he,rep_add [true] 6 _]
  simpa only [enc,O,rep,List.append_assoc,List.cons_append,List.nil_append] using h

theorem zeroLocal (L X : List Bool) : run0 table 32 ⟨3,[true,false] ++ L,[false,false,false,false,false,false] ++ X⟩ = some ⟨0,L,[false,false,true,true,true,true,true,true] ++ X⟩ := by rfl

theorem nilLocal (L : List Bool) : run0 table 32 ⟨3,[true,false] ++ L,[]⟩ = some ⟨0,L,[false,false,true,true,true,true,true,true]⟩ := by rfl

theorem popOne (L R : List Bool) : run0 table 1 ⟨0,[true] ++ L,R⟩ = some ⟨0,L,[false] ++ R⟩ := by rfl

theorem popQ (L R : List Bool) : run0 table 12 ⟨0,[false,true,true,true] ++ L,[false,false,false] ++ R⟩ = some ⟨0,L,[false,false,false,false,false,true,true] ++ R⟩ := by rfl

theorem extend (R : List Bool) : run0 table 9 ⟨0,[],[false,false,false] ++ R⟩ = some ⟨0,[],[false,false,true,true] ++ R⟩ := by rfl

theorem unwind (a m : Nat) (X : List Bool) : run0 table ((m+1)+12*a+9) ⟨0,O (m+1) ++ Q a,[false,false,true,true,true,true,true,true] ++ X⟩ = some ⟨0,[],P (a+1) ++ Z m ++ [true,true,true,true,true,true] ++ X⟩ := by
  have hz : Z (m+1) ++ [false,false] = [false,false,false] ++ Z m := by
    induction m with
    | zero => rfl
    | succ m ih =>
      simp only [Z,rep,List.cons_append,List.nil_append] at ih ⊢
      rw [ih]
  have h1 := sweepL table 0 [] [] [true] [false] 1 (by simpa only [List.nil_append] using popOne) (m+1) (Q a) ([false,false,true,true,true,true,true,true] ++ X)
  have h2 := sweepL table 0 [] [false,false,false] [false,true,true,true] [false,false,true,true] 12 (by intro L R; simpa only [List.nil_append,List.append_assoc,List.cons_append] using popQ L R) a [] (Z m ++ [true,true,true,true,true,true] ++ X)
  simp only [List.nil_append,List.append_nil,List.append_assoc,Nat.one_mul] at h1 h2
  have hh : run0 table (m+1) ⟨0,O (m+1) ++ Q a,[false,false,true,true,true,true,true,true] ++ X⟩ = some ⟨0,Q a,[false,false,false] ++ (Z m ++ ([true,true,true,true,true,true] ++ X))⟩ := by
    have e : Z (m+1) ++ ([false,false,true,true,true,true,true,true] ++ X) = [false,false,false] ++ (Z m ++ ([true,true,true,true,true,true] ++ X)) := by
      calc
        _ = (Z (m+1) ++ [false,false]) ++ ([true,true,true,true,true,true] ++ X) := by simp only [List.append_assoc,List.cons_append,List.nil_append]
        _ = _ := by rw [hz]; simp only [List.append_assoc]
    rw [e] at h1
    exact h1
  have h := join0 hh h2
  have h3 := extend (P a ++ (Z m ++ ([true,true,true,true,true,true] ++ X)))
  simpa only [P,rep,List.append_assoc,List.cons_append,List.nil_append] using join0 h h3

theorem zeroReset (a m : Nat) (X : List Bool) : run0 table (32+((m+1)+12*a+9)) (D a m ([false,false,false,false,false,false] ++ X)) = some ⟨0,[],P (a+1) ++ Z m ++ [true,true,true,true,true,true] ++ X⟩ := by
  exact join0 (zeroLocal (O (m+1) ++ Q a) X) (unwind a m X)

theorem nilReset (a m : Nat) : run0 table (32+((m+1)+12*a+9)) (D a m []) = some ⟨0,[],P (a+1) ++ Z m ++ [true,true,true,true,true,true]⟩ := by
  simpa only [D,List.append_nil,List.append_assoc] using join0 (nilLocal (O (m+1) ++ Q a)) (unwind a m [])

theorem phase2 (a : Nat) (X : List Bool) : run0 table ((8+8*a)+(32+((2+1)+12*a+9))) ⟨0,[],P (a+1) ++ [false,false,false,false,false,false] ++ X⟩ = some ⟨0,[],P (a+1+1) ++ [true,true,true,true] ++ X⟩ := by
  have h := join0 (beginG a ([false,false,false,false,false,false] ++ X)) (zeroReset a 2 X)
  unfold P
  rw [rep_add [false,false,true,true] (a+1) 1]
  simpa only [P,Z,rep,List.append_assoc,List.cons_append,List.nil_append,List.append_nil] using h

theorem afterCarry (a b : Nat) (bs : List Bool) : run0 table (32+((6*(b+1)+1)+12*a+9)) (S a b (false::bs)) = some ⟨0,[],P (a+1) ++ Z (6*(b+1)) ++ [true,true,true,true,true,true] ++ enc bs⟩ := by
  exact zeroReset a (6*(b+1)) (enc bs)

theorem finishCarry (a b : Nat) (bs : List Bool) : run0 table ((8+8*a)+(32+((2+1)+12*a+9))) ⟨0,[],P (a+1) ++ Z (6*(b+1)) ++ [true,true,true,true,true,true] ++ enc bs⟩ = some (F (a+1) (List.replicate b false ++ true::bs)) := by
  have hp := rep_group [false] 6 b
  change rep [false,false,false,false,false,false] b = Z (6*b) at hp
  have h := phase2 a (Z (6*b) ++ [true,true,true,true,true,true] ++ enc bs)
  unfold Z
  rw [show 6*(b+1)=6+6*b by omega,rep_add [false] 6 (6*b)]
  unfold F
  rw [enc_prefix b (true::bs),hp]
  simpa only [enc,Z,rep,List.append_assoc,List.cons_append,List.nil_append] using h

theorem carry (a b : Nat) (bs : List Bool) : ∃ x : Nat × List Bool, ∃ t, 0<t ∧ run0 table t (S a b bs) = some (F x.1 x.2) := by
  induction bs generalizing b with
  | nil =>
    have h := nilReset a (6*(b+1))
    have g := finishCarry a b []
    exact ⟨(a+1,List.replicate b false ++ [true]),(32+((6*(b+1)+1)+12*a+9))+((8+8*a)+(32+((2+1)+12*a+9))),by omega,join0 (by simpa only [S,enc,List.append_nil] using h) (by simpa only [enc,List.append_nil] using g)⟩
  | cons bit bs ih =>
    cases bit
    · exact ⟨(a+1,List.replicate b false ++ true::bs),(32+((6*(b+1)+1)+12*a+9))+((8+8*a)+(32+((2+1)+12*a+9))),by omega,join0 (afterCarry a b bs) (finishCarry a b bs)⟩
    · obtain ⟨x,t,ht,h⟩ := ih (b+1)
      exact ⟨x,30+t,by omega,join0 (one a b bs) h⟩

theorem returnExists (x : Nat × List Bool) : ∃ y : Nat × List Bool, ∃ t, 0<t ∧ run0 table t (F x.1 x.2) = some (F y.1 y.2) := by
  obtain ⟨y,t,ht,h⟩ := carry x.1 0 x.2
  exact ⟨y,28+8*x.1+t,by omega,join0 (beginRun x.1 x.2) h⟩

noncomputable def orbit : Nat → Nat × List Bool
  | 0 => (1,[])
  | n+1 => Classical.choose (returnExists (orbit n))
noncomputable def fam (n : Nat) : Z0 := F (orbit n).1 (orbit n).2

theorem entry : run0 table 61 ⟨0,[],[]⟩ = some (fam 0) := by rfl

theorem growth (n : Nat) : ∃ t, 0<t ∧ run0 table t (fam n) = some (fam (n+1)) := by exact Classical.choose_spec (returnExists (orbit n))

theorem never (m : Machine) (hm : compatible table m) : NeverHalts m :=
  never_of_returns table fam (fun _ => True) 0 trivial 61 entry
    (fun n _ => by obtain ⟨t,ht,h⟩ := growth n; exact ⟨n+1,t,trivial,ht,h⟩) m hm
#print axioms never
end BB6Coverage.Agent31Pump.Raw112Counter6''')
    return '\n\n'.join(ls)+'\n'
if __name__=='__main__':
    rows=(ROOT/'hard.txt').read_text().splitlines()
    (ROOT/'Raw112Counter6.lean').write_text(generate(c.pump.parse(rows[6])))
