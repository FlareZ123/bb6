"""Regular binary-word return invariant for raw112 holdouts 100 and 106."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT.parent/'agent47-raw115-cut'),str(ROOT.parent)]
import counter as c

def generate(i,p):
    slow=i==100
    template='''import Raw115CounterBase
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace BB6Coverage.Agent31Pump.Raw112Counter@ID@
open BB6Coverage BB6Coverage.Agent31Pump.Raw115CounterBase
@TABLE@

abbrev P (a : Nat) := rep [false,false,true,true] a
abbrev Q (a : Nat) := rep [false,true,true,true] a
abbrev U (b : Nat) := rep [true,true,true] b
abbrev V (a : Nat) := rep [true,true,false,false] a

def enc : List Bool → List Bool
  | [] => [false,false]
  | [b] => [b,true,false]
  | b::c::bs => [b,true,true] ++ enc (c::bs)

def F (a : Nat) (bs : List Bool) : Z0 := ⟨5,[],[true,true] ++ P a ++ enc bs⟩
def S (a b : Nat) (r : List Bool) : Z0 := ⟨0,[true,true] ++ U b ++ Q a ++ [false,true],r⟩
def D (a b : Nat) : Z0 := ⟨3,[false,false,true,true,true] ++ U b ++ Q a ++ [false,true],[]⟩

theorem enc_cons (x : Bool) (bs : List Bool) (h : bs ≠ []) : enc (x::bs) = [x,true,true] ++ enc bs := by
  cases bs with
  | nil => contradiction
  | cons b bs => rfl

theorem enc_prefix (b : Nat) (bs : List Bool) (h : bs ≠ []) : enc (List.replicate b true ++ bs) = U b ++ enc bs := by
  induction b with
  | zero => rfl
  | succ b ih =>
    rw [List.replicate_succ,List.cons_append,enc_cons _ _ (by simp [h]),ih]
    rfl

theorem Ucomm (b : Nat) : U b ++ [true,true] = [true,true] ++ U b := by
  induction b with
  | zero => rfl
  | succ b ih =>
    simp only [U,rep,List.append_assoc,List.cons_append,List.nil_append] at ih ⊢
    rw [ih]

theorem Vrotate (a : Nat) : [false,false] ++ V a ++ [true,true] = P (a+1) := by
  induction a with
  | zero => rfl
  | succ a ih =>
    change [false,false] ++ ([true,true,false,false] ++ V a) ++ [true,true] = [false,false,true,true] ++ P (a+1)
    rw [← ih]
    simp only [List.append_assoc,List.cons_append,List.nil_append]

theorem beginLocal (X : List Bool) : run0 table 6 ⟨5,[],[true,true] ++ X⟩ = some ⟨0,[true,true,false,true],X⟩ := by rfl

theorem scanP (L R : List Bool) : run0 table @SCAN@ ⟨0,[true,true] ++ L,[false,false,true,true] ++ R⟩ = some ⟨0,[true,true,false,true,true,true] ++ L,R⟩ := by rfl

theorem beginRun (a : Nat) (bs : List Bool) : run0 table (6+@SCAN@*a) (F a bs) = some (S a 0 (enc bs)) := by
  have h := beginLocal (P a ++ enc bs)
  have g := sweepR table 0 [true,true] [] [false,false,true,true] [false,true,true,true] @SCAN@ (by intro L R; simpa only [List.append_assoc,List.nil_append,List.cons_append] using scanP L R) a [false,true] (enc bs)
  simpa only [F,S,P,Q,U,rep,List.append_assoc,List.cons_append,List.nil_append,List.nil_append] using join0 h g

theorem scanOne (a b : Nat) (X : List Bool) : run0 table @ONE@ (S a b ([false,true,true] ++ X)) = some (S a (b+1) X) := by rfl

theorem scanZero (L X : List Bool) : run0 table @ZERO@ ⟨0,[true,true] ++ L,[true,true] ++ X⟩ = some ⟨5,L,[true,true,false,true] ++ X⟩ := by rfl

theorem popU (L R : List Bool) : run0 table 3 ⟨5,[true,true,true] ++ L,R⟩ = some ⟨5,L,[true,true,true] ++ R⟩ := by rfl

theorem popQ (L R : List Bool) : run0 table 4 ⟨5,[false,true,true,true] ++ L,R⟩ = some ⟨5,L,[true,true,false,false] ++ R⟩ := by rfl

theorem popEnd (X : List Bool) : run0 table 2 ⟨5,[false,true],X⟩ = some ⟨5,[],[false,false] ++ X⟩ := by rfl

theorem extend (X : List Bool) : run0 table @EXT@ ⟨5,[],[false,false,true,true] ++ X⟩ = some ⟨5,[],[true,true,false,false,true,true] ++ X⟩ := by rfl

theorem unwind (a b : Nat) (X : List Bool) : run0 table (3*b+4*a+2+@EXT@) ⟨5,U b ++ Q a ++ [false,true],[true,true] ++ X⟩ = some ⟨5,[],[true,true] ++ P (a+1) ++ U b ++ X⟩ := by
  have h1 := sweepL table 5 [] [] [true,true,true] [true,true,true] 3 (by simpa only [List.nil_append] using popU) b (Q a ++ [false,true]) ([true,true] ++ X)
  have h2 := sweepL table 5 [] [] [false,true,true,true] [true,true,false,false] 4 (by simpa only [List.nil_append] using popQ) a [false,true] (U b ++ [true,true] ++ X)
  have h3 := popEnd (V a ++ U b ++ [true,true] ++ X)
  simp only [List.nil_append,List.append_assoc] at h1 h2 h3
  have h := join0 (join0 h1 h2) h3
  have hword : [false,false] ++ (V a ++ (U b ++ ([true,true] ++ X))) = P (a+1) ++ U b ++ X := by
    calc
      _ = [false,false] ++ (V a ++ ((U b ++ [true,true]) ++ X)) := by simp only [List.append_assoc]
      _ = [false,false] ++ (V a ++ (([true,true] ++ U b) ++ X)) := by rw [Ucomm]
      _ = ([false,false] ++ V a ++ [true,true]) ++ (U b ++ X) := by simp only [List.append_assoc]
      _ = _ := by rw [Vrotate]; simp only [List.append_assoc]
  rw [hword] at h
  have h4 := extend (P a ++ U b ++ X)
  simpa only [List.append_assoc] using join0 h (by simpa only [P,rep,List.append_assoc,List.cons_append,List.nil_append] using h4)

theorem zeroReturn (a b : Nat) (X : List Bool) : run0 table (@ZERO@+(3*b+4*a+2+@EXT@)) (S a b ([true,true] ++ X)) = some ⟨5,[],[true,true] ++ P (a+1) ++ U b ++ [false,true] ++ X⟩ := by
  have h := scanZero (U b ++ Q a ++ [false,true]) X
  have g := unwind a b ([false,true] ++ X)
  exact join0 (by simpa only [S,List.append_assoc,List.cons_append,List.nil_append] using h) (by simpa only [List.append_assoc,List.cons_append,List.nil_append] using g)

theorem terminalNil (a b : Nat) : run0 table @NIL@ (S a b (enc [])) = some (D a b) := by rfl

theorem terminalOne (a b : Nat) : run0 table @TERM@ (S a b (enc [false])) = some (D a (b+1)) := by rfl

theorem Dstart (L : List Bool) : run0 table @DSTART@ ⟨3,[false,false,true,true,true] ++ L,[]⟩ = some ⟨5,L,[true,true,true,true,false]⟩ := by rfl

theorem Dreturn (a b : Nat) : run0 table (@DSTART@+(3*b+4*a+2+@EXT@)) (D a b) = some (F (a+1) (List.replicate b true ++ [true])) := by
  have h1 := Dstart (U b ++ Q a ++ [false,true])
  have h2 := unwind a b [true,true,false]
  have h := join0 (by simpa only [D,List.append_assoc,List.cons_append,List.nil_append] using h1) h2
  unfold F
  rw [enc_prefix b [true] (by decide)]
  simpa only [D,enc,List.append_assoc,List.cons_append,List.nil_append] using h

theorem carry (a b : Nat) (bs : List Bool) : ∃ x : Nat × List Bool, ∃ t, 0<t ∧ run0 table t (S a b (enc bs)) = some (F x.1 x.2) := by
  induction bs generalizing b with
  | nil => exact ⟨(a+1,List.replicate b true ++ [true]),_,by omega,join0 (terminalNil a b) (Dreturn a b)⟩
  | cons bit bs ih =>
    cases bit
    · cases bs with
      | nil => exact ⟨(a+1,List.replicate (b+1) true ++ [true]),_,by omega,join0 (terminalOne a b) (Dreturn a (b+1))⟩
      | cons c bs =>
        obtain ⟨x,t,ht,h⟩ := ih (b+1)
        exact ⟨x,@ONE@+t,by omega,join0 (scanOne a b (enc (c::bs))) h⟩
    · cases bs with
      | nil =>
        refine ⟨(a+1,List.replicate b true ++ [false]),@ZERO@+(3*b+4*a+2+@EXT@),by omega,?_⟩
        unfold F
        rw [enc_prefix b [false] (by decide)]
        simpa only [enc,List.append_assoc,List.cons_append,List.nil_append] using zeroReturn a b [false]
      | cons c bs =>
        refine ⟨(a+1,List.replicate b true ++ false::c::bs),@ZERO@+(3*b+4*a+2+@EXT@),by omega,?_⟩
        unfold F
        rw [enc_prefix b (false::c::bs) (by simp)]
        simpa only [enc,List.append_assoc,List.cons_append,List.nil_append] using zeroReturn a b ([true] ++ enc (c::bs))

theorem returnExists (x : Nat × List Bool) : ∃ y : Nat × List Bool, ∃ t, 0<t ∧ run0 table t (F x.1 x.2) = some (F y.1 y.2) := by
  obtain ⟨y,t,ht,h⟩ := carry x.1 0 x.2
  exact ⟨y,6+@SCAN@*x.1+t,by omega,join0 (beginRun x.1 x.2) h⟩

noncomputable def orbit : Nat → Nat × List Bool
  | 0 => (1,[])
  | n+1 => Classical.choose (returnExists (orbit n))
noncomputable def fam (n : Nat) : Z0 := F (orbit n).1 (orbit n).2

theorem entry : run0 table @ENTRY@ ⟨0,[],[]⟩ = some (fam 0) := by rfl

theorem growth (n : Nat) : ∃ t, 0<t ∧ run0 table t (fam n) = some (fam (n+1)) := by
  exact Classical.choose_spec (returnExists (orbit n))

theorem never (m : Machine) (hm : compatible table m) : NeverHalts m :=
  never_of_returns table fam (fun _ => True) 0 trivial @ENTRY@ entry
    (fun n _ => by obtain ⟨t,ht,h⟩ := growth n; exact ⟨n+1,t,trivial,ht,h⟩) m hm
#print axioms never
end BB6Coverage.Agent31Pump.Raw112Counter@ID@
'''
    for k,v in dict(ID=i,TABLE=c.tab(p),SCAN=8 if slow else 6,ONE=5 if slow else 3,ZERO=6 if slow else 4,EXT=14 if slow else 12,NIL=5 if slow else 3,TERM=8 if slow else 6,DSTART=13 if slow else 11,ENTRY=43 if slow else 37).items():template=template.replace('@'+k+'@',str(v))
    return template
if __name__=='__main__':
    rows=(ROOT/'hard.txt').read_text().splitlines()
    for i in [100,106]:(ROOT/f'Raw112Counter{i}.lean').write_text(generate(i,c.pump.parse(rows[i])))
