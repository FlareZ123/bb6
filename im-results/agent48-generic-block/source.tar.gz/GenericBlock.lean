import BlockFARBridge
set_option maxRecDepth 100000
namespace BB6.GenericBlock
open BB6BlockFAR (Q Ray Move Table Prim cons tail blankRay primStep run run_add primBlank blank_cons)

/-- Width is `w+1`, so blocks are nonempty by construction. -/
abbrev Sym (w : Nat) := {xs : List Bool // xs.length = w+1}
def Sym.zero (w : Nat) : Sym w := ⟨List.replicate (w+1) false,by simp⟩
def Sym.code {w} (a : Sym w) : Nat := (BitVec.ofBoolListLE a.val).toNat
def Sym.ofCode (w : Nat) (n : Nat) : Sym w :=
  ⟨(List.range (w+1)).map n.testBit,by simp⟩
theorem ofCode_code {w} (a : Sym w) : Sym.ofCode w a.code = a := by
  apply Subtype.ext
  apply List.ext_getElem
  · simp [Sym.ofCode,a.property]
  · intro i h₁ h₂
    simp only [Sym.ofCode,List.getElem_map,List.getElem_range]
    have hh := BitVec.getLsbD_ofBoolListLE (bs:=a.val) (i:=i)
    rw [List.getD] at hh
    rw [List.getElem?_eq_getElem h₂] at hh
    exact hh

def prepend : List Bool → Ray → Ray
  | [],r => r
  | a::l,r => cons a (prepend l r)
@[simp] theorem prepend_append (xs ys : List Bool) (r : Ray) :
    prepend (xs++ys) r = prepend xs (prepend ys r) := by
  induction xs with
  | nil => rfl
  | cons a xs ih => simp [prepend,ih]
@[simp] theorem prepend_replicate_false (n : Nat) :
    prepend (List.replicate n false) blankRay = blankRay := by
  induction n with
  | zero => rfl
  | succ n ih => simp [List.replicate_succ,prepend,ih,blank_cons]
def leftRay {w} : List (Sym w) → Ray
  | [] => blankRay
  | a::r => prepend a.val.reverse (leftRay r)
def rightRay {w} : List (Sym w) → Ray
  | [] => blankRay
  | a::r => prepend a.val (rightRay r)
theorem leftRay_unfold {w} (l : List (Sym w)) :
    leftRay l = prepend (l.headD (Sym.zero w)).val.reverse (leftRay l.tail) := by
  cases l with
  | nil => simp [leftRay,Sym.zero]
  | cons => rfl
theorem rightRay_unfold {w} (l : List (Sym w)) :
    rightRay l = prepend (l.headD (Sym.zero w)).val (rightRay l.tail) := by
  cases l with
  | nil => simp [rightRay,Sym.zero]
  | cons => rfl

def render {w} (q : Q) (l : List Bool) (b : Bool) (r : List Bool)
    (L R : List (Sym w)) : Prim :=
  ⟨q,prepend l (leftRay L),cons b (prepend r (rightRay R))⟩
def entryRender {w} (q : Q) (dir : Bool) (a : Sym w) (L R : List (Sym w)) : Prim :=
  if dir then render q [] (a.val.headD false) a.val.tail L R
  else render q a.val.reverse.tail (a.val.reverse.headD false) [] L R
structure BlockConfig (w : Nat) where
  q : Q
  dir : Bool
  l : List (Sym w)
  r : List (Sym w)
def BlockConfig.render {w} (c : BlockConfig w) : Prim :=
  entryRender c.q c.dir (c.r.headD (Sym.zero w)) c.l c.r.tail
def BlockConfig.next {w} (c : BlockConfig w) (q : Q) (dir : Bool) (a : Sym w) : BlockConfig w :=
  if dir then ⟨q,true,a::c.l,c.r.tail⟩
  else ⟨q,false,c.l.tail,c.l.headD (Sym.zero w)::a::c.r.tail⟩
structure Exit (w : Nat) where
  steps : Nat
  q : Q
  dir : Bool
  a : Sym w
  deriving DecidableEq

def macroRun {w} (M : Table) : (fuel : Nat) → (q : Q) → (l : List Bool) →
    (b : Bool) → (r : List Bool) → l.length + r.length = w → Option (Exit w)
  | 0,_,_,_,_,_ => none
  | fuel+1,q,l,b,r,h => do
    let mv ← M q b
    if mv.right then
      match r,h with
      | [],h => return ⟨1,mv.next,true,⟨(mv.write::l).reverse,by simp at h ⊢; omega⟩⟩
      | c::rs,h => (macroRun M fuel mv.next (mv.write::l) c rs (by simp at h ⊢; omega)).map (fun e => {e with steps := e.steps+1})
    else
      match l,h with
      | [],h => return ⟨1,mv.next,false,⟨mv.write::r,by simp at h ⊢; omega⟩⟩
      | c::ls,h => (macroRun M fuel mv.next ls c (mv.write::r) (by simp at h ⊢; omega)).map (fun e => {e with steps := e.steps+1})

def entryRight {w} (M : Table) (q : Q) : (xs : List Bool) → xs.length = w+1 → Option (Exit w)
  | [],_ => none
  | b::r,h => macroRun M (6*(w+1)*2^(w+1)+1) q [] b r (by simp at h ⊢; omega)
def entryLeft {w} (M : Table) (q : Q) : (xs : List Bool) → xs.length = w+1 → Option (Exit w)
  | [],_ => none
  | b::l,h => macroRun M (6*(w+1)*2^(w+1)+1) q l b [] (by simp at h ⊢; omega)
def blockExit {w} (M : Table) (q : Q) (dir : Bool) (a : Sym w) : Option (Exit w) :=
  if dir then entryRight M q a.val a.property
  else entryLeft M q a.val.reverse (by simp [a.property])

/-- A right entry reads the first bit; a left entry reads the last bit. -/
theorem entryRender_right {w} (q : Q) (a : Sym w) (L R : List (Sym w)) :
    entryRender q true a L R = ⟨q,leftRay L,prepend a.val (rightRay R)⟩ := by
  have h := a.property
  cases he : a.val with
  | nil => simp [he] at h
  | cons b r => simp [entryRender,render,he,prepend]

theorem entryRender_left {w} (q : Q) (a : Sym w) (L R : List (Sym w)) :
    entryRender q false a L R =
      ⟨q,tail (prepend a.val.reverse (leftRay L)),cons ((prepend a.val.reverse (leftRay L)) 0) (rightRay R)⟩ := by
  have h := a.property
  cases he : a.val.reverse with
  | nil => have hh:=congrArg List.length he; simp [a.property] at hh
  | cons b r => simp [entryRender,render,he,prepend,cons,tail]

theorem macroRun_sound {w} (M : Table) (fuel : Nat) (q : Q) (l : List Bool) (b : Bool) (r : List Bool)
    (hlen : l.length + r.length = w) (L R : List (Sym w)) (e : Exit w)
    (h : macroRun M fuel q l b r hlen = some e) :
    0 < e.steps ∧ run M e.steps (render q l b r L R) = some
      (entryRender e.q e.dir (if e.dir then R.headD (Sym.zero w) else L.headD (Sym.zero w))
        (if e.dir then e.a::L else L.tail) (if e.dir then R.tail else e.a::R)) := by
  induction fuel generalizing q l b r e with
  | zero => simp [macroRun] at h
  | succ fuel ih =>
    cases hm : M q b with
    | none => simp [macroRun,hm] at h
    | some mv =>
      cases hd : mv.right with
      | false =>
        cases l with
        | nil =>
          simp [macroRun,hm,hd] at h
          subst e
          constructor
          · simp
          · simp only [Bool.false_eq_true,ite_false]
            rw [entryRender_left]
            simp [run,primStep,render,hm,hd,prepend,cons,tail,rightRay]
            rw [leftRay_unfold L]
            cases L <;> constructor <;> rfl
        | cons c ls =>
          simp [macroRun,hm,hd,Option.map_eq_some_iff] at h
          obtain ⟨e',he',rfl⟩ := h
          obtain ⟨hpos,hrun⟩ := ih mv.next ls c (mv.write::r) (by simp at hlen ⊢; omega) e' he'
          refine ⟨by simp,?_⟩
          simpa [run,primStep,render,hm,hd,prepend,cons,tail] using hrun
      | true =>
        cases r with
        | nil =>
          simp [macroRun,hm,hd] at h
          subst e
          constructor
          · simp
          · simp only [ite_true]
            rw [entryRender_right]
            simp [run,primStep,render,hm,hd,prepend,cons,tail,leftRay]
            rw [rightRay_unfold R]
            cases R <;> rfl
        | cons c rs =>
          simp [macroRun,hm,hd,Option.map_eq_some_iff] at h
          obtain ⟨e',he',rfl⟩ := h
          obtain ⟨hpos,hrun⟩ := ih mv.next (mv.write::l) c rs (by simp at hlen ⊢; omega) e' he'
          refine ⟨by simp,?_⟩
          simpa [run,primStep,render,hm,hd,prepend,cons,tail] using hrun

theorem macro_sound {w} (M : Table) (c : BlockConfig w) (e : Exit w)
    (h : blockExit M c.q c.dir (c.r.headD (Sym.zero w)) = some e) :
    0 < e.steps ∧ run M e.steps c.render = some (c.next e.q e.dir e.a).render := by
  let a := c.r.headD (Sym.zero w)
  have ha := a.property
  change blockExit M c.q c.dir a = some e at h
  cases hd : c.dir with
  | false =>
    have hrev : a.val.reverse.length = w+1 := by simp [a.property]
    have hs : ∀ xs (hx : xs.length = w+1), entryLeft M c.q xs hx = some e →
        ∀ b l, xs = b::l → ∃ hlen, macroRun M (6*(w+1)*2^(w+1)+1) c.q l b [] hlen = some e := by
      intro xs hx H b l he
      subst xs
      exact ⟨_,H⟩
    cases hl : a.val.reverse with
    | nil => rw [hl] at hrev; simp at hrev
    | cons b l =>
      simp only [blockExit,hd,Bool.false_eq_true,ite_false] at h
      obtain ⟨hlen,hh⟩ := hs _ _ h _ _ hl
      have h' := macroRun_sound M _ c.q l b [] hlen c.l c.r.tail e hh
      refine ⟨h'.1,?_⟩
      have hstart : c.render = render c.q l b [] c.l c.r.tail := by
        change entryRender c.q c.dir a c.l c.r.tail = _
        rw [hd]
        simp only [entryRender,Bool.false_eq_true,ite_false,hl,List.tail_cons,List.headD_cons]
      rw [hstart]
      cases hed : e.dir <;> simpa only [BlockConfig.render,BlockConfig.next,hed,Bool.false_eq_true,ite_false,ite_true,List.headD_cons,List.tail_cons] using h'.2
  | true =>
    have hs : ∀ xs (hx : xs.length = w+1), entryRight M c.q xs hx = some e →
        ∀ b r, xs = b::r → ∃ hlen, macroRun M (6*(w+1)*2^(w+1)+1) c.q [] b r hlen = some e := by
      intro xs hx H b r he
      subst xs
      exact ⟨_,H⟩
    cases hr : a.val with
    | nil => rw [hr] at ha; simp at ha
    | cons b r =>
      simp only [blockExit,hd,ite_true] at h
      obtain ⟨hlen,hh⟩ := hs _ _ h _ _ hr
      have h' := macroRun_sound M _ c.q [] b r hlen c.l c.r.tail e hh
      refine ⟨h'.1,?_⟩
      have hstart : c.render = render c.q [] b r c.l c.r.tail := by
        change entryRender c.q c.dir a c.l c.r.tail = _
        rw [hd]
        simp only [entryRender,ite_true,hr,List.tail_cons,List.headD_cons]
      rw [hstart]
      cases hed : e.dir <;> simpa only [BlockConfig.render,BlockConfig.next,hed,Bool.false_eq_true,ite_false,ite_true,List.headD_cons,List.tail_cons] using h'.2

def blockBlank (w : Nat) : BlockConfig w := ⟨0,true,[],[]⟩
theorem render_blank (w : Nat) : (blockBlank w).render = primBlank := by
  rw [BlockConfig.render]
  rw [show (blockBlank w).dir = true by rfl,entryRender_right]
  simp [blockBlank,primBlank,leftRay,rightRay,Sym.zero]

theorem forever_of_invariant {w} (M : Table) (P : BlockConfig w → Prop)
    (closed : ∀ c, P c → ∃ e, blockExit M c.q c.dir (c.r.headD (Sym.zero w)) = some e ∧ P (c.next e.q e.dir e.a))
    (c : BlockConfig w) (hc : P c) : ∀ n, ∃ d, run M n c.render = some d := by
  intro n
  induction n using Nat.strongRecOn generalizing c with
  | ind n ih =>
    obtain ⟨e,he,hnext⟩ := closed c hc
    obtain ⟨hpos,hrun⟩ := macro_sound M c e he
    by_cases hle : e.steps ≤ n
    · obtain ⟨d,hd⟩ := ih (n-e.steps) (by omega) _ hnext
      refine ⟨d,?_⟩
      rw [show n=e.steps+(n-e.steps) by omega,run_add,hrun]
      exact hd
    · rw [show e.steps=n+(e.steps-n) by omega,run_add] at hrun
      cases hh : run M n c.render with
      | none => simp [hh] at hrun
      | some d => exact ⟨d,rfl⟩

#print axioms ofCode_code
#print axioms macroRun_sound
#print axioms forever_of_invariant
end BB6.GenericBlock
