import GenericBlock
import FastThreeHoleAudit
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent48OneRA4620
open BB6BlockFAR (Q Ray Move Table Prim cons tail blankRay primStep run run_add primBlank blank_cons)
def machine : Table := fun q b => ([some ⟨true,true,1⟩,none,some ⟨true,true,2⟩,some ⟨false,true,5⟩,
  some ⟨true,false,3⟩,some ⟨false,true,2⟩,some ⟨false,false,3⟩,some ⟨false,false,4⟩,
  some ⟨true,true,0⟩,some ⟨true,true,2⟩,some ⟨true,false,4⟩,some ⟨true,true,5⟩] : List (Option Move))[2*q.val+b.toNat]?.getD none

def repeatBit (b : Bool) : Nat → Ray → Ray
  | 0,r => r
  | n+1,r => cons b (repeatBit b n r)
abbrev ones := repeatBit true
abbrev zeros := repeatBit false
@[simp] theorem repeatBit_zero (b : Bool) (r : Ray) : repeatBit b 0 r = r := rfl
@[simp] theorem repeatBit_succ (b : Bool) (n : Nat) (r : Ray) : repeatBit b (n+1) r = cons b (repeatBit b n r) := rfl
theorem repeatBit_cons (b : Bool) (n : Nat) (r : Ray) : repeatBit b n (cons b r) = repeatBit b (n+1) r := by
  induction n with
  | zero => rfl
  | succ n ih => simp [repeatBit,ih]
theorem repeatBit_add (b : Bool) (n m : Nat) (r : Ray) : repeatBit b n (repeatBit b m r) = repeatBit b (n+m) r := by
  induction n with
  | zero => simp
  | succ n ih => rw [show n+1+m=n+m+1 by omega]; simp [repeatBit,ih]
@[simp] theorem cons_head (b : Bool) (r : Ray) : cons b r 0 = b := rfl
@[simp] theorem tail_cons (b : Bool) (r : Ray) : tail (cons b r) = r := rfl
@[simp] theorem cons_tail (r : Ray) : cons (r 0) (tail r) = r := by funext n; cases n <;> rfl

def cfg (q : Q) (l r : Ray) : Prim := ⟨q,l,r⟩

theorem scanF (n : Nat) (L R : Ray) :
    run machine n (cfg 5 L (ones n R)) = some (cfg 5 (ones n L) R) := by
  induction n generalizing L with
  | zero => rfl
  | succ n ih =>
    rw [show n+1=1+n by omega,run_add]
    simp only [Nat.one_add]
    change (run machine 1 (cfg 5 L (ones (n+1) R))).bind (run machine n) = _
    have hs : run machine 1 (cfg 5 L (ones (n+1) R)) = some (cfg 5 (cons true L) (ones n R)) := rfl
    rw [hs]
    simpa only [Option.bind_some,repeatBit_cons] using ih (cons true L)

theorem scanC (n : Nat) (L R : Ray) :
    run machine n (cfg 2 L (ones n R)) = some (cfg 2 (zeros n L) R) := by
  induction n generalizing L with
  | zero => rfl
  | succ n ih =>
    rw [show n+1=1+n by omega,run_add]
    simp only [Nat.one_add]
    change (run machine 1 (cfg 2 L (ones (n+1) R))).bind (run machine n) = _
    have hs : run machine 1 (cfg 2 L (ones (n+1) R)) = some (cfg 2 (cons false L) (ones n R)) := rfl
    rw [hs]
    simpa only [Option.bind_some,repeatBit_cons] using ih (cons false L)

theorem scanD (n : Nat) (L R : Ray) :
    run machine n (cfg 3 (tail (zeros n L)) (cons ((zeros n L) 0) R)) =
      some (cfg 3 (tail L) (cons (L 0) (zeros n R))) := by
  induction n generalizing R with
  | zero => rfl
  | succ n ih =>
    rw [show n+1=1+n by omega,run_add]
    simp only [Nat.one_add]
    change (run machine 1 (cfg 3 (tail (zeros (n+1) L)) (cons ((zeros (n+1) L) 0) R))).bind (run machine n) = _
    have hs : run machine 1 (cfg 3 (tail (zeros (n+1) L)) (cons ((zeros (n+1) L) 0) R)) =
        some (cfg 3 (tail (zeros n L)) (cons ((zeros n L) 0) (cons false R))) := rfl
    rw [hs]
    simpa only [Option.bind_some,repeatBit_cons] using ih (cons false R)

theorem scanCD (n : Nat) (L R : Ray) :
    run machine (2*n+2) (cfg 2 (cons true L) (ones n (cons false R))) =
      some (cfg 4 (tail L) (cons (L 0) (cons false (zeros n (cons true R))))) := by
  rw [show 2*n+2=n+1+n+1 by omega,run_add,run_add,run_add,scanC]
  simp only [Option.bind_some]
  have hs : run machine 1 (cfg 2 (zeros n (cons true L)) (cons false R)) =
      some (cfg 3 (tail (zeros n (cons true L))) (cons ((zeros n (cons true L)) 0) (cons true R))) := rfl
  rw [hs]
  simp only [Option.bind_some]
  rw [scanD]
  rfl

theorem scanE (n : Nat) (L R : Ray) :
    run machine (3*n+1) (cfg 4 (tail (ones n (cons false L)))
        (cons ((ones n (cons false L)) 0) (cons false R))) =
      some (cfg 0 (cons true L) (cons false (ones n R))) := by
  induction n generalizing R with
  | zero => rfl
  | succ n ih =>
    rw [show 3*(n+1)+1=3+(3*n+1) by omega,run_add]
    have hs : run machine 3 (cfg 4 (tail (ones (n+1) (cons false L)))
        (cons ((ones (n+1) (cons false L)) 0) (cons false R))) =
        some (cfg 4 (tail (ones n (cons false L))) (cons ((ones n (cons false L)) 0) (cons false (cons true R)))) := rfl
    rw [hs]
    simpa only [Option.bind_some,repeatBit_cons] using ih (cons true R)

/-- The nonfinal sweep shifts the delimiter two cells right and increments the suffix. -/
theorem advance (L n j : Nat) (R : Ray) :
    run machine (4*n+10+2*j) (cfg 0 (ones L blankRay) (cons false (ones (n+2) (cons false (ones j (cons false R)))))) =
      some (cfg 0 (ones (L+2) blankRay) (cons false (ones n (zeros (j+1) (cons true R))))) := by
  rw [show 4*n+10+2*j=2+(n+1)+2+(2*(j+1)+2)+(3*n+1) by omega]
  simp only [run_add]
  have hAB : run machine 2 (cfg 0 (ones L blankRay) (cons false (ones (n+2) (cons false (ones j (cons false R)))))) =
      some (cfg 5 (cons false (cons true (ones L blankRay))) (ones (n+1) (cons false (ones j (cons false R))))) := rfl
  rw [hAB]
  simp only [Option.bind_some]
  rw [scanF]
  simp only [Option.bind_some]
  have hFE : run machine 2 (cfg 5 (ones (n+1) (cons false (cons true (ones L blankRay)))) (cons false (ones j (cons false R)))) =
      some (cfg 2 (ones (n+1) (cons false (cons true (ones L blankRay)))) (ones (j+1) (cons false R))) := rfl
  rw [hFE]
  simp only [Option.bind_some,repeatBit_succ]
  -- Keep the abstract run of ones intact for the C/D and E sweep lemmas.
  change (run machine (2*(j+1)+2) (cfg 2 (cons true (ones n (cons false (cons true (ones L blankRay))))) (ones (j+1) (cons false R)))).bind (run machine (3*n+1)) = _
  rw [scanCD]
  simp only [Option.bind_some]
  rw [scanE]
  rfl

/-- At the left reset the prefix grows by two, provided the suffix was odd. -/
theorem reset (L j : Nat) (R : Ray) :
    run machine (3*L+8+2*j) (cfg 0 (ones L blankRay) (cons false (cons false (ones j (cons false R))))) =
      some (cfg 0 (cons true blankRay) (cons false (ones (L+1) (zeros j (cons true R))))) := by
  rw [show 3*L+8+2*j=2+(2*j+2)+(3*(L+1)+1) by omega]
  simp only [run_add]
  have hAB : run machine 2 (cfg 0 (ones L blankRay) (cons false (cons false (ones j (cons false R))))) =
      some (cfg 2 (cons true (cons true (ones L blankRay))) (ones j (cons false R))) := rfl
  rw [hAB]
  simp only [Option.bind_some]
  rw [scanCD]
  simp only [Option.bind_some]
  -- The boundary immediately left of the old prefix is blank.
  have hE := scanE (L+1) blankRay (zeros j (cons true R))
  simpa only [repeatBit_succ,blank_cons] using hE

def bin (y : Nat) : Ray := fun i => y.testBit i
@[simp] theorem bin_zero : bin 0 = blankRay := by funext i; simp [bin,blankRay]
theorem bin_even (y : Nat) : bin (2*y) = cons false (bin y) := by
  funext i
  cases i with
  | zero => simp [bin,cons]
  | succ i => simp [bin,cons,Nat.testBit_succ]
theorem bin_odd (y : Nat) : bin (2*y+1) = cons true (bin y) := by
  funext i
  cases i with
  | zero => simp [bin,cons]
  | succ i => rw [bin,Nat.testBit_succ,show (2*y+1)/2=y by omega]; rfl

theorem binary_increment (y : Nat) : ∃ j z : Nat,
    bin y = ones j (cons false (bin z)) ∧ bin (y+1) = zeros j (cons true (bin z)) := by
  induction y using Nat.strongRecOn with
  | ind y ih =>
    by_cases he : y%2=0
    · refine ⟨0,y/2,?_,?_⟩
      · calc
          bin y = bin (2*(y/2)) := congrArg bin (by omega)
          _ = _ := bin_even _
      · rw [show y+1=2*(y/2)+1 by omega,bin_odd]; rfl
    · obtain ⟨j,z,h1,h2⟩ := ih (y/2) (by omega)
      refine ⟨j+1,z,?_,?_⟩
      · calc
          bin y = bin (2*(y/2)+1) := congrArg bin (by omega)
          _ = _ := by rw [bin_odd,h1]; rfl
      · rw [show y+1=2*(y/2+1) by omega,bin_even,h2]; rfl

def C (l k y : Nat) : Prim := cfg 0 (ones (2*l+1) blankRay) (cons false (ones (2*k) (cons false (bin y))))
theorem advanceC (l k y : Nat) : ∃ t>0, run machine t (C l (k+1) y) = some (C (l+1) k (y+1)) := by
  obtain ⟨j,z,h1,h2⟩ := binary_increment y
  refine ⟨8*k+10+2*j,by omega,?_⟩
  unfold C
  rw [h1,h2]
  have H := advance (2*l+1) (2*k) j (bin z)
  rw [show 4*(2*k)+10+2*j=8*k+10+2*j by omega] at H
  rw [show 2*(k+1)=2*k+2 by omega,show 2*(l+1)+1=2*l+1+2 by omega]
  simpa only [repeatBit_succ] using H

theorem resetC (l y : Nat) : ∃ t>0, run machine t (C l 0 (2*y+1)) = some (C 0 (l+1) (y+1)) := by
  obtain ⟨j,z,h1,h2⟩ := binary_increment y
  have H := reset (2*l+1) (j+1) (bin z)
  refine ⟨3*(2*l+1)+8+2*(j+1),by omega,?_⟩
  unfold C
  rw [bin_odd,h1,h2]
  rw [show 2*(l+1)=2*l+1+1 by omega]
  simpa only [Nat.mul_zero,repeatBit_zero,repeatBit_succ] using H

theorem sweep (l k y : Nat) : ∃ t, run machine t (C l k y) = some (C (l+k) 0 (y+k)) := by
  induction k generalizing l y with
  | zero => exact ⟨0,by simp [run]⟩
  | succ k ih =>
    obtain ⟨t,ht,h⟩ := advanceC l k y
    obtain ⟨u,hu⟩ := ih (l+1) (y+1)
    refine ⟨t+u,?_⟩
    rw [run_add,h]
    simp only [Option.bind_some]
    rw [show l+1+k=l+(k+1) by omega,show y+1+k=y+(k+1) by omega] at hu
    exact hu

def epoch (n : Nat) : Prim := C 0 (n+1) n
theorem epochNext (n : Nat) : ∃ t>0, run machine t (epoch n) = some (epoch (n+1)) := by
  obtain ⟨u,hu⟩ := sweep 0 (n+1) n
  have hu' : run machine u (epoch n) = some (C (n+1) 0 (2*n+1)) := by simpa [epoch,Nat.add_assoc,Nat.two_mul] using hu
  obtain ⟨v,hv,h⟩ := resetC (n+1) n
  refine ⟨u+v,by omega,?_⟩
  rw [run_add,hu']
  simpa [epoch] using h

theorem initial : run machine 8 primBlank = some (epoch 0) := by
  -- Rays are functions; the finite eight-step trace is checked by normalization.
  change some (cfg 0 (cons true blankRay) (cons false (cons true (cons true blankRay)))) = some (epoch 0)
  simp [epoch,C,repeatBit,bin_zero,blank_cons]

theorem foreverEpoch (n steps : Nat) : ∃ c, run machine steps (epoch n) = some c := by
  induction steps using Nat.strongRecOn generalizing n with
  | ind steps ih =>
    obtain ⟨t,ht,h⟩ := epochNext n
    by_cases he : t≤steps
    · obtain ⟨c,hc⟩ := ih (steps-t) (by omega) (n+1)
      refine ⟨c,?_⟩
      rw [show steps=t+(steps-t) by omega,run_add,h]
      exact hc
    · rw [show t=steps+(t-steps) by omega,run_add] at h
      cases hr : run machine steps (epoch n) with
      | none => simp [hr] at h
      | some c => exact ⟨c,rfl⟩
theorem forever : ∀ steps, ∃ c, run machine steps primBlank = some c := by
  intro steps
  by_cases h : 8≤steps
  · obtain ⟨c,hc⟩ := foreverEpoch 0 (steps-8)
    refine ⟨c,?_⟩
    rw [show steps=8+(steps-8) by omega,run_add,initial]
    exact hc
  · have hi := initial
    rw [show 8=steps+(8-steps) by omega,run_add] at hi
    cases hr : run machine steps primBlank with
    | none => simp [hr] at hi
    | some c => exact ⟨c,rfl⟩

def ctr : BB6Coverage.PartialMachine := BB6Coverage.FAR.fromCodes [7,24,11,21,14,9,12,16,3,11,18,23]
theorem same : ctr = BB6BlockFAR.partialTable machine := BB6.Agent31ThreeHole.tableOK_sound _ _ (by decide +kernel)
theorem never (m : BB6Coverage.Machine) (hm : BB6Coverage.compatible ctr m) : BB6Coverage.NeverHalts m :=
  BB6BlockFAR.transfer_never machine m (by simpa only [← same] using hm) forever
#print axioms never
end BB6.Agent48OneRA4620
