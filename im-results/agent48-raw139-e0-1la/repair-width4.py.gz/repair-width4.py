#!/usr/bin/env python3
"""Repair exact width-four certificates emitted under the width-three type.
No machine discovery: decode the original dense data and specialize the
already checked width-five sparse model. Lean checks the actual invariants.
"""
import json, pathlib, re, sys


def specialize(extern):
    src=(extern/'OneLAWideBlock5.lean').read_text()
    assert src.count('961')==2
    src=src.replace('BB6.Agent48Wide5','BB6.Agent48Wide4')
    src=src.replace('  b4 : Bool\n','').replace('⟨false,false,false,false,false⟩','⟨false,false,false,false⟩')
    src=src.replace(' + 16*s.b4.toNat','').replace(',n/16%2 == 1','')
    src=src.replace('List.range 32','List.range 16').replace('s.code < 32','s.code < 16')
    src=src.replace('  have hb4 : s.b4.toNat ≤ 1 := by cases s.b4 <;> decide\n','')
    src=re.sub(r'  have h4 : .*?\n  cases s\n','  cases s\n',src,flags=re.S)
    src=src.replace('⟨h0,h1,h2,h3,h4⟩','⟨h0,h1,h2,h3⟩').replace(' | p4','')
    src=src.replace('  | .p4 => s.b4\n','').replace('  | .p4 => ⟨s.b0,s.b1,s.b2,s.b3,w⟩\n','')
    src=src.replace(',s.b4⟩','⟩')
    src=src.replace('cons a.b4 (cons a.b3 (cons a.b2 (cons a.b1 (cons a.b0 (leftRay r)))))','cons a.b3 (cons a.b2 (cons a.b1 (cons a.b0 (leftRay r))))')
    src=src.replace('cons (l.headD Sym.zero).b4 (cons (l.headD Sym.zero).b3 (cons (l.headD Sym.zero).b2 (cons (l.headD Sym.zero).b1 (cons (l.headD Sym.zero).b0 (leftRay l.tail)))))','cons (l.headD Sym.zero).b3 (cons (l.headD Sym.zero).b2 (cons (l.headD Sym.zero).b1 (cons (l.headD Sym.zero).b0 (leftRay l.tail))))')
    src=src.replace('(cons a.b4 (rightRay r))','(rightRay r)').replace('(cons (l.headD Sym.zero).b4 (rightRay l.tail))','(rightRay l.tail)')
    src=re.sub(r'^  \| .p4 => ⟨q,.*\n','',src,flags=re.M)
    src=src.replace('else .p4','else .p3').replace('    | .p3,true => more .p4\n    | .p4,false => more .p3\n    | .p4,true =>','    | .p3,true =>')
    src=re.sub(r'      · obtain ⟨e\',he\',rfl⟩ := h\n        obtain ⟨hpos,hrun⟩ := ih mv.next .p4 .*?\n      · subst e','      · subst e',src,flags=re.S)
    src=src.replace('961','385')
    assert not re.search(r'\bb4\b|\.p4\b|\b961\b',src)
    (extern/'OneLAWideBlock4.lean').write_text(src)
    src=(extern/'OneLAWideSparse5.lean').read_text().replace('BB6.Agent48Wide5','BB6.Agent48Wide4').replace('import OneLAWideBlock5','import OneLAWideBlock4')
    src=re.sub(r'\b192\b','96',src);src=re.sub(r'\b32\b','16',src)
    (extern/'OneLAWideSparse4.lean').write_text(src)


def decode(chunks,bits,stride):
    return [(c>>(bits*i))&((1<<bits)-1) for c in chunks for i in range(stride)]


def parse_vec(src,key,count):
    m=re.search(r'^  '+key+r' := ⟨(\d+),(\d+),#\[([^\]]*)\]⟩$',src,re.M);assert m,key
    b,k=map(int,m.groups()[:2]);cs=[int(x,16) for x in m[3].split(',')]
    vals=decode(cs,b,k);assert len(vals)>=count and not any(vals[count:]),key
    return vals[:count]


def parse_rows(src,key,count):
    m=re.search(r'^  '+key+r' := ⟨⟨(\d+),(\d+),#\[([^\]]*)\]⟩,(\d+),(\d+)⟩$',src,re.M);assert m,key
    b,k=int(m[1]),int(m[2]);bits,cap=int(m[4]),int(m[5]);assert b==bits*cap
    vals=decode([int(x,16) for x in m[3].split(',')],b,k);assert len(vals)>=count and not any(vals[count:]),key
    return [[v-1 for v in decode([x],bits,cap) if v] for x in vals[:count]]


def packed_tree(name,rows):
    # Chunk independently, retaining exact packed data; balanced lookup avoids
    # reducing a giant array literal for every finite-check access.
    stride=16; chunks=[]
    for i in range(0,len(rows),stride):
        vals=rows[i:i+stride]; bits=max(1,max(vals).bit_length())
        chunks.append((bits,sum(v<<(bits*j) for j,v in enumerate(vals))))
    def tree(lo,hi):
        if hi-lo==1:
            b,v=chunks[lo];return f'({b},{hex(v)})'
        mid=(lo+hi)//2;return f'if i < {mid} then ({tree(lo,mid)}) else ({tree(mid,hi)})'
    return f'def {name}Chunks (i : Nat) : Nat × Nat := {tree(0,len(chunks))}\ndef {name} (i : Nat) : Nat := if i < {len(rows)} then let p := {name}Chunks (i/16); (p.2 >>> (p.1*(i%16))) % (2^p.1) else 0\n'


def pack(xs,b):return sum(x<<(b*i) for i,x in enumerate(xs))


def emit(src,i,table,extern):
    d,n=map(int,re.search(r'def cert : BB6BlockFAR.Data (\d+) (\d+)',src).groups());D,N=d+1,n+1
    push=parse_vec(src,'pushCodes',D*16); ctrl=parse_vec(src,'controlCodes',D*12); aux=parse_vec(src,'auxiliaryCodes',D*96)
    pred=parse_rows(src,'predecessorCodes',D); edges=parse_rows(src,'edgeCodes',N*16);zn=parse_vec(src,'zeroNextCodes',N)
    zeros=int(re.search(r'^  zeroCodes := (\d+)$',src,re.M)[1]);assert all(v<=D for v in push) and all(v<N for v in ctrl+aux+zn)
    assert all(v<D*16 for row in pred for v in row) and all(v<N for row in edges for v in row)
    assert all((l*16+a in pred[j-1]) for l in range(D) for a in range(16) if (j:=push[l*16+a]))
    machine=re.search(r'^def machine : .*$',src,re.M)[0]
    assert re.search(r'def ctr : .*fromCodes (\[.*\])',src)[1]==str(table)
    name=f'OneLAWidth4H{i}'; ns=f'BB6.Agent48Wide4.H{i}'
    L=f'import OneLAWideSparse4\nset_option maxRecDepth 1000000\nset_option maxHeartbeats 0\nnamespace {ns}\n'+machine+'\n'
    L+='def unpack : Nat → Nat → Nat → List Nat\n  | 0,_,_ => []\n  | k+1,b,x => if x = 0 then [] else (x % 2^b).pred :: unpack k b (x >>> b)\n'
    L+='def pairs (fuel bits code : Nat) : List (Nat × Nat) := (unpack fuel bits code).map fun x => (x%16,x/16+1)\n'
    bits=max(D,N).bit_length()+4
    L+=packed_tree('pushData',[pack([a+16*(v-1)+1 for a,v in enumerate(push[l*16:l*16+16]) if v],bits) for l in range(D)])
    L+=f'def pushRows (l : Nat) : List (Nat × Nat) := pairs 16 {bits} (pushData l)\n'
    L+=packed_tree('ctrlData',ctrl)+packed_tree('auxData',aux)+packed_tree('zeroNextCodes',zn)
    pb=(D*16).bit_length();pc=max(1,max(map(len,pred)))
    L+=packed_tree('predData',[pack([x+1 for x in row],pb) for row in pred])
    L+=f'def predecessorCodes (l : Nat) : List Nat := unpack {pc} {pb} (predData l)\n'
    eb=N.bit_length(); ec=max(1,max(map(len,edges))); rowbits=4+eb*ec+1
    L+=packed_tree('edgeData',[pack([a+16*pack([v+1 for v in row],eb)+1 for a in range(16) if (row:=edges[v*16+a])],rowbits) for v in range(N)])
    L+=f'def edgeRows (v : Nat) : List (Nat × List Nat) := (unpack 16 {rowbits} (edgeData v)).map fun x => (x%16,unpack {ec} {eb} (x/16))\n'
    L+=f'def cert : ActiveData {d} {n} := {{ start := 0, pushRows := pushRows, controlCodes := ctrlData, auxiliaryCodes := auxData, predecessorCodes := predecessorCodes, edgeRows := edgeRows, zeroCodes := {zeros}, zeroNextCodes := zeroNextCodes }}\n'
    L+='theorem base_ok : cert.baseCheck = true := by decide +kernel\n'
    for label,fn in [('pred','cert.fastPredAt'),('rows','(cert.fastRowsAt machine)')]:
        def proof(lo,length):
            nonlocal L
            tag=f'{label}_{lo}_{length}'
            if length<=8:L+=f'theorem {tag} : rangeCheck {d} {fn} {lo} {length} = true := by decide +kernel\n'
            else:
                m=length//2;a=proof(lo,m);b=proof(lo+m,length-m)
                L+=f'theorem {tag} : rangeCheck {d} {fn} {lo} {length} = true := rangeCheck_join {d} {fn} {lo} {m} {length-m} {a} {b}\n'
            return tag
        tag=proof(0,D);L+=f'theorem {label}_full : (List.finRange {D}).all {fn} = true := rangeCheck_full _ _ {tag}\n'
    L+='theorem valid : cert.Valid machine := ⟨base_ok,pred_full,rows_full⟩\n'
    L+='theorem forever : ∀ k, ∃ c, BB6BlockFAR.run machine k BB6BlockFAR.primBlank = some c := cert.sound machine valid\n'
    L+=f'def ctr : BB6Coverage.PartialMachine := BB6Coverage.FAR.fromCodes {table}\n'
    L+='theorem same : ctr = BB6BlockFAR.partialTable machine := BB6.Agent31ThreeHole.tableOK_sound _ _ (by decide +kernel)\n'
    L+='theorem never (m : BB6Coverage.Machine) (hm : BB6Coverage.compatible ctr m) : BB6Coverage.NeverHalts m := BB6BlockFAR.transfer_never machine m (by simpa only [← same] using hm) forever\n#print axioms never\n'
    L+=f'end {ns}\n'
    (extern/(name+'.lean')).write_text(L)
    old=f'BB6.Agent48Raw139E0OneLABlocks.H{i}'
    return name, f'namespace {old}\nabbrev ctr := {ns}.ctr\ntheorem never (m : BB6Coverage.Machine) (hm : BB6Coverage.compatible ctr m) : BB6Coverage.NeverHalts m := {ns}.never m hm\n#print axioms never\nend {old}'


def main():
    imports,extern,part,spec=map(pathlib.Path,sys.argv[1:]);p=json.loads(part.read_text());s=json.loads(spec.read_text())
    ids={i for args,group in s['block_groups'] if args[0]==4 for i in group};assert len(ids)==31
    specialize(extern); seen=set()
    rx=re.compile(r'namespace BB6.Agent48Raw139E0OneLABlocks.H(\d+)\n(.*?)\nend BB6.Agent48Raw139E0OneLABlocks.H\1',re.S)
    for f in imports.glob('Raw139E0OneLABlock*.lean'):
        added=[]
        def repair(m):
            i=int(m[1]);
            if i not in ids:return m[0]
            assert i not in seen;seen.add(i);name,body=emit(m[2],i,p['open'][i],extern);added.append(name);return body
        orig=f.read_text();out=rx.sub(repair,orig)
        if added:f.write_text(''.join(f'import {m}\n' for m in added)+out)
    assert seen==ids,(seen,ids-seen)
    print('Repaired exact width-four witnesses:',sorted(seen))

if __name__=='__main__':main()
