import BoxCodes
namespace BB6.Agent49Box7
open BB6Coverage BB6.Agent49BoxCodes BB6.Agent49BoxOneHalt

def fixed : List Nat := [8,14,11,7,17,4,9,2,23]
def row (e f g : Nat) : List Nat := fixed ++ [e,f,g]
def codes : List (List Nat) := fixed.map (fun v => [v]) ++
  [(List.range 25).filter (· != 15),List.range 25,List.range 25]

def baseBox : Box := box codes

def eSlot : Slot := (4,true)
def fSlot : Slot := (5,false)
def gSlot : Slot := (5,true)

theorem fits_repr (m : Machine) (hm : Fits baseBox m) :
    ∃ e f g, e<25 ∧ e≠15 ∧ f<25 ∧ g<25 ∧ m=table (row e f g) := by
  have he : m eSlot ∈ ((List.range 25).filter (· != 15)).map decode := hm eSlot
  have hf : m fSlot ∈ (List.range 25).map decode := hm fSlot
  have hg : m gSlot ∈ (List.range 25).map decode := hm gSlot
  obtain ⟨e,he,hes⟩ := List.mem_map.mp he
  obtain ⟨f,hf,hfs⟩ := List.mem_map.mp hf
  obtain ⟨g,hg,hgs⟩ := List.mem_map.mp hg
  have hE := List.mem_filter.mp he
  refine ⟨e,f,g,List.mem_range.mp hE.1,by simpa using hE.2,List.mem_range.mp hf,List.mem_range.mp hg,?_⟩
  funext s
  rcases s with ⟨⟨q,hq⟩,b⟩
  have h : q=0 ∨ q=1 ∨ q=2 ∨ q=3 ∨ q=4 ∨ q=5 := by omega
  rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> cases b <;>
    first | exact hes.symm | exact hfs.symm | exact hgs.symm | exact List.mem_singleton.mp (hm _)

def fill (s : Slot) : Move := (decode ((row 1 1 1)[idx s]?.getD 1)).getD ⟨false,false,0⟩
theorem fill_ok (s : Slot) : some (fill s) ∈ baseBox s := by
  rcases s with ⟨⟨q,hq⟩,b⟩
  have h : q=0 ∨ q=1 ∨ q=2 ∨ q=3 ∨ q=4 ∨ q=5 := by omega
  rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> cases b <;> decide +revert

def oneHalt (e f g : Nat) : Bool :=
  ((if e=0 then 1 else 0)+(if f=0 then 1 else 0)+(if g=0 then 1 else 0) : Nat)==1

theorem oneHalt_of_unique (e f g : Nat)
    (h : ∃ s, ∀ x, table (row e f g) x=none ↔ x=s) : oneHalt e f g=true := by
  obtain ⟨s,hs⟩ := h
  have he : e=0 ↔ eSlot=s := (decode_none e).symm.trans (hs eSlot)
  have hf : f=0 ↔ fSlot=s := (decode_none f).symm.trans (hs fSlot)
  have hg : g=0 ↔ gSlot=s := (decode_none g).symm.trans (hs gSlot)
  have hS : s=eSlot ∨ s=fSlot ∨ s=gSlot := by
    have hnone := (hs s).mpr rfl
    rcases s with ⟨⟨q,hq⟩,b⟩
    have hh : q=0 ∨ q=1 ∨ q=2 ∨ q=3 ∨ q=4 ∨ q=5 := by omega
    rcases hh with rfl|rfl|rfl|rfl|rfl|rfl <;> cases b <;> first | contradiction | exact Or.inl rfl | exact Or.inr (Or.inl rfl) | exact Or.inr (Or.inr rfl)
  rcases hS with rfl|rfl|rfl <;> simp [eSlot,fSlot,gSlot] at he hf hg <;> simp [oneHalt,he,hf,hg]

#print axioms fits_repr
#print axioms oneHalt_of_unique
end BB6.Agent49Box7
