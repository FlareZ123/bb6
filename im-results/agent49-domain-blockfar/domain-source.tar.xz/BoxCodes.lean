import DomainBlockFARBridge
import BoxOneHalt

namespace BB6.Agent49BoxCodes
open BB6Coverage
open BB6.Agent49BoxOneHalt

def idx (s : Slot) : Nat := 2*s.1.val+s.2.toNat

def decode (v : Nat) : Transition :=
  if v=0 then none else some ⟨(v-1)/2%2==1,(v-1)%2==1,⟨(v-1)/4%6,by omega⟩⟩

def encode : Transition → Nat
  | none => 0
  | some m => 1+4*m.next.val+2*m.write.toNat+m.right.toNat

theorem decode_encode (t : Transition) : decode (encode t)=t := by
  cases t with
  | none => rfl
  | some t =>
    rcases t with ⟨w,r,⟨q,hq⟩⟩
    cases w <;> cases r <;> simp [encode,decode,Bool.toNat] <;> omega

theorem decode_none (v : Nat) : decode v=none ↔ v=0 := by
  by_cases h : v=0 <;> simp [decode,h]

def table (r : List Nat) : Machine := fun s => decode (r[idx s]?.getD 0)

def box (c : List (List Nat)) : Box := fun s => (c[idx s]?.getD []).map decode

def rowFits (c : List (List Nat)) (r : List Nat) : Bool :=
  (List.range 12).all fun i => (c[i]?.getD []).contains (r[i]?.getD 0)

theorem idx_lt (s : Slot) : idx s < 12 := by
  rcases s with ⟨⟨q,hq⟩,b⟩
  cases b <;> simp [idx,Bool.toNat] <;> omega

theorem rowFits_sound (c : List (List Nat)) (r : List Nat) (h : rowFits c r=true) : Fits (box c) (table r) := by
  intro s
  have hi := List.mem_range.mpr (idx_lt s)
  have hm := List.all_eq_true.mp h _ hi
  exact List.mem_map.mpr ⟨_,(by simpa using hm),rfl⟩

theorem blockFits (c : List (List Nat)) (m : Machine) (h : Fits (box c) m) :
    BB6BlockFAR.Domain.Fits (fun q b => (c[2*q.val+b.toNat]?.getD []).map
      (fun v => if v=0 then none else some ⟨(v-1)/2%2==1,(v-1)%2==1,BB6BlockFAR.finCode 5 ((v-1)/4)⟩))
      (BB6BlockFAR.Domain.fromSource m) := by
  intro q b
  obtain ⟨v,hv,he⟩ := List.mem_map.mp (h (q,b))
  refine List.mem_map.mpr ⟨v,hv,?_⟩
  unfold BB6BlockFAR.Domain.fromSource
  rw [←he]
  by_cases hz : v=0 <;> simp [decode,hz,BB6BlockFAR.finCode]

theorem code_never {d n} (C : BB6BlockFAR.Data d n) (c : List (List Nat))
    (G : BB6BlockFAR.Domain.Graph)
    (h : BB6BlockFAR.Domain.Valid C (fun q b => (c[2*q.val+b.toNat]?.getD []).map
      (fun v => if v=0 then none else some ⟨(v-1)/2%2==1,(v-1)%2==1,BB6BlockFAR.finCode 5 ((v-1)/4)⟩)) G)
    (m : Machine) (hm : Fits (box c) m) : NeverHalts m :=
  BB6BlockFAR.Domain.source_never C _ G h m (blockFits c m hm)

/-- A finite halt check bounds every possible reported halting time. -/
theorem haltBound (m : Machine) (B : Nat) (h : (run m B blank).isNone=true) :
    ∀ n, HaltsAfter m n → n+1≤B := by
  intro n hn
  by_cases hlt : n+1≤B
  · exact hlt
  ·
    have hsome := run_some_prefix m blank n B (by omega) hn.1
    cases he : run m B blank <;> simp [he] at h hsome

#print axioms rowFits_sound
#print axioms code_never
#print axioms haltBound
end BB6.Agent49BoxCodes
