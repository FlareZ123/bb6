import OneHalt

namespace BB6.Agent49BoxOneHalt
open BB6Coverage

abbrev Box := Slot → List Transition
def Fits (b : Box) (m : Machine) : Prop := ∀ s, m s ∈ b s

/-- Domain-preserving one-halt normalization. The existing unconstrained
normal form fills unused halt rows with a fixed move, which need not lie in
a residual rectangle. Here the replacement may be chosen per slot from the
actual domain. All queried ordinary rows and the actual halt row survive. -/
theorem normalize (b : Box) (fill : Slot → Move) (hf : ∀ s, some (fill s) ∈ b s)
    (m : Machine) (hm : Fits b m) (n : Nat) (hh : HaltsAfter m n) :
    ∃ s m', Fits b m' ∧ (∀ x, m' x = none ↔ x = s) ∧ HaltsAfter m' n := by
  rcases hh with ⟨hseen,hnext⟩
  cases hn : run m n blank with
  | none => simp [hn] at hseen
  | some d =>
    let s := readSlot d
    let m' : Machine := fun x => if x=s then none else some ((m x).getD (fill x))
    have hterminal : m s = none := by
      simp only [run,hn,Option.bind_some,rawStep] at hnext
      cases h : m s with
      | none => rfl
      | some t => simp [s,h] at hnext
    have hfit : Fits b m' := by
      intro x
      by_cases hx : x=s
      · subst x
        simpa [m',hterminal] using hm s
      · cases h : m x with
        | none => simpa [m',hx,h] using hf x
        | some t => simpa [m',hx,h] using hm x
    have hprefix : ∀ k, k<n → ∀ x, run m k blank = some x →
        m (readSlot x) = m' (readSlot x) := by
      intro k hk x hx
      obtain ⟨t,ht⟩ := defined_before_halt m blank n k hk (by simp [hn]) x hx
      have hneq : readSlot x ≠ s := by
        intro he
        rw [he,hterminal] at ht
        contradiction
      simp [m',hneq,ht]
    have hsame := run_agrees_on_prefix m m' blank n hprefix
    refine ⟨s,m',hfit,?_,?_⟩
    · intro x
      by_cases hx : x=s <;> simp [m',hx]
    · constructor
      · rw [←hsame,hn]; rfl
      · rw [run,←hsame,hn]
        simp [rawStep,m',s]

/-- A box of any finite or infinite cardinality can be bounded by its
one-halt members, as long as every row admits an ordinary replacement. -/
theorem upper_of_one_halt (b : Box) (fill : Slot → Move) (hf : ∀ s, some (fill s) ∈ b s)
    (B : Nat) (h : ∀ m, Fits b m → (∃ s, ∀ x, m x=none ↔ x=s) → DecidedBelow B m) :
    ∀ m, Fits b m → ∀ n, HaltsAfter m n → n+1≤B := by
  intro m hm n hn
  obtain ⟨s,m',hm',hu,hh⟩ := normalize b fill hf m hm n hn
  rcases h m' hm' ⟨s,hu⟩ with hnever|⟨k,hk,hhalt⟩
  · have bad := hnever (n+1)
    simp [hh.2] at bad
  · have he := halting_time_unique m' n k hh hhalt
    omega

#print axioms normalize
#print axioms upper_of_one_halt
end BB6.Agent49BoxOneHalt
