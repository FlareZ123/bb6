import BlockFAR

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace BB6BlockFAR.Domain
open BB6BlockFAR

/-- The machine is chosen once from a product of transition domains.
The checker is stronger: it allows an arbitrary permitted choice on every
visit to a slot. A successful certificate is thus valid for every fixed
completion in the product. -/
abbrev Domains := Q → Bool → List (Option Move)
def Fits (D : Domains) (M : Table) : Prop := ∀ q b, M q b ∈ D q b

structure Micro where
  q : Q
  p : Pos
  a : Sym
  deriving DecidableEq, Repr

def entry (q : Q) (dir : Bool) (a : Sym) : Micro := ⟨q,EntryPos dir,a⟩

def Micro.render (m : Micro) (l r : List Sym) : Prim :=
  BB6BlockFAR.render m.q m.p m.a l r

/-- A micro-step either stays in the current block or leaves it. Exit.steps
is set to one because this is one primitive move from the microstate. -/
def microNext (m : Micro) (mv : Move) : Micro ⊕ Exit :=
  let w := m.a.write m.p mv.write
  match m.p,mv.right with
  | .lo,false => .inr ⟨1,mv.next,false,w⟩
  | .hi,true => .inr ⟨1,mv.next,true,w⟩
  | .lo,true => .inl ⟨mv.next,.mid,w⟩
  | .mid,true => .inl ⟨mv.next,.hi,w⟩
  | .mid,false => .inl ⟨mv.next,.lo,w⟩
  | .hi,false => .inl ⟨mv.next,.mid,w⟩

/-- Exact primitive semantics for a micro-step, without any finite-exit
assumption. The exterior words are unchanged on internal moves. -/
theorem microNext_sound (M : Table) (m : Micro) (mv : Move)
    (hm : M m.q (m.a.read m.p) = some mv) (l r : List Sym) :
    primStep M (m.render l r) = some
      (match microNext m mv with
       | .inl m' => m'.render l r
       | .inr e => (BlockConfig.mk m.q true l (m.a::r)).next e.q e.dir e.w |>.render) := by
  rcases m with ⟨q,p,a⟩
  cases p <;> cases hd : mv.right <;>
    simp [microNext,Micro.render,render,Sym.read,Sym.write,primStep,hm,hd,BlockConfig.next,BlockConfig.render,EntryPos] at *
  · rw [leftRay_unfold l]
    cases l <;> simp [rightRay]
  · rw [rightRay_unfold r]
    cases r <;> simp [leftRay]

/-- The checker accepts finite *closed internal graphs*, not merely finite
exit paths. A safe internal cycle needs no special lasso certificate. -/
abbrev Graph := Q → Bool → Sym → List Micro

def exitCheck {d n} (C : Data d n) (l : LState d) (q : Q)
    (dir : Bool) (a : Sym) (e : Exit) : Bool :=
  let p := C.control l q dir
  if e.dir then
    match C.push l e.w with
    | none => false
    | some j => (C.targets p a).all fun v => C.inclusion v (C.control j e.q true)
  else (C.predecessors l).all (C.leftCheck p a e)

def edgeCheck {d n} (C : Data d n) (l : LState d) (q : Q)
    (dir : Bool) (a : Sym) (g : List Micro) (m : Micro) : Option Move → Bool
  | none => false
  | some mv => match microNext m mv with
    | .inl m' => decide (m' ∈ g)
    | .inr e => exitCheck C l q dir a e

def activeCheck {d n} (C : Data d n) (D : Domains) (G : Graph)
    (l : LState d) (q : Q) (dir : Bool) (a : Sym) : Bool :=
  let g := G q dir a
  decide (entry q dir a ∈ g) &&
    g.all fun m => (D m.q (m.a.read m.p)).all (edgeCheck C l q dir a g m)

def rowCheck {d n} (C : Data d n) (D : Domains) (G : Graph)
    (l : LState d) (q : Q) (dir : Bool) (a : Sym) : Bool :=
  if (C.targets (C.control l q dir) a).isEmpty then true
  else activeCheck C D G l q dir a

def rowsAt {d n} (C : Data d n) (D : Domains) (G : Graph) (l : LState d) : Bool :=
  (List.finRange 6).all fun q => [false,true].all fun dir => symbols.all (rowCheck C D G l q dir)

def rowsCheck {d n} (C : Data d n) (D : Domains) (G : Graph) : Bool :=
  (List.finRange (d+1)).all (rowsAt C D G)

def Valid {d n} (C : Data d n) (D : Domains) (G : Graph) : Prop :=
  C.baseCheck = true ∧ C.predCheck = true ∧ rowsCheck C D G = true

/-- A macro exit with the accepted side-language condition preserves the
existing deterministic BlockFAR invariant. Only the exit label matters. -/
theorem exit_sound {d n} (C : Data d n) (hb : C.baseCheck = true)
    (hp : C.predCheck = true) (c : BlockConfig) (l : LState d)
    (hl : C.leftVal c.l = some l) (hr : C.accept c.r (C.control l c.q c.dir))
    (e : Exit) (he : exitCheck C l c.q c.dir (c.r.headD Sym.zero) e = true) :
    C.Invariant (c.next e.q e.dir e.w) := by
  simp only [Data.baseCheck,Bool.and_eq_true,decide_eq_true_eq] at hb
  have hz (v : Node n) : C.zeroCheck v = true := List.all_eq_true.mp hb.2 v (List.mem_finRange v)
  obtain ⟨v,hv,hrest⟩ := C.accept_pop hz c.r _ hr
  unfold exitCheck at he
  cases hed : e.dir with
  | true =>
    simp only [hed,ite_true] at he
    cases hj : C.push l e.w with
    | none => simp [hj] at he
    | some j =>
      rw [hj] at he
      have hi := List.all_eq_true.mp he v hv
      refine ⟨j,?_,?_⟩
      · simp [BlockConfig.next,Data.leftVal,hl,hj]
      · exact C.inclusion_sound v (C.control j e.q true) hi c.r.tail hrest
  | false =>
    simp only [hed,Bool.false_eq_true,ite_false] at he
    obtain ⟨j,hj,hpush⟩ := C.leftVal_pop hb.1.1 c.l l hl
    have hpc := List.all_eq_true.mp hp j (List.mem_finRange j)
    have hpp := List.all_eq_true.mp hpc (c.l.headD Sym.zero) (symbols_complete _)
    unfold Data.predCheckAt at hpp
    rw [hpush] at hpp
    have hmem := of_decide_eq_true hpp
    have hh := List.all_eq_true.mp he (j,c.l.headD Sym.zero) hmem
    simp only [Data.leftCheck,Bool.and_eq_true,decide_eq_true_eq] at hh
    refine ⟨j,?_,?_⟩
    · simpa [BlockConfig.next,hed] using hj
    · change C.accept (c.l.headD Sym.zero::e.w::c.r.tail) (C.control j e.q false)
      exact ⟨_,hh.1,v,of_decide_eq_true (List.all_eq_true.mp hh.2 v hv),hrest⟩

theorem active_of_invariant {d n} (C : Data d n) (D : Domains) (G : Graph)
    (h : Valid C D G) (c : BlockConfig) (l : LState d)
    (hr : C.accept c.r (C.control l c.q c.dir)) :
    activeCheck C D G l c.q c.dir (c.r.headD Sym.zero) = true := by
  have hb := h.1
  simp only [Data.baseCheck,Bool.and_eq_true,decide_eq_true_eq] at hb
  have hz (v : Node n) : C.zeroCheck v = true := List.all_eq_true.mp hb.2 v (List.mem_finRange v)
  obtain ⟨v,hv,_⟩ := C.accept_pop hz c.r _ hr
  have hrows := List.all_eq_true.mp h.2.2 l (List.mem_finRange l)
  have hq := List.all_eq_true.mp hrows c.q (List.mem_finRange c.q)
  have hdir := List.all_eq_true.mp hq c.dir (by cases c.dir <;> simp)
  have H := List.all_eq_true.mp hdir (c.r.headD Sym.zero) (symbols_complete _)
  have hn : (C.targets (C.control l c.q c.dir) (c.r.headD Sym.zero)).isEmpty = false := by
    cases hh : C.targets (C.control l c.q c.dir) (c.r.headD Sym.zero) with
    | nil =>
      change v ∈ C.targets (C.control l c.q c.dir) (c.r.headD Sym.zero) at hv
      rw [hh] at hv
      contradiction
    | cons _ _ => rfl
  unfold rowCheck at H
  rw [hn] at H
  exact H

def Extended {d n} (C : Data d n) (G : Graph) (x : Prim) : Prop :=
  ∃ c : BlockConfig, C.Invariant c ∧
    ∃ m ∈ G c.q c.dir (c.r.headD Sym.zero), x = m.render c.l c.r.tail

theorem entry_extended {d n} (C : Data d n) (D : Domains) (G : Graph)
    (h : Valid C D G) (c : BlockConfig) (hc : C.Invariant c) : Extended C G c.render := by
  obtain ⟨l,hl,hr⟩ := hc
  have ha := active_of_invariant C D G h c l hr
  simp only [activeCheck,Bool.and_eq_true,decide_eq_true_eq] at ha
  exact ⟨c,⟨l,hl,hr⟩,entry c.q c.dir (c.r.headD Sym.zero),ha.1,rfl⟩

/-- Every primitive step exists and preserves the extended invariant,
including arbitrary permitted transitions inside the current block. -/
theorem closed {d n} (C : Data d n) (D : Domains) (G : Graph)
    (h : Valid C D G) (M : Table) (hm : Fits D M) (x : Prim) (hx : Extended C G x) :
    ∃ y, primStep M x = some y ∧ Extended C G y := by
  obtain ⟨c,⟨l,hl,hr⟩,m,hmem,rfl⟩ := hx
  have ha := active_of_invariant C D G h c l hr
  simp only [activeCheck,Bool.and_eq_true,decide_eq_true_eq] at ha
  have hh := List.all_eq_true.mp ha.2 m hmem
  have he := List.all_eq_true.mp hh (M m.q (m.a.read m.p)) (hm _ _)
  cases hm' : M m.q (m.a.read m.p) with
  | none => simp [hm',edgeCheck] at he
  | some mv =>
    rw [hm'] at he
    have hs := microNext_sound M m mv hm' c.l c.r.tail
    cases hn : microNext m mv with
    | inl m' =>
      have hg : m' ∈ G c.q c.dir (c.r.headD Sym.zero) := by simpa [edgeCheck,hn] using he
      exact ⟨_,by simpa [hn] using hs, c,⟨l,hl,hr⟩,m',hg,rfl⟩
    | inr e =>
      have hex : exitCheck C l c.q c.dir (c.r.headD Sym.zero) e = true := by simpa [edgeCheck,hn] using he
      have hnext := exit_sound C h.1 h.2.1 c l hl hr e hex
      have hs' : primStep M (m.render c.l c.r.tail) = some (c.next e.q e.dir e.w).render := by
        cases hd : e.dir <;> simpa [hn,BlockConfig.next,hd] using hs
      exact ⟨_,hs',entry_extended C D G h _ hnext⟩

/-- A single checked rectangle proves nonhalting for every fixed completion,
without enumerating those completions and without an exit-time bound. -/
theorem sound {d n} (C : Data d n) (D : Domains) (G : Graph)
    (h : Valid C D G) (M : Table) (hm : Fits D M) :
    ∀ k, ∃ x, run M k primBlank = some x := by
  have hc : Extended C G primBlank := by
    rw [←render_blank]
    exact entry_extended C D G h blockBlank (C.blank_invariant h.1)
  have stepAll (k : Nat) (x : Prim) (hx : Extended C G x) :
      ∃ y, run M k x = some y := by
    induction k generalizing x with
    | zero => exact ⟨x,rfl⟩
    | succ k ih =>
      obtain ⟨y,hy,hiy⟩ := closed C D G h M hm x hx
      obtain ⟨z,hz⟩ := ih y hiy
      exact ⟨z,by simp [run,hy,hz]⟩
  intro k
  exact stepAll k primBlank hc

#print axioms microNext_sound
#print axioms exit_sound
#print axioms closed
#print axioms sound
end BB6BlockFAR.Domain
