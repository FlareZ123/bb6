import DomainBlockFAR
import BlockFARBridge

namespace BB6BlockFAR.Domain

/-- Exact transport to the repository's raw source machine model. -/
def fromSource (m : BB6Coverage.Machine) : Table := fun q b =>
  (m (q,b)).map fun v => ⟨v.write,v.right,v.next⟩

theorem fromSource_compatible (m : BB6Coverage.Machine) :
    BB6Coverage.compatible (partialTable (fromSource m)) m := by
  intro s t ht
  rcases s with ⟨q,b⟩
  cases hm : m (q,b) with
  | none => simp [partialTable,fromSource,hm] at ht
  | some mv =>
    simp [partialTable,fromSource,hm,sourceMove] at ht
    exact ht

theorem source_never {d n} (C : Data d n) (D : Domains) (G : Graph)
    (h : Valid C D G) (m : BB6Coverage.Machine) (hm : Fits D (fromSource m)) :
    BB6Coverage.NeverHalts m :=
  transfer_never (fromSource m) m (fromSource_compatible m) (sound C D G h _ hm)

#print axioms source_never
end BB6BlockFAR.Domain
