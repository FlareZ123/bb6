"""Raw10 base34 box7, normalized to one actual halt."""
from itertools import product
from collections import Counter
from generate_domain import synthesize,UnsafeAbstractRow,emit
from pathlib import Path
import json
BASE=(8,14,11,7,17,4,9,2,23)
DOM=(tuple(v for v in range(25) if v!=15),tuple(range(25)),tuple(range(25)))

def simulate(row,lim=1000,period=128):
 q=h=0; tape=set();trace=[]; prev=[[] for _ in range(6)]
 for n in range(lim+1):
  v=row[2*q+(h in tape)]
  if not v:return ['halt',n]
  lo=hi=h;k=n
  for j in reversed(prev[q]):
   if n-j>period:break
   while k>j:
    k-=1;lo=min(lo,trace[k][0]);hi=max(hi,trace[k][0])
   hh,ss=trace[j];d=h-hh
   if d>=0:
    if all(x+d in tape for x in ss if x>=lo) and all(x-d in ss for x in tape if x>=lo+d):return ['cycle',j,n-j,True,lo]
   if d<=0:
    if all(x+d in tape for x in ss if x<=hi) and all(x-d in ss for x in tape if x<=hi+d):return ['cycle',j,n-j,False,hi]
  prev[q].append(n);trace.append((h,frozenset(tape)))
  m=v-1
  if m&2:tape.add(h)
  else:tape.discard(h)
  h+=1 if m&1 else -1;q=m>>2
 return ['open']

if __name__=='__main__':
 out=[]
 for v in product(*DOM):
  if v.count(0)!=1:continue
  r=simulate(BASE+v,lim=300)
  out.append([list(v),r])
 print(Counter(r[0] for v,r in out));print('max halt',max(r[1] for v,r in out if r[0]=='halt'));print('open',[(v,r) for v,r in out if r[0]=='open']);Path('box7_classify.json').write_text(json.dumps(out,separators=(',',':')))
