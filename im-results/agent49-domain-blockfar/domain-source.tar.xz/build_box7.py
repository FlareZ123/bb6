#!/usr/bin/env python3
"""Regenerate the 37 domain certificates, using the fixed manifest.
Run in this directory. Does not repeat the exploratory greedy search.
"""
from pathlib import Path
import json
from generate_domain import synthesize,emit

def main():
    root=Path(__file__).resolve().parent
    manifest=json.loads((root/'box7_groups/index.json').read_text())
    p=root/'box7_groups'; ds=[];ps=[]
    fixed=[8,14,11,7,17,4,9,2,23]
    for i,g in enumerate(manifest['groups']):
        name=g['name']; assert name==f'Box7Domain{i}'
        data=synthesize([[v] for v in fixed]+g['domains'],*g['params'],limit=300000)
        emit(data,p,name,chunk=1)
        ds.append('\n'.join((p/f'{name}Data.lean').read_text().splitlines()[3:]))
        ps.append('\n'.join((p/f'{name}Proof.lean').read_text().splitlines()[4:]))
    opts='set_option maxRecDepth 100000\nset_option maxHeartbeats 0\n'
    (root/'Box7AllData.lean').write_text('import DomainBlockFAR\n'+opts+'\n\n'.join(ds)+'\n')
    (root/'Box7AllProof.lean').write_text('import Box7AllData\nimport RangeCheck\n'+opts+'\n\n'.join(ps)+'\n')

if __name__=='__main__':main()
