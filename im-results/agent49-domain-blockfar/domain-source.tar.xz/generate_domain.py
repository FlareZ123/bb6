#!/usr/bin/env python3
"""Untrusted synthesis of one BlockFAR certificate for a transition-domain box.
Codes: 0 is halt; 1..24 are state-major (0L,0R,1L,1R) choices.
All permitted transitions are considered on every microstep. Internal cycles
are accepted when the finite local graph excludes halt and all exits close.
The Lean domain checker independently validates the finite data.
"""
from collections import defaultdict, deque
from functools import cache
from pathlib import Path
import argparse, json, sys

class UnsafeAbstractRow(RuntimeError): pass

def decode(v):
    if not v: return None
    m=v-1
    return (m>>1&1,m&1,m>>2)

def synthesize(domains, cap=2, mod=4, runs=2, limit=300000, minimize_left=True):
    assert len(domains)==12 and all(d and len(set(d))==len(d) and all(0<=v<=24 for v in d) for d in domains)
    moves=[tuple(map(decode,d)) for d in domains]
    graph={}
    @cache
    def macro(q,d,a):
        root=(q,0 if d else 2,a)
        seen={root}; work=[root]; exits=set()
        while work:
            q0,h,w0=work.pop()
            for mv in moves[2*q0+(w0>>h&1)]:
                if mv is None: raise UnsafeAbstractRow(f'permitted halt at microstate {(q0,h,w0)} from {(q,d,a)}')
                w,d2,q2=mv
                a2=(w0 & ~(1<<h))|(w<<h)
                h2=h+(1 if d2 else -1)
                if not 0<=h2<3:exits.add((q2,d2,a2))
                else:
                    k=(q2,h2,a2)
                    if k not in seen:seen.add(k);work.append(k)
        graph[q,int(d),a]=sorted(seen)
        return tuple(sorted(exits))
    left=[()]; leftids={():0}; delta={}; pred=defaultdict(list)
    nodes=[('T',)]; nodeids={nodes[0]:0}; edges=defaultdict(set)
    copier=defaultdict(set); pending=defaultdict(set); events=deque()
    def node(key):
        if key not in nodeids:nodeids[key]=len(nodes);nodes.append(key)
        return nodeids[key]
    def ctrl(l,q,d):return node(('c',l,q,int(d)))
    def add(s,a,t):
        if (a,t) not in edges[s]:edges[s].add((a,t));events.append((s,a,t))
    def copy(p,v):
        if p not in copier[v]:
            copier[v].add(p)
            for a,t in tuple(edges[v]):add(p,a,t)
    def applyleft(l0,b,q,w,v):
        p=ctrl(l0,q,False);x=node(('x',p,b));add(x,w,v);add(p,b,x)
    def push(l,a):
        key=(l,a)
        if key in delta:return delta[key]
        xs=left[l]
        if not xs and a==0:ys=()
        elif xs and xs[0][0]==a:
            s,n,m=xs[0];ys=((s,min(cap,n+1),(m+1)%mod),)+xs[1:]
        else:ys=((a,1,1%mod),)+xs[:runs-1]
        if ys not in leftids:leftids[ys]=len(left);left.append(ys)
        j=leftids[ys];delta[key]=j;pred[j].append(key)
        for q,w,v in tuple(pending[j]):applyleft(l,a,q,w,v)
        return j
    push(0,0);add(0,0,0);copy(ctrl(0,0,True),0)
    count=0
    while events:
        s,a,v=events.popleft();count+=1
        if count>limit:raise RuntimeError('saturation event cap')
        for p in tuple(copier[s]):add(p,a,v)
        key=nodes[s]
        if key[0]!='c':continue
        _,l,q,d=key
        for q2,d2,w in macro(q,d,a):
            if d2:copy(ctrl(push(l,w),q2,True),v)
            else:
                pending[l].add((q2,w,v))
                for l0,b in tuple(pred[l]):applyleft(l0,b,q2,w,v)
    zero={0};rev=defaultdict(list)
    for s,es in edges.items():
        for a,t in es:
            if a==0:rev[t].append(s)
    zq=deque(zero)
    while zq:
        for s in rev[zq.popleft()]:
            if s not in zero:zero.add(s);zq.append(s)
    assert all(v not in zero or p in zero for v,ps in copier.items() for p in ps)
    D=len(left);N=len(nodes);rows=defaultdict(set)
    for s,es in edges.items():
        for a,t in es:rows[s,a].add(t)
    cls=[int(s in zero) for s in range(N)]
    while True:
        keys={};new=[]
        for s in range(N):
            k=(s in zero,tuple(tuple(sorted({cls[t] for t in rows[s,a]})) for a in range(8)))
            new.append(keys.setdefault(k,len(keys)))
        if new==cls:break
        cls=new
    dead=len(set(cls));C=dead+1;r2=defaultdict(set);z2={cls[s] for s in zero}
    for (s,a),ts in rows.items():r2[cls[s],a].update(cls[t] for t in ts)
    ctr={tuple(rest):cls[i] for i,(k,*rest) in enumerate(nodes) if k=='c'};aux={}
    for i,(k,*rest) in enumerate(nodes):
        if k=='x':
            p,b=rest;_,l,q,d=nodes[p];aux[l,q,d,b]=cls[i]
    if minimize_left:
        sig=[tuple(ctr.get((l,q,d),dead) for q in range(6) for d in range(2))+tuple(aux.get((l,q,0,b),dead) for q in range(6) for b in range(8)) for l in range(D)]
        lc=[0]*D
        while True:
            keys={};new=[]
            for l in range(D):
                k=(sig[l],tuple(lc[delta[l,a]] if (l,a) in delta else -1 for a in range(8)))
                new.append(keys.setdefault(k,len(keys)))
            if new==lc:break
            lc=new
        D=len(set(lc));delta={(lc[l],a):lc[j] for (l,a),j in delta.items()}
        ctr={(lc[l],q,d):v for (l,q,d),v in ctr.items()};aux={(lc[l],q,d,b):v for (l,q,d,b),v in aux.items()}
    pred=defaultdict(list)
    for (l,a),j in sorted(delta.items()):pred[j].append((l,a))
    assert delta[0,0]==0 and ctr[0,0,1] in z2
    zeroNext=[min(r2[s,0]&z2) if s in z2 else dead for s in range(C)]
    active=0
    for l in range(D):
        for q in range(6):
            for d in range(2):
                p=ctr.get((l,q,d),dead)
                for a in range(8):
                    ts=r2[p,a]
                    if not ts:continue
                    active+=1
                    for q2,d2,w in macro(q,d,a):
                        if d2:
                            p2=ctr[delta[l,w],q2,1]
                            for v in ts:
                                assert v not in z2 or p2 in z2
                                assert all(r2[v,b]<=r2[p2,b] for b in range(8))
                        else:
                            for l0,b in pred[l]:
                                p2=ctr[l0,q2,0];x=aux[l0,q2,0,b]
                                assert x in r2[p2,b] and ts<=r2[x,w]
    data=dict(domains=domains,D=D,C=C,push=[1+delta[l,a] if (l,a) in delta else 0 for l in range(D) for a in range(8)],
        ctrl=[ctr.get((l,q,d),dead) for l in range(D) for q in range(6) for d in range(2)],
        aux=[aux.get((l,q,0,b),dead) for l in range(D) for q in range(6) for b in range(8)],
        edges=[sorted(r2[s,a]) for s in range(C) for a in range(8)],zeroNext=zeroNext,
        pred=[[8*l+a for l,a in pred[j]] for j in range(D)],zero=sorted(z2),
        graph=[[24*q0+8*h+w for q0,h,w in graph.get((q,d,a),[])] for q in range(6) for d in range(2) for a in range(8)],
        stats=dict(left=D,right=C,edges=sum(map(len,r2.values())),zero=len(z2),active=active,micrographs=len(graph),events=count))
    return data

def emit(data, out, name='DomainConcrete', chunk=5):
    D,C=data['D'],data['C']; b=max(D,C).bit_length();pb=(8*D).bit_length()
    def pack(xs,b):return sum(v<<(b*i) for i,v in enumerate(xs))
    def vector(xs,b,stride):
        assert all(0<=x<2**b for x in xs)
        words=[hex(pack(xs[i:i+stride],b)) for i in range(0,len(xs),stride)]
        return f'⟨{b},{stride},#[\n'+',\n'.join(','.join(words[i:i+4]) for i in range(0,len(words),4))+']⟩'
    def packedrows(xs,b,stride):
        length=max(1,max(map(len,xs)))
        return f'⟨{vector([pack([v+1 for v in x],b) for x in xs],b*length,stride)},{b},{length}⟩'
    def lean_list(xs):return '['+','.join(map(str,xs))+']'
    s='''import DomainBlockFAR
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6BlockFAR.Domain.'''+name+'\n\nopen BB6BlockFAR\n'
    s+='def domainCodes : List (List Nat) := [\n'+',\n'.join(map(lean_list,data['domains']))+']\n'
    s+='''def decodeMove (v : Nat) : Option Move :=
  if v=0 then none else some ⟨(v-1)/2%2==1,(v-1)%2==1,finCode 5 ((v-1)/4)⟩
def domains : Domains := fun q b => (domainCodes[2*q.val+b.toNat]?.getD []).map decodeMove

def microOfCode (v : Nat) : Micro :=
  ⟨finCode 5 (v/24), (if v/8%3=0 then .lo else if v/8%3=1 then .mid else .hi), Sym.ofCode (v%8)⟩
'''
    s+='def graphCodes : List (List Nat) := [\n'+',\n'.join(map(lean_list,data['graph']))+']\n'
    s+='def graphs : Graph := fun q dir a => (graphCodes[16*q.val+8*dir.toNat+a.code]?.getD []).map microOfCode\n'
    for name0,key in [('pushCodes','push'),('controlCodes','ctrl'),('auxiliaryCodes','aux'),('zeroNextCodes','zeroNext')]:
        s+=f'def {name0} : Packed := '+vector(data[key],b,32)+'\n\n'
    s+='def predecessorCodes : PackedRows := '+packedrows(data['pred'],pb,3)+'\n\n'
    s+='def edgeCodes : PackedRows := '+packedrows(data['edges'],b,10)+'\n\n'
    s+='def zeroCodes : Nat := '+hex(sum(1<<i for i in data['zero']))+'\n\n'
    s+=f'''def cert : Data {D-1} {C-1} := {{
  start := 0
  pushCodes := pushCodes
  controlCodes := controlCodes
  auxiliaryCodes := auxiliaryCodes
  predecessorCodes := predecessorCodes
  edgeCodes := edgeCodes
  zeroCodes := zeroCodes
  zeroNextCodes := zeroNextCodes
}}
end BB6BlockFAR.Domain.{name}
'''
    out.mkdir(parents=True,exist_ok=True);(out/(name+'Data.lean')).write_text(s)
    s=f'''import {name}Data
import RangeCheck
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6BlockFAR.Domain.{name}
open BB6BlockFAR

theorem base_ok : cert.baseCheck = true := by decide +kernel
'''
    for kind,f in [('pred','(fun l => symbols.all (cert.predCheckAt l))'),('rows','(rowsAt cert domains graphs)')]:
        for i in range(0,D,chunk):s+=f'theorem {kind}_{i} : rangeCheck {D-1} {f} {i} {min(chunk,D-i)} = true := by decide +kernel\n'
        s+=f'theorem {kind}_full : rangeCheck {D-1} {f} 0 {D} = true := by\n'
        expr=f'{kind}_0'
        for i in range(chunk,D,chunk):expr=f'(rangeCheck_join {D-1} {f} 0 {i} {min(chunk,D-i)} {expr} {kind}_{i})'
        s+='  exact '+expr+'\n'
    s+=f'''theorem pred_ok : cert.predCheck = true := rangeCheck_full _ _ pred_full
theorem rows_ok : rowsCheck cert domains graphs = true := rangeCheck_full _ _ rows_full
theorem valid : Valid cert domains graphs := ⟨base_ok,pred_ok,rows_ok⟩
theorem never (M : Table) (hm : Fits domains M) : ∀ k, ∃ c, run M k primBlank = some c :=
  sound cert domains graphs valid M hm
#print axioms never
end BB6BlockFAR.Domain.{name}
'''
    (out/(name+'Proof.lean')).write_text(s)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('domains',help='JSON list of 12 allowed code lists, or path to such a file');p.add_argument('--out',type=Path,default=Path('.'));p.add_argument('--name',default='DomainConcrete');p.add_argument('--cap',type=int,default=2);p.add_argument('--mod',type=int,default=4);p.add_argument('--runs',type=int,default=2);p.add_argument('--limit',type=int,default=300000);p.add_argument('--chunk',type=int,default=5);a=p.parse_args()
    ds=json.loads(a.domains if a.domains.startswith('[') else Path(a.domains).read_text())
    data=synthesize(ds,a.cap,a.mod,a.runs,a.limit)
    print(json.dumps(data['stats'],sort_keys=True));emit(data,a.out,a.name,a.chunk)
    (a.out/(a.name+'.json')).write_text(json.dumps(data,separators=(',',':'))+'\n')
