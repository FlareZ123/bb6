from box7 import *
from time import monotonic
from math import prod
from itertools import product
PARAMS=[(1,1,1),(2,2,1),(2,4,2),(2,4,3),(3,4,3),(2,4,4)]
rows=json.loads(Path('box7_classify.json').read_text())
nonhalt={tuple(v) for v,r in rows if r[0]!='halt'}
known={tuple(v):r for v,r in rows}

def support(row,n):
 q=h=0;t=set();seen=set()
 for i in range(n+1):
  s=2*q+(h in t);seen.add(s);v=row[s]
  if not v:break
  m=v-1
  if m&2:t.add(h)
  else:t.discard(h)
  h+=1 if m&1 else -1;q=m>>2
 return tuple(row[s] if s in seen else 25 for s in range(9,12))

def attempt(dom,params=PARAMS,limit=150000):
 for cap,mod,runs in params:
  try:return synthesize([[v] for v in BASE]+[list(d) for d in dom],cap,mod,runs,limit=limit),(cap,mod,runs)
  except RuntimeError:pass
 return None,None

def cover(dom,vs):return {v for v in vs if all(v[i] in dom[i] for i in range(3))}

def norm_safe(dom):
 # A candidate with a known halting single-halt completion cannot work.
 return not any(known[v][0]=='halt' for v in product(*dom) if v in known)

def seed(v):
 r=known[v]
 if r[0]=='cycle':
  pat=support(BASE+v,r[1]+r[2]-1)
  return tuple((x,) if x!=25 else DOM[i] for i,x in enumerate(pat))
 return tuple((x,) for x in v)

def grow(dom,initial,params,remaining):
 dom=tuple(tuple(d) for d in dom);data=initial
 # Prefer the greatest actual normalized coverage gain, then all-box mass.
 while True:
  old=cover(dom,remaining);opts=[]
  for i,d in enumerate(dom):
   for v in DOM[i]:
    if v in d:continue
    dd=dom[:i]+(tuple(sorted(d+(v,))),)+dom[i+1:]
    if not norm_safe(dd):continue
    new=cover(dd,remaining)
    opts.append((len(new)-len(old),prod(map(len,dd)),dd))
  opts.sort(reverse=True)
  success=False
  for gain,mass,dd in opts:
   # Do not widen if it has no useful effect on current target, except that
   # wildcard expansion from a support seed is already retained.
   if gain==0:continue
   d,p=attempt(dd,[params],limit=150000)
   if d is not None:
    dom,data,params=dd,d,p;success=True;break
  if not success:return dom,data,params

def main():
 left=set(nonhalt);fail=set();out=[];start=monotonic()
 # Start with the six cases that were not short side cycles.
 order=sorted(nonhalt,key=lambda v:(known[v][0]!='open',-len(cover(seed(v),nonhalt)),v))
 for v in order:
  if v not in left:continue
  dom=seed(v);d,p=attempt(dom)
  if d is None:
   dom=tuple((x,) for x in v);d,p=attempt(dom)
  if d is None:
   fail.add(v);continue
  dom,d,p=grow(dom,d,p,left)
  gained=cover(dom,left);left-=gained;fail-=gained
  name=f'Box7Domain{len(out)}';out.append(dict(name=name,domains=dom,params=p,stats=d['stats'],normalized=len(gained)))
  emit(d,Path('box7_groups'),name,chunk=1)
  Path('box7_groups',name+'.json').write_text(json.dumps(d,separators=(',',':')))
  print(name,'seed',v,'dims',list(map(len,dom)),'gained',len(gained),'remaining',len(left),'stats',d['stats'],flush=True)
  if not left:break
 print('done',len(out),'remaining',len(left),'seconds',monotonic()-start)
 Path('box7_groups/index.json').write_text(json.dumps(dict(groups=out,left=sorted(left)),separators=(',',':')))
if __name__=='__main__':main()
