import BlockMacro
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent49FamilyLate
open BB6BlockFAR

def machine : Table := fun q b =>
  match q.val,b with
  | 0,false => some ⟨true,true,1⟩
  | 0,true  => some ⟨true,true,5⟩
  | 1,false => some ⟨true,false,2⟩
  | 1,true  => some ⟨true,false,1⟩
  | 2,false => some ⟨false,false,4⟩
  | 2,true  => some ⟨false,false,3⟩
  | 3,false => some ⟨true,false,2⟩
  | 3,true  => some ⟨false,false,2⟩
  | 4,false => some ⟨true,true,4⟩
  | 4,true  => some ⟨true,true,0⟩
  | 5,false => none
  | 5,true  => some ⟨true,true,3⟩
  | _,_ => none

abbrev I := cons true
abbrev Z := cons false

def rep (b : Bool) : Nat → Ray → Ray
  | 0,r => r
  | n+1,r => cons b (rep b n r)
abbrev O := rep true
abbrev N := rep false

@[simp] theorem rep_zero (b : Bool) (r : Ray) : rep b 0 r = r := rfl
@[simp] theorem rep_succ (b : Bool) (n : Nat) (r : Ray) : rep b (n+1) r = cons b (rep b n r) := rfl

theorem rep_add (b : Bool) (m n : Nat) (r : Ray) : rep b (m+n) r = rep b m (rep b n r) := by
  induction m with
  | zero => simp
  | succ m ih => rw [Nat.succ_add,rep_succ,ih,rep_succ]

theorem rep_push (b : Bool) (n : Nat) (r : Ray) : rep b n (cons b r) = rep b (n+1) r := by
  rw [rep_add b n 1]; rfl

@[simp] theorem tail_blank : tail blankRay = blankRay := rfl

def Lscan (q : Q) (l r : Ray) : Prim := ⟨q,tail l,cons (l 0) r⟩
def E (l r : Ray) : Prim := ⟨4,l,r⟩
def F (n r : Nat) : Prim := ⟨5,O (2*n) blankRay,O r blankRay⟩

-- The two alternating erasing states both erase exactly two ones and return to themselves.
theorem eraseD_pair (l r : Ray) :
    run machine 2 (Lscan 3 (I (I l)) r) = some (Lscan 3 l (Z (Z r))) := rfl

theorem eraseC_pair (l r : Ray) :
    run machine 2 (Lscan 2 (I (I l)) r) = some (Lscan 2 l (Z (Z r))) := rfl

theorem eraseD (n : Nat) (l r : Ray) :
    run machine (2*n) (Lscan 3 (O (2*n) l) r) = some (Lscan 3 l (N (2*n) r)) := by
  induction n generalizing r with
  | zero => rfl
  | succ n ih =>
    rw [show 2*(n+1)=2+2*n by omega]
    unfold O N
    rw [rep_add true 2 (2*n),run_add]
    change (run machine 2 (Lscan 3 (I (I (O (2*n) l))) r)).bind _ = _
    rw [eraseD_pair]
    change run machine (2*n) (Lscan 3 (O (2*n) l) (Z (Z r))) = _
    rw [ih]
    congr 2
    change rep false (2*n) (rep false 2 r) = rep false (2+2*n) r
    rw [← rep_add,show 2*n+2=2+2*n by omega]

theorem eraseC (n : Nat) (l r : Ray) :
    run machine (2*n) (Lscan 2 (O (2*n) l) r) = some (Lscan 2 l (N (2*n) r)) := by
  induction n generalizing r with
  | zero => rfl
  | succ n ih =>
    rw [show 2*(n+1)=2+2*n by omega]
    unfold O N
    rw [rep_add true 2 (2*n),run_add]
    change (run machine 2 (Lscan 2 (I (I (O (2*n) l))) r)).bind _ = _
    rw [eraseC_pair]
    change run machine (2*n) (Lscan 2 (O (2*n) l) (Z (Z r))) = _
    rw [ih]
    congr 2
    change rep false (2*n) (rep false 2 r) = rep false (2+2*n) r
    rw [← rep_add,show 2*n+2=2+2*n by omega]

theorem E_zero (l r : Ray) : run machine 1 (E l (Z r)) = some (E (I l) r) := rfl

theorem E_fill (n : Nat) (l r : Ray) :
    run machine n (E l (N n r)) = some (E (O n l) r) := by
  induction n generalizing l with
  | zero => rfl
  | succ n ih =>
    rw [show n+1=1+n by omega,run_add,show 1+n=n+1 by omega]
    change (run machine 1 (E l (Z (N n r)))).bind _ = _
    rw [E_zero]
    change run machine n (E (I l) (N n r)) = _
    rw [ih]
    exact congrArg (fun x => some (E x r)) (rep_push true n l)

-- First F step exposes an even run for D to erase.
theorem F_open (n r : Nat) :
    run machine 1 (F n (r+3)) = some
      (Lscan 3 (O (2*(n+1)) blankRay) (O (r+1) blankRay)) := by
  unfold F Lscan
  rw [show 2*(n+1)=2*n+2 by omega,show 2*n+2=(2*n+1)+1 by omega]
  rfl

-- D0 writes a left marker, C0 steps left, then E fills two zeros.
theorem D_marker (r : Ray) :
    run machine 4 (Lscan 3 blankRay r) = some (E (O 2 blankRay) (I r)) := by
  change some (E (O 2 (tail (tail (tail blankRay)))) (I r)) = _
  rfl

-- A filled cell pair creates the next even left run to erase.
theorem E_open (m k : Nat) (r : Ray) :
    run machine 3 (E (O (2*m) blankRay) (I (N (2*(k+1)) r))) = some
      (Lscan 2 (O (2*(m+1)) blankRay) (I (N (2*k) r))) := by
  rw [show 2*(k+1)=2*k+2 by omega,show 2*k+2=(2*k+1)+1 by omega,
      show 2*(m+1)=2*m+2 by omega,show 2*m+2=(2*m+1)+1 by omega]
  rfl

theorem C_marker (r : Ray) :
    run machine 1 (Lscan 2 blankRay r) = some (E blankRay (Z (Z r))) := rfl

def inner (m k : Nat) (r : Ray) : Prim := E (O (2*m) blankRay) (I (N (2*k) r))

theorem innerStep (m k : Nat) (r : Ray) :
    run machine (4*m+10) (inner m (k+1) r) = some (inner (m+2) k r) := by
  unfold inner
  rw [show 4*m+10=3+(2*(m+1)+(1+2*(m+2))) by omega,run_add,E_open]
  change run machine (2*(m+1)+(1+2*(m+2)))
    (Lscan 2 (O (2*(m+1)) blankRay) (I (N (2*k) r))) = _
  rw [run_add,eraseC]
  change run machine (1+2*(m+2))
    (Lscan 2 blankRay (N (2*(m+1)) (I (N (2*k) r)))) = _
  rw [run_add,C_marker]
  change run machine (2*(m+2)) (E blankRay (Z (Z (N (2*(m+1)) (I (N (2*k) r)))))) = _
  rw [show 2*(m+2)=2+2*(m+1) by omega]
  have hh : Z (Z (N (2*(m+1)) (I (N (2*k) r)))) = N (2+2*(m+1)) (I (N (2*k) r)) := by unfold N; rw [rep_add]; rfl
  rw [hh,E_fill]

-- Exact cost of k inner iterations from a left run of length 2*m.
def innerCost (m k : Nat) : Nat := 4*k*k+(4*m+6)*k

theorem innerCost_succ (m k : Nat) : innerCost m (k+1) = 4*m+10+innerCost (m+2) k := by
  unfold innerCost
  simp only [Nat.mul_add,Nat.add_mul,Nat.mul_one,Nat.one_mul]
  omega

theorem innerSweep (m k : Nat) (r : Ray) :
    run machine (innerCost m k) (inner m k r) = some (inner (m+2*k) 0 r) := by
  induction k generalizing m with
  | zero => simp [innerCost,run]
  | succ k ih =>
    rw [innerCost_succ,run_add,innerStep]
    change run machine (innerCost (m+2) k) (inner (m+2) k r) = _
    rw [ih,show m+2+2*k=m+2*(k+1) by omega]

-- No gap remains: E1 and A1 advance two cells to the next F state.
theorem innerClose (m r : Nat) :
    run machine 2 (inner m 0 (O (r+1) blankRay)) = some (F (m+1) r) := by
  unfold inner F E
  rw [show 2*(m+1)=2*m+2 by omega,show 2*m+2=(2*m+1)+1 by omega]
  rfl

def cost (n : Nat) : Nat := 1+2*(n+1)+4+innerCost 1 (n+1)+2

theorem fReturn (n r : Nat) :
    run machine (cost n) (F n (r+3)) = some (F (2*n+4) r) := by
  unfold cost
  rw [show 1+2*(n+1)+4+innerCost 1 (n+1)+2 = 1+(2*(n+1)+(4+(innerCost 1 (n+1)+2))) by omega,
      run_add,F_open]
  change run machine (2*(n+1)+(4+(innerCost 1 (n+1)+2)))
    (Lscan 3 (O (2*(n+1)) blankRay) (O (r+1) blankRay)) = _
  rw [run_add,eraseD]
  change run machine (4+(innerCost 1 (n+1)+2))
    (Lscan 3 blankRay (N (2*(n+1)) (O (r+1) blankRay))) = _
  rw [run_add,D_marker]
  change run machine (innerCost 1 (n+1)+2) (inner 1 (n+1) (O (r+1) blankRay)) = _
  rw [run_add,innerSweep]
  change run machine 2 (inner (1+2*(n+1)) 0 (O (r+1) blankRay)) = _
  rw [innerClose,show 1+2*(n+1)+1=2*n+4 by omega]

-- Only the 503-step initial transient is evaluated; all later execution is symbolic.
structure Finite where
  q : Q
  l : List Bool
  r : List Bool
  deriving DecidableEq, Repr

def listRay : List Bool → Ray
  | [] => blankRay
  | b::bs => cons b (listRay bs)

def Finite.render (c : Finite) : Prim := ⟨c.q,listRay c.l,listRay c.r⟩

theorem listRay_head (xs : List Bool) : listRay xs 0 = xs.headD false := by cases xs <;> rfl
theorem listRay_tail (xs : List Bool) : tail (listRay xs) = listRay xs.tail := by cases xs <;> rfl

def finiteStep (c : Finite) : Option Finite := do
  let mv ← machine c.q (c.r.headD false)
  if mv.right then return ⟨mv.next,mv.write::c.l,c.r.tail⟩
  else return ⟨mv.next,c.l.tail,c.l.headD false::mv.write::c.r.tail⟩

def finiteRun : Nat → Finite → Option Finite
  | 0,c => some c
  | n+1,c => (finiteStep c).bind (finiteRun n)

theorem finiteStep_correct (c : Finite) : (finiteStep c).map Finite.render = primStep machine c.render := by
  cases c with
  | mk q l r =>
    cases h : machine q (r.head?.getD false) with
    | none => simp [finiteStep,primStep,Finite.render,listRay_head,h]
    | some mv => cases hd : mv.right <;> simp [finiteStep,primStep,Finite.render,listRay_head,listRay_tail,listRay,h,hd]

theorem finiteRun_correct (n : Nat) (c : Finite) :
    (finiteRun n c).map Finite.render = run machine n c.render := by
  induction n generalizing c with
  | zero => rfl
  | succ n ih =>
    simp only [finiteRun,run,← finiteStep_correct]
    cases h : finiteStep c with
    | none => rfl
    | some d => exact ih d

theorem listRay_replicate (b : Bool) (n : Nat) : listRay (List.replicate n b) = rep b n blankRay := by
  induction n with
  | zero => rfl
  | succ n ih => simp [List.replicate_succ,listRay,ih]

theorem initial : run machine 503 primBlank = some (F 2 36) := by
  have hf : finiteRun 503 ⟨0,[],[]⟩ = some ⟨5,List.replicate 4 true,List.replicate 36 true⟩ := by decide +kernel
  have hs := finiteRun_correct 503 ⟨0,[],[]⟩
  rw [hf] at hs
  have hr : Finite.render ⟨5,List.replicate 4 true,List.replicate 36 true⟩ = F 2 36 := by
    simp only [Finite.render,listRay_replicate,F]
  rw [show (some (⟨5,List.replicate 4 true,List.replicate 36 true⟩ : Finite)).map Finite.render = some (F 2 36) from congrArg some hr] at hs
  exact hs.symm

-- Twelve applications of the macro equation, with the exact accumulated cost.
def nextN : Nat → Nat → Nat
  | 0,n => n
  | k+1,n => nextN k (2*n+4)

def totalCost : Nat → Nat → Nat
  | 0,_ => 0
  | k+1,n => cost n+totalCost k (2*n+4)

theorem fReturns (k n r : Nat) :
    run machine (totalCost k n) (F n (3*k+r)) = some (F (nextN k n) r) := by
  induction k generalizing n with
  | zero => simp [totalCost,nextN,run]
  | succ k ih =>
    rw [totalCost,show 3*(k+1)+r=(3*k+r)+3 by omega,run_add,fReturn]
    exact ih (2*n+4)

theorem chain (a b : Nat) (c d e : Prim) (h1 : run machine a c = some d) (h2 : run machine b d = some e) : run machine (a+b) c = some e := by
  rw [run_add,h1]
  exact h2

theorem endpoint0 : run machine (503+totalCost 12 2) primBlank = some (F (nextN 12 2) 0) :=
  chain 503 (totalCost 12 2) primBlank (F 2 36) (F (nextN 12 2) 0) initial (fReturns 12 2 0)
theorem reindexRun (a b : Nat) (c d : Prim) (h : a=b)
    (hr : run machine b c = some d) : run machine a c = some d := by subst b; exact hr

theorem endpoint : run machine 805012067 primBlank = some (F (nextN 12 2) 0) :=
  reindexRun 805012067 (503+totalCost 12 2) primBlank (F (nextN 12 2) 0)
    (by decide +kernel) endpoint0

theorem endpoint_hole : (F (nextN 12 2) 0).q = 5 ∧ (F (nextN 12 2) 0).r 0 = false := ⟨rfl,rfl⟩

#print axioms fReturn
#print axioms initial
#print axioms endpoint
end BB6.Agent49FamilyLate
