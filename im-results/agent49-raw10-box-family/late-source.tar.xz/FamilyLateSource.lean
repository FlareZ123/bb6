import FamilyLateHalter
import BlockFARBridge

set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent49FamilyLateSource
open BB6Coverage
open BB6.Agent49FamilyLate (machine F nextN endpoint endpoint_hole)

/-- Finite, source-level transfer, including the exact final relative configuration.
    The proof is independent of the size of the time index. -/
theorem transfer_prefix (M : BB6BlockFAR.Table) (m : Machine)
    (hm : compatible (BB6BlockFAR.partialTable M) m) (n : Nat) (x : BB6BlockFAR.Prim)
    (h : BB6BlockFAR.run M n BB6BlockFAR.primBlank = some x) :
    ∃ c, run m n blank = some c ∧ BB6BlockFAR.Related c x := by
  induction n generalizing x with
  | zero =>
    have hx : BB6BlockFAR.primBlank = x := Option.some.inj h
    subst x
    exact ⟨_,rfl,BB6BlockFAR.related_blank⟩
  | succ n ih =>
    rw [BB6BlockFAR.run_succ_last] at h
    cases hp : BB6BlockFAR.run M n BB6BlockFAR.primBlank with
    | none => rw [hp] at h; contradiction
    | some y =>
      obtain ⟨c,hc,hrel⟩ := ih y hp
      rw [hp] at h
      obtain ⟨d,hd,hr⟩ := BB6BlockFAR.related_step M m hm c y x hrel h
      refine ⟨d,?_,hr⟩
      change (run m n blank).bind (rawStep m) = some d
      rw [hc]
      exact hd

abbrev p := BB6BlockFAR.partialTable machine

theorem endpoint_source (m : Machine) (hm : compatible p m) :
    ∃ c, run m 805012067 blank = some c ∧ readSlot c = (5,false) := by
  obtain ⟨c,hc,hr⟩ := transfer_prefix machine m hm 805012067 (F (nextN 12 2) 0) endpoint
  refine ⟨c,hc,Prod.ext (hr.1.trans endpoint_hole.1) ?_⟩
  have h := hr.2.2 0
  change c.tape (c.head+0) = (F (nextN 12 2) 0).r 0 at h
  rw [Int.add_zero] at h
  exact h.trans endpoint_hole.2

-- The unique unknown slot is F0. When it is assigned an ordinary transition,
-- every slot is ordinary, so no halt is possible at any time.
theorem only_hole : ∀ q : Fin 6, ∀ b : Bool,
    (q,b) ≠ (5,false) → (machine q b).isSome = true := by decide +kernel

theorem total_never (m : Machine) (ht : ∀ s, ∃ v, m s = some v) : NeverHalts m := by
  intro n
  induction n with
  | zero => rfl
  | succ n ih =>
    cases hr : run m n blank with
    | none => rw [hr] at ih; contradiction
    | some c =>
      obtain ⟨mv,hv⟩ := ht (readSlot c)
      change ((run m n blank).bind (rawStep m)).isSome = true
      rw [hr]
      simp only [Option.bind_some,rawStep,hv,Option.map_some,Option.isSome_some]

private theorem halt_from_endpoint (m : Machine) (n : Nat) (c : Config)
    (hc : run m n blank = some c) (hh : m (readSlot c) = none) : HaltsAfter m n := by
  exact ⟨by rw [hc]; rfl,halting_entry m blank c n hc hh⟩

theorem finite_halt (m : Machine) (hm : compatible p m) (hh : m (5,false) = none) :
    HaltsAfter m 805012067 := by
  obtain ⟨c,hc,hs⟩ := endpoint_source m hm
  exact halt_from_endpoint m 805012067 c hc (by rw [hs]; exact hh)

theorem all_completions (m : Machine) (hm : compatible p m) : DecidedBelow 805012068 m := by
  cases hF : m (5,false) with
  | none => exact Or.inr ⟨805012067,by decide,finite_halt m hm hF⟩
  | some mv =>
    apply Or.inl
    apply total_never
    intro s
    by_cases hs : s = (5,false)
    · subst s; exact ⟨mv,hF⟩
    · have hk := only_hole s.1 s.2 hs
      cases h : machine s.1 s.2 with
      | none => rw [h] at hk; contradiction
      | some v =>
        exact ⟨BB6BlockFAR.sourceMove v,hm s _ (by unfold p BB6BlockFAR.partialTable; rw [h]; rfl)⟩

#print axioms transfer_prefix
#print axioms endpoint_source
#print axioms finite_halt
#print axioms all_completions
end BB6.Agent49FamilyLateSource
