import RecursiveResidual
import NGramCertificate
import Raw10BoxCore

set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace BB6.Agent49Box18to24
open BB6Coverage BB6.Agent13BlankDelay
open BB6.Agent50RootFrontier BB6.Agent50RecursiveResidual
open BB6.Agent49Box BB6.Agent49BoxBridge

/-- A checked proof tree relative to a product of allowed transition domains.
    A branch outside the rectangle is deliberately ignored, never certified. -/
inductive DomainTree where
  | invalid
  | last (n : Nat) (s : Slot)
  | side (n k : Nat) (right : Bool) (boundary : Int)
  | ngram (c : BB6.Agent1NGram.Cert)
  | branch (n : Nat) (s : Slot) (children : Move → DomainTree)

def DomainTree.check (B : Nat) (b : Box Slot Transition) (p : PartialMachine) :
    DomainTree → Bool
  | .invalid => false
  | .last n s => lastOK B p n s
  | .side n k r boundary => sideOK p n k r boundary
  | .ngram c => BB6.Agent1NGram.check p c
  | .branch n s f =>
    queryOK B p n s &&
      allMoves.all (fun mv =>
        if some mv ∈ b s then (f mv).check B b (refine p s (some mv)) else true)

theorem DomainTree.sound (B : Nat) (b : Box Slot Transition) (tree : DomainTree)
    (p : PartialMachine) (h : tree.check B b p = true) (m : Machine)
    (hm : Fits b m) (hp : compatible p m) : WeightedBound B m := by
  induction tree generalizing p with
  | invalid => simp [check] at h
  | last n s => exact lastOK_sound B p n s h m hp
  | side n k r boundary => exact sideOK_sound B p n k r boundary h m hp
  | ngram c => exact weighted_never B m (BB6.Agent1NGram.never p c h m hp)
  | branch n s f ih =>
    have hh : queryOK B p n s = true ∧
      allMoves.all (fun mv =>
        if some mv ∈ b s then (f mv).check B b (refine p s (some mv)) else true) = true := by
      simpa only [check, Bool.and_eq_true] using h
    cases hv : m s with
    | none => exact queryOK_sound B p n s hh.1 m (compatible_refine hp s none hv)
    | some mv =>
      have hmem : some mv ∈ b s := hv ▸ hm s
      have hc := List.all_eq_true.mp hh.2 mv (allMoves_complete mv)
      have hc' : (f mv).check B b (refine p s (some mv)) = true := by
        simpa [hmem] using hc
      exact ih mv (refine p s (some mv)) hc' (compatible_refine hp s (some mv) hv)

def domainBranch (n : Nat) (s : Slot) (cs : List DomainTree) : DomainTree :=
  .branch n s (fun mv => (cs[moveIndex mv]?).getD .invalid)

def slotCode (s : Slot) : Nat := 2*s.1.val + s.2.toNat

def decodeMove (n : Nat) : Transition :=
  if n = 0 then none else allMoves[n-1]?

def decodeRow (n : Nat) : Option Transition :=
  if n = 0 then none else some (decodeMove n)

def rootRows (a : Nat) : List Nat := [8,a,11,6,17,13,11,0,2,23,0,0]
def root (a : Nat) : PartialMachine := unpackTable ((rootRows a).map decodeRow)

def domains (a : Nat) : List (List Nat) :=
  [[8],[a],[11],[6],[17],[13],[11],List.range 25,[2],[23],
    [0,2,4,11,12,14,15,16,19,20,22,24],List.range 25]

def rect (a : Nat) : Box Slot Transition :=
  fun s => ((domains a)[slotCode s]?).getD [] |>.map decodeMove

/-- This finite check is deliberately independent of the tree:
    every table in the rectangle must extend the starting partial table. -/
def rootOK (b : Box Slot Transition) (p : PartialMachine) : Bool :=
  slots.all fun s => (b s).all fun t =>
    match p s with
    | none => true
    | some u => decide (t = u)

theorem rootOK_sound (b : Box Slot Transition) (p : PartialMachine)
    (h : rootOK b p = true) (m : Machine) (hm : Fits b m) : compatible p m := by
  intro s t ht
  have hs := List.all_eq_true.mp h s (slots_complete s)
  have hmt := List.all_eq_true.mp hs (m s) (hm s)
  simpa [ht] using hmt

def sourceMatch (a : Nat) (b : Box Slot Transition) : Bool :=
  slots.all fun s => transitions.all fun t =>
    decide ((t ∈ b s) ↔ (t ∈ rect a s))

theorem sourceMatch_sound (a : Nat) (b : Box Slot Transition)
    (h : sourceMatch a b = true) (m : Machine) (hm : Fits b m) :
    Fits (rect a) m := by
  intro s
  have hs := List.all_eq_true.mp h s (slots_complete s)
  have ht := List.all_eq_true.mp hs (m s) (transitions_complete (m s))
  exact (of_decide_eq_true ht).mp (hm s)


/-- Compositional proof interface. Each leaf is checked separately to keep
    kernel memory independent of the total number of branches. -/
def Safe (B : Nat) (b : Box Slot Transition) (p : PartialMachine) : Prop :=
  ∀ m, Fits b m → compatible p m → WeightedBound B m

theorem checkedLeaf (B : Nat) (b : Box Slot Transition) (p : PartialMachine)
    (tree : DomainTree) (h : tree.check B b p = true) : Safe B b p :=
  fun m hb hp => DomainTree.sound B b tree p h m hb hp

structure Child (B : Nat) (b : Box Slot Transition) (p : PartialMachine) (s : Slot) where
  mv : Move
  safe : Safe B b (refine p s (some mv))

def childOK (B : Nat) (b : Box Slot Transition) (p : PartialMachine)
    (s : Slot) (cs : List (Child B b p s)) : Bool :=
  (b s).all fun t => match t with
    | none => true
    | some mv => cs.any fun c => decide (c.mv = mv)

theorem branchCert (B : Nat) (b : Box Slot Transition) (p : PartialMachine)
    (n : Nat) (s : Slot) (hq : queryOK B p n s = true)
    (cs : List (Child B b p s)) (hcs : childOK B b p s cs = true) :
    Safe B b p := by
  intro m hb hp
  cases hv : m s with
  | none => exact queryOK_sound B p n s hq m (compatible_refine hp s none hv)
  | some mv =>
    have hm : some mv ∈ b s := by simpa [hv] using hb s
    have h := List.all_eq_true.mp hcs (some mv) hm
    obtain ⟨c, _, hc⟩ := List.any_eq_true.mp h
    have he : c.mv = mv := of_decide_eq_true hc
    apply c.safe m hb
    rw [he]
    exact compatible_refine hp s (some mv) hv

#print axioms branchCert

#print axioms DomainTree.sound
#print axioms rootOK_sound
#print axioms sourceMatch_sound
end BB6.Agent49Box18to24
