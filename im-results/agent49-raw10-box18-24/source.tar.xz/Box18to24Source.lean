import Box18to24_19
import Box18to24_18
import Box18to24_17
import Box18to24_8
import Box18to24_6
import Box18to24_3
import Box18to24_2

set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent49Box18to24
open BB6Coverage BB6.Agent13BlankDelay BB6.Agent49Box BB6.Agent49BoxBridge

def closedRows : List Nat := [19,18,17,8,6,3,2]
def expectedIndices : List (Nat × Nat) :=
  [(18,19),(19,18),(20,17),(21,8),(22,6),(23,3),(24,2)]

/-- Source identity checks the seven exact rectangles at their stated
    stable indices; it does not assume the encoded fixture is authoritative. -/
def sourceIndexCheck : Bool :=
  expectedIndices.all fun e =>
    (raw10Remainder[e.1]?).any (sourceMatch e.2)

theorem source_indices_checked : sourceIndexCheck = true := by decide +kernel

theorem rectBound (a : Nat) (ha : a ∈ closedRows) (m : Machine)
    (hm : Fits (rect a) m) : WeightedBound 598 m := by
  simp [closedRows] at ha
  rcases ha with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact rect19_bound m hm
  · exact rect18_bound m hm
  · exact rect17_bound m hm
  · exact rect8_bound m hm
  · exact rect6_bound m hm
  · exact rect3_bound m hm
  · exact rect2_bound m hm

def closedMatch (b : Box Slot Transition) : Bool :=
  closedRows.any fun a => sourceMatch a b

theorem closedMatch_bound (B : Nat) (hB : 598 ≤ B)
    (b : Box Slot Transition) (hc : closedMatch b = true)
    (m : Machine) (hm : Fits b m) : WeightedBound B m := by
  obtain ⟨a,ha,hs⟩ := List.any_eq_true.mp hc
  have h := rectBound a ha m (sourceMatch_sound a b hs m hm)
  intro k d hk hd
  exact Nat.le_trans (h k d hk hd) hB

/-- No other source rectangle is dropped. At score B this reduces the raw10
    residual obligation by the seven checked domains. -/
theorem residual_without_18to24 (B : Nat) (hB : 598 ≤ B)
    (hrest : ∀ b ∈ raw10Remainder, closedMatch b = false →
      ∀ m, Fits b m → WeightedBound B m) :
    ∀ b ∈ raw10Remainder, ∀ m, Fits b m → WeightedBound B m := by
  intro b hb m hm
  cases hc : closedMatch b with
  | false => exact hrest b hb hc m hm
  | true => exact closedMatch_bound B hB b hc m hm

#print axioms source_indices_checked
#print axioms rectBound
#print axioms residual_without_18to24
end BB6.Agent49Box18to24
