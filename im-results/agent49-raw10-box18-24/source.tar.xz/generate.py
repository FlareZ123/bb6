#!/usr/bin/env python3
"""Untrusted deterministic raw10 rectangle proof-candidate generator.
The generated Lean proof checks each leaf and allowed branch independently.
Run from the directory containing Box18to24Core.lean.
"""
from collections import Counter, defaultdict, deque
from pathlib import Path

def detect(table,limit=300):
    q=0; h=0; tape=set(); hist=[]; byq=[[] for i in range(6)]
    if all(v>0 for v in table):return ('total',)
    for n in range(limit+1):
        # same-state recurrence
        for j in reversed(byq[q]):
            oldh,oldt=hist[j][1:]
            delta=h-oldh
            if not delta:
                if tape==oldt: return ('cycle',j,n-j,0)
                continue
            if delta>0:
                edge=min(z[1] for z in hist[j:]+[(q,h,tape)])
                if {x+delta for x in oldt if x>=edge}=={x for x in tape if x>=edge+delta}:
                    return ('right',j,n-j,edge)
            else:
                edge=max(z[1] for z in hist[j:]+[(q,h,tape)])
                if {x+delta for x in oldt if x<=edge}=={x for x in tape if x<=edge+delta}:
                    return ('left',j,n-j,edge)
        hist.append((q,h,frozenset(tape))); byq[q].append(n)
        slot=2*q+(h in tape); v=table[slot]
        if v==-1:return ('hole',slot,n)
        if v==0:return ('halt',n+1)
        v-=1
        if v&2:tape.add(h)
        else:tape.discard(h)
        q=v//4; h+=1 if v&1 else -1
    return ('open',)


def ngram(table,k,cap=100000):
    mask=(1<<k)-1; M=1<<k
    seen=set(); todo=deque(); edges=[defaultdict(int),defaultdict(int)]; waiting=[defaultdict(list),defaultdict(list)]
    edges[0][0]=edges[1][0]=1
    fail=False
    def add(s,l,r):
        nonlocal fail
        if table[s]<=0:fail=True;return
        z=(s,l,r)
        if z not in seen:
            seen.add(z);todo.append(z)
    def pop(z,e):
        s,l,r=z;v=table[s]-1;q=v//4;w=(v>>1)&1
        if v&1:add(2*q+(r&1),((l<<1)|w)&mask,(r>>1)|(e<<(k-1)))
        else:add(2*q+(l&1),(l>>1)|(e<<(k-1)),((r<<1)|w)&mask)
    def edge(d,x,e):
        if edges[d][x]&(1<<e):return
        edges[d][x]|=1<<e
        for z in waiting[d][x]:pop(z,e)
    add(0,0,0)
    while todo and not fail and len(seen)<cap:
        z=todo.popleft();s,l,r=z;v=table[s]-1;w=(v>>1)&1;d=v&1
        pushx,popx=(l,r) if d else (r,l)
        edge(1-d,((pushx<<1)|w)&mask,pushx>>(k-1))
        waiting[d][popx].append(z)
        e=edges[d][popx]
        if e&1:pop(z,0)
        if e&2:pop(z,1)
    if fail or todo:return None
    return (k,seen,edges)


def detect2(table,limit):
    r=detect(table,limit)
    if r[0]=='cycle':
        # For delta=0 use an actual lower boundary over the witnessed segment.
        q=h=0;tape=set();heads=[]
        for _ in range(r[1]+r[2]+1):
            heads.append(h)
            v=table[2*q+(h in tape)]-1
            if v<0:break
            if v&2:tape.add(h)
            else:tape.discard(h)
            q=v//4;h+=1 if v&1 else -1
        return ('right',r[1],r[2],min(heads[r[1]:r[1]+r[2]]))
    return r


def buildtree(tab,dom,stats):
    r=detect2(tab,200)
    if r[0]=='open':
        for k in range(1,4):
            c=ngram(tab,k)
            if c:
                stats['ngram']+=1
                return ('ngram',c)
        r=detect2(tab,700)
    if r[0] in ('right','left'):
        stats[r[0]]+=1
        stats['maxside']=max(stats['maxside'],r[1]+r[2])
        return r
    if r[0]!='hole':raise ValueError((tab,r))
    _,s,n=r
    stats['maxhole']=max(stats['maxhole'],n)
    if tab.count(-1)==1:
        stats['last']+=1
        return ('last',n,s)
    stats['branch']+=1
    cs=[]
    for v in range(1,25):
        if v not in dom[s]:cs.append(('invalid',));continue
        a=list(tab);a[s]=v
        cs.append(buildtree(tuple(a),dom,stats))
    return ('branch',n,s,cs)


def trie(vals):
    if not vals:return '.empty'
    if vals=={0}:return '.leaf'
    return '(.branch '+trie({v//2 for v in vals if not v%2})+' '+trie({v//2 for v in vals if v%2})+')'


def cert_render(c):
    k,states,edges=c;M=1<<k
    edge_nums=[sum(1<<(2*x+b) for x,e in e0.items() for b in range(2) if e&(1<<b)) for e0 in edges]
    tries=[trie({l*M+r for s,l,r in states if s==j}) for j in range(12)]
    return f'⟨{k-1}, {edge_nums[0]}, {edge_nums[1]}, #[{", ".join(tries)}]⟩'


def slot(s):return f'({s//2},{str(bool(s%2)).lower()})'


def render(tree):
    tag,*r=tree
    if tag=='invalid':return '.invalid'
    if tag=='last':return f'.last {r[0]} {slot(r[1])}'
    if tag in ('left','right'):return f'.side {r[0]} {r[1]} {str(tag=="right").lower()} ({r[2]})'
    if tag=='ngram':return '.ngram '+cert_render(r[0])
    if tag=='branch':return f'(domainBranch {r[0]} {slot(r[1])} [\n  '+',\n  '.join(render(c) for c in r[2])+'])'


def move(v):
    i=v-1
    return f'⟨{str(bool(i&2)).lower()},{str(bool(i&1)).lower()},{i//4}⟩'


def gen_proofs(a,t):
    lines=[];serial=0
    def rec(tree,p):
        nonlocal serial
        serial+=1;name=f'node{a}_{serial}'
        tag=tree[0]
        if tag=='branch':
            _,n,s,cs=tree
            children=[]
            for v,c in enumerate(cs,1):
                if c[0]=='invalid':continue
                q=f'(refine {p} {slot(s)} (some {move(v)}))'
                child=rec(c,q)
                children.append(f'⟨{move(v)}, {child}⟩')
            body=f'branchCert 598 (rect {a}) {p} {n} {slot(s)} (by decide +kernel)\n    ['+',\n     '.join(children)+'] (by decide +kernel)'
        else:
            body=f'checkedLeaf 598 (rect {a}) {p} ({render(tree)}) (by decide +kernel)'
        lines.append(f'private theorem {name} : Safe 598 (rect {a}) {p} :=\n  {body}\n')
        return name
    top=rec(t,f'(root {a})')
    return f'''import Box18to24Core
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent49Box18to24
open BB6Coverage BB6.Agent13BlankDelay BB6.Agent49Box
'''+ '\n'.join(lines)+f'''
theorem rect{a}_bound (m : Machine) (hm : Fits (rect {a}) m) : WeightedBound 598 m :=
  {top} m hm (rootOK_sound (rect {a}) (root {a}) (by decide +kernel) m hm)
#print axioms rect{a}_bound
end BB6.Agent49Box18to24
'''


def main():
    allvals=tuple(range(25))
    for a in (19,18,17,8,6,3,2):
        dom=[(8,),(a,),(11,),(6,),(17,),(13,),(11,),allvals,(2,),(23,),
             (0,2,4,11,12,14,15,16,19,20,22,24),allvals]
        stats=Counter()
        tree=buildtree(tuple(x[0] if len(x)==1 else -1 for x in dom),dom,stats)
        assert stats["maxhole"] <= 592
        Path(f"Box18to24_{a}.lean").write_text(gen_proofs(a,tree))
        print(a, dict(stats))

if __name__ == "__main__":
    main()
