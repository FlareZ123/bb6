#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <sstream>
#include <unordered_map>
#include <unordered_set>
#include <vector>
using namespace std;
using U=uint64_t; using T=array<int,12>;
struct NGram {
 int k; U mask; T tr; unordered_set<U> seen; vector<U> todo; array<unordered_map<U,int>,2> edges; array<unordered_map<U,vector<U>>,2> waiting; bool fail=false;
 NGram(T s,int n):k(n),mask((1ull<<k)-1),tr(s){edges[0][0]=edges[1][0]=1;add(0,0,0,0);}
 void add(int q,int a,U l,U r){U id=(U(q*2+a)<<(2*k))|(l<<k)|r;if(seen.insert(id).second){todo.push_back(id);if(tr[2*q+a]<=0||todo.size()>100000)fail=true;}}
 void decode(U id,int &s,U &l,U&r){r=id&mask;id>>=k;l=id&mask;s=id>>k;}
 void pop(U id,int e){int s;U l,r;decode(id,s,l,r);int m=tr[s]-1;if(m<0){fail=true;return;}int q=m/4,w=(m/2)%2;bool R=m%2;if(R)add(q,r&1,((l<<1)|w)&mask,(r>>1)|(U(e)<<(k-1)));else add(q,l&1,(l>>1)|(U(e)<<(k-1)),((r<<1)|w)&mask);}
 void edge(int d,U x,int e){if(edges[d][x]&(1<<e))return;edges[d][x]|=1<<e;auto it=waiting[d].find(x);if(it!=waiting[d].end())for(auto id:it->second)pop(id,e);}
 bool check(){for(size_t i=0;i<todo.size()&&!fail;i++){U id=todo[i],l,r;int s;decode(id,s,l,r);int m=tr[s]-1,q=m/4,w=(m/2)%2;bool R=m%2;U push=R?l:r,popx=R?r:l;edge(R?0:1,((push<<1)|w)&mask,push>>(k-1));int d=R?1:0;waiting[d][popx].push_back(id);for(int e=0;e<2;e++)if(edges[d][popx]&(1<<e))pop(id,e);}return !fail;}
};
string trie(const vector<U>& xs){
 if(xs.empty())return ".empty";
 if(*max_element(xs.begin(),xs.end())==0)return ".leaf";
 vector<U> e,o;for(U x:xs)(x%2?o:e).push_back(x/2);
 return "(.branch "+trie(e)+" "+trie(o)+")";
}
string emit(NGram& n){
 string s="⟨"+to_string(n.k-1)+",";
 for(int d=0;d<2;d++){vector<U> xs;for(auto [x,v]:n.edges[d])for(int b=0;b<2;b++)if(v>>b&1)xs.push_back(2*x+b);s+=trie(xs)+",";}
 vector<U> rows[12];for(U id:n.todo){int q;U l,r;n.decode(id,q,l,r);rows[q].push_back(r+(U(1)<<n.k)*l);}
 s+="#[";
 for(int i=0;i<12;i++){if(i)s+=",";s+=trie(rows[i]);}return s+"]⟩";
}
int main(){string s;int i=0;while(getline(cin,s)){if(s.empty())continue;T a;replace(s.begin(),s.end(),',',' ');istringstream ss(s);for(int &x:a)ss>>x;bool ok=false;for(int k=1;k<=29;k++){NGram n(a,k);if(n.check()){cout<<i<<'\t'<<emit(n)<<'\n';ok=true;break;}}if(!ok)cerr<<i<<'\n';i++;}}
