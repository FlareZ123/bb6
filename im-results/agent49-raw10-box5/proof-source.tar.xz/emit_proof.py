#!/usr/bin/env python3
"""Emit sharded kernel-checkable Box5 tree. Discovery is untrusted."""
from pathlib import Path
from collections import Counter
import sys, json
out=Path(sys.argv[1] if len(sys.argv)>1 else '.')
out.mkdir(parents=True,exist_ok=True)
rows=[tuple(map(int,s.strip(',\n').split(','))) for s in Path('open.csv').read_text().splitlines()]
ngram={int(i):v for i,v in (s.split('\t',1) for s in Path('ngram-cert.tsv').read_text().splitlines())}
params=json.loads(Path('rle.json').read_text())|json.loads(Path('diff.json').read_text())
hard=sorted(map(int,params));assert set(hard)|set(ngram)==set(range(len(rows))) and not set(hard)&set(ngram)
# Hard partials all have exactly one unknown row, no assigned halt.
assert all(rows[i].count(-1)==1 and 0 not in rows[i] for i in hard)
header='''set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent49Box5
open BB6Coverage BB6.Agent13BlankDelay BB6.Agent49BoxBridge
open BB6.Agent49Box (Box Fits)
'''
def slot(i):return f'({i//2},{str(bool(i%2)).lower()})'
def pstr(t):return '#['+','.join(str(25 if v<0 else v) for v in t)+']'
# Match each emitted hard partial table extensionally before consuming its theorem.
s='import Box5Core\nimport Box5Automata\n'+header
for i in hard:
    s+=f'def h{i} : PartialMachine := BB6.Agent49Box5Automata.M{i}.table\n'
s+='def externalCheck (p : PartialMachine) : Bool :=\n  '+' || '.join(f'partialEq p h{i}' for i in hard)+'\n'
s+='''theorem externalCheck_sound (p : PartialMachine) (h : externalCheck p = true)
    (m : Machine) (hm : compatible p m) : NeverHalts m := by
  simp only [externalCheck,Bool.or_eq_true] at h
'''
# `||` is right associative in Lean; explicit disjunction normalizing avoids association assumptions.
s=s.replace('simp only [externalCheck,Bool.or_eq_true] at h','simp only [externalCheck,Bool.or_eq_true,or_assoc] at h')
s+='  rcases h with '+' | '.join('h' for _ in hard)+'\n'
for i in hard:s+=f'  · rw [partialEq_sound h] at hm\n    exact BB6.Agent49Box5Automata.M{i}.never m hm\n'
s+='\n#print axioms externalCheck_sound\nend BB6.Agent49Box5\n'
(out/'Box5Hard.lean').write_text(s)
# Preorder parser retains exact table at each leaf; the kernel independently checks all choices.
it=iter(Path('partition.txt').read_text().splitlines());counts=Counter()
def parse(t):
    a=next(it).split();kind=a[0];counts[kind]+=1;v=list(map(int,a[1:]));kids={}
    if kind=='S':
        k=v[0];assert t[k]==-1
        for c in range(25):
            if k==7 and c==2:continue
            kids[c]=parse(t[:k]+(c,)+t[k+1:])
    elif kind=='O':assert rows[v[0]]==t
    elif kind=='L':assert t.count(-1)==1 and 0 not in t and t[v[0]]==-1
    return kind,v,kids
root=parse((8,14,11,7,17,4,9)+(-1,)*5)
assert next(it,None) is None and root[:2]==('S',[9])
assert counts=={'S':1067,'L':4633,'C':19047,'H':1067,'O':518},counts
# Tree literals contain certificate data only; missing (excluded) code receives a dummy total leaf.
def tree(n):
    k,v,c=n
    if k=='S':return f'(.split {slot(v[0])} #[\n'+',\n'.join(tree(c[i]) if i in c else '(.leaf .total)' for i in range(25))+'\n])'
    if k=='L':return f'(.leaf (.last {slot(v[0])} {v[1]}))'
    if k=='H':return f'(.leaf (.halt {v[0]}))'
    if k=='C':return f'(.leaf (.ray {str(bool(v[0])).lower()} {v[1]} {v[2]} {v[3]}))'
    if k=='O':return f'(.leaf (.ngram {ngram[v[0]]}))' if v[0] in ngram else '(.leaf .external)'
    raise ValueError(k)
# Root E1; second split E0 or F0, both full domain. Separate checks keep kernel terms bounded.
for v,n in root[2].items():
    s='import Box5Hard\n'+header
    if n[0]!='S':
        s+=f'def t{v} : Tree := {tree(n)}\n'
        s+=f'theorem c{v} : treeCheck externalCheck baseBox 5 (refine initial (4,true) (decode {v})) t{v} = true := by decide +kernel\n'
        s+=f'theorem shard{v} (m : Machine) (hm : Fits baseBox m) (hv : m (4,true) = decode {v}) : DecidedBelow 155 m :=\n  shard_sound externalCheck externalCheck_sound {v} t{v} c{v} m hm hv\n'
    else:
        k=n[1][0];assert k in (8,10);sl=slot(k)
        for a,x in n[2].items():
            s+=f'def t{v}_{a} : Tree := {tree(x)}\n'
            s+=f'theorem c{v}_{a} : treeCheck externalCheck baseBox 4 (refine (refine initial (4,true) (decode {v})) {sl} (decode {a})) t{v}_{a} = true := by decide +kernel\n'
        s+=f'theorem shard{v} (m : Machine) (hm : Fits baseBox m) (hv : m (4,true) = decode {v}) : DecidedBelow 155 m := by\n'
        s+=f'  have hc := code_ok (m {sl})\n  have hs : '+' ∨ '.join(f'code (m {sl}) = {a}' for a in range(25))+' := by omega\n'
        s+='  rcases hs with '+' | '.join('h' for _ in range(25))+'\n'
        for a in range(25):s+=f'  · exact subshard_sound externalCheck externalCheck_sound {v} {sl} {a} t{v}_{a} c{v}_{a} m hm hv (by rw [← h, hc.2])\n'
    s+='end BB6.Agent49Box5\n';(out/f'Box5Shard{v}.lean').write_text(s)
s=''.join(f'import Box5Shard{i}\n' for i in range(25))+header
s+='theorem box5_ordinary (m : Machine) (hm : Fits baseBox m) : DecidedBelow 155 m := by\n  have hc := code_ok (m (4,true))\n  have hs : '+' ∨ '.join(f'code (m (4,true)) = {i}' for i in range(25))+' := by omega\n  rcases hs with '+' | '.join('h' for _ in range(25))+'\n'
s+=''.join(f'  · exact shard{i} m hm (by rw [← h, hc.2])\n' for i in range(25))
s+='''
theorem box5_weighted (B : Nat) (hB : 160≤B) (m : Machine) (hm : Fits baseBox m) : WeightedBound B m :=
  ordinary_weighted B hB m (box5_ordinary m hm)

def sourceMatch (b : Box Slot Transition) : Bool :=
  slots.all fun s => transitions.all fun t => decide ((t ∈ b s) ↔ (t ∈ baseBox s))

theorem sourceMatch_sound (b : Box Slot Transition) (h : sourceMatch b=true)
    (m : Machine) (hm : Fits b m) : Fits baseBox m := by
  intro s
  have hs := List.all_eq_true.mp h s (slots_complete s)
  have ht := List.all_eq_true.mp hs (m s) (transitions_complete (m s))
  exact (of_decide_eq_true ht).mp (hm s)

theorem source_index5 : sourceMatch raw10Remainder[5]! = true := by decide +kernel

theorem sourceBound (m : Machine) (hm : Fits raw10Remainder[5]! m) : WeightedBound 160 m :=
  box5_weighted 160 (by decide) m (sourceMatch_sound _ source_index5 m hm)

theorem residual_without_box5 (B : Nat) (hB : 160≤B)
    (hrest : ∀ b ∈ raw10Remainder, sourceMatch b=false → ∀ m, Fits b m → WeightedBound B m) :
    ∀ b ∈ raw10Remainder, ∀ m, Fits b m → WeightedBound B m := by
  intro b hb m hm
  cases h : sourceMatch b with
  | false => exact hrest b hb h m hm
  | true => exact box5_weighted B hB m (sourceMatch_sound b h m hm)

#print axioms box5_ordinary
#print axioms source_index5
#print axioms sourceBound
#print axioms residual_without_box5
end BB6.Agent49Box5
'''
(out/'Box5SourceConsumer.lean').write_text(s)
print('Generated',dict(counts),'with',len(ngram),'sparse and',len(hard),'automata certificates')
