#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
g++ -O3 -std=c++17 partition.cpp -o partition
./partition >partition.txt 2>partition.log
head -1 partition.log
tail -n+2 partition.log >open.csv
g++ -O3 -std=c++17 emit_ngram.cpp -o emit_ngram
./emit_ngram <open.csv >ngram-cert.tsv 2>still-open29.txt
python3 emit_automata.py >Box5Automata.lean
python3 emit_proof.py .
