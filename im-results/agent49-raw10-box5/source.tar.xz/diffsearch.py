from difflearn import check
from itertools import product
from pathlib import Path
import json
root=Path(__file__).parent
rows=[list(map(int,s.strip(',\n').split(','))) for s in (root/'open.csv').read_text().splitlines()]
def code(x):
    if x<=0:return '---'
    x-=1
    return f'{x//2%2}{"R" if x%2 else "L"}{chr(65+x//4)}'
params=sorted(product(range(1,7),range(1,7),range(1,7)),key=lambda p:(p[0]*(p[1]+p[2]),p))
p=list(map(code,rows[483]))
for x in params:
    for ty in [('diff','diff'),('rle','diff'),('diff','rle')]:
        ok,n,*_=check(p,x,x,50000,ty)
        if ok:
            print(483,ty,x,n,flush=True);(root/'diff.json').write_text(json.dumps({'483':{'types':ty,'left':x,'right':x,'states':n}}));raise SystemExit
print('open')
