from pathlib import Path
from difflearn import check
import json

def bit(x):return 'true' if x else 'false'
def code(x):
    if x<=0:return '---'
    x-=1
    return f'{x//2%2}{"R" if x%2 else "L"}{chr(65+x//4)}'
def trie(xs):
    if not xs:return '.empty'
    if xs==[0]:return '.leaf'
    return f'(.branch {trie([x//2 for x in xs if x%2==0])} {trie([x//2 for x in xs if x%2==1])})'
def emit(i,p,cert):
    ok,n,edges,seen,D,T=cert
    assert ok
    def stack(d):
        E=','.join('['+','.join(f'({bit(b)},{j})' for b,j in sorted(edges[d][k]))+']' for k in range(len(T[d])))
        P=','.join(f'({D[d].get((k,0),0)},{D[d].get((k,1),0)})' for k in range(len(T[d])))
        return f'⟨#[{E}],#[{P}]⟩'
    rows=[trie(sorted(r+len(T[1])*l for qq,aa,l,r in seen if (qq,aa)==(q,a))) for q in range(6) for a in range(2)]
    def move(t):return 'none' if t=='---' else f'some (some ⟨{bit(t[0]=="1")},{bit(t[1]=="R")},{ord(t[2])-65}⟩)'
    cases='\n'.join(f'  | ({q},{bit(a)}) => {move(p[2*q+a])}' for q in range(6) for a in range(2))
    return f'''namespace M{i}
def table : PartialMachine := fun s => match s with
{cases}
  | _ => none
def cert : BB6.Agent4Automata.Cert := ⟨{stack(0)}, {stack(1)}, #[{','.join(rows)}]⟩
theorem checked : BB6.Agent4Automata.check table cert = true := by decide +kernel
theorem never (m : Machine) (hm : compatible table m) : NeverHalts m :=
  BB6.Agent4Automata.never table cert checked m hm
#print axioms never
end M{i}
'''
if __name__=='__main__':
    root=Path(__file__).parent
    rows=[list(map(int,s.strip(',\n').split(','))) for s in (root/'open.csv').read_text().splitlines()]
    params=json.loads((root/'rle.json').read_text())|json.loads((root/'diff.json').read_text())
    print('import TwoSidedAutomata\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\nnamespace BB6.Agent49Box5Automata\nopen BB6Coverage')
    for i,z in sorted(params.items(),key=lambda kv:int(kv[0])):
        p=list(map(code,rows[int(i)])); c=check(p,z['left'],z['right'],150000,tuple(z.get('types',['rle','rle'])))
        assert c[1]==z['states'];print(emit(i,p,c))
    print('end BB6.Agent49Box5Automata')
