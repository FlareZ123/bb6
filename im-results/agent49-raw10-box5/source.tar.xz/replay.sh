#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
g++ -O3 -std=c++17 search.cpp -o search
./search > open.csv
g++ -O3 -std=c++17 ngram.cpp -o ngram
./ngram 29 < open.csv > ngram.txt 2> still-open29.txt
python3 rlesearch.py
python3 diffsearch.py
python3 emit_automata.py > Box5Automata.lean
