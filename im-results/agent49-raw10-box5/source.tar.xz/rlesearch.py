from rlelearn import check
from itertools import product
from pathlib import Path
import json
root=Path(__file__).parent
rows=[list(map(int,s.strip(',\n').split(','))) for s in (root/'open.csv').read_text().splitlines()]
ids=[int(i) for i in (root/'still-open29.txt').read_text().split()]
def code(x):
    if x<=0:return '---'
    x-=1
    return f'{x//2%2}{"R" if x%2 else "L"}{chr(65+x//4)}'
params=sorted(product(range(1,7),range(1,7),range(1,7)),key=lambda p:(p[0]*(p[1]+p[2]),p))
found={}
for i in ids:
    p=list(map(code,rows[i]))
    for x in params:
        ok,n,*_=check(p,x,x,50000)
        if ok:
            found[i]={'left':x,'right':x,'states':n}
            print(i,x,n,flush=True);break
    else:print(i,'open',flush=True)
(root/'rle.json').write_text(json.dumps(found,indent=2))
