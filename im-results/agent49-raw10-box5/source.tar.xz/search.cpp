#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <string>
using namespace std;
using Table=array<int,12>;
struct W {int entry,period,boundary;bool right;};
struct Conf {int q,h,lo,hi; vector<uint8_t> tape;};
// First-hole search. Side-cycle test compares full retained half-line, with a boundary
// determined from the head excursion. All traces start from blank.
constexpr int N=1024, C=2048;
int maxH=0; uint64_t branch=0,halt=0,cycle=0,total=0,open=0;
vector<Table> pending;
struct Snap {int t,h,lo,hi; array<uint64_t,65> bits;};
struct RunResult {int kind,step,slot; W w;};
RunResult run(const Table &a,int lim){
 array<uint64_t,65> bits{}; int h=C,q=0,lo=C,hi=C;
 vector<Snap> hist[6]; vector<int> heads; heads.reserve(lim+1);
 auto read=[&](int p){return int((bits[p/64]>>(p%64))&1);};
 auto eqbit=[&](const Snap &s,int i,int j){return int((s.bits[i/64]>>(i%64))&1)==read(j);};
 for(int t=0;t<lim;t++){
  heads.push_back(h);
  int c=a[2*q+read(h)]; if(c<0)return {0,t,2*q+read(h),{}}; if(c==0)return {1,t,0,{}};
  auto &v=hist[q];
  // only last 24 same-state observations, exact comparison of retained rays
  for(int j=int(v.size())-1;j>=max(0,int(v.size())-24);--j){
   auto &s=v[j];int d=h-s.h, mn=s.h,mx=s.h;
   for(int k=s.t;k<t;k++){mn=min(mn,heads[k]);mx=max(mx,heads[k]);}
   if(d>=0){bool ok=true;for(int p=mn;p<=max(s.hi,hi-d);p++) if(!eqbit(s,p,p+d)){ok=false;break;}
    if(ok)return {2,t,0,{s.t,t-s.t,mn-C,true}};}
   if(d<=0){bool ok=true;for(int p=mx;p>=min(s.lo,lo-d);p--) if(!eqbit(s,p,p+d)){ok=false;break;}
    if(ok)return {2,t,0,{s.t,t-s.t,mx-C,false}};}
  }
  v.push_back({t,h,lo,hi,bits});
  --c; bool w=(c/2)%2; uint64_t mask=1ull<<(h%64);if(w)bits[h/64]|=mask;else bits[h/64]&=~mask;
  lo=min(lo,h);hi=max(hi,h);h+=(c%2)?1:-1;q=c/4;
 }
 return {3,lim,0,{}};
}
void dfs(Table &a){
 // If all slots ordinary, halt impossible; otherwise simulate until first hole.
 if(find(a.begin(),a.end(),-1)==a.end()&&find(a.begin(),a.end(),0)==a.end()){total++;return;}
 auto r=run(a,N);
 if(r.kind==1){halt++;maxH=max(maxH,r.step+1);return;}
 if(r.kind==2){cycle++;return;}
 if(r.kind==3){open++;pending.push_back(a);return;}
 branch++;
 for(int c=0;c<25;c++){if(r.slot==7&&c==2)continue;a[r.slot]=c;dfs(a);}a[r.slot]=-1;
}
int main(){Table a={8,14,11,7,17,4,9,-1,-1,-1,-1,-1};dfs(a);cerr<<"branch "<<branch<<" halt "<<halt<<" cycle "<<cycle<<" ordinary "<<total<<" open "<<open<<" maxhalt "<<maxH<<"\n";for(auto &p:pending){for(int x:p)cout<<x<<",";cout<<"\n";}}
