import TranslatedCycler
import SparseNGram
import Raw10BoxCore

set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent49Box6
open BB6Coverage BB6.Agent32FiniteSource BB6.Agent13BlankDelay BB6.Agent49BoxBridge
open BB6.Agent49Box (Box Fits)

def index (s : Slot) : Nat := 2*s.1.val+s.2.toNat

def decode (v : Nat) : Transition := choices[v]?.getD none

def code (t : Transition) : Nat := match t with
  | none => 0
  | some mv => 1+4*mv.next.val+2*mv.write.toNat+mv.right.toNat

theorem code_ok (t : Transition) : code t < 25 ∧ decode (code t) = t := by
  have h : choices.all (fun t => decide (code t < 25 ∧ decode (code t) = t)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h t (choices_complete t))

def initialCodes : Array Nat := #[8,14,11,7,17,4,9,2]

def initial : PartialMachine := fun s => (initialCodes[index s]?).map decode

def baseBox : Box Slot Transition := fun s =>
  match initial s with
  | some t => [t]
  | none => if index s = 8 then choices.filter (fun t => decide (t ≠ decode 23)) else choices

theorem initial_compatible (m : Machine) (hm : Fits baseBox m) : compatible initial m := by
  intro s t h
  have hs := hm s
  simpa [baseBox,h] using hs

def fromCodes (cs : Array Nat) : PartialMachine := fun s =>
  if cs[index s]?.getD 25 = 25 then none else some (decode (cs[index s]?.getD 25))

def partialEq (p q : PartialMachine) : Bool :=
  slots.all (fun s => decide (p s = q s))

theorem partialEq_sound {p q : PartialMachine} (h : partialEq p q = true) : p = q := by
  funext s
  exact of_decide_eq_true (List.all_eq_true.mp h s (slots_complete s))

theorem finite_prefix (p : PartialMachine) (m : Machine) (hm : compatible p m)
    (n : Nat) (c d : FiniteCfg)
    (h : finiteRun (weightedTNFDefaultCompletion p) n c = some d) : finiteRun m n c = some d := by
  induction n generalizing c with
  | zero => exact h
  | succ n ih =>
    cases hp : p (query c) with
    | none => simp [finiteRun,step,weightedTNFDefaultCompletion,hp] at h
    | some t =>
      cases t with
      | none => simp [finiteRun,step,weightedTNFDefaultCompletion,hp] at h
      | some mv =>
        have he := hm _ _ hp
        simp only [finiteRun,step,weightedTNFDefaultCompletion,hp,Option.getD_some,Option.map_some,Option.bind_some] at h
        simp only [finiteRun,step,he,Option.map_some,Option.bind_some]
        exact ih _ h

def haltCheck (p : PartialMachine) (n : Nat) : Bool :=
  match finiteRun (weightedTNFDefaultCompletion p) n finiteBlank with
  | none => false
  | some c => decide (n+1≤70) && decide (p (query c) = some none)

theorem haltCheck_sound (p : PartialMachine) (n : Nat) (h : haltCheck p n = true)
    (m : Machine) (hm : compatible p m) : DecidedBelow 70 m := by
  unfold haltCheck at h
  cases hr : finiteRun (weightedTNFDefaultCompletion p) n finiteBlank with
  | none => simp [hr] at h
  | some c =>
    simp only [hr,Bool.and_eq_true,decide_eq_true_eq] at h
    have hf := finite_prefix p m hm n finiteBlank c hr
    obtain ⟨d,hd,hs,hh⟩ := finite_halt_sound m n c (query c) hf rfl (hm _ _ h.2)
    refine Or.inr ⟨n,h.1,?_,?_⟩
    · simp [hd]
    · simp [run,hd,rawStep,hs,hh]

def totalCheck (p : PartialMachine) : Bool := slots.all (fun s => ((p s).getD none).isSome)

theorem totalCheck_sound (p : PartialMachine) (h : totalCheck p = true)
    (m : Machine) (hm : compatible p m) : NeverHalts m := by
  have ht : ∀ s, ∃ mv, m s = some mv := by
    intro s
    have hh := List.all_eq_true.mp h s (slots_complete s)
    cases hs : p s with
    | none => simp [hs] at hh
    | some t =>
      cases t with
      | none => simp [hs] at hh
      | some mv => exact ⟨mv,hm _ _ hs⟩
  intro n
  induction n with
  | zero => rfl
  | succ n ih =>
    cases hr : run m n blank with
    | none => simp [hr] at ih
    | some c =>
      obtain ⟨mv,hv⟩ := ht (readSlot c)
      simp [run,hr,rawStep,hv]

theorem default_never_sound (p : PartialMachine) (h : NeverHalts (weightedTNFDefaultCompletion p)) :
    ∀ m, compatible p m → NeverHalts m := by
  apply (weightedTNFKnownRunForever_iff p).mp
  intro n
  have hh := h n
  rw [← weightedTNFKnownRun_eq_defaultRun p n] at hh
  cases hr : knownRun p n with
  | none => simp [hr] at hh
  | some c => exact ⟨c,rfl⟩

inductive Witness where
  | halt (n : Nat)
  | ray (right : Bool) (entry period budget : Nat)
  | total
  | ngram (c : BB6.Agent47SparseNGram.Cert)
  | external

inductive Tree where
  | leaf (w : Witness)
  | split (s : Slot) (kids : Array Tree)

def leafCheck (ext : PartialMachine → Bool) (p : PartialMachine) : Witness → Bool
  | .halt n => haltCheck p n
  | .ray r e n k => BB6.Agent50TranslatedCycler.translatedCyclerCheck (weightedTNFDefaultCompletion p) r e n k
  | .total => totalCheck p
  | .ngram c => BB6.Agent47SparseNGram.check p c
  | .external => ext p

theorem leafCheck_sound (ext : PartialMachine → Bool)
    (hExt : ∀ p, ext p = true → ∀ m, compatible p m → NeverHalts m)
    (p : PartialMachine) (w : Witness) (h : leafCheck ext p w = true)
    (m : Machine) (hm : compatible p m) : DecidedBelow 70 m := by
  cases w with
  | halt n => exact haltCheck_sound p n h m hm
  | ray r e n k => exact Or.inl (default_never_sound p (BB6.Agent50TranslatedCycler.translatedCyclerCheck_sound h) m hm)
  | total => exact Or.inl (totalCheck_sound p h m hm)
  | ngram c => exact Or.inl (BB6.Agent47SparseNGram.never p c h m hm)
  | external => exact Or.inl (hExt p h m hm)

/-- Exhaustiveness does not trust first-hole enumeration: each branch is checked
against the original allowed domain, and each leaf is checked under its actual
accumulated assignments. -/
def treeCheck (ext : PartialMachine → Bool) (domain : Box Slot Transition) :
    Nat → PartialMachine → Tree → Bool
  | 0, _, _ => false
  | fuel+1, p, .leaf w => leafCheck ext p w
  | fuel+1, p, .split s kids => (domain s).all (fun t =>
      match kids[code t]? with
      | none => false
      | some child => treeCheck ext domain fuel (refine p s t) child)

theorem treeCheck_sound (ext : PartialMachine → Bool)
    (hExt : ∀ p, ext p = true → ∀ m, compatible p m → NeverHalts m)
    (domain : Box Slot Transition) (fuel : Nat) (p : PartialMachine) (tree : Tree)
    (h : treeCheck ext domain fuel p tree = true)
    (m : Machine) (hm : Fits domain m) (hp : compatible p m) : DecidedBelow 70 m := by
  induction fuel generalizing p tree with
  | zero => simp [treeCheck] at h
  | succ fuel ih =>
    cases tree with
    | leaf w => exact leafCheck_sound ext hExt p w h m hp
    | split s kids =>
      have hh := List.all_eq_true.mp h (m s) (hm s)
      cases hk : kids[code (m s)]? with
      | none => simp [hk] at hh
      | some child =>
        rw [hk] at hh
        exact ih (refine p s (m s)) child hh (compatible_refine p m s hp)

theorem base_ordinary (ext : PartialMachine → Bool)
    (hExt : ∀ p, ext p = true → ∀ m, compatible p m → NeverHalts m)
    (tree : Tree) (h : treeCheck ext baseBox 5 initial tree = true)
    (m : Machine) (hm : Fits baseBox m) : DecidedBelow 70 m :=
  treeCheck_sound ext hExt baseBox 5 initial tree h m hm (initial_compatible m hm)

theorem shard_sound (ext : PartialMachine → Bool)
    (hExt : ∀ p, ext p = true → ∀ m, compatible p m → NeverHalts m)
    (v : Nat) (tree : Tree) (h : treeCheck ext baseBox 4 (refine initial (4,true) (decode v)) tree = true)
    (m : Machine) (hm : Fits baseBox m) (hv : m (4,true) = decode v) : DecidedBelow 70 m := by
  apply treeCheck_sound ext hExt baseBox 4 _ tree h m hm
  rw [← hv]
  exact compatible_refine initial m (4,true) (initial_compatible m hm)

theorem subshard_sound (ext : PartialMachine → Bool)
    (hExt : ∀ p, ext p = true → ∀ m, compatible p m → NeverHalts m)
    (v : Nat) (s : Slot) (a : Nat) (tree : Tree)
    (h : treeCheck ext baseBox 3 (refine (refine initial (4,true) (decode v)) s (decode a)) tree = true)
    (m : Machine) (hm : Fits baseBox m) (hv : m (4,true) = decode v)
    (ha : m s = decode a) : DecidedBelow 70 m := by
  apply treeCheck_sound ext hExt baseBox 3 _ tree h m hm
  rw [← hv, ← ha]
  exact compatible_refine _ m s (compatible_refine initial m (4,true) (initial_compatible m hm))

theorem base_e0_ne (m : Machine) (hm : Fits baseBox m) : m (4,false) ≠ decode 23 := by
  have h : m (4,false) ∈ choices.filter (fun t => decide (t ≠ decode 23)) := hm (4,false)
  exact of_decide_eq_true (List.mem_filter.mp h).2

theorem ordinary_weighted (B : Nat) (hB : 75≤B) (m : Machine)
    (h : DecidedBelow 70 m) : WeightedBound B m := by
  intro k d hk hd
  rcases h with hn | ⟨n,hbound,hh⟩
  · have hx := hn (k+1)
    rw [hk.2] at hx
    contradiction
  · have he := halting_time_unique m k n hk hh
    have hlt : d < 6 := List.mem_range.mp (List.mem_filter.mp hd).1
    omega

#print axioms treeCheck_sound
#print axioms base_ordinary
#print axioms ordinary_weighted
end BB6.Agent49Box6
