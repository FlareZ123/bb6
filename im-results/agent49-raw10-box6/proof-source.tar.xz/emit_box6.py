#!/usr/bin/env python3
"""Emit Lean source witnesses and exact domain-cover checks for raw10 box6.

Run after unpacking source.tar.gz and running search.py and ngram.py.
Only the existing Lean semantic checkers determine acceptance.
"""
from pathlib import Path
from collections import Counter
import json, sys, importlib.util
from search import simulate, prefix, dom


def trace(t,n):
    q=L=R=h=0; hist=[h]
    for _ in range(n):
        a=t[2*q+(R&1)]-1
        assert a>=0
        q=a//4; w=(a>>1)&1; r=a&1
        if r:L=(L<<1)|w;R>>=1;h+=1
        else:R=(((R>>1)<<1|w)<<1)|(L&1);L>>=1;h-=1
        hist.append(h)
    return hist


def trie(xs):
    if not xs:return '.empty'
    if max(xs)==0:return '.leaf'
    e=[x//2 for x in xs if x%2==0];o=[x//2 for x in xs if x%2==1]
    return f'(.branch {trie(e)} {trie(o)})'


def emit_ngram(c):
    k=c['k']; edges=[]
    for d in c['edges']:
        edges.append(trie([2*int(x)+b for x,v in d.items() for b in (0,1) if v>>b&1]))
    rows=[[] for _ in range(12)]
    for s,l,r in c['states']:rows[s].append(r+(1<<k)*l)
    return '⟨'+str(k-1)+','+','.join(edges)+',#['+','.join(trie(row) for row in rows)+']⟩'


def build_tree(t,leafmap,ngram,hard,counts):
    kind,v,i=simulate(t)
    if kind=='hole':
        counts['split']+=1
        kids=['(.leaf .total)']*25
        for a in dom[v]:kids[a]=build_tree(t[:v]+(a,)+t[v+1:],leafmap,ngram,hard,counts)
        return f'(.split ({v//2},{str(bool(v%2)).lower()}) #[\n'+',\n'.join(kids)+'\n])'
    assert leafmap[t]==(kind,v,i)
    counts[kind]+=1
    if kind=='halt':return f'(.leaf (.halt {v-1}))'
    if kind in ('cycle','rayL','rayR'):
        hist=trace(t,v); seg=hist[i:v+1]
        right=hist[v]>=hist[i]
        if kind=='rayR':assert right and hist[v]>hist[i]
        if kind=='rayL':assert not right
        k=hist[i]-min(seg) if right else max(seg)-hist[i]
        return f'(.leaf (.ray {str(right).lower()} {i} {v-i} {k}))'
    assert kind=='open'
    if all(x>0 for x in t):return '(.leaf .total)'
    if t in ngram:return f'(.leaf (.ngram {emit_ngram(ngram[t])}))'
    assert t in hard
    return '(.leaf .external)'


def tmstring(t):
    def move(x):
        if x<=0:return '---'
        x-=1
        return f'{(x>>1)&1}{"R" if x&1 else "L"}{chr(65+x//4)}'
    return '_'.join(''.join(move(x) for x in t[i:i+2]) for i in range(0,12,2))


def build_hard(out, hard, generator_path):
    spec=importlib.util.spec_from_file_location('blockfargen',generator_path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    for t in sorted(hard):
        name=f'Box6Hard{t[9]}_{t[10]}'
        temp=out/f'.gen{t[9]}_{t[10]}';temp.mkdir(exist_ok=True)
        mod.generate(tmstring(t),temp)
        for kind in ('Packed','Proof'):
            file=temp/f'HeldBlock{kind}.lean'
            data=file.read_text().replace('HeldBlockPacked',name+'Packed').replace('BB6BlockFAR.Held','BB6BlockFAR.'+name)
            (out/f'{name}{kind}.lean').write_text(data)
        for f in temp.iterdir():f.unlink()
        temp.rmdir()
    names=[f'Box6Hard{t[9]}_{t[10]}' for t in sorted(hard)]
    source='import Box6Core\nimport BlockFARBridge\n'+''.join(f'import {name}Proof\n' for name in names)
    source+='\nnamespace BB6.Agent49Box6\nopen BB6Coverage\n'
    for name in names:source+=f'def p{name} : PartialMachine := BB6BlockFAR.partialTable BB6BlockFAR.{name}.machine\n'
    expr=f'partialEq p p{names[-1]}'
    for name in reversed(names[:-1]):expr=f'partialEq p p{name} || ({expr})'
    source+=f'def externalCheck (p : PartialMachine) : Bool := {expr}\n'
    source+='''theorem externalCheck_sound (p : PartialMachine) (h : externalCheck p = true)
    (m : Machine) (hm : compatible p m) : NeverHalts m := by
  simp only [externalCheck,Bool.or_eq_true] at h
  rcases h with '''+ ' | '.join('h' for name in names)+'\n'
    for name in names:
        source+=f'  · rw [partialEq_sound h] at hm\n    exact BB6BlockFAR.transfer_never BB6BlockFAR.{name}.machine m hm BB6BlockFAR.{name}.never\n'
    source+='\n#print axioms externalCheck_sound\nend BB6.Agent49Box6\n'
    (out/'Box6Hard.lean').write_text(source)


def main():
    out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True)
    generator_path=Path(sys.argv[2]) if len(sys.argv)>2 else None
    x=json.load(open('leaves.json'));leafmap={tuple(t):(k,v,i) for t,k,v,i in x['leaves']}
    x=json.load(open('ngram.json'));ngram={tuple(t):c for t,c in x['solved']};hard={tuple(t) for t in x['left']}
    assert hard=={prefix+(21,19,4,-1),prefix+(21,19,16,-1)}
    # BlockFAR is much smaller than two width-15 bit n-grams.
    for t in list(ngram):
        if ngram[t]['k']>=15:hard.add(t);del ngram[t]
    assert hard=={prefix+(21,e,f,-1) for e in (7,19) for f in (4,16)}
    if generator_path:build_hard(out,hard,generator_path)
    header='import Box6Hard\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\nnamespace BB6.Agent49Box6\nopen BB6Coverage\nopen BB6.Agent49Box (Fits)\n'
    # Root query is E1. Each of 25 shards is independently checked.
    assert simulate(prefix+(-1,)*4)==('hole',9,0)
    counts=Counter()
    for v in range(25):
        t=prefix+(-1,v,-1,-1)
        k,slot,_=simulate(t)
        # Separate kernel checks for the largest first-level branch.
        if v==23:
            assert k=='hole'
            counts['split']+=1
            sl=f'({slot//2},{str(bool(slot%2)).lower()})'
            s=header
            for a in dom[slot]:
                tree=build_tree(t[:slot]+(a,)+t[slot+1:],leafmap,ngram,hard,counts)
                s+=f'def tree{v}_{a} : Tree := {tree}\n\n'
                s+=f'theorem check{v}_{a} : treeCheck externalCheck baseBox 3 (refine (refine initial (4,true) (decode {v})) {sl} (decode {a})) tree{v}_{a} = true := by decide +kernel\n\n'
            s+=f'theorem shard{v} (m : Machine) (hm : Fits baseBox m) (hv : m (4,true) = decode {v}) : DecidedBelow 70 m := by\n'
            s+=f'  have hc := code_ok (m {sl})\n  have hs : '+' ∨ '.join(f'code (m {sl}) = {a}' for a in range(25))+' := by omega\n'
            s+='  rcases hs with '+' | '.join('h' for _ in range(25))+'\n'
            for a in range(25):
                if a not in dom[slot]:
                    assert slot==8 and a==23
                    s+='  · exact False.elim (base_e0_ne m hm (by rw [← h, hc.2]))\n'
                else:
                    s+=f'  · exact subshard_sound externalCheck externalCheck_sound {v} {sl} {a} tree{v}_{a} check{v}_{a} m hm hv (by rw [← h, hc.2])\n'
            s+='end BB6.Agent49Box6\n'
        else:
            tree=build_tree(t,leafmap,ngram,hard,counts)
            s=header+f'def tree{v} : Tree := {tree}\n\n'
            s+=f'theorem check{v} : treeCheck externalCheck baseBox 4 (refine initial (4,true) (decode {v})) tree{v} = true := by decide +kernel\n\n'
            s+=f'theorem shard{v} (m : Machine) (hm : Fits baseBox m) (hv : m (4,true) = decode {v}) : DecidedBelow 70 m :=\n  shard_sound externalCheck externalCheck_sound {v} tree{v} check{v} m hm hv\nend BB6.Agent49Box6\n'
        (out/f'Box6Shard{v}.lean').write_text(s)
    assert counts=={'split':478,'halt':479,'cycle':3561,'rayL':4866,'rayR':2047,'open':356},counts
    s=''.join(f'import Box6Shard{i}\n' for i in range(25))+'''set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent49Box6
open BB6Coverage BB6.Agent13BlankDelay BB6.Agent49BoxBridge
open BB6.Agent49Box (Fits Box)

theorem box6_ordinary (m : Machine) (hm : Fits baseBox m) : DecidedBelow 70 m := by
  have hc := code_ok (m (4,true))
  have hs : '''+' ∨ '.join(f'code (m (4,true)) = {i}' for i in range(25))+''' := by omega
  rcases hs with '''+' | '.join('h' for _ in range(25))+'\n'
    s+=''.join(f'  · exact shard{i} m hm (by rw [← h, hc.2])\n' for i in range(25))
    s+='''
theorem box6_weighted (B : Nat) (hB : 75≤B) (m : Machine) (hm : Fits baseBox m) : WeightedBound B m :=
  ordinary_weighted B hB m (box6_ordinary m hm)

/-- Compare finite pointwise membership, independent of domain order. -/
def sourceMatch (b : Box Slot Transition) : Bool :=
  slots.all fun s => transitions.all fun t => decide ((t ∈ b s) ↔ (t ∈ baseBox s))

theorem sourceMatch_sound (b : Box Slot Transition) (h : sourceMatch b=true)
    (m : Machine) (hm : Fits b m) : Fits baseBox m := by
  intro s
  have hs := List.all_eq_true.mp h s (slots_complete s)
  have ht := List.all_eq_true.mp hs (m s) (transitions_complete (m s))
  exact (of_decide_eq_true ht).mp (hm s)

theorem source_has_box6 : raw10Remainder.any sourceMatch = true := by decide +kernel

theorem raw10_box6_closed (B : Nat) (hB : 75≤B) :
    ∃ b ∈ raw10Remainder, sourceMatch b=true ∧ ∀ m, Fits b m → WeightedBound B m := by
  obtain ⟨b,hb,hmatch⟩ := List.any_eq_true.mp source_has_box6
  exact ⟨b,hb,hmatch,fun m hm => box6_weighted B hB m (sourceMatch_sound b hmatch m hm)⟩

theorem residual_without_box6 (B : Nat) (hB : 75≤B)
    (hrest : ∀ b ∈ raw10Remainder, sourceMatch b=false → ∀ m, Fits b m → WeightedBound B m) :
    ∀ b ∈ raw10Remainder, ∀ m, Fits b m → WeightedBound B m := by
  intro b hb m hm
  cases h : sourceMatch b with
  | false => exact hrest b hb h m hm
  | true => exact box6_weighted B hB m (sourceMatch_sound b h m hm)

#print axioms box6_ordinary
#print axioms box6_weighted
#print axioms raw10_box6_closed
#print axioms residual_without_box6
end BB6.Agent49Box6
'''
    (out/'Box6SourceConsumer.lean').write_text(s)
    print('Generated exact tree with',dict(counts))
if __name__=='__main__':main()
