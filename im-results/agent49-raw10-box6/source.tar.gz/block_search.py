from functools import lru_cache
from collections import defaultdict,deque
import json

def macro_fn(t,k):
    @lru_cache(None)
    def macro(s,a):
        q,d=divmod(s,2);h=0 if d else k-1;seen=set()
        while 0<=h<k:
            z=(q,h,a)
            if z in seen:return 'cycle'
            seen.add(z);x=t[2*q+(a>>h&1)]
            if x<=0:return None
            x-=1;q=x//4;w=(x>>1)&1;d=x&1
            a=(a&~(1<<h))|(w<<h);h+=1 if d else -1
        return 2*q+d,a,d
    return macro

def block_ngram(t,k,n,offset=0,cap=300000):
    A=1<<k;mask=(1<<(k*n))-1;macro=macro_fn(t,k)
    edges=[defaultdict(set),defaultdict(set)];wait=[defaultdict(list),defaultdict(list)];seen=set();todo=[];fail=False
    # start at left-aligned cell; offset would require first partial macro, not used
    def add(s,a,l,r):
        nonlocal fail
        v=s,a,l,r
        if v in seen:return
        if len(seen)>=cap or macro(s,a) is None:fail=True;return
        seen.add(v);todo.append(v)
    def pop(v,e):
        s,a,l,r=v;m=macro(s,a)
        if m=='cycle':return
        q,w,d=m
        if d:add(q,r&(A-1),((l<<k)|w)&mask,(r>>k)|(e<<(k*(n-1))))
        else:add(q,l&(A-1),(l>>k)|(e<<(k*(n-1))),((r<<k)|w)&mask)
    def edge(d,x,e):
        if e in edges[d][x]:return
        edges[d][x].add(e)
        for v in wait[d][x]:
            pop(v,e)
            if fail:return
    edges[0][0].add(0);edges[1][0].add(0);add(1,0,0,0)
    for v in todo:
        if fail:return None,len(todo)
        s,a,l,r=v;m=macro(s,a)
        if m=='cycle':continue
        q,w,d=m;push=l if d else r;px=r if d else l
        edge(0 if d else 1,((push<<k)|w)&mask,push>>(k*(n-1)))
        if fail:return None,len(todo)
        j=1 if d else 0;wait[j][px].append(v)
        for e in edges[j][px]:pop(v,e)
    if fail:return None,len(todo)
    return (seen,edges),len(todo)

def far(t,k,cap=2000000):
    A=1<<k;macro=macro_fn(t,k)
    left=[()];leftids={():0};delta={};pred=defaultdict(list)
    nodes=[('T',)];nodeids={nodes[0]:0};edges=defaultdict(set);copier=defaultdict(set);pending=defaultdict(list);event=deque()
    def node(key):
        if key not in nodeids:nodeids[key]=len(nodes);nodes.append(key)
        return nodeids[key]
    def ctrl(l,s):return node(('c',l,s))
    def add(s,a,t):
        if (a,t) not in edges[s]:edges[s].add((a,t));event.append((s,a,t))
    def copy(q,v):
        if q not in copier[v]:
            copier[v].add(q)
            for a,t in tuple(edges[v]):add(q,a,t)
    def applyleft(l0,b,q,w,v):
        p=ctrl(l0,q);x=node(('x',p,b));add(x,w,v);add(p,b,x)
    def push(l,a):
        key=l,a
        if key in delta:return delta[key]
        xs=left[l]
        if not xs and a==0:ys=()
        elif xs and xs[0][0]==a:
            s,n,m=xs[0];ys=((s,min(2,n+1),(m+1)%4),)+xs[1:]
        else:ys=((a,1,1),)+xs[:1]
        if ys not in leftids:leftids[ys]=len(left);left.append(ys)
        j=leftids[ys];delta[key]=j;pred[j].append(key)
        for q,w,v in pending[j]:applyleft(l,a,q,w,v)
        return j
    push(0,0);add(0,0,0);copy(ctrl(0,1),0);count=0
    while event:
        s,a,v=event.popleft();count+=1
        if count>cap:return 'limit',len(left),len(nodes),count
        for q in tuple(copier[s]):add(q,a,v)
        key=nodes[s]
        if key[0]!='c':continue
        _,l,q=key;m=macro(q,a)
        if m is None:return 'halt',len(left),len(nodes),count
        if m=='cycle':continue
        q2,w,d=m
        if d:copy(ctrl(push(l,w),q2),v)
        else:
            pending[l].append((q2,w,v))
            for l0,b in tuple(pred[l]):applyleft(l0,b,q2,w,v)
    return 'solved',len(left),len(nodes),count

if __name__=='__main__':
    for t in json.load(open('ngram.json'))['left']:
        for k in range(1,9):
            for n in range(1,7):
                c,N=block_ngram(t,k,n,cap=100000)
                print('ng',t[8:],k,n,N,bool(c),flush=True)
                if c:break
            if c:break
        for k in range(1,7):
            print('FAR',t[8:],k,far(t,k,200000),flush=True)
