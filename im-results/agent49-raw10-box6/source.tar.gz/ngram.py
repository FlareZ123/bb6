import json
from collections import defaultdict,Counter
from search import simulate,dom

def ngram(t,k,cap=100000):
    mask=(1<<k)-1;seen=set();todo=[];edges=[defaultdict(int),defaultdict(int)];waiting=[defaultdict(list),defaultdict(list)];fail=False
    def add(s,l,r):
        nonlocal fail
        v=(s,l,r)
        if v in seen:return
        if t[s]<=0 or len(seen)>=cap:fail=True;return
        seen.add(v);todo.append(v)
    def pop(v,e):
        s,l,r=v;a=t[s]-1;q=a//4;w=(a>>1)&1;R=a&1
        if R:add(2*q+(r&1),((l<<1)|w)&mask,(r>>1)|(e<<(k-1)))
        else:add(2*q+(l&1),(l>>1)|(e<<(k-1)),((r<<1)|w)&mask)
    def edge(d,x,e):
        if edges[d][x]&(1<<e):return
        edges[d][x]|=1<<e
        for v in waiting[d][x]:
            pop(v,e)
            if fail:return
    edges[0][0]=edges[1][0]=1;add(0,0,0)
    for v in todo:
        if fail:return None
        s,l,r=v;a=t[s]-1;w=(a>>1)&1;R=a&1;push=l if R else r;px=r if R else l
        edge(0 if R else 1,((push<<1)|w)&mask,push>>(k-1))
        if fail:return None
        d=1 if R else 0;waiting[d][px].append(v)
        for e in (0,1):
            if edges[d][px]&(1<<e):pop(v,e)
    if fail:return None
    return {'k':k,'edges':[{x:v for x,v in e.items() if v} for e in edges],'states':todo}

if __name__=='__main__':
    src=json.load(open('leaves.json'));o=[tuple(t) for t in src['opens'] if -1 in t];solved=[];left=[]
    for t in o:
        for k in range(1,20):
            c=ngram(t,k)
            if c is not None:
                solved.append((t,c));print('NGRAM',t[8:],k,len(c['states']),flush=True);break
        else:left.append(t);print('OPEN',t[8:],flush=True)
    print('total',len(solved),len(left));json.dump({'solved':solved,'left':left},open('ngram.json','w'))
