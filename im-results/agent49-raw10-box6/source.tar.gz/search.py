from collections import Counter,defaultdict
from itertools import product
import json,time,math
prefix=(8,14,11,7,17,4,9,2)
dom=[tuple([x]) for x in prefix]+[tuple(i for i in range(25) if i!=23)]+[tuple(range(25))]*3

def simulate(t,limit=256):
    q=L=R=h=0
    seen={}; right=defaultdict(list);left=defaultdict(list); hist=[]
    for n in range(limit):
        cfg=(q,L,R)
        if cfg in seen:return ('cycle',n,seen[cfg])
        seen[cfg]=n
        hist.append((h,L,R))
        for i in reversed(right[q,R][-2:]):
            hi,li,ri=hist[i]
            if h<=hi or n-i>128:continue
            k=max(0,hi-min(x[0] for x in hist[i:n+1]))
            if ((L^li)&((1<<k)-1))==0:return ('rayR',n,i)
        for i in reversed(left[q,L][-2:]):
            hi,li,ri=hist[i]
            if h>=hi or n-i>128:continue
            k=max(x[0] for x in hist[i:n+1])-hi+1
            if ((R^ri)&((1<<k)-1))==0:return ('rayL',n,i)
        right[q,R].append(n);left[q,L].append(n)
        x=2*q+(R&1); a=t[x]
        if a<0:return ('hole',x,0)
        if a==0:return ('halt',n+1,0)
        a-=1;q=a//4;w=(a>>1)&1;r=a&1
        if r:L=(L<<1)|w;R>>=1;h+=1
        else:R=(((R>>1)<<1|w)<<1)|(L&1);L>>=1;h-=1
    return ('open',limit,0)

def run():
    root=prefix+(-1,)*4
    stack=[root]; cnt=Counter(); leaves=[]; opens=[]; bound=0
    while stack:
        t=stack.pop(); k,v,i=simulate(t)
        if k=='hole':
            stack.extend(t[:v]+(a,)+t[v+1:] for a in dom[v]);cnt[k]+=1
        else:
            cnt[k]+=1; leaves.append((t,k,v,i))
            if k=='open':opens.append(t)
            if k=='halt':bound=max(bound,v)
    print(cnt,'bound',bound,'open mass',sum(math.prod(len(dom[i]) if x<0 else 1 for i,x in enumerate(t)) for t in opens));print(opens[:30]);json.dump({'leaves':leaves,'opens':opens},open('leaves.json','w'))
if __name__=='__main__':run()
