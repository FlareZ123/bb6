import Raw54LADigitCore
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.LA.M76
open BB6Coverage BB6Coverage.Agent31Pump BB6.Agent8Raw54.LADigit
def table : PartialMachine := fun s => match s.1.val,s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 0,true => some (some ⟨false,true,1⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨false,true,5⟩)
  | 2,false => some (some ⟨false,true,3⟩)
  | 2,true => some (some ⟨true,true,1⟩)
  | 3,false => some (some ⟨true,false,3⟩)
  | 3,true => some (some ⟨false,false,4⟩)
  | 4,false => some (some ⟨true,false,0⟩)
  | 4,true => some (some ⟨false,false,4⟩)
  | 5,false => some (some ⟨false,false,0⟩)
  | _,_ => none
theorem entry : run0 table 85 ⟨0,[],[]⟩ = some (idle [true]) := by rfl
theorem enter (T : List Bool) : run0 table 49 ⟨1,[true,true],h ++ T⟩ = some ⟨1,ones ++ ones ++ [false,true,false],T⟩ := by rfl
theorem pop (n : Nat) (T : List Bool) : run0 table 5 ⟨1,ones ++ ones ++ rep ones n ++ [false,true,false],o ++ T⟩ = some ⟨1,ones ++ ones ++ rep ones (n+1) ++ [false,true,false],T⟩ := by rfl
theorem stop (n : Nat) (T : List Bool) : run0 table (3*n+27) ⟨1,([true,true,true,true,true,true] ++ (rep [true,true,true] n ++ [false,true,false])),([false,false,false] ++ T)⟩ = some ⟨1,[true,true],([false,false,true,true,false,false,false] ++ (rep [false,false,false] n ++ ([false,true,true] ++ T)))⟩ := by
  have h0 : run0 table 8 ⟨1,([true,true,true,true,true,true] ++ (rep [true,true,true] n ++ [false,true,false])),([false,false,false] ++ T)⟩ = some ⟨4,([true,true,true,true,true,true] ++ (rep [true,true,true] n ++ [false,true,false])),([false,true,true] ++ T)⟩ := by rfl
  have h1 : run0 table (3*n) ⟨4,([true,true,true,true,true,true] ++ (rep [true,true,true] n ++ [false,true,false])),([false,true,true] ++ T)⟩ = some ⟨4,[true,true,true,true,true,true,false,true,false],([] ++ (rep [false,false,false] n ++ ([false,true,true] ++ T)))⟩ := by
    exact sweepL table 4 [true,true,true,true,true,true] [] [true,true,true] [false,false,false] 3 (fun _ _ => rfl) n [false,true,false] ([false,true,true] ++ T)
  have g1 := join0 h0 h1
  have h2 : run0 table 19 ⟨4,[true,true,true,true,true,true,false,true,false],([] ++ (rep [false,false,false] n ++ ([false,true,true] ++ T)))⟩ = some ⟨1,[true,true],([false,false,true,true,false,false,false] ++ (rep [false,false,false] n ++ ([false,true,true] ++ T)))⟩ := by rfl
  have g2 := join0 g1 h2
  rw [show 8+(3*n)+19=3*n+27 by omega] at g2
  exact g2
theorem finish (n : Nat) : run0 table (3*n+27) ⟨1,([true,true,true,true,true,true] ++ (rep [true,true,true] n ++ [false,true,false])),[]⟩ = some ⟨1,[true,true],([false,false,true,true,false,false,false] ++ (rep [false,false,false] n ++ [false,true,true]))⟩ := by
  have h0 : run0 table 8 ⟨1,([true,true,true,true,true,true] ++ (rep [true,true,true] n ++ [false,true,false])),[]⟩ = some ⟨4,([true,true,true,true,true,true] ++ (rep [true,true,true] n ++ [false,true,false])),[false,true,true]⟩ := by rfl
  have h1 : run0 table (3*n) ⟨4,([true,true,true,true,true,true] ++ (rep [true,true,true] n ++ [false,true,false])),[false,true,true]⟩ = some ⟨4,[true,true,true,true,true,true,false,true,false],([] ++ (rep [false,false,false] n ++ [false,true,true]))⟩ := by
    exact sweepL table 4 [true,true,true,true,true,true] [] [true,true,true] [false,false,false] 3 (fun _ _ => rfl) n [false,true,false] [false,true,true]
  have g1 := join0 h0 h1
  have h2 : run0 table 19 ⟨4,[true,true,true,true,true,true,false,true,false],([] ++ (rep [false,false,false] n ++ [false,true,true]))⟩ = some ⟨1,[true,true],([false,false,true,true,false,false,false] ++ (rep [false,false,false] n ++ [false,true,true]))⟩ := by rfl
  have g2 := join0 g1 h2
  rw [show 8+(3*n)+19=3*n+27 by omega] at g2
  exact g2
theorem never (m : Machine) (hm : compatible table m) : NeverHalts m := by
  apply LADigit.never table 49 27 85 (by decide) (by decide) entry enter pop _ _ m hm
  · intro n T; simpa only [ones,z,o,h,List.append_assoc,List.cons_append,List.nil_append] using stop n T
  · intro n; simpa only [carry,enc,ones,z,o,h,List.append_assoc,List.append_nil,List.cons_append,List.nil_append] using finish n
#print axioms never
end BB6.Agent8Raw54.LA.M76
