import Raw54RAClosedCore
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.LADigit
open BB6Coverage BB6Coverage.Agent31Pump BB6.Agent8Raw54.RAClosed

def z : List Bool := [false,false,false]
def o : List Bool := [false,true,true]
def h : List Bool := [false,false,true,true,false,false,false]
def ones : List Bool := [true,true,true]
def enc : List Bool → List Bool
  | [] => []
  | false::w => z ++ enc w
  | true::w => o ++ enc w
def idle (w : List Bool) : Z0 := ⟨1,[true,true],h ++ enc w⟩
def carry (n : Nat) (w : List Bool) : Z0 :=
  ⟨1,ones ++ ones ++ rep ones n ++ [false,true,false],enc w⟩
def sect (s : Option Nat × List Bool) : Z0 :=
  match s with
  | (none,w) => idle w
  | (some n,w) => carry n w

theorem enc_zeros (n : Nat) (w : List Bool) : enc (List.replicate n false ++ w) = rep z n ++ enc w := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [List.replicate_succ,List.cons_append,enc,rep,ih,List.append_assoc]

theorem never (p : PartialMachine) (enterCost stopCost startTime : Nat)
    (hp : 0 < enterCost) (hs : 0 < stopCost)
    (entry : run0 p startTime ⟨0,[],[]⟩ = some (idle [true]))
    (enter : ∀ T, run0 p enterCost ⟨1,[true,true],h ++ T⟩ = some ⟨1,ones ++ ones ++ [false,true,false],T⟩)
    (pop : ∀ n T, run0 p 5 ⟨1,ones ++ ones ++ rep ones n ++ [false,true,false],o ++ T⟩ =
      some ⟨1,ones ++ ones ++ rep ones (n+1) ++ [false,true,false],T⟩)
    (stop : ∀ n T, run0 p (3*n+stopCost) ⟨1,ones ++ ones ++ rep ones n ++ [false,true,false],z ++ T⟩ =
      some ⟨1,[true,true],h ++ rep z n ++ o ++ T⟩)
    (finish : ∀ n, run0 p (3*n+stopCost) (carry n []) = some ⟨1,[true,true],h ++ rep z n ++ o⟩)
    (m : Machine) (hm : compatible p m) : NeverHalts m := by
  apply neverOfSection p _ sect (none,[true]) startTime entry _ m hm
  rintro ⟨s,w⟩
  cases s with
  | none =>
    exact ⟨enterCost,(some 0,w),hp,enter (enc w)⟩
  | some n =>
    cases w with
    | nil =>
      refine ⟨3*n+stopCost,(none,List.replicate n false ++ [true]),by omega,?_⟩
      simpa only [sect,idle,enc_zeros,enc,List.append_assoc,List.append_nil] using finish n
    | cons d w =>
      cases d
      · refine ⟨3*n+stopCost,(none,List.replicate n false ++ true::w),by omega,?_⟩
        simpa only [sect,idle,carry,enc_zeros,enc,List.append_assoc] using stop n (enc w)
      · exact ⟨5,(some (n+1),w),by decide,pop n (enc w)⟩
#print axioms never
end BB6.Agent8Raw54.LADigit
