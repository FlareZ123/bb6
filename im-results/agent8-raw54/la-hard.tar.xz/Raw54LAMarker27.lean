import Raw54RAClosedCore
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.LA.M27
open BB6Coverage BB6Coverage.Agent31Pump BB6.Agent8Raw54.RAClosed
def table : PartialMachine := fun s => match s.1.val,s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 0,true => some (some ⟨false,false,5⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨false,true,0⟩)
  | 2,false => some (some ⟨false,true,3⟩)
  | 2,true => some (some ⟨true,false,1⟩)
  | 3,false => some (some ⟨true,false,3⟩)
  | 3,true => some (some ⟨false,false,4⟩)
  | 4,false => some (some ⟨true,false,0⟩)
  | 4,true => some (some ⟨false,false,4⟩)
  | 5,false => some (some ⟨true,false,4⟩)
  | _,_ => none
theorem beginMark (n : Nat) : run0 table (8*n+13) ⟨0,[],([true,false] ++ (rep [true,false,true,false] n ++ [false,true,true]))⟩ = some ⟨0,[],([true,true,false,true,false,true,false] ++ (rep [true,false,true,false] n ++ [true]))⟩ := by
  have h0 : run0 table 1 ⟨0,[],([true,false] ++ (rep [true,false,true,false] n ++ [false,true,true]))⟩ = some ⟨1,[true,true],([false] ++ (rep [true,false,true,false] n ++ [false,true,true]))⟩ := by rfl
  have h1 : run0 table (4*n) ⟨1,[true,true],([false] ++ (rep [true,false,true,false] n ++ [false,true,true]))⟩ = some ⟨1,([true] ++ (rep [true,false,true,false] n ++ [true])),[false,false,true,true]⟩ := by
    exact sweepR table 1 [true] [false] [true,false,true,false] [true,false,true,false] 4 (fun _ _ => rfl) n [true] [false,true,true]
  have g1 := join0 h0 h1
  have h2 : run0 table 5 ⟨1,([true] ++ (rep [true,false,true,false] n ++ [true])),[false,false,true,true]⟩ = some ⟨0,([true,false,true,false] ++ (rep [true,false,true,false] n ++ [true])),[true]⟩ := by rfl
  have g2 := join0 g1 h2
  have h3 : run0 table (4*n) ⟨0,([true,false,true,false] ++ (rep [true,false,true,false] n ++ [true])),[true]⟩ = some ⟨0,[true,false,true,false,true],([] ++ (rep [true,false,true,false] n ++ [true]))⟩ := by
    exact sweepL table 0 [true,false,true,false] [] [true,false,true,false] [true,false,true,false] 4 (fun _ _ => rfl) n [true] [true]
  have g3 := join0 g2 h3
  have h4 : run0 table 7 ⟨0,[true,false,true,false,true],([] ++ (rep [true,false,true,false] n ++ [true]))⟩ = some ⟨0,[],([true,true,false,true,false,true,false] ++ (rep [true,false,true,false] n ++ [true]))⟩ := by rfl
  have g4 := join0 g3 h4
  rw [show 1+(4*n)+5+(4*n)+7=8*n+13 by omega] at g4
  exact g4
theorem mark (n : Nat) : run0 table (0*n+6) ⟨0,[],([true,true,false] ++ (rep [true,false,true,false] n ++ [true]))⟩ = some ⟨0,[],([true,false,true,false,false] ++ (rep [true,false,true,false] n ++ [true]))⟩ := by
  have h0 : run0 table 6 ⟨0,[],([true,true,false] ++ (rep [true,false,true,false] n ++ [true]))⟩ = some ⟨0,[],([true,false,true,false,false] ++ (rep [true,false,true,false] n ++ [true]))⟩ := by rfl
  simp only [Nat.zero_mul,Nat.zero_add]
  exact h0
theorem carry (n : Nat) (T : List Bool) : run0 table (8*n+16) ⟨0,[],([true,false,true,false] ++ (rep [true,false,true,false] n ++ ([false,true,false] ++ T)))⟩ = some ⟨0,[],([true,false,true,false,true,false,true,false] ++ (rep [true,false,true,false] n ++ ([false] ++ T)))⟩ := by
  have h0 : run0 table 1 ⟨0,[],([true,false,true,false] ++ (rep [true,false,true,false] n ++ ([false,true,false] ++ T)))⟩ = some ⟨1,[true,true],([false,true,false] ++ (rep [true,false,true,false] n ++ ([false,true,false] ++ T)))⟩ := by rfl
  have h1 : run0 table (4*n) ⟨1,[true,true],([false,true,false] ++ (rep [true,false,true,false] n ++ ([false,true,false] ++ T)))⟩ = some ⟨1,([true] ++ (rep [true,false,true,false] n ++ [true])),([false,true,false,false,true,false] ++ T)⟩ := by
    exact sweepR table 1 [true] [false,true,false] [true,false,true,false] [true,false,true,false] 4 (fun _ _ => rfl) n [true] ([false,true,false] ++ T)
  have g1 := join0 h0 h1
  have h2 : run0 table 7 ⟨1,([true] ++ (rep [true,false,true,false] n ++ [true])),([false,true,false,false,true,false] ++ T)⟩ = some ⟨0,([true,false,true,false,true,false] ++ (rep [true,false,true,false] n ++ [true])),([false] ++ T)⟩ := by rfl
  have g2 := join0 g1 h2
  have h3 : run0 table (4*n) ⟨0,([true,false,true,false,true,false] ++ (rep [true,false,true,false] n ++ [true])),([false] ++ T)⟩ = some ⟨0,[true,false,true,false,true,false,true],([] ++ (rep [true,false,true,false] n ++ ([false] ++ T)))⟩ := by
    exact sweepL table 0 [true,false,true,false,true,false] [] [true,false,true,false] [true,false,true,false] 4 (fun _ _ => rfl) n [true] ([false] ++ T)
  have g3 := join0 g2 h3
  have h4 : run0 table 8 ⟨0,[true,false,true,false,true,false,true],([] ++ (rep [true,false,true,false] n ++ ([false] ++ T)))⟩ = some ⟨0,[],([true,false,true,false,true,false,true,false] ++ (rep [true,false,true,false] n ++ ([false] ++ T)))⟩ := by rfl
  have g4 := join0 g3 h4
  rw [show 1+(4*n)+7+(4*n)+8=8*n+16 by omega] at g4
  exact g4
theorem zero (n : Nat) : run0 table (8*n+16) ⟨0,[],([true,false,true,false] ++ (rep [true,false,true,false] n ++ [false,true]))⟩ = some ⟨0,[],([true,false,true,false,true,false,true,false] ++ (rep [true,false,true,false] n ++ []))⟩ := by
  have h0 : run0 table 1 ⟨0,[],([true,false,true,false] ++ (rep [true,false,true,false] n ++ [false,true]))⟩ = some ⟨1,[true,true],([false,true,false] ++ (rep [true,false,true,false] n ++ [false,true]))⟩ := by rfl
  have h1 : run0 table (4*n) ⟨1,[true,true],([false,true,false] ++ (rep [true,false,true,false] n ++ [false,true]))⟩ = some ⟨1,([true] ++ (rep [true,false,true,false] n ++ [true])),[false,true,false,false,true]⟩ := by
    exact sweepR table 1 [true] [false,true,false] [true,false,true,false] [true,false,true,false] 4 (fun _ _ => rfl) n [true] [false,true]
  have g1 := join0 h0 h1
  have h2 : run0 table 7 ⟨1,([true] ++ (rep [true,false,true,false] n ++ [true])),[false,true,false,false,true]⟩ = some ⟨0,([true,false,true,false,true,false] ++ (rep [true,false,true,false] n ++ [true])),[]⟩ := by rfl
  have g2 := join0 g1 h2
  have h3 : run0 table (4*n) ⟨0,([true,false,true,false,true,false] ++ (rep [true,false,true,false] n ++ [true])),[]⟩ = some ⟨0,[true,false,true,false,true,false,true],([] ++ (rep [true,false,true,false] n ++ []))⟩ := by
    exact sweepL table 0 [true,false,true,false,true,false] [] [true,false,true,false] [true,false,true,false] 4 (fun _ _ => rfl) n [true] []
  have g3 := join0 g2 h3
  have h4 : run0 table 8 ⟨0,[true,false,true,false,true,false,true],([] ++ (rep [true,false,true,false] n ++ []))⟩ = some ⟨0,[],([true,false,true,false,true,false,true,false] ++ (rep [true,false,true,false] n ++ []))⟩ := by rfl
  have g4 := join0 g3 h4
  rw [show 1+(4*n)+7+(4*n)+8=8*n+16 by omega] at g4
  exact g4
theorem finish (n : Nat) : run0 table (8*n+16) ⟨0,[],([true,false,true,false] ++ (rep [true,false,true,false] n ++ []))⟩ = some ⟨0,[],([true,false,true,false,true,false] ++ (rep [true,false,true,false] n ++ [false,true,true]))⟩ := by
  have h0 : run0 table 1 ⟨0,[],([true,false,true,false] ++ (rep [true,false,true,false] n ++ []))⟩ = some ⟨1,[true,true],([false,true,false] ++ (rep [true,false,true,false] n ++ []))⟩ := by rfl
  have h1 : run0 table (4*n) ⟨1,[true,true],([false,true,false] ++ (rep [true,false,true,false] n ++ []))⟩ = some ⟨1,([true] ++ (rep [true,false,true,false] n ++ [true])),[false,true,false]⟩ := by
    exact sweepR table 1 [true] [false,true,false] [true,false,true,false] [true,false,true,false] 4 (fun _ _ => rfl) n [true] []
  have g1 := join0 h0 h1
  have h2 : run0 table 9 ⟨1,([true] ++ (rep [true,false,true,false] n ++ [true])),[false,true,false]⟩ = some ⟨4,([true,false,true,false] ++ (rep [true,false,true,false] n ++ [true])),[false,true,true]⟩ := by rfl
  have g2 := join0 g1 h2
  have h3 : run0 table (4*n) ⟨4,([true,false,true,false] ++ (rep [true,false,true,false] n ++ [true])),[false,true,true]⟩ = some ⟨4,[true,false,true,false,true],([] ++ (rep [true,false,true,false] n ++ [false,true,true]))⟩ := by
    exact sweepL table 4 [true,false,true,false] [] [true,false,true,false] [true,false,true,false] 4 (fun _ _ => rfl) n [true] [false,true,true]
  have g3 := join0 g2 h3
  have h4 : run0 table 6 ⟨4,[true,false,true,false,true],([] ++ (rep [true,false,true,false] n ++ [false,true,true]))⟩ = some ⟨0,[],([true,false,true,false,true,false] ++ (rep [true,false,true,false] n ++ [false,true,true]))⟩ := by rfl
  have g4 := join0 g3 h4
  rw [show 1+(4*n)+9+(4*n)+6=8*n+16 by omega] at g4
  exact g4
def P : List Bool := [true,false,true,false]
def Q : List Bool := [true,false]
inductive S
  | beginMark (n : Nat)
  | mark (n : Nat)
  | carry (n k : Nat)
  | finish (n : Nat)
def sect : S → Z0
  | .beginMark n => ⟨0,[],Q ++ rep P n ++ [false,true,true]⟩
  | .mark n => ⟨0,[],[true,true,false] ++ rep P n ++ [true]⟩
  | .carry n k => ⟨0,[],P ++ rep P n ++ [false] ++ rep Q k ++ [true]⟩
  | .finish n => ⟨0,[],P ++ rep P n⟩
theorem double (n : Nat) : rep Q (2*n) = rep P n := by
  induction n with
  | zero => rfl
  | succ n ih =>
    rw [show 2*(n+1) = (2*n+1)+1 by omega,rep,rep,ih]
    rfl
theorem entry : run0 table 8 ⟨0,[],[]⟩ = some (sect (.beginMark 0)) := by rfl
theorem never (m : Machine) (hm : compatible table m) : NeverHalts m := by
  apply neverOfSection table _ sect (.beginMark 0) 8 entry _ m hm
  intro s
  cases s with
  | beginMark n =>
    refine ⟨8*n+13,.mark (n+1),by omega,?_⟩
    simpa only [sect,P,Q,rep,List.append_assoc,List.cons_append,List.nil_append,List.append_nil] using beginMark n
  | mark n =>
    refine ⟨6,.carry 0 (2*n),by decide,?_⟩
    simp only [sect,double]
    simpa only [sect,double,P,Q,rep,Nat.zero_mul,Nat.zero_add,List.append_assoc,List.cons_append,List.nil_append,List.append_nil] using mark n
  | carry n k =>
    cases k with
    | zero =>
      refine ⟨8*n+16,.finish (n+1),by omega,?_⟩
      simpa only [sect,P,Q,rep,List.append_assoc,List.cons_append,List.nil_append,List.append_nil] using zero n
    | succ k =>
      refine ⟨8*n+16,.carry (n+1) k,by omega,?_⟩
      simpa only [sect,P,Q,rep,List.append_assoc,List.cons_append,List.nil_append,List.append_nil] using carry n (rep Q k ++ [true])
  | finish n =>
    refine ⟨8*n+16,.beginMark (n+1),by omega,?_⟩
    simpa only [sect,P,Q,rep,List.append_assoc,List.cons_append,List.nil_append,List.append_nil] using finish n
#print axioms never

end BB6.Agent8Raw54.LA.M27
