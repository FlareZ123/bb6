import Raw54LACarryCore
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.LA.M138
open BB6Coverage BB6Coverage.Agent31Pump BB6.Agent8Raw54.LACarry
def table : PartialMachine := fun s => match s.1.val,s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨true,false,5⟩)
  | 2,false => some (some ⟨false,true,3⟩)
  | 2,true => some (some ⟨true,true,2⟩)
  | 3,false => some (some ⟨true,false,3⟩)
  | 3,true => some (some ⟨false,false,4⟩)
  | 4,false => some (some ⟨true,false,0⟩)
  | 4,true => some (some ⟨false,false,4⟩)
  | 5,false => some (some ⟨true,true,0⟩)
  | 5,true => some (some ⟨false,true,5⟩)
  | _,_ => none
def pre : List Bool := [false,true,true,true]
def P : List Bool := [true,true]
def z : List Bool := [false,false]
def o : List Bool := [true,true]
def tail (b : Bool) : List Bool := if b then [false,false,false,true,false,false] else [false,false,false,true,false,false]
def out (b : Bool) := b
theorem entry : run0 table 21 ⟨0,[],[]⟩ = some (sect pre P z o tail (0,true,none)) := by rfl
theorem stopHi (n : Nat) (T : List Bool) : run0 table (2*n+16) ⟨2,[false,true,true,true,false,false,false,true,false,false],([false] ++ (rep [true,true] n ++ ([false,false] ++ T)))⟩ = some ⟨2,([false,true,true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),([false] ++ T)⟩ := by
  have h0 : run0 table 14 ⟨2,[false,true,true,true,false,false,false,true,false,false],([false] ++ (rep [true,true] n ++ ([false,false] ++ T)))⟩ = some ⟨2,[true,true,true,true,false,false,false,true,false,false],([true] ++ (rep [true,true] n ++ ([false,false] ++ T)))⟩ := by rfl
  have h1 : run0 table (2*n) ⟨2,[true,true,true,true,false,false,false,true,false,false],([true] ++ (rep [true,true] n ++ ([false,false] ++ T)))⟩ = some ⟨2,([true] ++ (rep [true,true] n ++ [true,true,true,false,false,false,true,false,false])),([true,false,false] ++ T)⟩ := by
    exact sweepR table 2 [true] [true] [true,true] [true,true] 2 (fun _ _ => rfl) n [true,true,true,false,false,false,true,false,false] ([false,false] ++ T)
  have g1 := join0 h0 h1
  have h2 : run0 table 2 ⟨2,([true] ++ (rep [true,true] n ++ [true,true,true,false,false,false,true,false,false])),([true,false,false] ++ T)⟩ = some ⟨2,([false,true,true] ++ (rep [true,true] n ++ [true,true,true,false,false,false,true,false,false])),([false] ++ T)⟩ := by rfl
  have g2 := join0 g1 h2
  have e3 : (⟨2,([false,true,true] ++ (rep [true,true] n ++ [true,true,true,false,false,false,true,false,false])),([false] ++ T)⟩ : Z0) = ⟨2,([false,true,true,true] ++ (rep [true,true] n ++ [true,true,false,false,false,true,false,false])),([false] ++ T)⟩ := congrArg (fun x => (⟨2,x,([false] ++ T)⟩ : Z0)) ((moveCut [false,true,true] [true,true,false,false,false,true,false,false] [true] true n).symm)
  rw [e3] at g2
  have e4 : (⟨2,([false,true,true,true] ++ (rep [true,true] n ++ [true,true,false,false,false,true,false,false])),([false] ++ T)⟩ : Z0) = ⟨2,([false,true,true,true,true] ++ (rep [true,true] n ++ [true,false,false,false,true,false,false])),([false] ++ T)⟩ := congrArg (fun x => (⟨2,x,([false] ++ T)⟩ : Z0)) ((moveCut [false,true,true,true] [true,false,false,false,true,false,false] [true] true n).symm)
  rw [e4] at g2
  have e5 : (⟨2,([false,true,true,true,true] ++ (rep [true,true] n ++ [true,false,false,false,true,false,false])),([false] ++ T)⟩ : Z0) = ⟨2,([false,true,true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),([false] ++ T)⟩ := congrArg (fun x => (⟨2,x,([false] ++ T)⟩ : Z0)) ((moveCut [false,true,true,true,true] [false,false,false,true,false,false] [true] true n).symm)
  rw [e5] at g2
  rw [show 14+(2*n)+2=2*n+16 by omega] at g2
  exact g2
theorem finishHi (n : Nat) : run0 table (2*n+18) ⟨2,[false,true,true,true,false,false,false,true,false,false],([false] ++ (rep [true,true] n ++ [true,true]))⟩ = some ⟨2,([false,true,true,true,true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),[]⟩ := by
  have h0 : run0 table 14 ⟨2,[false,true,true,true,false,false,false,true,false,false],([false] ++ (rep [true,true] n ++ [true,true]))⟩ = some ⟨2,[true,true,true,true,false,false,false,true,false,false],([true] ++ (rep [true,true] n ++ [true,true]))⟩ := by rfl
  have h1 : run0 table (2*n) ⟨2,[true,true,true,true,false,false,false,true,false,false],([true] ++ (rep [true,true] n ++ [true,true]))⟩ = some ⟨2,([true] ++ (rep [true,true] n ++ [true,true,true,false,false,false,true,false,false])),[true,true,true]⟩ := by
    exact sweepR table 2 [true] [true] [true,true] [true,true] 2 (fun _ _ => rfl) n [true,true,true,false,false,false,true,false,false] [true,true]
  have g1 := join0 h0 h1
  have h2 : run0 table 4 ⟨2,([true] ++ (rep [true,true] n ++ [true,true,true,false,false,false,true,false,false])),[true,true,true]⟩ = some ⟨2,([false,true,true,true,true] ++ (rep [true,true] n ++ [true,true,true,false,false,false,true,false,false])),[]⟩ := by rfl
  have g2 := join0 g1 h2
  have e3 : (⟨2,([false,true,true,true,true] ++ (rep [true,true] n ++ [true,true,true,false,false,false,true,false,false])),[]⟩ : Z0) = ⟨2,([false,true,true,true,true,true] ++ (rep [true,true] n ++ [true,true,false,false,false,true,false,false])),[]⟩ := congrArg (fun x => (⟨2,x,[]⟩ : Z0)) ((moveCut [false,true,true,true,true] [true,true,false,false,false,true,false,false] [true] true n).symm)
  rw [e3] at g2
  have e4 : (⟨2,([false,true,true,true,true,true] ++ (rep [true,true] n ++ [true,true,false,false,false,true,false,false])),[]⟩ : Z0) = ⟨2,([false,true,true,true,true,true,true] ++ (rep [true,true] n ++ [true,false,false,false,true,false,false])),[]⟩ := congrArg (fun x => (⟨2,x,[]⟩ : Z0)) ((moveCut [false,true,true,true,true,true] [true,false,false,false,true,false,false] [true] true n).symm)
  rw [e4] at g2
  have e5 : (⟨2,([false,true,true,true,true,true,true] ++ (rep [true,true] n ++ [true,false,false,false,true,false,false])),[]⟩ : Z0) = ⟨2,([false,true,true,true,true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),[]⟩ := congrArg (fun x => (⟨2,x,[]⟩ : Z0)) ((moveCut [false,true,true,true,true,true,true] [false,false,false,true,false,false] [true] true n).symm)
  rw [e5] at g2
  rw [show 14+(2*n)+4=2*n+18 by omega] at g2
  exact g2
theorem pushHi (n : Nat) (T : List Bool) : run0 table (2*n+16) ⟨2,([false,true,true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),([false] ++ T)⟩ = some ⟨2,[false,true,true,true,false,false,false,true,false,false],([false] ++ (rep [false,false] n ++ ([true,true] ++ T)))⟩ := by
  have h0 : run0 table 4 ⟨2,([false,true,true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),([false] ++ T)⟩ = some ⟨4,([true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),([false,true,true] ++ T)⟩ := by rfl
  have h1 : run0 table (2*n) ⟨4,([true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),([false,true,true] ++ T)⟩ = some ⟨4,[true,true,true,true,false,false,false,true,false,false],([] ++ (rep [false,false] n ++ ([false,true,true] ++ T)))⟩ := by
    exact sweepL table 4 [true,true,true,true] [] [true,true] [false,false] 2 (fun _ _ => rfl) n [false,false,false,true,false,false] ([false,true,true] ++ T)
  have g1 := join0 h0 h1
  have h2 : run0 table 12 ⟨4,[true,true,true,true,false,false,false,true,false,false],([] ++ (rep [false,false] n ++ ([false,true,true] ++ T)))⟩ = some ⟨2,[false,true,true,true,false,false,false,true,false,false],([] ++ (rep [false,false] n ++ ([false,true,true] ++ T)))⟩ := by rfl
  have g2 := join0 g1 h2
  have e3 : (⟨2,[false,true,true,true,false,false,false,true,false,false],([] ++ (rep [false,false] n ++ ([false,true,true] ++ T)))⟩ : Z0) = ⟨2,[false,true,true,true,false,false,false,true,false,false],([false] ++ (rep [false,false] n ++ ([true,true] ++ T)))⟩ := congrArg (fun x => (⟨2,[false,true,true,true,false,false,false,true,false,false],x⟩ : Z0)) ((moveCut [] ([true,true] ++ T) [false] false n).symm)
  rw [e3] at g2
  rw [show 4+(2*n)+12=2*n+16 by omega] at g2
  exact g2
theorem pushEmptyHi (n : Nat) : run0 table (2*n+16) ⟨2,([false,true,true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),[]⟩ = some ⟨2,[false,true,true,true,false,false,false,true,false,false],([false] ++ (rep [false,false] n ++ [true,true]))⟩ := by
  have h0 : run0 table 4 ⟨2,([false,true,true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),[]⟩ = some ⟨4,([true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),[false,true,true]⟩ := by rfl
  have h1 : run0 table (2*n) ⟨4,([true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),[false,true,true]⟩ = some ⟨4,[true,true,true,true,false,false,false,true,false,false],([] ++ (rep [false,false] n ++ [false,true,true]))⟩ := by
    exact sweepL table 4 [true,true,true,true] [] [true,true] [false,false] 2 (fun _ _ => rfl) n [false,false,false,true,false,false] [false,true,true]
  have g1 := join0 h0 h1
  have h2 : run0 table 12 ⟨4,[true,true,true,true,false,false,false,true,false,false],([] ++ (rep [false,false] n ++ [false,true,true]))⟩ = some ⟨2,[false,true,true,true,false,false,false,true,false,false],([] ++ (rep [false,false] n ++ [false,true,true]))⟩ := by rfl
  have g2 := join0 g1 h2
  have e3 : (⟨2,[false,true,true,true,false,false,false,true,false,false],([] ++ (rep [false,false] n ++ [false,true,true]))⟩ : Z0) = ⟨2,[false,true,true,true,false,false,false,true,false,false],([false] ++ (rep [false,false] n ++ [true,true]))⟩ := congrArg (fun x => (⟨2,[false,true,true,true,false,false,false,true,false,false],x⟩ : Z0)) ((moveCut [] [true,true] [false] false n).symm)
  rw [e3] at g2
  rw [show 4+(2*n)+12=2*n+16 by omega] at g2
  exact g2
theorem stopLo (n : Nat) (T : List Bool) : run0 table (2*n+16) ⟨2,[false,true,true,true,false,false,false,true,false,false],([false] ++ (rep [true,true] n ++ ([false,false] ++ T)))⟩ = some ⟨2,([false,true,true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),([false] ++ T)⟩ := by
  have h0 : run0 table 14 ⟨2,[false,true,true,true,false,false,false,true,false,false],([false] ++ (rep [true,true] n ++ ([false,false] ++ T)))⟩ = some ⟨2,[true,true,true,true,false,false,false,true,false,false],([true] ++ (rep [true,true] n ++ ([false,false] ++ T)))⟩ := by rfl
  have h1 : run0 table (2*n) ⟨2,[true,true,true,true,false,false,false,true,false,false],([true] ++ (rep [true,true] n ++ ([false,false] ++ T)))⟩ = some ⟨2,([true] ++ (rep [true,true] n ++ [true,true,true,false,false,false,true,false,false])),([true,false,false] ++ T)⟩ := by
    exact sweepR table 2 [true] [true] [true,true] [true,true] 2 (fun _ _ => rfl) n [true,true,true,false,false,false,true,false,false] ([false,false] ++ T)
  have g1 := join0 h0 h1
  have h2 : run0 table 2 ⟨2,([true] ++ (rep [true,true] n ++ [true,true,true,false,false,false,true,false,false])),([true,false,false] ++ T)⟩ = some ⟨2,([false,true,true] ++ (rep [true,true] n ++ [true,true,true,false,false,false,true,false,false])),([false] ++ T)⟩ := by rfl
  have g2 := join0 g1 h2
  have e3 : (⟨2,([false,true,true] ++ (rep [true,true] n ++ [true,true,true,false,false,false,true,false,false])),([false] ++ T)⟩ : Z0) = ⟨2,([false,true,true,true] ++ (rep [true,true] n ++ [true,true,false,false,false,true,false,false])),([false] ++ T)⟩ := congrArg (fun x => (⟨2,x,([false] ++ T)⟩ : Z0)) ((moveCut [false,true,true] [true,true,false,false,false,true,false,false] [true] true n).symm)
  rw [e3] at g2
  have e4 : (⟨2,([false,true,true,true] ++ (rep [true,true] n ++ [true,true,false,false,false,true,false,false])),([false] ++ T)⟩ : Z0) = ⟨2,([false,true,true,true,true] ++ (rep [true,true] n ++ [true,false,false,false,true,false,false])),([false] ++ T)⟩ := congrArg (fun x => (⟨2,x,([false] ++ T)⟩ : Z0)) ((moveCut [false,true,true,true] [true,false,false,false,true,false,false] [true] true n).symm)
  rw [e4] at g2
  have e5 : (⟨2,([false,true,true,true,true] ++ (rep [true,true] n ++ [true,false,false,false,true,false,false])),([false] ++ T)⟩ : Z0) = ⟨2,([false,true,true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),([false] ++ T)⟩ := congrArg (fun x => (⟨2,x,([false] ++ T)⟩ : Z0)) ((moveCut [false,true,true,true,true] [false,false,false,true,false,false] [true] true n).symm)
  rw [e5] at g2
  rw [show 14+(2*n)+2=2*n+16 by omega] at g2
  exact g2
theorem finishLo (n : Nat) : run0 table (2*n+18) ⟨2,[false,true,true,true,false,false,false,true,false,false],([false] ++ (rep [true,true] n ++ [true,true]))⟩ = some ⟨2,([false,true,true,true,true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),[]⟩ := by
  have h0 : run0 table 14 ⟨2,[false,true,true,true,false,false,false,true,false,false],([false] ++ (rep [true,true] n ++ [true,true]))⟩ = some ⟨2,[true,true,true,true,false,false,false,true,false,false],([true] ++ (rep [true,true] n ++ [true,true]))⟩ := by rfl
  have h1 : run0 table (2*n) ⟨2,[true,true,true,true,false,false,false,true,false,false],([true] ++ (rep [true,true] n ++ [true,true]))⟩ = some ⟨2,([true] ++ (rep [true,true] n ++ [true,true,true,false,false,false,true,false,false])),[true,true,true]⟩ := by
    exact sweepR table 2 [true] [true] [true,true] [true,true] 2 (fun _ _ => rfl) n [true,true,true,false,false,false,true,false,false] [true,true]
  have g1 := join0 h0 h1
  have h2 : run0 table 4 ⟨2,([true] ++ (rep [true,true] n ++ [true,true,true,false,false,false,true,false,false])),[true,true,true]⟩ = some ⟨2,([false,true,true,true,true] ++ (rep [true,true] n ++ [true,true,true,false,false,false,true,false,false])),[]⟩ := by rfl
  have g2 := join0 g1 h2
  have e3 : (⟨2,([false,true,true,true,true] ++ (rep [true,true] n ++ [true,true,true,false,false,false,true,false,false])),[]⟩ : Z0) = ⟨2,([false,true,true,true,true,true] ++ (rep [true,true] n ++ [true,true,false,false,false,true,false,false])),[]⟩ := congrArg (fun x => (⟨2,x,[]⟩ : Z0)) ((moveCut [false,true,true,true,true] [true,true,false,false,false,true,false,false] [true] true n).symm)
  rw [e3] at g2
  have e4 : (⟨2,([false,true,true,true,true,true] ++ (rep [true,true] n ++ [true,true,false,false,false,true,false,false])),[]⟩ : Z0) = ⟨2,([false,true,true,true,true,true,true] ++ (rep [true,true] n ++ [true,false,false,false,true,false,false])),[]⟩ := congrArg (fun x => (⟨2,x,[]⟩ : Z0)) ((moveCut [false,true,true,true,true,true] [true,false,false,false,true,false,false] [true] true n).symm)
  rw [e4] at g2
  have e5 : (⟨2,([false,true,true,true,true,true,true] ++ (rep [true,true] n ++ [true,false,false,false,true,false,false])),[]⟩ : Z0) = ⟨2,([false,true,true,true,true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),[]⟩ := congrArg (fun x => (⟨2,x,[]⟩ : Z0)) ((moveCut [false,true,true,true,true,true,true] [false,false,false,true,false,false] [true] true n).symm)
  rw [e5] at g2
  rw [show 14+(2*n)+4=2*n+18 by omega] at g2
  exact g2
theorem pushLo (n : Nat) (T : List Bool) : run0 table (2*n+16) ⟨2,([false,true,true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),([false] ++ T)⟩ = some ⟨2,[false,true,true,true,false,false,false,true,false,false],([false] ++ (rep [false,false] n ++ ([true,true] ++ T)))⟩ := by
  have h0 : run0 table 4 ⟨2,([false,true,true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),([false] ++ T)⟩ = some ⟨4,([true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),([false,true,true] ++ T)⟩ := by rfl
  have h1 : run0 table (2*n) ⟨4,([true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),([false,true,true] ++ T)⟩ = some ⟨4,[true,true,true,true,false,false,false,true,false,false],([] ++ (rep [false,false] n ++ ([false,true,true] ++ T)))⟩ := by
    exact sweepL table 4 [true,true,true,true] [] [true,true] [false,false] 2 (fun _ _ => rfl) n [false,false,false,true,false,false] ([false,true,true] ++ T)
  have g1 := join0 h0 h1
  have h2 : run0 table 12 ⟨4,[true,true,true,true,false,false,false,true,false,false],([] ++ (rep [false,false] n ++ ([false,true,true] ++ T)))⟩ = some ⟨2,[false,true,true,true,false,false,false,true,false,false],([] ++ (rep [false,false] n ++ ([false,true,true] ++ T)))⟩ := by rfl
  have g2 := join0 g1 h2
  have e3 : (⟨2,[false,true,true,true,false,false,false,true,false,false],([] ++ (rep [false,false] n ++ ([false,true,true] ++ T)))⟩ : Z0) = ⟨2,[false,true,true,true,false,false,false,true,false,false],([false] ++ (rep [false,false] n ++ ([true,true] ++ T)))⟩ := congrArg (fun x => (⟨2,[false,true,true,true,false,false,false,true,false,false],x⟩ : Z0)) ((moveCut [] ([true,true] ++ T) [false] false n).symm)
  rw [e3] at g2
  rw [show 4+(2*n)+12=2*n+16 by omega] at g2
  exact g2
theorem pushEmptyLo (n : Nat) : run0 table (2*n+16) ⟨2,([false,true,true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),[]⟩ = some ⟨2,[false,true,true,true,false,false,false,true,false,false],([false] ++ (rep [false,false] n ++ [true,true]))⟩ := by
  have h0 : run0 table 4 ⟨2,([false,true,true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),[]⟩ = some ⟨4,([true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),[false,true,true]⟩ := by rfl
  have h1 : run0 table (2*n) ⟨4,([true,true,true,true] ++ (rep [true,true] n ++ [false,false,false,true,false,false])),[false,true,true]⟩ = some ⟨4,[true,true,true,true,false,false,false,true,false,false],([] ++ (rep [false,false] n ++ [false,true,true]))⟩ := by
    exact sweepL table 4 [true,true,true,true] [] [true,true] [false,false] 2 (fun _ _ => rfl) n [false,false,false,true,false,false] [false,true,true]
  have g1 := join0 h0 h1
  have h2 : run0 table 12 ⟨4,[true,true,true,true,false,false,false,true,false,false],([] ++ (rep [false,false] n ++ [false,true,true]))⟩ = some ⟨2,[false,true,true,true,false,false,false,true,false,false],([] ++ (rep [false,false] n ++ [false,true,true]))⟩ := by rfl
  have g2 := join0 g1 h2
  have e3 : (⟨2,[false,true,true,true,false,false,false,true,false,false],([] ++ (rep [false,false] n ++ [false,true,true]))⟩ : Z0) = ⟨2,[false,true,true,true,false,false,false,true,false,false],([false] ++ (rep [false,false] n ++ [true,true]))⟩ := congrArg (fun x => (⟨2,[false,true,true,true,false,false,false,true,false,false],x⟩ : Z0)) ((moveCut [] [true,true] [false] false n).symm)
  rw [e3] at g2
  rw [show 4+(2*n)+12=2*n+16 by omega] at g2
  exact g2
def popCost (b : Bool) := if b then 16 else 16
def endCost (b : Bool) := if b then 18 else 18
def pushCost (b : Bool) := if b then 16 else 16
theorem never (m : Machine) (hm : compatible table m) : NeverHalts m := by
  apply LACarry.never table pre P z o tail out 2 2 popCost endCost pushCost (by intro b; cases b <;> decide) (by intro b; cases b <;> decide) (by intro b; cases b <;> decide) 0 21 entry _ _ _ _ _ m hm
  · intro b; cases b <;> rfl
  · intro b n T; cases b
    · simpa [C,pre,P,z,o,tail,out,left,rep,List.append_assoc,popCost,endCost,pushCost] using stopLo n T
    · simpa [C,pre,P,z,o,tail,out,left,rep,List.append_assoc,popCost,endCost,pushCost] using stopHi n T
  · intro b n; cases b
    · simpa [C,pre,P,z,o,tail,out,left,rep,List.append_assoc,popCost,endCost,pushCost] using finishLo n
    · simpa [C,pre,P,z,o,tail,out,left,rep,List.append_assoc,popCost,endCost,pushCost] using finishHi n
  · intro b n T; cases b
    · simpa [C,pre,P,z,o,tail,out,left,rep,List.append_assoc,popCost,endCost,pushCost] using pushLo n T
    · simpa [C,pre,P,z,o,tail,out,left,rep,List.append_assoc,popCost,endCost,pushCost] using pushHi n T
  · intro b n; cases b
    · simpa [C,pre,P,z,o,tail,out,left,rep,List.append_assoc,popCost,endCost,pushCost] using pushEmptyLo n
    · simpa [C,pre,P,z,o,tail,out,left,rep,List.append_assoc,popCost,endCost,pushCost] using pushEmptyHi n
#print axioms never
end BB6.Agent8Raw54.LA.M138
