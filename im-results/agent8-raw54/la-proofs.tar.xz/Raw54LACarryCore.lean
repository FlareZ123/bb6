import Raw54RAClosedCore
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.LACarry
open BB6Coverage BB6Coverage.Agent31Pump BB6.Agent8Raw54.RAClosed

def C (l r : List Bool) : Z0 := ⟨2,l,r⟩
def left (pre P : List Bool) (tail : Bool → List Bool) (n : Nat) (b : Bool) : List Bool := pre ++ rep P n ++ tail b
def enc (z o : List Bool) : List Bool → List Bool
  | [] => o
  | false::w => z ++ enc z o w
  | true::w => o ++ enc z o w
def right (z o : List Bool) : Option (List Bool) → List Bool
  | none => []
  | some w => false::enc z o w
def sect (pre P z o : List Bool) (tail : Bool → List Bool) (s : Nat × Bool × Option (List Bool)) : Z0 :=
  C (left pre P tail s.1 s.2.1) (right z o s.2.2)

theorem enc_zeros (z o : List Bool) (n : Nat) (w : List Bool) :
    enc z o (List.replicate n false ++ w) = rep z n ++ enc z o w := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [List.replicate_succ,List.cons_append,enc,rep,ih,List.append_assoc]

theorem drain (p : PartialMachine) (pre P z o : List Bool) (tail : Bool → List Bool)
    (out : Bool → Bool) (a : Nat) (popCost endCost : Bool → Nat)
    (hp : ∀ b, 0 < popCost b) (he : ∀ b, 0 < endCost b)
    (stop : ∀ b k T, run0 p (a*k+popCost b)
      (C (left pre P tail 0 b) (false::(rep o k ++ z ++ T))) =
      some (C (left pre P tail (k+1) (out b)) (false::T)))
    (finish : ∀ b k, run0 p (a*k+endCost b)
      (C (left pre P tail 0 b) (false::(rep o k ++ o))) =
      some (C (left pre P tail (k+2) (out b)) []))
    (b : Bool) (w : List Bool) (k : Nat) :
    ∃ t n r, 0<t ∧ run0 p t (C (left pre P tail 0 b) (false::(rep o k ++ enc z o w))) =
      some (C (left pre P tail n (out b)) (right z o r)) := by
  induction w generalizing k with
  | nil => exact ⟨a*k+endCost b,k+2,none,by have := he b; omega,finish b k⟩
  | cons d w ih =>
    cases d
    · refine ⟨a*k+popCost b,k+1,some w,by have := hp b; omega,?_⟩
      simpa only [enc,right,List.append_assoc] using stop b k (enc z o w)
    · obtain ⟨t,n,r,ht,H⟩ := ih (k+1)
      refine ⟨t,n,r,ht,?_⟩
      simpa only [enc,rep,← rep_snoc o k,List.append_assoc] using H

theorem never (p : PartialMachine) (pre P z o : List Bool) (tail : Bool → List Bool)
    (out : Bool → Bool) (a u : Nat) (popCost endCost pushCost : Bool → Nat)
    (hp : ∀ b, 0 < popCost b) (he : ∀ b, 0 < endCost b) (hu : ∀ b, 0 < pushCost b)
    (entryN entryTime : Nat)
    (entry : run0 p entryTime ⟨0,[],[]⟩ = some (sect pre P z o tail (entryN,true,none)))
    (zeroEmpty : ∀ b, run0 p (popCost b) (C (left pre P tail 0 b) []) =
      some (C (left pre P tail 1 (out b)) []))
    (stop : ∀ b k T, run0 p (a*k+popCost b)
      (C (left pre P tail 0 b) (false::(rep o k ++ z ++ T))) =
      some (C (left pre P tail (k+1) (out b)) (false::T)))
    (finish : ∀ b k, run0 p (a*k+endCost b)
      (C (left pre P tail 0 b) (false::(rep o k ++ o))) =
      some (C (left pre P tail (k+2) (out b)) []))
    (push : ∀ b k T, run0 p (u*k+pushCost b)
      (C (left pre P tail (k+1) b) (false::T)) =
      some (C (left pre P tail 0 (out b)) (false::(rep z k ++ o ++ T))))
    (pushEmpty : ∀ b k, run0 p (u*k+pushCost b)
      (C (left pre P tail (k+1) b) []) =
      some (C (left pre P tail 0 (out b)) (false::(rep z k ++ o))))
    (m : Machine) (hm : compatible p m) : NeverHalts m := by
  apply neverOfSection p _ (sect pre P z o tail) (entryN,true,none) entryTime entry _ m hm
  rintro ⟨n,b,r⟩
  cases n with
  | zero =>
    cases r with
    | none => exact ⟨popCost b,(1,out b,none),hp b,zeroEmpty b⟩
    | some w =>
      obtain ⟨t,n,r,ht,H⟩ := drain p pre P z o tail out a popCost endCost hp he stop finish b w 0
      refine ⟨t,(n,out b,r),ht,?_⟩
      simpa only [sect,right,rep,List.nil_append] using H
  | succ k =>
    cases r with
    | none =>
      refine ⟨u*k+pushCost b,(0,out b,some (List.replicate k false)),by have := hu b; omega,?_⟩
      have h := enc_zeros z o k []
      rw [List.append_nil] at h
      simpa only [sect,right,h,enc] using pushEmpty b k
    | some w =>
      refine ⟨u*k+pushCost b,(0,out b,some (List.replicate k false ++ true::w)),by have := hu b; omega,?_⟩
      simpa only [sect,right,enc_zeros,enc,List.append_assoc] using push b k (enc z o w)
#print axioms never
end BB6.Agent8Raw54.LACarry
