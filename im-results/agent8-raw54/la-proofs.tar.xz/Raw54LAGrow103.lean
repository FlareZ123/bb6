import SweepPumping
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.LA.M103
open BB6Coverage BB6Coverage.Agent31Pump
def table : PartialMachine := fun s => match s.1.val,s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 0,true => some (some ⟨true,false,1⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨false,true,5⟩)
  | 2,false => some (some ⟨false,true,3⟩)
  | 2,true => some (some ⟨false,true,2⟩)
  | 3,false => some (some ⟨true,false,3⟩)
  | 3,true => some (some ⟨false,false,4⟩)
  | 4,false => some (some ⟨true,false,0⟩)
  | 4,true => some (some ⟨false,false,4⟩)
  | 5,false => some (some ⟨true,false,4⟩)
  | _,_ => none
def family (n : Nat) : Z0 := ⟨2,([] ++ (rep [false,false,false,false,false,false,false,false] n ++ [false,true,true])),[]⟩
theorem entry : run0 table 2 ⟨0,[],[]⟩ = some (family 0) := by rfl
theorem epoch (n : Nat) : run0 table (32*n+58) (family n) = some (family (n+1)) := by
  have e0 : (⟨2,([] ++ (rep [false,false,false,false,false,false,false,false] n ++ [false,true,true])),[]⟩ : Z0) = ⟨2,([false] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,true])),[]⟩ := congrArg (fun x => (⟨2,x,[]⟩ : Z0)) ((moveCut [] [true,true] [false,false,false,false,false,false,false] false n).symm)
  have h0 : run0 table 0 ⟨2,([] ++ (rep [false,false,false,false,false,false,false,false] n ++ [false,true,true])),[]⟩ = some ⟨2,([false] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,true])),[]⟩ := by rw [e0]; rfl
  have h1 : run0 table 1 ⟨2,([false] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,true])),[]⟩ = some ⟨3,([false,false] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,true])),[]⟩ := by rfl
  have g1 := join0 h0 h1
  have h2 : run0 table (8*n) ⟨3,([false,false] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,true])),[]⟩ = some ⟨3,[false,false,true,true],([] ++ (rep [true,true,true,true,true,true,true,true] n ++ []))⟩ := by
    exact sweepL table 3 [false,false] [] [false,false,false,false,false,false,false,false] [true,true,true,true,true,true,true,true] 8 (fun _ _ => rfl) n [true,true] []
  have g2 := join0 g1 h2
  have h3 : run0 table 23 ⟨3,[false,false,true,true],([] ++ (rep [true,true,true,true,true,true,true,true] n ++ []))⟩ = some ⟨2,[true,true,false,true],([true,true,true] ++ (rep [true,true,true,true,true,true,true,true] n ++ []))⟩ := by rfl
  have g3 := join0 g2 h3
  have h4 : run0 table (8*n) ⟨2,[true,true,false,true],([true,true,true] ++ (rep [true,true,true,true,true,true,true,true] n ++ []))⟩ = some ⟨2,([true] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,false,true])),[true,true,true]⟩ := by
    exact sweepR table 2 [true] [true,true,true] [true,true,true,true,true,true,true,true] [false,false,false,false,false,false,false,false] 8 (fun _ _ => rfl) n [true,false,true] []
  have g4 := join0 g3 h4
  have h5 : run0 table 5 ⟨2,([true] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,false,true])),[true,true,true]⟩ = some ⟨3,([false,false,false,false,false,false] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,false,true])),[]⟩ := by rfl
  have g5 := join0 g4 h5
  have h6 : run0 table (8*n) ⟨3,([false,false,false,false,false,false] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,false,true])),[]⟩ = some ⟨3,[false,false,false,false,false,false,true,false,true],([] ++ (rep [true,true,true,true,true,true,true,true] n ++ []))⟩ := by
    exact sweepL table 3 [false,false,false,false,false,false] [] [false,false,false,false,false,false,false,false] [true,true,true,true,true,true,true,true] 8 (fun _ _ => rfl) n [true,false,true] []
  have g6 := join0 g5 h6
  have h7 : run0 table 21 ⟨3,[false,false,false,false,false,false,true,false,true],([] ++ (rep [true,true,true,true,true,true,true,true] n ++ []))⟩ = some ⟨2,[true,true,true],([true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true,true,true] n ++ []))⟩ := by rfl
  have g7 := join0 g6 h7
  have h8 : run0 table (8*n) ⟨2,[true,true,true],([true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true,true,true] n ++ []))⟩ = some ⟨2,([true] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,true])),[true,true,true,true,true,true,true]⟩ := by
    exact sweepR table 2 [true] [true,true,true,true,true,true,true] [true,true,true,true,true,true,true,true] [false,false,false,false,false,false,false,false] 8 (fun _ _ => rfl) n [true,true] []
  have g8 := join0 g7 h8
  have h9 : run0 table 8 ⟨2,([true] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,true])),[true,true,true,true,true,true,true]⟩ = some ⟨2,([false,false,false,false,false,false,false,false,false] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,true])),[]⟩ := by rfl
  have g9 := join0 g8 h9
  have e10 : (⟨2,([false,false,false,false,false,false,false,false,false] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,true])),[]⟩ : Z0) = ⟨2,([false,false,false,false,false,false,false,false] ++ (rep [false,false,false,false,false,false,false,false] n ++ [false,true,true])),[]⟩ := congrArg (fun x => (⟨2,x,[]⟩ : Z0)) (moveCut [false,false,false,false,false,false,false,false] [true,true] [false,false,false,false,false,false,false] false n)
  rw [e10] at g9
  rw [show 0+1+(8*n)+23+(8*n)+5+(8*n)+21+(8*n)+8=32*n+58 by omega] at g9
  exact g9
theorem never (m : Machine) (hm : compatible table m) : NeverHalts m :=
  never_of_growth table family 2 (fun n => 32*n+58) entry (by intro n; omega) epoch m hm
#print axioms never
end BB6.Agent8Raw54.LA.M103
