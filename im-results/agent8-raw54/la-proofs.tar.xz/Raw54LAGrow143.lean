import SweepPumping
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.LA.M143
open BB6Coverage BB6Coverage.Agent31Pump
def table : PartialMachine := fun s => match s.1.val,s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 0,true => some (some ⟨true,false,5⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨true,true,1⟩)
  | 2,false => some (some ⟨false,true,3⟩)
  | 2,true => some (some ⟨false,true,2⟩)
  | 3,false => some (some ⟨true,false,3⟩)
  | 3,true => some (some ⟨false,false,4⟩)
  | 4,false => some (some ⟨true,false,0⟩)
  | 4,true => some (some ⟨false,false,4⟩)
  | 5,true => some (some ⟨true,true,2⟩)
  | _,_ => none
def family (n : Nat) : Z0 := ⟨3,[false,false,true,true,true,false,false,false,true,true,true],([] ++ (rep [true,true,true,true,true,true,true,true] n ++ [true]))⟩
theorem entry : run0 table 58 ⟨0,[],[]⟩ = some (family 0) := by rfl
theorem epoch (n : Nat) : run0 table (32*n+138) (family n) = some (family (n+1)) := by
  have h0 : run0 table 52 ⟨3,[false,false,true,true,true,false,false,false,true,true,true],([] ++ (rep [true,true,true,true,true,true,true,true] n ++ [true]))⟩ = some ⟨2,[true,true,true,true,false,true,true,true,false,true,true],([true,true] ++ (rep [true,true,true,true,true,true,true,true] n ++ [true]))⟩ := by rfl
  have h1 : run0 table (8*n) ⟨2,[true,true,true,true,false,true,true,true,false,true,true],([true,true] ++ (rep [true,true,true,true,true,true,true,true] n ++ [true]))⟩ = some ⟨2,([true] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,true,true,false,true,true,true,false,true,true])),[true,true,true]⟩ := by
    exact sweepR table 2 [true] [true,true] [true,true,true,true,true,true,true,true] [false,false,false,false,false,false,false,false] 8 (fun _ _ => rfl) n [true,true,true,false,true,true,true,false,true,true] [true]
  have g1 := join0 h0 h1
  have h2 : run0 table 5 ⟨2,([true] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,true,true,false,true,true,true,false,true,true])),[true,true,true]⟩ = some ⟨3,([false,false,false,false,false,false] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,true,true,false,true,true,true,false,true,true])),[]⟩ := by rfl
  have g2 := join0 g1 h2
  have h3 : run0 table (8*n) ⟨3,([false,false,false,false,false,false] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,true,true,false,true,true,true,false,true,true])),[]⟩ = some ⟨3,[false,false,false,false,false,false,true,true,true,false,true,true,true,false,true,true],([] ++ (rep [true,true,true,true,true,true,true,true] n ++ []))⟩ := by
    exact sweepL table 3 [false,false,false,false,false,false] [] [false,false,false,false,false,false,false,false] [true,true,true,true,true,true,true,true] 8 (fun _ _ => rfl) n [true,true,true,false,true,true,true,false,true,true] []
  have g3 := join0 g2 h3
  have h4 : run0 table 50 ⟨3,[false,false,false,false,false,false,true,true,true,false,true,true,true,false,true,true],([] ++ (rep [true,true,true,true,true,true,true,true] n ++ []))⟩ = some ⟨2,[true,true,true,true,false,false,false,false,false,false,false,true,true,true],([true,true,true,true] ++ (rep [true,true,true,true,true,true,true,true] n ++ []))⟩ := by rfl
  have g4 := join0 g3 h4
  have h5 : run0 table (8*n) ⟨2,[true,true,true,true,false,false,false,false,false,false,false,true,true,true],([true,true,true,true] ++ (rep [true,true,true,true,true,true,true,true] n ++ []))⟩ = some ⟨2,([true] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,true,true,false,false,false,false,false,false,false,true,true,true])),[true,true,true,true]⟩ := by
    exact sweepR table 2 [true] [true,true,true,true] [true,true,true,true,true,true,true,true] [false,false,false,false,false,false,false,false] 8 (fun _ _ => rfl) n [true,true,true,false,false,false,false,false,false,false,true,true,true] []
  have g5 := join0 g4 h5
  have h6 : run0 table 6 ⟨2,([true] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,true,true,false,false,false,false,false,false,false,true,true,true])),[true,true,true,true]⟩ = some ⟨3,([false,false,false,false,false,false,false] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,true,true,false,false,false,false,false,false,false,true,true,true])),[]⟩ := by rfl
  have g6 := join0 g5 h6
  have h7 : run0 table (8*n) ⟨3,([false,false,false,false,false,false,false] ++ (rep [false,false,false,false,false,false,false,false] n ++ [true,true,true,false,false,false,false,false,false,false,true,true,true])),[]⟩ = some ⟨3,[false,false,false,false,false,false,false,true,true,true,false,false,false,false,false,false,false,true,true,true],([] ++ (rep [true,true,true,true,true,true,true,true] n ++ []))⟩ := by
    exact sweepL table 3 [false,false,false,false,false,false,false] [] [false,false,false,false,false,false,false,false] [true,true,true,true,true,true,true,true] 8 (fun _ _ => rfl) n [true,true,true,false,false,false,false,false,false,false,true,true,true] []
  have g7 := join0 g6 h7
  have h8 : run0 table 25 ⟨3,[false,false,false,false,false,false,false,true,true,true,false,false,false,false,false,false,false,true,true,true],([] ++ (rep [true,true,true,true,true,true,true,true] n ++ []))⟩ = some ⟨3,[false,false,true,true,true,false,false,false,true,true,true],([true,true,true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true,true,true] n ++ []))⟩ := by rfl
  have g8 := join0 g7 h8
  have e9 : (⟨3,[false,false,true,true,true,false,false,false,true,true,true],([true,true,true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true,true,true] n ++ []))⟩ : Z0) = ⟨3,[false,false,true,true,true,false,false,false,true,true,true],([true,true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true,true,true] n ++ [true]))⟩ := congrArg (fun x => (⟨3,[false,false,true,true,true,false,false,false,true,true,true],x⟩ : Z0)) (moveCut [true,true,true,true,true,true,true,true] [] [true,true,true,true,true,true,true] true n)
  rw [e9] at g8
  rw [show 52+(8*n)+5+(8*n)+50+(8*n)+6+(8*n)+25=32*n+138 by omega] at g8
  exact g8
theorem never (m : Machine) (hm : compatible table m) : NeverHalts m :=
  never_of_growth table family 58 (fun n => 32*n+138) entry (by intro n; omega) epoch m hm
#print axioms never
end BB6.Agent8Raw54.LA.M143
