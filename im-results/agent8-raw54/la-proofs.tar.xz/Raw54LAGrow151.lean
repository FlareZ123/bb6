import SweepPumping
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.LA.M151
open BB6Coverage BB6Coverage.Agent31Pump
def table : PartialMachine := fun s => match s.1.val,s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 0,true => some (some ⟨true,false,0⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨true,true,5⟩)
  | 2,false => some (some ⟨false,true,3⟩)
  | 3,false => some (some ⟨true,false,3⟩)
  | 3,true => some (some ⟨false,false,4⟩)
  | 4,false => some (some ⟨true,false,0⟩)
  | 4,true => some (some ⟨false,false,4⟩)
  | 5,false => some (some ⟨false,true,0⟩)
  | 5,true => some (some ⟨true,true,1⟩)
  | _,_ => none
def family (n : Nat) : Z0 := ⟨0,([] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [])),[true,false,false,true,true]⟩
theorem entry : run0 table 8 ⟨0,[],[]⟩ = some (family 0) := by rfl
theorem epoch (n : Nat) : run0 table (40*n+46) (family n) = some (family (n+1)) := by
  have h0 : run0 table (10*n) ⟨0,([] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [])),[true,false,false,true,true]⟩ = some ⟨0,[],([] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [true,false,false,true,true]))⟩ := by
    exact sweepL table 0 [] [] [true,true,true,true,true,true,true,true,true,true] [true,true,true,true,true,true,true,true,true,true] 10 (fun _ _ => rfl) n [] [true,false,false,true,true]
  have e1 : (⟨0,[],([] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [true,false,false,true,true]))⟩ : Z0) = ⟨0,[],([true] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [false,false,true,true]))⟩ := congrArg (fun x => (⟨0,[],x⟩ : Z0)) ((moveCut [] [false,false,true,true] [true,true,true,true,true,true,true,true,true] true n).symm)
  rw [e1] at h0
  have h2 : run0 table 1 ⟨0,[],([true] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [false,false,true,true]))⟩ = some ⟨1,[true,true],([] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [false,false,true,true]))⟩ := by rfl
  have g2 := join0 h0 h2
  have h3 : run0 table (10*n) ⟨1,[true,true],([] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [false,false,true,true]))⟩ = some ⟨1,([true] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [true])),[false,false,true,true]⟩ := by
    exact sweepR table 1 [true] [] [true,true,true,true,true,true,true,true,true,true] [true,true,true,true,true,true,true,true,true,true] 10 (fun _ _ => rfl) n [true] [false,false,true,true]
  have g3 := join0 g2 h3
  have h4 : run0 table 14 ⟨1,([true] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [true])),[false,false,true,true]⟩ = some ⟨0,([true] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [true])),[true,false,false,false,false,true,true]⟩ := by rfl
  have g4 := join0 g3 h4
  have h5 : run0 table (10*n) ⟨0,([true] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [true])),[true,false,false,false,false,true,true]⟩ = some ⟨0,[true,true],([] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [true,false,false,false,false,true,true]))⟩ := by
    exact sweepL table 0 [true] [] [true,true,true,true,true,true,true,true,true,true] [true,true,true,true,true,true,true,true,true,true] 10 (fun _ _ => rfl) n [true] [true,false,false,false,false,true,true]
  have g5 := join0 g4 h5
  have h6 : run0 table 3 ⟨0,[true,true],([] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [true,false,false,false,false,true,true]))⟩ = some ⟨1,[true,true],([true] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [true,false,false,false,false,true,true]))⟩ := by rfl
  have g6 := join0 g5 h6
  have h7 : run0 table (10*n) ⟨1,[true,true],([true] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [true,false,false,false,false,true,true]))⟩ = some ⟨1,([true] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [true])),[true,true,false,false,false,false,true,true]⟩ := by
    exact sweepR table 1 [true] [true] [true,true,true,true,true,true,true,true,true,true] [true,true,true,true,true,true,true,true,true,true] 10 (fun _ _ => rfl) n [true] [true,false,false,false,false,true,true]
  have g7 := join0 g6 h7
  have h8 : run0 table 28 ⟨1,([true] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [true])),[true,true,false,false,false,false,true,true]⟩ = some ⟨0,([true,true,true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [true])),[true,false,false,true,true]⟩ := by rfl
  have g8 := join0 g7 h8
  have e9 : (⟨0,([true,true,true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [true])),[true,false,false,true,true]⟩ : Z0) = ⟨0,([true,true,true,true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true,true,true,true,true] n ++ [])),[true,false,false,true,true]⟩ := congrArg (fun x => (⟨0,x,[true,false,false,true,true]⟩ : Z0)) ((moveCut [true,true,true,true,true,true,true,true,true] [] [true,true,true,true,true,true,true,true,true] true n).symm)
  rw [e9] at g8
  rw [show (10*n)+1+(10*n)+14+(10*n)+3+(10*n)+28=40*n+46 by omega] at g8
  exact g8
theorem never (m : Machine) (hm : compatible table m) : NeverHalts m :=
  never_of_growth table family 8 (fun n => 40*n+46) entry (by intro n; omega) epoch m hm
#print axioms never
end BB6.Agent8Raw54.LA.M151
