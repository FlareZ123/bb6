import SweepPumping
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.LA.M157
open BB6Coverage BB6Coverage.Agent31Pump
def table : PartialMachine := fun s => match s.1.val,s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 0,true => some (some ⟨false,false,5⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨true,true,5⟩)
  | 2,false => some (some ⟨false,true,3⟩)
  | 2,true => some (some ⟨false,true,2⟩)
  | 3,false => some (some ⟨true,false,3⟩)
  | 3,true => some (some ⟨false,false,4⟩)
  | 4,false => some (some ⟨true,false,0⟩)
  | 4,true => some (some ⟨false,false,4⟩)
  | 5,false => some (some ⟨true,false,2⟩)
  | _,_ => none
def family (n : Nat) : Z0 := ⟨2,[],([true,false,true,false] ++ (rep [true,true,true,true,true,true] n ++ [true,true,true,true,true]))⟩
theorem entry : run0 table 32 ⟨0,[],[]⟩ = some (family 0) := by rfl
theorem epoch (n : Nat) : run0 table (24*n+82) (family n) = some (family (n+1)) := by
  have h0 : run0 table 16 ⟨2,[],([true,false,true,false] ++ (rep [true,true,true,true,true,true] n ++ [true,true,true,true,true]))⟩ = some ⟨2,[false,false,false,true,false,true],([] ++ (rep [true,true,true,true,true,true] n ++ [true,true,true,true,true]))⟩ := by rfl
  have e1 : (⟨2,[false,false,false,true,false,true],([] ++ (rep [true,true,true,true,true,true] n ++ [true,true,true,true,true]))⟩ : Z0) = ⟨2,[false,false,false,true,false,true],([true] ++ (rep [true,true,true,true,true,true] n ++ [true,true,true,true]))⟩ := congrArg (fun x => (⟨2,[false,false,false,true,false,true],x⟩ : Z0)) ((moveCut [] [true,true,true,true] [true,true,true,true,true] true n).symm)
  rw [e1] at h0
  have h2 : run0 table 6 ⟨2,[false,false,false,true,false,true],([true] ++ (rep [true,true,true,true,true,true] n ++ [true,true,true,true]))⟩ = some ⟨2,[true,true,false,true,false,true],([true] ++ (rep [true,true,true,true,true,true] n ++ [true,true,true,true]))⟩ := by rfl
  have g2 := join0 h0 h2
  have h3 : run0 table (6*n) ⟨2,[true,true,false,true,false,true],([true] ++ (rep [true,true,true,true,true,true] n ++ [true,true,true,true]))⟩ = some ⟨2,([true] ++ (rep [false,false,false,false,false,false] n ++ [true,false,true,false,true])),[true,true,true,true,true]⟩ := by
    exact sweepR table 2 [true] [true] [true,true,true,true,true,true] [false,false,false,false,false,false] 6 (fun _ _ => rfl) n [true,false,true,false,true] [true,true,true,true]
  have g3 := join0 g2 h3
  have h4 : run0 table 7 ⟨2,([true] ++ (rep [false,false,false,false,false,false] n ++ [true,false,true,false,true])),[true,true,true,true,true]⟩ = some ⟨3,([false,false,false,false,false,false,false,false] ++ (rep [false,false,false,false,false,false] n ++ [true,false,true,false,true])),[]⟩ := by rfl
  have g4 := join0 g3 h4
  have h5 : run0 table (6*n) ⟨3,([false,false,false,false,false,false,false,false] ++ (rep [false,false,false,false,false,false] n ++ [true,false,true,false,true])),[]⟩ = some ⟨3,[false,false,false,false,false,false,false,false,true,false,true,false,true],([] ++ (rep [true,true,true,true,true,true] n ++ []))⟩ := by
    exact sweepL table 3 [false,false,false,false,false,false,false,false] [] [false,false,false,false,false,false] [true,true,true,true,true,true] 6 (fun _ _ => rfl) n [true,false,true,false,true] []
  have g5 := join0 g4 h5
  have h6 : run0 table 28 ⟨3,[false,false,false,false,false,false,false,false,true,false,true,false,true],([] ++ (rep [true,true,true,true,true,true] n ++ []))⟩ = some ⟨2,[true,true,false,true,false],([true,true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true] n ++ []))⟩ := by rfl
  have g6 := join0 g5 h6
  have h7 : run0 table (6*n) ⟨2,[true,true,false,true,false],([true,true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true] n ++ []))⟩ = some ⟨2,([true] ++ (rep [false,false,false,false,false,false] n ++ [true,false,true,false])),[true,true,true,true,true,true,true,true]⟩ := by
    exact sweepR table 2 [true] [true,true,true,true,true,true,true,true] [true,true,true,true,true,true] [false,false,false,false,false,false] 6 (fun _ _ => rfl) n [true,false,true,false] []
  have g7 := join0 g6 h7
  have h8 : run0 table 10 ⟨2,([true] ++ (rep [false,false,false,false,false,false] n ++ [true,false,true,false])),[true,true,true,true,true,true,true,true]⟩ = some ⟨3,([false,false,false,false,false,false,false,false,false,false,false] ++ (rep [false,false,false,false,false,false] n ++ [true,false,true,false])),[]⟩ := by rfl
  have g8 := join0 g7 h8
  have h9 : run0 table (6*n) ⟨3,([false,false,false,false,false,false,false,false,false,false,false] ++ (rep [false,false,false,false,false,false] n ++ [true,false,true,false])),[]⟩ = some ⟨3,[false,false,false,false,false,false,false,false,false,false,false,true,false,true,false],([] ++ (rep [true,true,true,true,true,true] n ++ []))⟩ := by
    exact sweepL table 3 [false,false,false,false,false,false,false,false,false,false,false] [] [false,false,false,false,false,false] [true,true,true,true,true,true] 6 (fun _ _ => rfl) n [true,false,true,false] []
  have g9 := join0 g8 h9
  have h10 : run0 table 15 ⟨3,[false,false,false,false,false,false,false,false,false,false,false,true,false,true,false],([] ++ (rep [true,true,true,true,true,true] n ++ []))⟩ = some ⟨2,[],([true,false,true,false,true,true,true,true,true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true] n ++ []))⟩ := by rfl
  have g10 := join0 g9 h10
  have e11 : (⟨2,[],([true,false,true,false,true,true,true,true,true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true] n ++ []))⟩ : Z0) = ⟨2,[],([true,false,true,false,true,true,true,true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true] n ++ [true]))⟩ := congrArg (fun x => (⟨2,[],x⟩ : Z0)) (moveCut [true,false,true,false,true,true,true,true,true,true,true,true,true,true] [] [true,true,true,true,true] true n)
  rw [e11] at g10
  have e12 : (⟨2,[],([true,false,true,false,true,true,true,true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true] n ++ [true]))⟩ : Z0) = ⟨2,[],([true,false,true,false,true,true,true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true] n ++ [true,true]))⟩ := congrArg (fun x => (⟨2,[],x⟩ : Z0)) (moveCut [true,false,true,false,true,true,true,true,true,true,true,true,true] [true] [true,true,true,true,true] true n)
  rw [e12] at g10
  have e13 : (⟨2,[],([true,false,true,false,true,true,true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true] n ++ [true,true]))⟩ : Z0) = ⟨2,[],([true,false,true,false,true,true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true] n ++ [true,true,true]))⟩ := congrArg (fun x => (⟨2,[],x⟩ : Z0)) (moveCut [true,false,true,false,true,true,true,true,true,true,true,true] [true,true] [true,true,true,true,true] true n)
  rw [e13] at g10
  have e14 : (⟨2,[],([true,false,true,false,true,true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true] n ++ [true,true,true]))⟩ : Z0) = ⟨2,[],([true,false,true,false,true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true] n ++ [true,true,true,true]))⟩ := congrArg (fun x => (⟨2,[],x⟩ : Z0)) (moveCut [true,false,true,false,true,true,true,true,true,true,true] [true,true,true] [true,true,true,true,true] true n)
  rw [e14] at g10
  have e15 : (⟨2,[],([true,false,true,false,true,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true] n ++ [true,true,true,true]))⟩ : Z0) = ⟨2,[],([true,false,true,false,true,true,true,true,true,true] ++ (rep [true,true,true,true,true,true] n ++ [true,true,true,true,true]))⟩ := congrArg (fun x => (⟨2,[],x⟩ : Z0)) (moveCut [true,false,true,false,true,true,true,true,true,true] [true,true,true,true] [true,true,true,true,true] true n)
  rw [e15] at g10
  rw [show 16+6+(6*n)+7+(6*n)+28+(6*n)+10+(6*n)+15=24*n+82 by omega] at g10
  exact g10
theorem never (m : Machine) (hm : compatible table m) : NeverHalts m :=
  never_of_growth table family 32 (fun n => 24*n+82) entry (by intro n; omega) epoch m hm
#print axioms never
end BB6.Agent8Raw54.LA.M157
