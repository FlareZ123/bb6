import SweepPumping
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.LA.M2
open BB6Coverage BB6Coverage.Agent31Pump
def table : PartialMachine := fun s => match s.1.val,s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 0,true => some (some ⟨false,false,5⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨false,true,0⟩)
  | 2,false => some (some ⟨false,true,3⟩)
  | 2,true => some (some ⟨false,false,1⟩)
  | 3,false => some (some ⟨true,false,3⟩)
  | 3,true => some (some ⟨false,false,4⟩)
  | 4,false => some (some ⟨true,false,0⟩)
  | 4,true => some (some ⟨false,false,4⟩)
  | 5,false => some (some ⟨false,false,2⟩)
  | _,_ => none
def family (n : Nat) : Z0 := ⟨1,([] ++ (rep [false,true,false,true,false,true] n ++ [false,true])),[]⟩
theorem entry : run0 table 1 ⟨0,[],[]⟩ = some (family 0) := by rfl
theorem epoch (n : Nat) : run0 table (18*n+16) (family n) = some (family (n+1)) := by
  have e0 : (⟨1,([] ++ (rep [false,true,false,true,false,true] n ++ [false,true])),[]⟩ : Z0) = ⟨1,([false] ++ (rep [true,false,true,false,true,false] n ++ [true])),[]⟩ := congrArg (fun x => (⟨1,x,[]⟩ : Z0)) ((moveCut [] [true] [true,false,true,false,true] false n).symm)
  have h0 : run0 table 0 ⟨1,([] ++ (rep [false,true,false,true,false,true] n ++ [false,true])),[]⟩ = some ⟨1,([false] ++ (rep [true,false,true,false,true,false] n ++ [true])),[]⟩ := by rw [e0]; rfl
  have h1 : run0 table 2 ⟨1,([false] ++ (rep [true,false,true,false,true,false] n ++ [true])),[]⟩ = some ⟨3,([false,false,true] ++ (rep [true,false,true,false,true,false] n ++ [true])),[]⟩ := by rfl
  have g1 := join0 h0 h1
  have h2 : run0 table (10*n) ⟨3,([false,false,true] ++ (rep [true,false,true,false,true,false] n ++ [true])),[]⟩ = some ⟨3,[false,false,true,true],([] ++ (rep [false,true,false,false,true,true] n ++ []))⟩ := by
    exact sweepL table 3 [false,false,true] [] [true,false,true,false,true,false] [false,true,false,false,true,true] 10 (fun _ _ => rfl) n [true] []
  have g2 := join0 g1 h2
  have h3 : run0 table 6 ⟨3,[false,false,true,true],([] ++ (rep [false,true,false,false,true,true] n ++ []))⟩ = some ⟨1,[true,true],([false,false,true,true] ++ (rep [false,true,false,false,true,true] n ++ []))⟩ := by rfl
  have g3 := join0 g2 h3
  have h4 : run0 table (8*n) ⟨1,[true,true],([false,false,true,true] ++ (rep [false,true,false,false,true,true] n ++ []))⟩ = some ⟨1,([true] ++ (rep [true,false,true,false,true,false] n ++ [true])),[false,false,true,true]⟩ := by
    exact sweepR table 1 [true] [false,false,true,true] [false,true,false,false,true,true] [true,false,true,false,true,false] 8 (fun _ _ => rfl) n [true] []
  have g4 := join0 g3 h4
  have h5 : run0 table 8 ⟨1,([true] ++ (rep [true,false,true,false,true,false] n ++ [true])),[false,false,true,true]⟩ = some ⟨1,([false,true,false,true,false,true,false] ++ (rep [true,false,true,false,true,false] n ++ [true])),[]⟩ := by rfl
  have g5 := join0 g4 h5
  have e6 : (⟨1,([false,true,false,true,false,true,false] ++ (rep [true,false,true,false,true,false] n ++ [true])),[]⟩ : Z0) = ⟨1,([false,true,false,true,false,true] ++ (rep [false,true,false,true,false,true] n ++ [false,true])),[]⟩ := congrArg (fun x => (⟨1,x,[]⟩ : Z0)) (moveCut [false,true,false,true,false,true] [true] [true,false,true,false,true] false n)
  rw [e6] at g5
  rw [show 0+2+(10*n)+6+(8*n)+8=18*n+16 by omega] at g5
  exact g5
theorem never (m : Machine) (hm : compatible table m) : NeverHalts m :=
  never_of_growth table family 1 (fun n => 18*n+16) entry (by intro n; omega) epoch m hm
#print axioms never
end BB6.Agent8Raw54.LA.M2
