import SweepPumping
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.LA.M40
open BB6Coverage BB6Coverage.Agent31Pump
def table : PartialMachine := fun s => match s.1.val,s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 0,true => some (some ⟨false,false,5⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨false,true,1⟩)
  | 2,false => some (some ⟨false,true,3⟩)
  | 3,false => some (some ⟨true,false,3⟩)
  | 3,true => some (some ⟨false,false,4⟩)
  | 4,false => some (some ⟨true,false,0⟩)
  | 4,true => some (some ⟨false,false,4⟩)
  | 5,false => some (some ⟨false,true,2⟩)
  | 5,true => some (some ⟨false,false,1⟩)
  | _,_ => none
def family (n : Nat) : Z0 := ⟨1,([] ++ (rep [true,true] n ++ [true,true])),[false,false,true,true]⟩
theorem entry : run0 table 9 ⟨0,[],[]⟩ = some (family 0) := by rfl
theorem epoch (n : Nat) : run0 table (42*n+77) (family n) = some (family (n+1)) := by
  have e0 : (⟨1,([] ++ (rep [true,true] n ++ [true,true])),[false,false,true,true]⟩ : Z0) = ⟨1,([true] ++ (rep [true,true] n ++ [true])),[false,false,true,true]⟩ := congrArg (fun x => (⟨1,x,[false,false,true,true]⟩ : Z0)) ((moveCut [] [true] [true] true n).symm)
  have h0 : run0 table 0 ⟨1,([] ++ (rep [true,true] n ++ [true,true])),[false,false,true,true]⟩ = some ⟨1,([true] ++ (rep [true,true] n ++ [true])),[false,false,true,true]⟩ := by rw [e0]; rfl
  have h1 : run0 table 25 ⟨1,([true] ++ (rep [true,true] n ++ [true])),[false,false,true,true]⟩ = some ⟨3,([false,false,true,false,true,true] ++ (rep [true,true] n ++ [true])),[]⟩ := by rfl
  have g1 := join0 h0 h1
  have h2 : run0 table (20*n) ⟨3,([false,false,true,false,true,true] ++ (rep [true,true] n ++ [true])),[]⟩ = some ⟨3,[false,false,true,false,true,true,true],([] ++ (rep [true,true] n ++ []))⟩ := by
    exact sweepL table 3 [false,false,true,false,true,true] [] [true,true] [true,true] 20 (fun _ _ => rfl) n [true] []
  have g2 := join0 g1 h2
  have h3 : run0 table 26 ⟨3,[false,false,true,false,true,true,true],([] ++ (rep [true,true] n ++ []))⟩ = some ⟨2,[false,false],([true,false,true,true,true,true] ++ (rep [true,true] n ++ []))⟩ := by rfl
  have g3 := join0 g2 h3
  have h4 : run0 table (22*n) ⟨2,[false,false],([true,false,true,true,true,true] ++ (rep [true,true] n ++ []))⟩ = some ⟨2,([false,false] ++ (rep [true,true] n ++ [])),[true,false,true,true,true,true]⟩ := by
    exact sweepR table 2 [false,false] [true,false,true,true,true,true] [true,true] [true,true] 22 (fun _ _ => rfl) n [] []
  have g4 := join0 g3 h4
  have h5 : run0 table 26 ⟨2,([false,false] ++ (rep [true,true] n ++ [])),[true,false,true,true,true,true]⟩ = some ⟨1,([true,true,true,true] ++ (rep [true,true] n ++ [])),[false,false,true,true]⟩ := by rfl
  have g5 := join0 g4 h5
  have e6 : (⟨1,([true,true,true,true] ++ (rep [true,true] n ++ [])),[false,false,true,true]⟩ : Z0) = ⟨1,([true,true,true] ++ (rep [true,true] n ++ [true])),[false,false,true,true]⟩ := congrArg (fun x => (⟨1,x,[false,false,true,true]⟩ : Z0)) (moveCut [true,true,true] [] [true] true n)
  rw [e6] at g5
  have e7 : (⟨1,([true,true,true] ++ (rep [true,true] n ++ [true])),[false,false,true,true]⟩ : Z0) = ⟨1,([true,true] ++ (rep [true,true] n ++ [true,true])),[false,false,true,true]⟩ := congrArg (fun x => (⟨1,x,[false,false,true,true]⟩ : Z0)) (moveCut [true,true] [true] [true] true n)
  rw [e7] at g5
  rw [show 0+25+(20*n)+26+(22*n)+26=42*n+77 by omega] at g5
  exact g5
theorem never (m : Machine) (hm : compatible table m) : NeverHalts m :=
  never_of_growth table family 9 (fun n => 42*n+77) entry (by intro n; omega) epoch m hm
#print axioms never
end BB6.Agent8Raw54.LA.M40
