import SweepPumping
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.LA.M69
open BB6Coverage BB6Coverage.Agent31Pump
def table : PartialMachine := fun s => match s.1.val,s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 0,true => some (some ⟨true,true,5⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨false,true,1⟩)
  | 2,false => some (some ⟨false,true,3⟩)
  | 2,true => some (some ⟨false,true,0⟩)
  | 3,false => some (some ⟨true,false,3⟩)
  | 3,true => some (some ⟨false,false,4⟩)
  | 4,false => some (some ⟨true,false,0⟩)
  | 4,true => some (some ⟨false,false,4⟩)
  | 5,true => some (some ⟨true,false,3⟩)
  | _,_ => none
def family (n : Nat) : Z0 := ⟨1,([] ++ (rep [false,true,false,true,false,true,false,true] n ++ [false,true])),[]⟩
theorem entry : run0 table 1 ⟨0,[],[]⟩ = some (family 0) := by rfl
theorem epoch (n : Nat) : run0 table (48*n+30) (family n) = some (family (n+1)) := by
  have e0 : (⟨1,([] ++ (rep [false,true,false,true,false,true,false,true] n ++ [false,true])),[]⟩ : Z0) = ⟨1,([false] ++ (rep [true,false,true,false,true,false,true,false] n ++ [true])),[]⟩ := congrArg (fun x => (⟨1,x,[]⟩ : Z0)) ((moveCut [] [true] [true,false,true,false,true,false,true] false n).symm)
  have h0 : run0 table 0 ⟨1,([] ++ (rep [false,true,false,true,false,true,false,true] n ++ [false,true])),[]⟩ = some ⟨1,([false] ++ (rep [true,false,true,false,true,false,true,false] n ++ [true])),[]⟩ := by rw [e0]; rfl
  have h1 : run0 table 5 ⟨1,([false] ++ (rep [true,false,true,false,true,false,true,false] n ++ [true])),[]⟩ = some ⟨4,([] ++ (rep [true,false,true,false,true,false,true,false] n ++ [true])),[false,true,true]⟩ := by rfl
  have g1 := join0 h0 h1
  have e2 : (⟨4,([] ++ (rep [true,false,true,false,true,false,true,false] n ++ [true])),[false,true,true]⟩ : Z0) = ⟨4,([true] ++ (rep [false,true,false,true,false,true,false,true] n ++ [])),[false,true,true]⟩ := congrArg (fun x => (⟨4,x,[false,true,true]⟩ : Z0)) ((moveCut [] [] [false,true,false,true,false,true,false] true n).symm)
  rw [e2] at g1
  have h3 : run0 table 1 ⟨4,([true] ++ (rep [false,true,false,true,false,true,false,true] n ++ [])),[false,true,true]⟩ = some ⟨4,([] ++ (rep [false,true,false,true,false,true,false,true] n ++ [])),[false,false,true,true]⟩ := by rfl
  have g3 := join0 g1 h3
  have h4 : run0 table (16*n) ⟨4,([] ++ (rep [false,true,false,true,false,true,false,true] n ++ [])),[false,false,true,true]⟩ = some ⟨4,[],([] ++ (rep [false,true,false,true,false,true,false,true] n ++ [false,false,true,true]))⟩ := by
    exact sweepL table 4 [] [] [false,true,false,true,false,true,false,true] [false,true,false,true,false,true,false,true] 16 (fun _ _ => rfl) n [] [false,false,true,true]
  have g4 := join0 g3 h4
  have h5 : run0 table 2 ⟨4,[],([] ++ (rep [false,true,false,true,false,true,false,true] n ++ [false,false,true,true]))⟩ = some ⟨1,[true,true],([] ++ (rep [false,true,false,true,false,true,false,true] n ++ [false,false,true,true]))⟩ := by rfl
  have g5 := join0 g4 h5
  have h6 : run0 table (8*n) ⟨1,[true,true],([] ++ (rep [false,true,false,true,false,true,false,true] n ++ [false,false,true,true]))⟩ = some ⟨1,([true] ++ (rep [true,false,true,false,true,false,true,false] n ++ [true])),[false,false,true,true]⟩ := by
    exact sweepR table 1 [true] [] [false,true,false,true,false,true,false,true] [true,false,true,false,true,false,true,false] 8 (fun _ _ => rfl) n [true] [false,false,true,true]
  have g6 := join0 g5 h6
  have h7 : run0 table 3 ⟨1,([true] ++ (rep [true,false,true,false,true,false,true,false] n ++ [true])),[false,false,true,true]⟩ = some ⟨3,([true,false,true,false] ++ (rep [true,false,true,false,true,false,true,false] n ++ [true])),[true]⟩ := by rfl
  have g7 := join0 g6 h7
  have h8 : run0 table (16*n) ⟨3,([true,false,true,false] ++ (rep [true,false,true,false,true,false,true,false] n ++ [true])),[true]⟩ = some ⟨3,[true,false,true,false,true],([] ++ (rep [true,false,true,false,true,false,true,false] n ++ [true]))⟩ := by
    exact sweepL table 3 [true,false,true,false] [] [true,false,true,false,true,false,true,false] [true,false,true,false,true,false,true,false] 16 (fun _ _ => rfl) n [true] [true]
  have g8 := join0 g7 h8
  have h9 : run0 table 11 ⟨3,[true,false,true,false,true],([] ++ (rep [true,false,true,false,true,false,true,false] n ++ [true]))⟩ = some ⟨1,[true,true],([false,true,false,true,false] ++ (rep [true,false,true,false,true,false,true,false] n ++ [true]))⟩ := by rfl
  have g9 := join0 g8 h9
  have h10 : run0 table (8*n) ⟨1,[true,true],([false,true,false,true,false] ++ (rep [true,false,true,false,true,false,true,false] n ++ [true]))⟩ = some ⟨1,([true] ++ (rep [true,false,true,false,true,false,true,false] n ++ [true])),[false,true,false,true,false,true]⟩ := by
    exact sweepR table 1 [true] [false,true,false,true,false] [true,false,true,false,true,false,true,false] [true,false,true,false,true,false,true,false] 8 (fun _ _ => rfl) n [true] [true]
  have g10 := join0 g9 h10
  have h11 : run0 table 8 ⟨1,([true] ++ (rep [true,false,true,false,true,false,true,false] n ++ [true])),[false,true,false,true,false,true]⟩ = some ⟨1,([false,true,false,true,false,true,false,true,false] ++ (rep [true,false,true,false,true,false,true,false] n ++ [true])),[]⟩ := by rfl
  have g11 := join0 g10 h11
  have e12 : (⟨1,([false,true,false,true,false,true,false,true,false] ++ (rep [true,false,true,false,true,false,true,false] n ++ [true])),[]⟩ : Z0) = ⟨1,([false,true,false,true,false,true,false,true] ++ (rep [false,true,false,true,false,true,false,true] n ++ [false,true])),[]⟩ := congrArg (fun x => (⟨1,x,[]⟩ : Z0)) (moveCut [false,true,false,true,false,true,false,true] [true] [true,false,true,false,true,false,true] false n)
  rw [e12] at g11
  rw [show 0+5+1+(16*n)+2+(8*n)+3+(16*n)+11+(8*n)+8=48*n+30 by omega] at g11
  exact g11
theorem never (m : Machine) (hm : compatible table m) : NeverHalts m :=
  never_of_growth table family 1 (fun n => 48*n+30) entry (by intro n; omega) epoch m hm
#print axioms never
end BB6.Agent8Raw54.LA.M69
