import SweepPumping
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.LA.M26
open BB6Coverage BB6Coverage.Agent31Pump
def table : PartialMachine := fun s => match s.1.val,s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 0,true => some (some ⟨true,true,5⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨false,true,0⟩)
  | 2,false => some (some ⟨false,true,3⟩)
  | 2,true => some (some ⟨true,false,0⟩)
  | 3,false => some (some ⟨true,false,3⟩)
  | 3,true => some (some ⟨false,false,4⟩)
  | 4,false => some (some ⟨true,false,0⟩)
  | 4,true => some (some ⟨false,false,4⟩)
  | 5,true => some (some ⟨false,true,2⟩)
  | _,_ => none
def family (n : Nat) : Z0 := ⟨0,([false] ++ (rep [true,false,true] n ++ ([false] ++ (rep [true] n ++ [true,true,false,true,false,true])))),[true,true,true,true]⟩
theorem entry : run0 table 55 ⟨0,[],[]⟩ = some (family 0) := by rfl
theorem epoch (n : Nat) : run0 table (14*n+44) (family n) = some (family (n+1)) := by
  have h0 : run0 table 10 ⟨0,([false] ++ (rep [true,false,true] n ++ ([false] ++ (rep [true] n ++ [true,true,false,true,false,true])))),[true,true,true,true]⟩ = some ⟨3,([false,false,true,true,false,true,true,false,true] ++ (rep [true,false,true] n ++ ([false] ++ (rep [true] n ++ [true,true,false,true,false,true])))),[]⟩ := by rfl
  have h1 : run0 table (9*n) ⟨3,([false,false,true,true,false,true,true,false,true] ++ (rep [true,false,true] n ++ ([false] ++ (rep [true] n ++ [true,true,false,true,false,true])))),[]⟩ = some ⟨3,([false,false,true,true,false,true,true,false,true,false] ++ (rep [true] n ++ [true,true,false,true,false,true])),rep [true,true,true] n⟩ := by
    simpa [List.append_assoc] using sweepL table 3 [false,false,true,true,false,true,true,false,true] [] [true,false,true] [true,true,true] 9 (fun _ _ => rfl) n ([false] ++ (rep [true] n ++ [true,true,false,true,false,true])) []
  have g1 := join0 h0 h1
  have h2 : run0 table 22 ⟨3,([false,false,true,true,false,true,true,false,true,false] ++ (rep [true] n ++ [true,true,false,true,false,true])),rep [true,true,true] n⟩ = some ⟨0,(rep [true] n ++ [true,true,false,true,false,true]),([true,false,true,true,true,true,true,true,true,true] ++ rep [true,true,true] n)⟩ := by rfl
  have g2 := join0 g1 h2
  have e3 : (⟨0,(rep [true] n ++ [true,true,false,true,false,true]),([true,false,true,true,true,true,true,true,true,true] ++ rep [true,true,true] n)⟩ : Z0) = ⟨0,([true] ++ (rep [true] n ++ [true,false,true,false,true])),([true,false,true,true,true,true,true,true,true,true] ++ rep [true,true,true] n)⟩ := by simpa [List.append_assoc] using congrArg (fun x => (⟨0,x,([true,false,true,true,true,true,true,true,true,true] ++ rep [true,true,true] n)⟩ : Z0)) ((moveCut [] [true,false,true,false,true] [] true n).symm)
  rw [e3] at g2
  have h4 : run0 table 7 ⟨0,([true] ++ (rep [true] n ++ [true,false,true,false,true])),([true,false,true,true,true,true,true,true,true,true] ++ rep [true,true,true] n)⟩ = some ⟨0,([false,false,true,true] ++ (rep [true] n ++ [true,false,true,false,true])),([true,true,true,true,true,true,true] ++ rep [true,true,true] n)⟩ := by rfl
  have g4 := join0 g2 h4
  have h5 : run0 table (5*n) ⟨0,([false,false,true,true] ++ (rep [true] n ++ [true,false,true,false,true])),([true,true,true,true,true,true,true] ++ rep [true,true,true] n)⟩ = some ⟨0,([false] ++ (rep [true,false,true] n ++ ([false,true,true] ++ (rep [true] n ++ [true,false,true,false,true])))),[true,true,true,true,true,true,true]⟩ := by
    simpa [List.append_assoc] using sweepR table 0 [false] [true,true,true,true,true,true,true] [true,true,true] [true,false,true] 5 (fun _ _ => rfl) n ([false,true,true] ++ (rep [true] n ++ [true,false,true,false,true])) []
  have g5 := join0 g4 h5
  have h6 : run0 table 5 ⟨0,([false] ++ (rep [true,false,true] n ++ ([false,true,true] ++ (rep [true] n ++ [true,false,true,false,true])))),[true,true,true,true,true,true,true]⟩ = some ⟨0,([false,true,false,true] ++ (rep [true,false,true] n ++ ([false,true,true] ++ (rep [true] n ++ [true,false,true,false,true])))),[true,true,true,true]⟩ := by rfl
  have g6 := join0 g5 h6
  have e7 : (⟨0,([false,true,false,true] ++ (rep [true,false,true] n ++ ([false,true,true] ++ (rep [true] n ++ [true,false,true,false,true])))),[true,true,true,true]⟩ : Z0) = ⟨0,([false,true,false,true] ++ (rep [true,false,true] n ++ ([false,true] ++ (rep [true] n ++ [true,true,false,true,false,true])))),[true,true,true,true]⟩ := by simpa [List.append_assoc] using congrArg (fun x => (⟨0,x,[true,true,true,true]⟩ : Z0)) (moveCut ([false,true,false,true] ++ (rep [true,false,true] n ++ [false,true])) [true,false,true,false,true] [] true n)
  rw [e7] at g6
  rw [show 10+(9*n)+22+7+(5*n)+5=14*n+44 by omega] at g6
  simpa [family,rep,List.append_assoc] using g6
theorem never (m : Machine) (hm : compatible table m) : NeverHalts m :=
  never_of_growth table family 55 (fun n => 14*n+44) entry (by intro n; omega) epoch m hm
#print axioms never
end BB6.Agent8Raw54.LA.M26
