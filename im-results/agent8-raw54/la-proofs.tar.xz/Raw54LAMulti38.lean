import SweepPumping
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.LA.M38
open BB6Coverage BB6Coverage.Agent31Pump
def table : PartialMachine := fun s => match s.1.val,s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 0,true => some (some ⟨false,false,5⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨false,true,1⟩)
  | 2,false => some (some ⟨false,true,3⟩)
  | 2,true => some (some ⟨false,false,1⟩)
  | 3,false => some (some ⟨true,false,3⟩)
  | 3,true => some (some ⟨false,false,4⟩)
  | 4,false => some (some ⟨true,false,0⟩)
  | 4,true => some (some ⟨false,false,4⟩)
  | 5,false => some (some ⟨false,false,2⟩)
  | _,_ => none
def family (n : Nat) : Z0 := ⟨3,[false,false,true],(rep [true] n ++ ([false,true] ++ (rep [false] n ++ [false,true])))⟩
theorem entry : run0 table 19 ⟨0,[],[]⟩ = some (family 0) := by rfl
theorem epoch (n : Nat) : run0 table (4*n+20) (family n) = some (family (n+1)) := by
  have h0 : run0 table 5 ⟨3,[false,false,true],(rep [true] n ++ ([false,true] ++ (rep [false] n ++ [false,true])))⟩ = some ⟨1,[true,true],([false,true,true] ++ (rep [true] n ++ ([false,true] ++ (rep [false] n ++ [false,true]))))⟩ := by rfl
  have h1 : run0 table (3*n) ⟨1,[true,true],([false,true,true] ++ (rep [true] n ++ ([false,true] ++ (rep [false] n ++ [false,true]))))⟩ = some ⟨1,([true] ++ (rep [false] n ++ [true])),([false,true,true,false,true] ++ (rep [false] n ++ [false,true]))⟩ := by
    simpa [List.append_assoc] using sweepR table 1 [true] [false,true,true] [true] [false] 3 (fun _ _ => rfl) n [true] ([false,true] ++ (rep [false] n ++ [false,true]))
  have g1 := join0 h0 h1
  have h2 : run0 table 14 ⟨1,([true] ++ (rep [false] n ++ [true])),([false,true,true,false,true] ++ (rep [false] n ++ [false,true]))⟩ = some ⟨3,([false,false,false] ++ (rep [false] n ++ [true])),([false,true,false] ++ (rep [false] n ++ [false,true]))⟩ := by rfl
  have g2 := join0 g1 h2
  have h3 : run0 table (1*n) ⟨3,([false,false,false] ++ (rep [false] n ++ [true])),([false,true,false] ++ (rep [false] n ++ [false,true]))⟩ = some ⟨3,[false,false,false,true],(rep [true] n ++ ([false,true,false] ++ (rep [false] n ++ [false,true])))⟩ := by
    simpa [List.append_assoc] using sweepL table 3 [false,false,false] [] [false] [true] 1 (fun _ _ => rfl) n [true] ([false,true,false] ++ (rep [false] n ++ [false,true]))
  have g3 := join0 g2 h3
  have h4 : run0 table 1 ⟨3,[false,false,false,true],(rep [true] n ++ ([false,true,false] ++ (rep [false] n ++ [false,true])))⟩ = some ⟨3,[false,false,true],([true] ++ (rep [true] n ++ ([false,true,false] ++ (rep [false] n ++ [false,true]))))⟩ := by rfl
  have g4 := join0 g3 h4
  rw [show 5+(3*n)+14+(1*n)+1=4*n+20 by omega] at g4
  simpa [family,rep,List.append_assoc] using g4
theorem never (m : Machine) (hm : compatible table m) : NeverHalts m :=
  never_of_growth table family 19 (fun n => 4*n+20) entry (by intro n; omega) epoch m hm
#print axioms never
end BB6.Agent8Raw54.LA.M38
