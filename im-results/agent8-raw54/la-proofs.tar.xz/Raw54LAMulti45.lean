import SweepPumping
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.LA.M45
open BB6Coverage BB6Coverage.Agent31Pump
def table : PartialMachine := fun s => match s.1.val,s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 0,true => some (some ⟨false,true,0⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨false,true,1⟩)
  | 2,false => some (some ⟨false,true,3⟩)
  | 2,true => some (some ⟨true,false,5⟩)
  | 3,false => some (some ⟨true,false,3⟩)
  | 3,true => some (some ⟨false,false,4⟩)
  | 4,false => some (some ⟨true,false,0⟩)
  | 4,true => some (some ⟨false,false,4⟩)
  | 5,true => some (some ⟨false,false,2⟩)
  | _,_ => none
def family (n : Nat) : Z0 := ⟨1,([true] ++ (rep [false,false] n ++ (rep [true,false,false,false] n ++ [true,false,false,false,true]))),[]⟩
theorem entry : run0 table 17 ⟨0,[],[]⟩ = some (family 0) := by rfl
theorem epoch (n : Nat) : run0 table (24*n+40) (family n) = some (family (n+1)) := by
  have h0 : run0 table 3 ⟨1,([true] ++ (rep [false,false] n ++ (rep [true,false,false,false] n ++ [true,false,false,false,true]))),[]⟩ = some ⟨3,([false,false,true,false] ++ (rep [false,false] n ++ (rep [true,false,false,false] n ++ [true,false,false,false,true]))),[]⟩ := by rfl
  have h1 : run0 table (10*n) ⟨3,([false,false,true,false] ++ (rep [false,false] n ++ (rep [true,false,false,false] n ++ [true,false,false,false,true]))),[]⟩ = some ⟨3,([false,false,true,false] ++ (rep [true,false,false,false] n ++ [true,false,false,false,true])),rep [true,true] n⟩ := by
    simpa [List.append_assoc] using sweepL table 3 [false,false,true,false] [] [false,false] [true,true] 10 (fun _ _ => rfl) n (rep [true,false,false,false] n ++ [true,false,false,false,true]) []
  have g1 := join0 h0 h1
  have h2 : run0 table 4 ⟨3,([false,false,true,false] ++ (rep [true,false,false,false] n ++ [true,false,false,false,true])),rep [true,true] n⟩ = some ⟨0,(rep [true,false,false,false] n ++ [true,false,false,false,true]),([true,false,true,true] ++ rep [true,true] n)⟩ := by rfl
  have g2 := join0 g1 h2
  have e3 : (⟨0,(rep [true,false,false,false] n ++ [true,false,false,false,true]),([true,false,true,true] ++ rep [true,true] n)⟩ : Z0) = ⟨0,([true] ++ (rep [false,false,false,true] n ++ [false,false,false,true])),([true,false,true,true] ++ rep [true,true] n)⟩ := by simpa [List.append_assoc] using congrArg (fun x => (⟨0,x,([true,false,true,true] ++ rep [true,true] n)⟩ : Z0)) ((moveCut [] [false,false,false,true] [false,false,false] true n).symm)
  rw [e3] at g2
  have h4 : run0 table 3 ⟨0,([true] ++ (rep [false,false,false,true] n ++ [false,false,false,true])),([true,false,true,true] ++ rep [true,true] n)⟩ = some ⟨1,([true,true,false,false] ++ (rep [false,false,false,true] n ++ [false,false,false,true])),([true] ++ rep [true,true] n)⟩ := by rfl
  have g4 := join0 g2 h4
  have h5 : run0 table (2*n) ⟨1,([true,true,false,false] ++ (rep [false,false,false,true] n ++ [false,false,false,true])),([true] ++ rep [true,true] n)⟩ = some ⟨1,([true] ++ (rep [false,false] n ++ ([true,false,false] ++ (rep [false,false,false,true] n ++ [false,false,false,true])))),[true]⟩ := by
    simpa [List.append_assoc] using sweepR table 1 [true] [true] [true,true] [false,false] 2 (fun _ _ => rfl) n ([true,false,false] ++ (rep [false,false,false,true] n ++ [false,false,false,true])) []
  have g5 := join0 g4 h5
  have h6 : run0 table 4 ⟨1,([true] ++ (rep [false,false] n ++ ([true,false,false] ++ (rep [false,false,false,true] n ++ [false,false,false,true])))),[true]⟩ = some ⟨3,([false,false,true,false,false] ++ (rep [false,false] n ++ ([true,false,false] ++ (rep [false,false,false,true] n ++ [false,false,false,true])))),[]⟩ := by rfl
  have g6 := join0 g5 h6
  have h7 : run0 table (10*n) ⟨3,([false,false,true,false,false] ++ (rep [false,false] n ++ ([true,false,false] ++ (rep [false,false,false,true] n ++ [false,false,false,true])))),[]⟩ = some ⟨3,([false,false,true,false,false,true,false,false] ++ (rep [false,false,false,true] n ++ [false,false,false,true])),rep [true,true] n⟩ := by
    simpa [List.append_assoc] using sweepL table 3 [false,false,true,false,false] [] [false,false] [true,true] 10 (fun _ _ => rfl) n ([true,false,false] ++ (rep [false,false,false,true] n ++ [false,false,false,true])) []
  have g7 := join0 g6 h7
  have h8 : run0 table 24 ⟨3,([false,false,true,false,false,true,false,false] ++ (rep [false,false,false,true] n ++ [false,false,false,true])),rep [true,true] n⟩ = some ⟨1,([true,true,false,false,false,true] ++ (rep [false,false,false,true] n ++ [false,false,false,true])),([true,true] ++ rep [true,true] n)⟩ := by rfl
  have g8 := join0 g7 h8
  have h9 : run0 table (2*n) ⟨1,([true,true,false,false,false,true] ++ (rep [false,false,false,true] n ++ [false,false,false,true])),([true,true] ++ rep [true,true] n)⟩ = some ⟨1,([true] ++ (rep [false,false] n ++ ([true,false,false,false,true] ++ (rep [false,false,false,true] n ++ [false,false,false,true])))),[true,true]⟩ := by
    simpa [List.append_assoc] using sweepR table 1 [true] [true,true] [true,true] [false,false] 2 (fun _ _ => rfl) n ([true,false,false,false,true] ++ (rep [false,false,false,true] n ++ [false,false,false,true])) []
  have g9 := join0 g8 h9
  have h10 : run0 table 2 ⟨1,([true] ++ (rep [false,false] n ++ ([true,false,false,false,true] ++ (rep [false,false,false,true] n ++ [false,false,false,true])))),[true,true]⟩ = some ⟨1,([true,false,false] ++ (rep [false,false] n ++ ([true,false,false,false,true] ++ (rep [false,false,false,true] n ++ [false,false,false,true])))),[]⟩ := by rfl
  have g10 := join0 g9 h10
  have e11 : (⟨1,([true,false,false] ++ (rep [false,false] n ++ ([true,false,false,false,true] ++ (rep [false,false,false,true] n ++ [false,false,false,true])))),[]⟩ : Z0) = ⟨1,([true,false,false] ++ (rep [false,false] n ++ ([true,false,false,false] ++ (rep [true,false,false,false] n ++ [true,false,false,false,true])))),[]⟩ := by simpa [List.append_assoc] using congrArg (fun x => (⟨1,x,[]⟩ : Z0)) (moveCut ([true,false,false] ++ (rep [false,false] n ++ [true,false,false,false])) [false,false,false,true] [false,false,false] true n)
  rw [e11] at g10
  rw [show 3+(10*n)+4+3+(2*n)+4+(10*n)+24+(2*n)+2=24*n+40 by omega] at g10
  simpa [family,rep,List.append_assoc] using g10
theorem never (m : Machine) (hm : compatible table m) : NeverHalts m :=
  never_of_growth table family 17 (fun n => 24*n+40) entry (by intro n; omega) epoch m hm
#print axioms never
end BB6.Agent8Raw54.LA.M45
