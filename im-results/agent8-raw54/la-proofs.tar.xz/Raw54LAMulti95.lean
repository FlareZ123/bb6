import SweepPumping
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.LA.M95
open BB6Coverage BB6Coverage.Agent31Pump
def table : PartialMachine := fun s => match s.1.val,s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨false,true,5⟩)
  | 2,false => some (some ⟨false,true,3⟩)
  | 2,true => some (some ⟨true,true,5⟩)
  | 3,false => some (some ⟨true,false,3⟩)
  | 3,true => some (some ⟨false,false,4⟩)
  | 4,false => some (some ⟨true,false,0⟩)
  | 4,true => some (some ⟨false,false,4⟩)
  | 5,false => some (some ⟨false,true,2⟩)
  | 5,true => some (some ⟨false,true,1⟩)
  | _,_ => none
def family (n : Nat) : Z0 := ⟨5,(rep [false,false] n ++ ([false,true,false,false] ++ (rep [true] n ++ [true,false,true]))),[]⟩
theorem entry : run0 table 18 ⟨0,[],[]⟩ = some (family 0) := by rfl
theorem epoch (n : Nat) : run0 table (4*n+13) (family n) = some (family (n+1)) := by
  have e0 : (⟨5,(rep [false,false] n ++ ([false,true,false,false] ++ (rep [true] n ++ [true,false,true]))),[]⟩ : Z0) = ⟨5,([false] ++ (rep [false,false] n ++ ([true,false,false] ++ (rep [true] n ++ [true,false,true])))),[]⟩ := by simpa [List.append_assoc] using congrArg (fun x => (⟨5,x,[]⟩ : Z0)) ((moveCut [] ([true,false,false] ++ (rep [true] n ++ [true,false,true])) [false] false n).symm)
  have h0 : run0 table 0 ⟨5,(rep [false,false] n ++ ([false,true,false,false] ++ (rep [true] n ++ [true,false,true]))),[]⟩ = some ⟨5,([false] ++ (rep [false,false] n ++ ([true,false,false] ++ (rep [true] n ++ [true,false,true])))),[]⟩ := by rw [e0]; rfl
  have h1 : run0 table 2 ⟨5,([false] ++ (rep [false,false] n ++ ([true,false,false] ++ (rep [true] n ++ [true,false,true])))),[]⟩ = some ⟨3,([false,false,false] ++ (rep [false,false] n ++ ([true,false,false] ++ (rep [true] n ++ [true,false,true])))),[]⟩ := by rfl
  have g1 := join0 h0 h1
  have h2 : run0 table (2*n) ⟨3,([false,false,false] ++ (rep [false,false] n ++ ([true,false,false] ++ (rep [true] n ++ [true,false,true])))),[]⟩ = some ⟨3,([false,false,false,true,false,false] ++ (rep [true] n ++ [true,false,true])),rep [true,true] n⟩ := by
    simpa [List.append_assoc] using sweepL table 3 [false,false,false] [] [false,false] [true,true] 2 (fun _ _ => rfl) n ([true,false,false] ++ (rep [true] n ++ [true,false,true])) []
  have g2 := join0 g1 h2
  have h3 : run0 table 9 ⟨3,([false,false,false,true,false,false] ++ (rep [true] n ++ [true,false,true])),rep [true,true] n⟩ = some ⟨5,([true,true,false,false,true] ++ (rep [true] n ++ [true,false,true])),([true] ++ rep [true,true] n)⟩ := by rfl
  have g3 := join0 g2 h3
  have h4 : run0 table (2*n) ⟨5,([true,true,false,false,true] ++ (rep [true] n ++ [true,false,true])),([true] ++ rep [true,true] n)⟩ = some ⟨5,([true] ++ (rep [false,false] n ++ ([true,false,false,true] ++ (rep [true] n ++ [true,false,true])))),[true]⟩ := by
    simpa [List.append_assoc] using sweepR table 5 [true] [true] [true,true] [false,false] 2 (fun _ _ => rfl) n ([true,false,false,true] ++ (rep [true] n ++ [true,false,true])) []
  have g4 := join0 g3 h4
  have h5 : run0 table 2 ⟨5,([true] ++ (rep [false,false] n ++ ([true,false,false,true] ++ (rep [true] n ++ [true,false,true])))),[true]⟩ = some ⟨5,([false,false,false] ++ (rep [false,false] n ++ ([true,false,false,true] ++ (rep [true] n ++ [true,false,true])))),[]⟩ := by rfl
  have g5 := join0 g4 h5
  have e6 : (⟨5,([false,false,false] ++ (rep [false,false] n ++ ([true,false,false,true] ++ (rep [true] n ++ [true,false,true])))),[]⟩ : Z0) = ⟨5,([false,false] ++ (rep [false,false] n ++ ([false,true,false,false,true] ++ (rep [true] n ++ [true,false,true])))),[]⟩ := by simpa [List.append_assoc] using congrArg (fun x => (⟨5,x,[]⟩ : Z0)) (moveCut [false,false] ([true,false,false,true] ++ (rep [true] n ++ [true,false,true])) [false] false n)
  rw [e6] at g5
  rw [show 0+2+(2*n)+9+(2*n)+2=4*n+13 by omega] at g5
  simpa [family,rep,List.append_assoc] using g5
theorem never (m : Machine) (hm : compatible table m) : NeverHalts m :=
  never_of_growth table family 18 (fun n => 4*n+13) entry (by intro n; omega) epoch m hm
#print axioms never
end BB6.Agent8Raw54.LA.M95
