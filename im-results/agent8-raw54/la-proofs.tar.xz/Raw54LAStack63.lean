import Raw54LAStackCore
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.LA.M63
open BB6Coverage BB6Coverage.Agent31Pump BB6.Agent8Raw54.LAStack
def table : PartialMachine := fun s => match s.1.val,s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 0,true => some (some ⟨true,false,5⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨false,true,1⟩)
  | 2,false => some (some ⟨false,true,3⟩)
  | 2,true => some (some ⟨true,false,3⟩)
  | 3,false => some (some ⟨true,false,3⟩)
  | 3,true => some (some ⟨false,false,4⟩)
  | 4,false => some (some ⟨true,false,0⟩)
  | 4,true => some (some ⟨false,false,4⟩)
  | 5,false => some (some ⟨true,false,4⟩)
  | _,_ => none
theorem entry : run0 table 18 ⟨0,[],[]⟩ = some (sect (none,0,true)) := by rfl
theorem pushZeroHi (n : Nat) (T : List Bool) : run0 table (3*n+6) ⟨0,([false] ++ T),([true] ++ (rep [true,true,true] n ++ [false,true,true,true,false,true]))⟩ = some ⟨0,([] ++ (rep [false,false,false] n ++ ([true] ++ T))),[true,false,true,true,true,false,true]⟩ := by
  have h0 : run0 table 1 ⟨0,([false] ++ T),([true] ++ (rep [true,true,true] n ++ [false,true,true,true,false,true]))⟩ = some ⟨1,([true,true] ++ T),([] ++ (rep [true,true,true] n ++ [false,true,true,true,false,true]))⟩ := by rfl
  have h1 : run0 table (3*n) ⟨1,([true,true] ++ T),([] ++ (rep [true,true,true] n ++ [false,true,true,true,false,true]))⟩ = some ⟨1,([true] ++ (rep [false,false,false] n ++ ([true] ++ T))),[false,true,true,true,false,true]⟩ := by
    exact sweepR table 1 [true] [] [true,true,true] [false,false,false] 3 (fun _ _ => rfl) n ([true] ++ T) [false,true,true,true,false,true]
  have g1 := join0 h0 h1
  have h2 : run0 table 5 ⟨1,([true] ++ (rep [false,false,false] n ++ ([true] ++ T))),[false,true,true,true,false,true]⟩ = some ⟨0,([] ++ (rep [false,false,false] n ++ ([true] ++ T))),[true,false,true,true,true,false,true]⟩ := by rfl
  have g2 := join0 g1 h2
  rw [show 1+(3*n)+5=3*n+6 by omega] at g2
  exact g2
theorem pushEmptyHi (n : Nat) : run0 table (3*n+6) ⟨0,[],([true] ++ (rep [true,true,true] n ++ [false,true,true,true,false,true]))⟩ = some ⟨0,([] ++ (rep [false,false,false] n ++ [true])),[true,false,true,true,true,false,true]⟩ := by
  have h0 : run0 table 1 ⟨0,[],([true] ++ (rep [true,true,true] n ++ [false,true,true,true,false,true]))⟩ = some ⟨1,[true,true],([] ++ (rep [true,true,true] n ++ [false,true,true,true,false,true]))⟩ := by rfl
  have h1 : run0 table (3*n) ⟨1,[true,true],([] ++ (rep [true,true,true] n ++ [false,true,true,true,false,true]))⟩ = some ⟨1,([true] ++ (rep [false,false,false] n ++ [true])),[false,true,true,true,false,true]⟩ := by
    exact sweepR table 1 [true] [] [true,true,true] [false,false,false] 3 (fun _ _ => rfl) n [true] [false,true,true,true,false,true]
  have g1 := join0 h0 h1
  have h2 : run0 table 5 ⟨1,([true] ++ (rep [false,false,false] n ++ [true])),[false,true,true,true,false,true]⟩ = some ⟨0,([] ++ (rep [false,false,false] n ++ [true])),[true,false,true,true,true,false,true]⟩ := by rfl
  have g2 := join0 g1 h2
  rw [show 1+(3*n)+5=3*n+6 by omega] at g2
  exact g2
theorem pushZeroLo (n : Nat) (T : List Bool) : run0 table (3*n+8) ⟨0,([false] ++ T),([true] ++ (rep [true,true,true] n ++ [false,false,false,true,false,true]))⟩ = some ⟨0,([] ++ (rep [false,false,false] n ++ ([true] ++ T))),[true,false,true,true,true,false,true]⟩ := by
  have h0 : run0 table 1 ⟨0,([false] ++ T),([true] ++ (rep [true,true,true] n ++ [false,false,false,true,false,true]))⟩ = some ⟨1,([true,true] ++ T),([] ++ (rep [true,true,true] n ++ [false,false,false,true,false,true]))⟩ := by rfl
  have h1 : run0 table (3*n) ⟨1,([true,true] ++ T),([] ++ (rep [true,true,true] n ++ [false,false,false,true,false,true]))⟩ = some ⟨1,([true] ++ (rep [false,false,false] n ++ ([true] ++ T))),[false,false,false,true,false,true]⟩ := by
    exact sweepR table 1 [true] [] [true,true,true] [false,false,false] 3 (fun _ _ => rfl) n ([true] ++ T) [false,false,false,true,false,true]
  have g1 := join0 h0 h1
  have h2 : run0 table 7 ⟨1,([true] ++ (rep [false,false,false] n ++ ([true] ++ T))),[false,false,false,true,false,true]⟩ = some ⟨0,([] ++ (rep [false,false,false] n ++ ([true] ++ T))),[true,false,true,true,true,false,true]⟩ := by rfl
  have g2 := join0 g1 h2
  rw [show 1+(3*n)+7=3*n+8 by omega] at g2
  exact g2
theorem pushEmptyLo (n : Nat) : run0 table (3*n+8) ⟨0,[],([true] ++ (rep [true,true,true] n ++ [false,false,false,true,false,true]))⟩ = some ⟨0,([] ++ (rep [false,false,false] n ++ [true])),[true,false,true,true,true,false,true]⟩ := by
  have h0 : run0 table 1 ⟨0,[],([true] ++ (rep [true,true,true] n ++ [false,false,false,true,false,true]))⟩ = some ⟨1,[true,true],([] ++ (rep [true,true,true] n ++ [false,false,false,true,false,true]))⟩ := by rfl
  have h1 : run0 table (3*n) ⟨1,[true,true],([] ++ (rep [true,true,true] n ++ [false,false,false,true,false,true]))⟩ = some ⟨1,([true] ++ (rep [false,false,false] n ++ [true])),[false,false,false,true,false,true]⟩ := by
    exact sweepR table 1 [true] [] [true,true,true] [false,false,false] 3 (fun _ _ => rfl) n [true] [false,false,false,true,false,true]
  have g1 := join0 h0 h1
  have h2 : run0 table 7 ⟨1,([true] ++ (rep [false,false,false] n ++ [true])),[false,false,false,true,false,true]⟩ = some ⟨0,([] ++ (rep [false,false,false] n ++ [true])),[true,false,true,true,true,false,true]⟩ := by rfl
  have g2 := join0 g1 h2
  rw [show 1+(3*n)+7=3*n+8 by omega] at g2
  exact g2
def cost (b : Bool) := if b then 6 else 8
def out (b : Bool) := true
theorem never (m : Machine) (hm : compatible table m) : NeverHalts m := by
  apply LAStack.never table cost out (by intro b; cases b <;> decide) entry _ _ (by intro T R; rfl) (by intro R; rfl) m hm
  · intro b n T; cases b
    · exact pushZeroLo n T
    · exact pushZeroHi n T
  · intro b n; cases b
    · exact pushEmptyLo n
    · exact pushEmptyHi n
#print axioms never
end BB6.Agent8Raw54.LA.M63
