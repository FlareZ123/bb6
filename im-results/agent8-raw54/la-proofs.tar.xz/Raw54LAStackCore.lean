import Raw54RAClosedCore
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.LAStack
open BB6Coverage BB6Coverage.Agent31Pump BB6.Agent8Raw54.RAClosed

def z : List Bool := [false,false,false]
def o : List Bool := [true,false,false]
def ones : List Bool := [true,true,true]
def tail : Bool → List Bool
  | true => [false,true,true,true,false,true]
  | false => [false,false,false,true,false,true]
def right (n : Nat) (b : Bool) : List Bool := [true] ++ rep ones n ++ tail b
def enc : List Bool → List Bool
  | [] => [true]
  | false::w => z ++ enc w
  | true::w => o ++ enc w
def left : Option (List Bool) → List Bool | none => [] | some w => enc w
def A (l r : List Bool) : Z0 := ⟨0,l,r⟩
def sect (s : Option (List Bool) × Nat × Bool) : Z0 := A (left s.1) (right s.2.1 s.2.2)

theorem enc_zeros (n : Nat) (w : List Bool) : enc (List.replicate n false ++ w) = rep z n ++ enc w := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [List.replicate_succ,List.cons_append,enc,rep,ih,List.append_assoc]
theorem pop_right (n : Nat) (b : Bool) : ones ++ right n b = right (n+1) b := rfl

theorem never (p : PartialMachine) (cost : Bool → Nat) (out : Bool → Bool)
    (pos : ∀ b, 0 < cost b)
    (entry : run0 p 18 ⟨0,[],[]⟩ = some (sect (none,0,true)))
    (push0 : ∀ b n T, run0 p (3*n+cost b) (A (false::T) (right n b)) =
      some (A (rep z n ++ true::T) (right 0 (out b))))
    (pushEmpty : ∀ b n, run0 p (3*n+cost b) (A [] (right n b)) =
      some (A (rep z n ++ [true]) (right 0 (out b))))
    (pop : ∀ T R, run0 p 3 (A (o ++ T) R) = some (A T (ones ++ R)))
    (popEnd : ∀ R, run0 p 3 (A [true] R) = some (A [] (ones ++ R)))
    (m : Machine) (hm : compatible p m) : NeverHalts m := by
  apply neverOfSection p _ sect (none,0,true) 18 entry _ m hm
  rintro ⟨w,n,b⟩
  cases w with
  | none =>
    refine ⟨3*n+cost b,(some (List.replicate n false),0,out b),by have := pos b; omega,?_⟩
    have h := enc_zeros n []
    rw [List.append_nil] at h
    simpa only [sect,left,h,enc] using pushEmpty b n
  | some w =>
    cases w with
    | nil =>
      refine ⟨3,(none,n+1,b),by decide,?_⟩
      simpa only [sect,left,enc,pop_right] using popEnd (right n b)
    | cons d w =>
      cases d
      · refine ⟨3*n+cost b,(some (List.replicate n false ++ true::w),0,out b),by have := pos b; omega,?_⟩
        simpa only [sect,left,enc_zeros,enc,z,o,List.cons_append] using push0 b n ([false,false] ++ enc w)
      · refine ⟨3,(some w,n+1,b),by decide,?_⟩
        simpa only [sect,left,enc,pop_right] using pop (enc w) (right n b)
#print axioms never
end BB6.Agent8Raw54.LAStack
