import Raw54RFStack011
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.RF.M61
open BB6Coverage BB6Coverage.Agent31Pump BB6.Agent8Raw54.RAClosed
open BB6.Agent8Raw54.RF.Stack011 (Word enc pushZero enc_pushZero U Z M T)
def table : PartialMachine := fun s =>
  match s.1.val,s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨false,true,5⟩)
  | 2,false => some (some ⟨false,true,3⟩)
  | 2,true => some (some ⟨true,true,1⟩)
  | 3,false => some (some ⟨true,false,3⟩)
  | 3,true => some (some ⟨false,false,4⟩)
  | 4,false => some (some ⟨true,true,5⟩)
  | 4,true => some (some ⟨false,false,4⟩)
  | 5,false => some (some ⟨true,false,1⟩)
  | 5,true => some (some ⟨true,true,0⟩)
  | _,_ => none
def A (R : List Bool) : Z0 := ⟨0,[false,true,false,true,true,false],R⟩
def C (n : Nat) (R : List Bool) : Z0 := ⟨2,[true,true] ++ rep U n ++ [false,true,true,false],R⟩

theorem resetPrefix (n : Nat) (R : List Bool) :
    run0 table 8 (C n (Z ++ R)) = some ⟨4,rep U n ++ [false,true,true,false],[false,false] ++ M ++ R⟩ := by rfl

theorem resetPrefixEmpty (n : Nat) :
    run0 table 8 (C n []) = some ⟨4,rep U n ++ [false,true,true,false],[false,false] ++ T⟩ := by rfl

theorem resetTail (R : List Bool) :
    run0 table 4 ⟨4,[false,true,true,false],[false,false] ++ R⟩ = some (A R) := by rfl

theorem shiftZ (n : Nat) : rep Z n ++ [false,false] = [false,false] ++ rep Z n := by
  induction n with
  | zero => rfl
  | succ n ih => rw [rep,List.append_assoc,ih]; rfl

theorem resetMid (n : Nat) (R : List Bool) :
    run0 table (4*n+4) ⟨4,rep U n ++ [false,true,true,false],[false,false] ++ R⟩ = some (A (rep Z n ++ R)) := by
  have h := sweepL table 4 [] [] U Z 4 (fun _ _ => rfl) n [false,true,true,false] ([false,false] ++ R)
  simp only [List.nil_append] at h
  rw [← List.append_assoc (rep Z n) [false,false] R,shiftZ,List.append_assoc] at h
  exact join0 h (resetTail (rep Z n ++ R))

theorem reset (n : Nat) (R : List Bool) :
    run0 table (4*n+12) (C n (Z ++ R)) = some (A (rep Z n ++ M ++ R)) := by
  have h := resetPrefix n R
  rw [List.append_assoc] at h
  have g := join0 h (resetMid n (M ++ R))
  rw [show 8+(4*n+4)=4*n+12 by omega] at g
  simpa only [List.append_assoc] using g

theorem resetEmpty (n : Nat) :
    run0 table (4*n+12) (C n []) = some (A (rep Z n ++ T)) := by
  have g := join0 (resetPrefixEmpty n) (resetMid n T)
  rw [show 8+(4*n+4)=4*n+12 by omega] at g
  exact g

theorem cPop (n : Nat) (R : List Bool) : run0 table 6 (C n (M ++ R)) = some (C (n+1) R) := by rfl
theorem cLast (n : Nat) : run0 table 6 (C n T) = some (C (n+1) []) := by rfl
theorem aPop (R : List Bool) : run0 table 6 (A (M ++ R)) = some (C 1 R) := by rfl
theorem aLast : run0 table 6 (A T) = some (C 1 []) := by rfl
theorem aReset (R : List Bool) : run0 table 12 (A (Z ++ R)) = some (A (M ++ R)) := by rfl
theorem aEmpty : run0 table 12 (A []) = some (A T) := by rfl

def sect (s : Option Nat × Word) : Z0 := match s.1 with
  | none => A (enc s.2)
  | some n => C n (enc s.2)
theorem sectionReturn (s : Option Nat × Word) : ∃ t s', 0 < t ∧ run0 table t (sect s) = some (sect s') := by
  rcases s with ⟨n,w⟩
  cases n with
  | none =>
    cases w with
    | empty => exact ⟨12,(none,.last),by decide,aEmpty⟩
    | last => exact ⟨6,(some 1,.empty),by decide,aLast⟩
    | zero w => exact ⟨12,(none,.one w),by decide,aReset (enc w)⟩
    | one w => exact ⟨6,(some 1,w),by decide,aPop (enc w)⟩
  | some n =>
    cases w with
    | empty =>
      refine ⟨4*n+12,(none,pushZero n .last),by omega,?_⟩
      simpa only [sect,enc_pushZero,enc] using resetEmpty n
    | last => exact ⟨6,(some (n+1),.empty),by decide,cLast n⟩
    | zero w =>
      refine ⟨4*n+12,(none,pushZero n (.one w)),by omega,?_⟩
      simpa only [sect,enc_pushZero,enc,List.append_assoc] using reset n (enc w)
    | one w => exact ⟨6,(some (n+1),w),by decide,cPop n (enc w)⟩
theorem entry : run0 table 14 ⟨0,[],[]⟩ = some (sect (none,.empty)) := by rfl
theorem never (m : Machine) (hm : compatible table m) : NeverHalts m :=
  neverOfSection table _ sect (none,.empty) 14 entry sectionReturn m hm
#print axioms never
end BB6.Agent8Raw54.RF.M61
