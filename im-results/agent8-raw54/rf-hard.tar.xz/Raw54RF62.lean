import Raw54RAClosedCore
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.RF.M62
open BB6Coverage BB6Coverage.Agent31Pump BB6.Agent8Raw54.RAClosed
def table : PartialMachine := fun s =>
  match s.1.val,s.2 with
  | 0,false => some (some ⟨true,true,1⟩)
  | 1,false => some (some ⟨true,true,2⟩)
  | 1,true => some (some ⟨false,true,5⟩)
  | 2,false => some (some ⟨false,true,3⟩)
  | 2,true => some (some ⟨true,true,2⟩)
  | 3,false => some (some ⟨true,false,3⟩)
  | 3,true => some (some ⟨false,false,4⟩)
  | 4,false => some (some ⟨true,true,5⟩)
  | 4,true => some (some ⟨false,false,4⟩)
  | 5,false => some (some ⟨true,false,1⟩)
  | 5,true => some (some ⟨true,true,0⟩)
  | _,_ => none
def U := [true,true]
def Z := [false,false]
def A (R : List Bool) : Z0 := ⟨0,[false,true,false,true,true,false],R⟩
def C (n : Nat) (R : List Bool) : Z0 := ⟨2,[true,true,true] ++ rep U n ++ [false,true,true,false],R⟩

theorem resetPrefix (n : Nat) (R : List Bool) :
    run0 table 7 (C n (Z ++ R)) = some ⟨4,rep U n ++ [false,true,true,false],[false,false,false,true,true] ++ R⟩ := by rfl

theorem resetPrefixEmpty (n : Nat) :
    run0 table 7 (C n []) = some ⟨4,rep U n ++ [false,true,true,false],[false,false,false,true,true]⟩ := by rfl

theorem resetTail (R : List Bool) :
    run0 table 4 ⟨4,[false,true,true,false],[false,false] ++ R⟩ = some (A R) := by rfl

theorem shiftZ (n : Nat) : rep Z n ++ [false,false] = [false,false] ++ rep Z n := rep_snoc Z n

theorem resetMid (n : Nat) (R : List Bool) :
    run0 table (2*n+4) ⟨4,rep U n ++ [false,true,true,false],[false,false] ++ R⟩ = some (A (rep Z n ++ R)) := by
  have h := sweepL table 4 [] [] U Z 2 (fun _ _ => rfl) n [false,true,true,false] ([false,false] ++ R)
  simp only [List.nil_append] at h
  rw [← List.append_assoc (rep Z n) [false,false] R,shiftZ,List.append_assoc] at h
  exact join0 h (resetTail (rep Z n ++ R))

theorem reset (n : Nat) (R : List Bool) :
    run0 table (2*n+11) (C n (Z ++ R)) = some (A (rep Z n ++ [false,true,true] ++ R)) := by
  have h := resetPrefix n R
  have g := join0 h (resetMid n ([false,true,true] ++ R))
  rw [show 7+(2*n+4)=2*n+11 by omega] at g
  simpa only [List.append_assoc] using g

theorem resetEmpty (n : Nat) :
    run0 table (2*n+11) (C n []) = some (A (rep Z n ++ [false,true,true])) := by
  have g := join0 (resetPrefixEmpty n) (resetMid n [false,true,true])
  rw [show 7+(2*n+4)=2*n+11 by omega] at g
  exact g

theorem cPop (n : Nat) (R : List Bool) : run0 table 2 (C n (U ++ R)) = some (C (n+1) R) := by rfl
theorem aPop (R : List Bool) : run0 table 3 (A (false::U ++ R)) = some (C 1 R) := by rfl
theorem aReset (R : List Bool) : run0 table 12 (A (false::Z ++ R)) = some (A ([false,true,true] ++ R)) := by rfl
theorem aEmpty : run0 table 12 (A []) = some (A [false,true,true]) := by rfl
theorem aSingleton : run0 table 12 (A [false]) = some (A [false,true,true]) := by rfl

def enc : List Bool → List Bool
  | [] => []
  | b::w => b::b::enc w
theorem encRep (n : Nat) (w : List Bool) : enc (List.replicate n false ++ w) = rep Z n ++ enc w := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [List.replicate_succ,List.cons_append,enc,rep,Z,List.cons_append,List.nil_append,ih]
theorem rotateZ (n : Nat) : rep Z n ++ [false] = false :: rep Z n := by
  induction n with
  | zero => rfl
  | succ n ih => rw [rep,List.append_assoc,ih]; rfl
inductive Section where
  | empty
  | a (w : List Bool)
  | c (n : Nat) (w : List Bool)
def sect : Section → Z0
  | .empty => A []
  | .a w => A (false::enc w)
  | .c n w => C n (enc w)
theorem sectionReturn (s : Section) : ∃ t s', 0 < t ∧ run0 table t (sect s) = some (sect s') := by
  cases s with
  | empty => exact ⟨12,.a [true],by decide,aEmpty⟩
  | a w =>
    cases w with
    | nil => exact ⟨12,.a [true],by decide,aSingleton⟩
    | cons b w => cases b with
      | false => exact ⟨12,.a (true::w),by decide,aReset (enc w)⟩
      | true => exact ⟨3,.c 1 w,by decide,aPop (enc w)⟩
  | c n w =>
    cases w with
    | nil =>
      refine ⟨2*n+11,.a (List.replicate n false ++ [true]),by omega,?_⟩
      simp only [sect,encRep,enc]
      have h := resetEmpty n
      rw [show ([false,true,true] : List Bool) = [false] ++ [true,true] by rfl, ← List.append_assoc,rotateZ] at h
      exact h
    | cons b w =>
      cases b with
      | true => exact ⟨2,.c (n+1) w,by decide,cPop n (enc w)⟩
      | false =>
        refine ⟨2*n+11,.a (List.replicate n false ++ true::w),by omega,?_⟩
        simp only [sect,encRep,enc]
        have h := reset n (enc w)
        change run0 table (2*n+11) (C n (Z ++ enc w)) = some (A (rep Z n ++ [false,true,true] ++ enc w)) at h
        rw [show ([false,true,true] : List Bool) = [false] ++ [true,true] by rfl,← List.append_assoc (rep Z n) [false] [true,true],rotateZ] at h
        simpa only [List.append_assoc,List.cons_append,List.nil_append,Z] using h

theorem entry : run0 table 14 ⟨0,[],[]⟩ = some (sect .empty) := by rfl
theorem never (m : Machine) (hm : compatible table m) : NeverHalts m :=
  neverOfSection table _ sect .empty 14 entry sectionReturn m hm
#print axioms never
end BB6.Agent8Raw54.RF.M62
