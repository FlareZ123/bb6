import Raw54RAClosedCore
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.RF.Stack011
open BB6Coverage BB6Coverage.Agent31Pump BB6.Agent8Raw54.RAClosed
inductive Variant where | m0 | m10 | m11
def table (v : Variant) : PartialMachine := fun s => match v with
  | .m0 => (match s.1.val,s.2 with
      | 0,false => some (some ⟨true,true,1⟩)
      | 0,true => some (some ⟨false,true,1⟩)
      | 1,false => some (some ⟨true,true,2⟩)
      | 2,false => some (some ⟨false,true,3⟩)
      | 2,true => some (some ⟨true,true,5⟩)
      | 3,false => some (some ⟨true,false,3⟩)
      | 3,true => some (some ⟨false,false,4⟩)
      | 4,false => some (some ⟨true,true,5⟩)
      | 4,true => some (some ⟨false,false,4⟩)
      | 5,false => some (some ⟨false,false,0⟩)
      | 5,true => some (some ⟨true,true,0⟩)
      | _,_ => none)
  | .m10 => (match s.1.val,s.2 with
      | 0,false => some (some ⟨true,true,1⟩)
      | 1,false => some (some ⟨true,true,2⟩)
      | 1,true => some (some ⟨false,true,1⟩)
      | 2,false => some (some ⟨false,true,3⟩)
      | 2,true => some (some ⟨true,true,5⟩)
      | 3,false => some (some ⟨true,false,3⟩)
      | 3,true => some (some ⟨false,false,4⟩)
      | 4,false => some (some ⟨true,true,5⟩)
      | 4,true => some (some ⟨false,false,4⟩)
      | 5,false => some (some ⟨false,false,1⟩)
      | 5,true => some (some ⟨true,true,0⟩)
      | _,_ => none)
  | .m11 => (match s.1.val,s.2 with
      | 0,false => some (some ⟨true,true,1⟩)
      | 1,false => some (some ⟨true,true,2⟩)
      | 1,true => some (some ⟨true,false,4⟩)
      | 2,false => some (some ⟨false,true,3⟩)
      | 2,true => some (some ⟨false,true,1⟩)
      | 3,false => some (some ⟨true,false,3⟩)
      | 3,true => some (some ⟨false,false,4⟩)
      | 4,false => some (some ⟨true,true,5⟩)
      | 4,true => some (some ⟨false,false,4⟩)
      | 5,false => some (some ⟨false,false,2⟩)
      | 5,true => some (some ⟨true,true,0⟩)
      | _,_ => none)

def cost (v : Variant) : Nat := match v with | .m11 => 26 | _ => 24
def popCost (v : Variant) : Nat := match v with | .m11 => 6 | _ => 4
def U := [true,true,true,true]
def Z := [false,false,false,false]
def M := [false,true,true,false]
def T := [false,true,true]
def L (n : Nat) : List Bool := false :: true :: (rep U n ++ [true,true,false,true,false,true,false])
def C (n : Nat) (R : List Bool) : Z0 := ⟨0,L n,R⟩

theorem shift (n : Nat) : [true,true] ++ rep U n = rep U n ++ [true,true] := by
  induction n with
  | zero => rfl
  | succ n ih => simpa only [rep,U,List.append_assoc,List.cons_append,List.nil_append] using congrArg (fun x => [true,true,true,true] ++ x) ih

theorem resetPrefix (v : Variant) (n : Nat) (R : List Bool) :
    run0 (table v) 6 (C n (Z ++ R)) = some ⟨4,rep U n ++ [true,true,true,true,false,true,false,true,false],M ++ R⟩ := by
  have h : run0 (table v) 6 (C n (Z ++ R)) = some ⟨4,([true,true] ++ rep U n) ++ [true,true,false,true,false,true,false],M ++ R⟩ := by cases v <;> rfl
  rw [shift,List.append_assoc] at h
  exact h

theorem resetPrefixEmpty (v : Variant) (n : Nat) :
    run0 (table v) 6 (C n []) = some ⟨4,rep U n ++ [true,true,true,true,false,true,false,true,false],T⟩ := by
  have h : run0 (table v) 6 (C n []) = some ⟨4,([true,true] ++ rep U n) ++ [true,true,false,true,false,true,false],T⟩ := by cases v <;> rfl
  rw [shift,List.append_assoc] at h
  exact h

theorem resetTail (v : Variant) (R : List Bool) :
    run0 (table v) (cost v-6) ⟨4,[true,true,true,true,false,true,false,true,false],R⟩ = some (C 0 R) := by
  cases v <;> rfl

theorem resetMid (v : Variant) (n : Nat) (R : List Bool) :
    run0 (table v) (4*n+cost v-6) ⟨4,rep U n ++ [true,true,true,true,false,true,false,true,false],R⟩ = some (C 0 (rep Z n ++ R)) := by
  have h := sweepL (table v) 4 [] [] U Z 4 (by intro l r; cases v <;> rfl) n [true,true,true,true,false,true,false,true,false] R
  have g := join0 h (resetTail v (rep Z n ++ R))
  cases v <;> simpa [cost] using g

theorem reset (v : Variant) (n : Nat) (R : List Bool) :
    run0 (table v) (4*n+cost v) (C n (Z ++ R)) = some (C 0 (rep Z n ++ M ++ R)) := by
  have g := join0 (resetPrefix v n R) (resetMid v n (M ++ R))
  have e : 6+(4*n+cost v-6)=4*n+cost v := by cases v <;> simp [cost] <;> omega
  rw [e] at g
  simpa only [List.append_assoc] using g

theorem resetEmpty (v : Variant) (n : Nat) :
    run0 (table v) (4*n+cost v) (C n []) = some (C 0 (rep Z n ++ T)) := by
  have g := join0 (resetPrefixEmpty v n) (resetMid v n T)
  have e : 6+(4*n+cost v-6)=4*n+cost v := by cases v <;> simp [cost] <;> omega
  rw [e] at g
  exact g

theorem pop (v : Variant) (n : Nat) (R : List Bool) :
    run0 (table v) (popCost v) (C n (M ++ R)) = some (C (n+1) R) := by cases v <;> rfl

theorem popLast (v : Variant) (n : Nat) :
    run0 (table v) (popCost v) (C n T) = some (C (n+1) []) := by cases v <;> rfl

inductive Word where
  | empty
  | last
  | zero (w : Word)
  | one (w : Word)
def enc : Word → List Bool
  | .empty => []
  | .last => T
  | .zero w => Z ++ enc w
  | .one w => M ++ enc w
def pushZero : Nat → Word → Word
  | 0,w => w
  | n+1,w => .zero (pushZero n w)
theorem enc_pushZero (n : Nat) (w : Word) : enc (pushZero n w) = rep Z n ++ enc w := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [pushZero,enc,rep,List.append_assoc,ih]
def sect (w : Nat × Word) : Z0 := C w.1 (enc w.2)
theorem sectionReturn (v : Variant) (s : Nat × Word) : ∃ t s', 0 < t ∧ run0 (table v) t (sect s) = some (sect s') := by
  rcases s with ⟨n,w⟩
  cases w with
  | empty =>
    refine ⟨4*n+cost v,(0,pushZero n .last),by cases v <;> simp [cost] <;> omega,?_⟩
    simpa only [sect,enc_pushZero,enc] using resetEmpty v n
  | last => exact ⟨popCost v,(n+1,.empty),by cases v <;> decide,popLast v n⟩
  | zero w =>
    refine ⟨4*n+cost v,(0,pushZero n (.one w)),by cases v <;> simp [cost] <;> omega,?_⟩
    simpa only [sect,enc_pushZero,enc,List.append_assoc] using reset v n (enc w)
  | one w => exact ⟨popCost v,(n+1,w),by cases v <;> decide,pop v n (enc w)⟩
theorem entry (v : Variant) : run0 (table v) 31 ⟨0,[],[]⟩ = some (sect (0,.empty)) := by cases v <;> rfl
theorem never (v : Variant) (m : Machine) (hm : compatible (table v) m) : NeverHalts m :=
  neverOfSection (table v) _ sect (0,.empty) 31 (entry v) (sectionReturn v) m hm
#print axioms never
end BB6.Agent8Raw54.RF.Stack011
