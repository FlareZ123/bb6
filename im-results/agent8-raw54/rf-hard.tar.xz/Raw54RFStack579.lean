import Raw54RAClosedCore
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace BB6.Agent8Raw54.RF.Stack579
open BB6Coverage BB6Coverage.Agent31Pump BB6.Agent8Raw54.RAClosed
inductive Variant where | m57 | m59 | m63
def table (v : Variant) : PartialMachine := fun s => match v with
  | .m57 => (match s.1.val,s.2 with
      | 0,false => some (some ⟨true,true,1⟩)
      | 0,true => some (some ⟨false,true,5⟩)
      | 1,false => some (some ⟨true,true,2⟩)
      | 1,true => some (some ⟨false,true,2⟩)
      | 2,false => some (some ⟨false,true,3⟩)
      | 2,true => some (some ⟨true,true,0⟩)
      | 3,false => some (some ⟨true,false,3⟩)
      | 3,true => some (some ⟨false,false,4⟩)
      | 4,false => some (some ⟨true,true,5⟩)
      | 4,true => some (some ⟨false,false,4⟩)
      | 5,false => some (some ⟨true,false,1⟩)
      | _,_ => none)
  | .m59 => (match s.1.val,s.2 with
      | 0,false => some (some ⟨true,true,1⟩)
      | 1,false => some (some ⟨true,true,2⟩)
      | 1,true => some (some ⟨false,true,5⟩)
      | 2,false => some (some ⟨false,true,3⟩)
      | 2,true => some (some ⟨false,false,5⟩)
      | 3,false => some (some ⟨true,false,3⟩)
      | 3,true => some (some ⟨false,false,4⟩)
      | 4,false => some (some ⟨true,true,5⟩)
      | 4,true => some (some ⟨false,false,4⟩)
      | 5,false => some (some ⟨true,false,1⟩)
      | 5,true => some (some ⟨true,true,0⟩)
      | _,_ => none)
  | .m63 => (match s.1.val,s.2 with
      | 0,false => some (some ⟨true,true,1⟩)
      | 1,false => some (some ⟨true,true,2⟩)
      | 1,true => some (some ⟨false,true,5⟩)
      | 2,false => some (some ⟨false,true,3⟩)
      | 2,true => some (some ⟨true,true,5⟩)
      | 3,false => some (some ⟨true,false,3⟩)
      | 3,true => some (some ⟨false,false,4⟩)
      | 4,false => some (some ⟨true,true,5⟩)
      | 4,true => some (some ⟨false,false,4⟩)
      | 5,false => some (some ⟨true,false,1⟩)
      | 5,true => some (some ⟨true,true,0⟩)
      | _,_ => none)

def width (v : Variant) : Nat := match v with | .m57 => 5 | _ => 4
def popCost (v : Variant) : Nat := match v with | .m57 => 7 | .m59 => 10 | .m63 => 4
def U (v : Variant) := List.replicate (width v) true
def Z (v : Variant) := List.replicate (width v) false
def M (v : Variant) := [false,true,true] ++ List.replicate (width v-3) false
def T := [false,true,true]
def L (v : Variant) (n : Nat) : List Bool := false :: true :: (rep (U v) n ++ [false,true,true,false])
def C (v : Variant) (n : Nat) (R : List Bool) : Z0 := ⟨0,L v n,R⟩

theorem resetPrefix (v : Variant) (n : Nat) (R : List Bool) :
    run0 (table v) 8 (C v n (Z v ++ R)) = some ⟨4,rep (U v) n ++ [false,true,true,false],[false,false] ++ M v ++ R⟩ := by
  cases v <;> rfl

theorem resetPrefixEmpty (v : Variant) (n : Nat) :
    run0 (table v) 8 (C v n []) = some ⟨4,rep (U v) n ++ [false,true,true,false],[false,false] ++ T⟩ := by
  cases v <;> rfl

theorem resetTail (v : Variant) (R : List Bool) :
    run0 (table v) 4 ⟨4,[false,true,true,false],[false,false] ++ R⟩ = some (C v 0 R) := by
  cases v <;> rfl

theorem shiftZ (v : Variant) (n : Nat) : rep (Z v) n ++ [false,false] = [false,false] ++ rep (Z v) n := by
  induction n with
  | zero => rfl
  | succ n ih => rw [rep,List.append_assoc,ih]; cases v <;> rfl

theorem resetMid (v : Variant) (n : Nat) (R : List Bool) :
    run0 (table v) (width v*n+4) ⟨4,rep (U v) n ++ [false,true,true,false],[false,false] ++ R⟩ = some (C v 0 (rep (Z v) n ++ R)) := by
  have h := sweepL (table v) 4 [] [] (U v) (Z v) (width v) (by intro l r; cases v <;> rfl) n [false,true,true,false] ([false,false] ++ R)
  simp only [List.nil_append] at h
  rw [← List.append_assoc (rep (Z v) n) [false,false] R,shiftZ,List.append_assoc] at h
  exact join0 h (resetTail v (rep (Z v) n ++ R))

theorem reset (v : Variant) (n : Nat) (R : List Bool) :
    run0 (table v) (width v*n+12) (C v n (Z v ++ R)) = some (C v 0 (rep (Z v) n ++ M v ++ R)) := by
  have h := resetPrefix v n R
  rw [List.append_assoc] at h
  have g := join0 h (resetMid v n (M v ++ R))
  rw [show 8+(width v*n+4)=width v*n+12 by omega] at g
  simpa only [List.append_assoc] using g

theorem resetEmpty (v : Variant) (n : Nat) :
    run0 (table v) (width v*n+12) (C v n []) = some (C v 0 (rep (Z v) n ++ T)) := by
  have g := join0 (resetPrefixEmpty v n) (resetMid v n T)
  rw [show 8+(width v*n+4)=width v*n+12 by omega] at g
  exact g

theorem pop (v : Variant) (n : Nat) (R : List Bool) :
    run0 (table v) (popCost v) (C v n (M v ++ R)) = some (C v (n+1) R) := by cases v <;> rfl

theorem popLast (v : Variant) (n : Nat) :
    run0 (table v) (popCost v) (C v n T) = some (C v (n+1) []) := by cases v <;> rfl

inductive Word where
  | empty
  | last
  | zero (w : Word)
  | one (w : Word)
def enc (v : Variant) : Word → List Bool
  | .empty => []
  | .last => T
  | .zero w => Z v ++ enc v w
  | .one w => M v ++ enc v w
def pushZero : Nat → Word → Word
  | 0,w => w
  | n+1,w => .zero (pushZero n w)
theorem enc_pushZero (v : Variant) (n : Nat) (w : Word) : enc v (pushZero n w) = rep (Z v) n ++ enc v w := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [pushZero,enc,rep,List.append_assoc,ih]
def sect (v : Variant) (w : Nat × Word) : Z0 := C v w.1 (enc v w.2)
theorem sectionReturn (v : Variant) (s : Nat × Word) : ∃ t s', 0 < t ∧ run0 (table v) t (sect v s) = some (sect v s') := by
  rcases s with ⟨n,w⟩
  cases w with
  | empty =>
    refine ⟨width v*n+12,(0,pushZero n .last),by omega,?_⟩
    simpa only [sect,enc_pushZero,enc] using resetEmpty v n
  | last => exact ⟨popCost v,(n+1,.empty),by cases v <;> decide,popLast v n⟩
  | zero w =>
    refine ⟨width v*n+12,(0,pushZero n (.one w)),by omega,?_⟩
    simpa only [sect,enc_pushZero,enc,List.append_assoc] using reset v n (enc v w)
  | one w => exact ⟨popCost v,(n+1,w),by cases v <;> decide,pop v n (enc v w)⟩
theorem entry (v : Variant) : run0 (table v) 14 ⟨0,[],[]⟩ = some (sect v (0,.empty)) := by cases v <;> rfl
theorem never (v : Variant) (m : Machine) (hm : compatible (table v) m) : NeverHalts m :=
  neverOfSection (table v) _ (sect v) (0,.empty) 14 (entry v) (sectionReturn v) m hm
#print axioms never
end BB6.Agent8Raw54.RF.Stack579
